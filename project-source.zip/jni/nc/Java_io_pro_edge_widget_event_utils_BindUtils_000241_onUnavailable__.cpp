#include "Dex2C.h"

/* Lio/pro/edge/widget/event/utils/BindUtils$1;->onUnavailable()V */
extern "C" JNIEXPORT void JNICALL
Java_io_pro_edge_widget_event_utils_BindUtils_000241_onUnavailable__(JNIEnv *env, jobject thiz){
jobject v0 = NULL;
jobject v1 = NULL;
jobject v2 = NULL;
jint v3;
jint v4;
jclass cls0 = NULL,cls1 = NULL,cls2 = NULL,cls3 = NULL;
jfieldID fld0 = NULL;
jmethodID mth0 = NULL, mth1 = NULL, mth2 = NULL;
v0 = (jobject)env->NewLocalRef(thiz);
L0:
LOGD("0:invoke-super \x76\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x6e\x65\x74\x2f\x43\x6f\x6e\x6e\x65\x63\x74\x69\x76\x69\x74\x79\x4d\x61\x6e\x61\x67\x65\x72\x24\x4e\x65\x74\x77\x6f\x72\x6b\x43\x61\x6c\x6c\x62\x61\x63\x6b\x3b\x2d\x3e\x6f\x6e\x55\x6e\x61\x76\x61\x69\x6c\x61\x62\x6c\x65\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jmethodID &mid = mth0;
D2C_RESOLVE_METHOD(clz, mid, "android/net/ConnectivityManager$NetworkCallback", "onUnavailable", "()V");
jvalue args[] = {};
env->CallNonvirtualVoidMethodA(v0, clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("6:iget-object \x76\x30\x2c\x20\x76\x31\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x75\x74\x69\x6c\x73\x2f\x42\x69\x6e\x64\x55\x74\x69\x6c\x73\x24\x31\x3b\x2d\x3e\x62\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x75\x74\x69\x6c\x73\x2f\x42\x69\x6e\x64\x55\x74\x69\x6c\x73\x24\x42\x69\x6e\x64\x4c\x69\x73\x74\x65\x6e\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls1;
jfieldID &fld = fld0;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/utils/BindUtils$1", "b", "Lio/pro/edge/widget/event/utils/BindUtils$BindListener;");
v1 = (jobject) env->GetObjectField(v0,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
v2 = (jobject) v1;
LOGD("a:invoke-interface \x76\x30\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x75\x74\x69\x6c\x73\x2f\x42\x69\x6e\x64\x55\x74\x69\x6c\x73\x24\x42\x69\x6e\x64\x4c\x69\x73\x74\x65\x6e\x65\x72\x3b\x2d\x3e\x62\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
jclass &clz = cls2;
jmethodID &mid = mth1;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/event/utils/BindUtils$BindListener", "b", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
v3 = 1;
LOGD("12:invoke-static \x76\x30\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x75\x74\x69\x6c\x73\x2f\x42\x69\x6e\x64\x55\x74\x69\x6c\x73\x3b\x2d\x3e\x61\x28\x5a\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls3;
jmethodID &mid = mth2;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "io/pro/edge/widget/event/utils/BindUtils", "a", "(Z)Z");
jvalue args[] = {{.z = (jboolean) v3}};
v4 = (jboolean) env->CallStaticBooleanMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
return;
EX_UnwindBlock: return;
}
