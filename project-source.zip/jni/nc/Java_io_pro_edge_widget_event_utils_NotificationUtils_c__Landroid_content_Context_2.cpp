#include "Dex2C.h"

/* Lio/pro/edge/widget/event/utils/NotificationUtils;->c(Landroid/content/Context;)V */
extern "C" JNIEXPORT void JNICALL
Java_io_pro_edge_widget_event_utils_NotificationUtils_c__Landroid_content_Context_2(JNIEnv *env, jobject thiz, jobject p4){
jobject v0 = NULL;
jobject v1 = NULL;
jobject v2 = NULL;
jobject v3 = NULL;
jobject v4 = NULL;
jint v5;
jint v6;
jthrowable exception;
jclass cls0 = NULL,cls1 = NULL,cls2 = NULL,cls3 = NULL,cls4 = NULL;
jmethodID mth0 = NULL, mth1 = NULL, mth2 = NULL, mth3 = NULL, mth4 = NULL;
v0 = (jobject)env->NewLocalRef(p4);
L0:
LOGD("0:invoke-virtual \x76\x34\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6e\x74\x65\x78\x74\x3b\x2d\x3e\x67\x65\x74\x50\x61\x63\x6b\x61\x67\x65\x4d\x61\x6e\x61\x67\x65\x72\x28\x29\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x70\x6d\x2f\x50\x61\x63\x6b\x61\x67\x65\x4d\x61\x6e\x61\x67\x65\x72\x3b");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jmethodID &mid = mth0;
D2C_RESOLVE_METHOD(clz, mid, "android/content/Context", "getPackageManager", "()Landroid/content/pm/PackageManager;");
jvalue args[] = {};
v1 = (jobject) env->CallObjectMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L1:
LOGD("6:move-result-object \x76\x30");
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
v2 = (jobject) v1;
L2:
LOGD("8:new-instance \x76\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6d\x70\x6f\x6e\x65\x6e\x74\x4e\x61\x6d\x65\x3b");
{
#define EX_HANDLE EX_LandingPad_0
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
jclass &clz = cls1;
D2C_RESOLVE_CLASS(clz,"android/content/ComponentName");
v3 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L3:
LOGD("c:invoke-static \x76\x34\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x75\x74\x69\x6c\x73\x2f\x4e\x6f\x74\x69\x66\x69\x63\x61\x74\x69\x6f\x6e\x55\x74\x69\x6c\x73\x3b\x2d\x3e\x62\x28\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6e\x74\x65\x78\x74\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x6c\x61\x73\x73\x3b");
{
#define EX_HANDLE EX_LandingPad_0
jclass &clz = cls2;
jmethodID &mid = mth1;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "io/pro/edge/widget/event/utils/NotificationUtils", "b", "(Landroid/content/Context;)Ljava/lang/Class;");
jvalue args[] = {{.l = v0}};
v1 = (jobject) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L4:
LOGD("12:move-result-object \x76\x32");
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
v4 = (jobject) v1;
L5:
LOGD("14:invoke-direct \x76\x31\x2c\x20\x76\x34\x2c\x20\x76\x32\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6d\x70\x6f\x6e\x65\x6e\x74\x4e\x61\x6d\x65\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6e\x74\x65\x78\x74\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x6c\x61\x73\x73\x3b\x29\x56");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v3);
jclass &clz = cls1;
jmethodID &mid = mth2;
D2C_RESOLVE_METHOD(clz, mid, "android/content/ComponentName", "<init>", "(Landroid/content/Context;Ljava/lang/Class;)V");
jvalue args[] = {{.l = v0},{.l = v4}};
env->CallVoidMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L6:
v5 = 2;
v6 = 1;
v6 = 1;
L7:
LOGD("1e:invoke-virtual \x76\x30\x2c\x20\x76\x31\x2c\x20\x76\x32\x2c\x20\x76\x33\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x70\x6d\x2f\x50\x61\x63\x6b\x61\x67\x65\x4d\x61\x6e\x61\x67\x65\x72\x3b\x2d\x3e\x73\x65\x74\x43\x6f\x6d\x70\x6f\x6e\x65\x6e\x74\x45\x6e\x61\x62\x6c\x65\x64\x53\x65\x74\x74\x69\x6e\x67\x28\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6d\x70\x6f\x6e\x65\x6e\x74\x4e\x61\x6d\x65\x3b\x20\x49\x20\x49\x29\x56");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v2);
jclass &clz = cls3;
jmethodID &mid = mth3;
D2C_RESOLVE_METHOD(clz, mid, "android/content/pm/PackageManager", "setComponentEnabledSetting", "(Landroid/content/ComponentName;II)V");
jvalue args[] = {{.l = v3},{.i = v5},{.i = v6}};
env->CallVoidMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L8:
LOGD("24:new-instance \x76\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6d\x70\x6f\x6e\x65\x6e\x74\x4e\x61\x6d\x65\x3b");
{
#define EX_HANDLE EX_LandingPad_0
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
jclass &clz = cls1;
D2C_RESOLVE_CLASS(clz,"android/content/ComponentName");
v3 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L9:
LOGD("28:invoke-static \x76\x34\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x75\x74\x69\x6c\x73\x2f\x4e\x6f\x74\x69\x66\x69\x63\x61\x74\x69\x6f\x6e\x55\x74\x69\x6c\x73\x3b\x2d\x3e\x62\x28\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6e\x74\x65\x78\x74\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x6c\x61\x73\x73\x3b");
{
#define EX_HANDLE EX_LandingPad_0
jclass &clz = cls2;
jmethodID &mid = mth1;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "io/pro/edge/widget/event/utils/NotificationUtils", "b", "(Landroid/content/Context;)Ljava/lang/Class;");
jvalue args[] = {{.l = v0}};
v1 = (jobject) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L10:
LOGD("2e:move-result-object \x76\x32");
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
v4 = (jobject) v1;
L11:
LOGD("30:invoke-direct \x76\x31\x2c\x20\x76\x34\x2c\x20\x76\x32\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6d\x70\x6f\x6e\x65\x6e\x74\x4e\x61\x6d\x65\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6e\x74\x65\x78\x74\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x6c\x61\x73\x73\x3b\x29\x56");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v3);
jclass &clz = cls1;
jmethodID &mid = mth2;
D2C_RESOLVE_METHOD(clz, mid, "android/content/ComponentName", "<init>", "(Landroid/content/Context;Ljava/lang/Class;)V");
jvalue args[] = {{.l = v0},{.l = v4}};
env->CallVoidMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L12:
LOGD("36:invoke-virtual \x76\x30\x2c\x20\x76\x31\x2c\x20\x76\x33\x2c\x20\x76\x33\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x70\x6d\x2f\x50\x61\x63\x6b\x61\x67\x65\x4d\x61\x6e\x61\x67\x65\x72\x3b\x2d\x3e\x73\x65\x74\x43\x6f\x6d\x70\x6f\x6e\x65\x6e\x74\x45\x6e\x61\x62\x6c\x65\x64\x53\x65\x74\x74\x69\x6e\x67\x28\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6d\x70\x6f\x6e\x65\x6e\x74\x4e\x61\x6d\x65\x3b\x20\x49\x20\x49\x29\x56");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v2);
jclass &clz = cls3;
jmethodID &mid = mth3;
D2C_RESOLVE_METHOD(clz, mid, "android/content/pm/PackageManager", "setComponentEnabledSetting", "(Landroid/content/ComponentName;II)V");
jvalue args[] = {{.l = v3},{.i = v6},{.i = v6}};
env->CallVoidMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L13:
goto L15;
L14:
LOGD("3e:move-exception \x76\x34");
if (v0) {
LOGD("env->DeleteLocalRef(%p):v0", v0);
env->DeleteLocalRef(v0);
}
v0 = exception;
LOGD("40:invoke-virtual \x76\x34\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3b\x2d\x3e\x70\x72\x69\x6e\x74\x53\x74\x61\x63\x6b\x54\x72\x61\x63\x65\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls4;
jmethodID &mid = mth4;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/Exception", "printStackTrace", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L15:
return;

EX_LandingPad_0:
D2C_GET_PENDING_EX
if(d2c_is_instance_of(env, exception, "java/lang/Exception")) {
goto L14;
}
D2C_GOTO_UNWINDBLOCK
EX_UnwindBlock: return;
}
