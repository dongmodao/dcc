#include "Dex2C.h"

/* Lio/pro/edge/ps/PermissionUtils;->a(Landroid/app/Activity;Landroid/content/DialogInterface$OnClickListener;)La/b/a/k; */
extern "C" JNIEXPORT jobject JNICALL
Java_io_pro_edge_ps_PermissionUtils_a__Landroid_app_Activity_2Landroid_content_DialogInterface_00024OnClickListener_2(JNIEnv *env, jobject thiz, jobject p6, jobject p7){
jobject v0 = NULL;
jobject v1 = NULL;
jobject v2 = NULL;
jobject v3 = NULL;
jint v4;
jobject v5 = NULL;
jobject v6 = NULL;
jint v7;
jint v8;
jobject v9 = NULL;
jobject v10 = NULL;
jint v11;
jint v12;
jint v13;
jobject v14 = NULL;
jint v15;
jclass cls0 = NULL,cls1 = NULL,cls2 = NULL,cls3 = NULL,cls4 = NULL,cls5 = NULL,cls6 = NULL,cls7 = NULL,cls8 = NULL,cls9 = NULL,cls10 = NULL,cls11 = NULL;
jfieldID fld0 = NULL,fld1 = NULL,fld2 = NULL,fld3 = NULL,fld4 = NULL,fld5 = NULL,fld6 = NULL;
jmethodID mth0 = NULL, mth1 = NULL, mth2 = NULL, mth3 = NULL, mth4 = NULL, mth5 = NULL, mth6 = NULL, mth7 = NULL, mth8 = NULL, mth9 = NULL, mth10 = NULL, mth11 = NULL;
v0 = (jobject)env->NewLocalRef(p6);
v1 = (jobject)env->NewLocalRef(p7);
L0:
LOGD("0:invoke-static \x76\x36\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x76\x69\x65\x77\x2f\x4c\x61\x79\x6f\x75\x74\x49\x6e\x66\x6c\x61\x74\x65\x72\x3b\x2d\x3e\x66\x72\x6f\x6d\x28\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6e\x74\x65\x78\x74\x3b\x29\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x76\x69\x65\x77\x2f\x4c\x61\x79\x6f\x75\x74\x49\x6e\x66\x6c\x61\x74\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls0;
jmethodID &mid = mth0;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "android/view/LayoutInflater", "from", "(Landroid/content/Context;)Landroid/view/LayoutInflater;");
jvalue args[] = {{.l = v0}};
v2 = (jobject) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("6:move-result-object \x76\x30");
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
v3 = (jobject) v2;
LOGD("8:sget \x76\x31\x2c\x20\x4c\x63\x2f\x61\x2f\x61\x2f\x63\x3b\x2d\x3e\x64\x69\x61\x6c\x6f\x67\x5f\x70\x65\x72\x6d\x69\x73\x73\x69\x6f\x6e\x5f\x6e\x65\x65\x64\x65\x64\x20\x49");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls1;
jfieldID &fld = fld0;
D2C_RESOLVE_STATIC_FIELD(clz, fld, "c/a/a/c", "dialog_permission_needed", "I");
v4 = (jint) env->GetStaticIntField(clz,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v5) {
LOGD("env->DeleteLocalRef(%p):v5", v5);
env->DeleteLocalRef(v5);
}
v5 = 0;
LOGD("e:invoke-virtual \x76\x30\x2c\x20\x76\x31\x2c\x20\x76\x32\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x76\x69\x65\x77\x2f\x4c\x61\x79\x6f\x75\x74\x49\x6e\x66\x6c\x61\x74\x65\x72\x3b\x2d\x3e\x69\x6e\x66\x6c\x61\x74\x65\x28\x49\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x76\x69\x65\x77\x2f\x56\x69\x65\x77\x47\x72\x6f\x75\x70\x3b\x29\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x76\x69\x65\x77\x2f\x56\x69\x65\x77\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls0;
jmethodID &mid = mth1;
D2C_RESOLVE_METHOD(clz, mid, "android/view/LayoutInflater", "inflate", "(ILandroid/view/ViewGroup;)Landroid/view/View;");
jvalue args[] = {{.i = v4},{.l = v5}};
v2 = (jobject) env->CallObjectMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("14:move-result-object \x76\x30");
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
v3 = (jobject) v2;
LOGD("16:sget \x76\x31\x2c\x20\x4c\x63\x2f\x61\x2f\x61\x2f\x62\x3b\x2d\x3e\x69\x76\x5f\x73\x74\x61\x72\x20\x49");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls2;
jfieldID &fld = fld1;
D2C_RESOLVE_STATIC_FIELD(clz, fld, "c/a/a/b", "iv_star", "I");
v4 = (jint) env->GetStaticIntField(clz,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("1a:invoke-virtual \x76\x30\x2c\x20\x76\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x76\x69\x65\x77\x2f\x56\x69\x65\x77\x3b\x2d\x3e\x66\x69\x6e\x64\x56\x69\x65\x77\x42\x79\x49\x64\x28\x49\x29\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x76\x69\x65\x77\x2f\x56\x69\x65\x77\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls3;
jmethodID &mid = mth2;
D2C_RESOLVE_METHOD(clz, mid, "android/view/View", "findViewById", "(I)Landroid/view/View;");
jvalue args[] = {{.i = v4}};
v2 = (jobject) env->CallObjectMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("20:move-result-object \x76\x31");
if (v6) {
LOGD("env->DeleteLocalRef(%p):v6", v6);
env->DeleteLocalRef(v6);
}
v6 = (jobject) v2;
LOGD("22:check-cast \x76\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x49\x6d\x61\x67\x65\x56\x69\x65\x77\x3b");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls4;
D2C_RESOLVE_CLASS(clz,"android/widget/ImageView");
D2C_CHECK_CAST(v6, clz, "android/widget/ImageView");
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("26:sget \x76\x32\x2c\x20\x4c\x63\x2f\x61\x2f\x61\x2f\x62\x3b\x2d\x3e\x69\x76\x5f\x69\x74\x65\x6d\x5f\x62\x67\x20\x49");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls2;
jfieldID &fld = fld2;
D2C_RESOLVE_STATIC_FIELD(clz, fld, "c/a/a/b", "iv_item_bg", "I");
v7 = (jint) env->GetStaticIntField(clz,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("2a:invoke-virtual \x76\x30\x2c\x20\x76\x32\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x76\x69\x65\x77\x2f\x56\x69\x65\x77\x3b\x2d\x3e\x66\x69\x6e\x64\x56\x69\x65\x77\x42\x79\x49\x64\x28\x49\x29\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x76\x69\x65\x77\x2f\x56\x69\x65\x77\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls3;
jmethodID &mid = mth2;
D2C_RESOLVE_METHOD(clz, mid, "android/view/View", "findViewById", "(I)Landroid/view/View;");
jvalue args[] = {{.i = v7}};
v2 = (jobject) env->CallObjectMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("30:move-result-object \x76\x32");
if (v5) {
LOGD("env->DeleteLocalRef(%p):v5", v5);
env->DeleteLocalRef(v5);
}
v5 = (jobject) v2;
LOGD("32:check-cast \x76\x32\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x49\x6d\x61\x67\x65\x56\x69\x65\x77\x3b");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls4;
D2C_RESOLVE_CLASS(clz,"android/widget/ImageView");
D2C_CHECK_CAST(v5, clz, "android/widget/ImageView");
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("36:sget \x76\x33\x2c\x20\x4c\x63\x2f\x61\x2f\x61\x2f\x62\x3b\x2d\x3e\x69\x76\x5f\x66\x61\x63\x65\x20\x49");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls2;
jfieldID &fld = fld3;
D2C_RESOLVE_STATIC_FIELD(clz, fld, "c/a/a/b", "iv_face", "I");
v8 = (jint) env->GetStaticIntField(clz,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("3a:invoke-virtual \x76\x30\x2c\x20\x76\x33\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x76\x69\x65\x77\x2f\x56\x69\x65\x77\x3b\x2d\x3e\x66\x69\x6e\x64\x56\x69\x65\x77\x42\x79\x49\x64\x28\x49\x29\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x76\x69\x65\x77\x2f\x56\x69\x65\x77\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls3;
jmethodID &mid = mth2;
D2C_RESOLVE_METHOD(clz, mid, "android/view/View", "findViewById", "(I)Landroid/view/View;");
jvalue args[] = {{.i = v8}};
v2 = (jobject) env->CallObjectMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("40:move-result-object \x76\x33");
if (v9) {
LOGD("env->DeleteLocalRef(%p):v9", v9);
env->DeleteLocalRef(v9);
}
v9 = (jobject) v2;
LOGD("42:check-cast \x76\x33\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x49\x6d\x61\x67\x65\x56\x69\x65\x77\x3b");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls4;
D2C_RESOLVE_CLASS(clz,"android/widget/ImageView");
D2C_CHECK_CAST(v9, clz, "android/widget/ImageView");
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("46:invoke-virtual \x76\x36\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x61\x70\x70\x2f\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x2d\x3e\x67\x65\x74\x52\x65\x73\x6f\x75\x72\x63\x65\x73\x28\x29\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x72\x65\x73\x2f\x52\x65\x73\x6f\x75\x72\x63\x65\x73\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls5;
jmethodID &mid = mth3;
D2C_RESOLVE_METHOD(clz, mid, "android/app/Activity", "getResources", "()Landroid/content/res/Resources;");
jvalue args[] = {};
v2 = (jobject) env->CallObjectMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("4c:move-result-object \x76\x34");
if (v10) {
LOGD("env->DeleteLocalRef(%p):v10", v10);
env->DeleteLocalRef(v10);
}
v10 = (jobject) v2;
LOGD("4e:sget \x76\x35\x2c\x20\x4c\x63\x2f\x61\x2f\x61\x2f\x61\x3b\x2d\x3e\x66\x6c\x6f\x61\x74\x5f\x64\x69\x61\x6c\x6f\x67\x5f\x63\x6f\x6d\x6d\x6f\x6e\x5f\x63\x6f\x6c\x6f\x72\x20\x49");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls6;
jfieldID &fld = fld4;
D2C_RESOLVE_STATIC_FIELD(clz, fld, "c/a/a/a", "float_dialog_common_color", "I");
v11 = (jint) env->GetStaticIntField(clz,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("52:invoke-virtual \x76\x34\x2c\x20\x76\x35\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x72\x65\x73\x2f\x52\x65\x73\x6f\x75\x72\x63\x65\x73\x3b\x2d\x3e\x67\x65\x74\x43\x6f\x6c\x6f\x72\x28\x49\x29\x49");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v10);
jclass &clz = cls7;
jmethodID &mid = mth4;
D2C_RESOLVE_METHOD(clz, mid, "android/content/res/Resources", "getColor", "(I)I");
jvalue args[] = {{.i = v11}};
v12 = (jint) env->CallIntMethodA(v10, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("58:move-result \x76\x34");
v13 = (jint) v12;
LOGD("5a:sget-object \x76\x35\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x67\x72\x61\x70\x68\x69\x63\x73\x2f\x50\x6f\x72\x74\x65\x72\x44\x75\x66\x66\x24\x4d\x6f\x64\x65\x3b\x2d\x3e\x53\x52\x43\x5f\x41\x54\x4f\x50\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x67\x72\x61\x70\x68\x69\x63\x73\x2f\x50\x6f\x72\x74\x65\x72\x44\x75\x66\x66\x24\x4d\x6f\x64\x65\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v14) {
LOGD("env->DeleteLocalRef(%p):v14", v14);
env->DeleteLocalRef(v14);
}
jclass &clz = cls8;
jfieldID &fld = fld5;
D2C_RESOLVE_STATIC_FIELD(clz, fld, "android/graphics/PorterDuff$Mode", "SRC_ATOP", "Landroid/graphics/PorterDuff$Mode;");
v14 = (jobject) env->GetStaticObjectField(clz,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("5e:invoke-virtual \x76\x31\x2c\x20\x76\x34\x2c\x20\x76\x35\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x49\x6d\x61\x67\x65\x56\x69\x65\x77\x3b\x2d\x3e\x73\x65\x74\x43\x6f\x6c\x6f\x72\x46\x69\x6c\x74\x65\x72\x28\x49\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x67\x72\x61\x70\x68\x69\x63\x73\x2f\x50\x6f\x72\x74\x65\x72\x44\x75\x66\x66\x24\x4d\x6f\x64\x65\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v6);
jclass &clz = cls4;
jmethodID &mid = mth5;
D2C_RESOLVE_METHOD(clz, mid, "android/widget/ImageView", "setColorFilter", "(ILandroid/graphics/PorterDuff$Mode;)V");
jvalue args[] = {{.i = v13},{.l = v14}};
env->CallVoidMethodA(v6, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("64:sget-object \x76\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x67\x72\x61\x70\x68\x69\x63\x73\x2f\x50\x6f\x72\x74\x65\x72\x44\x75\x66\x66\x24\x4d\x6f\x64\x65\x3b\x2d\x3e\x53\x52\x43\x5f\x41\x54\x4f\x50\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x67\x72\x61\x70\x68\x69\x63\x73\x2f\x50\x6f\x72\x74\x65\x72\x44\x75\x66\x66\x24\x4d\x6f\x64\x65\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v6) {
LOGD("env->DeleteLocalRef(%p):v6", v6);
env->DeleteLocalRef(v6);
}
jclass &clz = cls8;
jfieldID &fld = fld5;
D2C_RESOLVE_STATIC_FIELD(clz, fld, "android/graphics/PorterDuff$Mode", "SRC_ATOP", "Landroid/graphics/PorterDuff$Mode;");
v6 = (jobject) env->GetStaticObjectField(clz,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("68:invoke-virtual \x76\x32\x2c\x20\x76\x34\x2c\x20\x76\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x49\x6d\x61\x67\x65\x56\x69\x65\x77\x3b\x2d\x3e\x73\x65\x74\x43\x6f\x6c\x6f\x72\x46\x69\x6c\x74\x65\x72\x28\x49\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x67\x72\x61\x70\x68\x69\x63\x73\x2f\x50\x6f\x72\x74\x65\x72\x44\x75\x66\x66\x24\x4d\x6f\x64\x65\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v5);
jclass &clz = cls4;
jmethodID &mid = mth5;
D2C_RESOLVE_METHOD(clz, mid, "android/widget/ImageView", "setColorFilter", "(ILandroid/graphics/PorterDuff$Mode;)V");
jvalue args[] = {{.i = v13},{.l = v6}};
env->CallVoidMethodA(v5, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("6e:sget-object \x76\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x67\x72\x61\x70\x68\x69\x63\x73\x2f\x50\x6f\x72\x74\x65\x72\x44\x75\x66\x66\x24\x4d\x6f\x64\x65\x3b\x2d\x3e\x53\x52\x43\x5f\x41\x54\x4f\x50\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x67\x72\x61\x70\x68\x69\x63\x73\x2f\x50\x6f\x72\x74\x65\x72\x44\x75\x66\x66\x24\x4d\x6f\x64\x65\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v6) {
LOGD("env->DeleteLocalRef(%p):v6", v6);
env->DeleteLocalRef(v6);
}
jclass &clz = cls8;
jfieldID &fld = fld5;
D2C_RESOLVE_STATIC_FIELD(clz, fld, "android/graphics/PorterDuff$Mode", "SRC_ATOP", "Landroid/graphics/PorterDuff$Mode;");
v6 = (jobject) env->GetStaticObjectField(clz,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("72:invoke-virtual \x76\x33\x2c\x20\x76\x34\x2c\x20\x76\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x49\x6d\x61\x67\x65\x56\x69\x65\x77\x3b\x2d\x3e\x73\x65\x74\x43\x6f\x6c\x6f\x72\x46\x69\x6c\x74\x65\x72\x28\x49\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x67\x72\x61\x70\x68\x69\x63\x73\x2f\x50\x6f\x72\x74\x65\x72\x44\x75\x66\x66\x24\x4d\x6f\x64\x65\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v9);
jclass &clz = cls4;
jmethodID &mid = mth5;
D2C_RESOLVE_METHOD(clz, mid, "android/widget/ImageView", "setColorFilter", "(ILandroid/graphics/PorterDuff$Mode;)V");
jvalue args[] = {{.i = v13},{.l = v6}};
env->CallVoidMethodA(v9, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("78:new-instance \x76\x31\x2c\x20\x4c\x61\x2f\x62\x2f\x61\x2f\x6b\x24\x61\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v6) {
LOGD("env->DeleteLocalRef(%p):v6", v6);
env->DeleteLocalRef(v6);
}
jclass &clz = cls9;
D2C_RESOLVE_CLASS(clz,"a/b/a/k$a");
v6 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("7c:sget \x76\x32\x2c\x20\x4c\x63\x2f\x61\x2f\x61\x2f\x65\x3b\x2d\x3e\x44\x69\x61\x6c\x6f\x67\x20\x49");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls10;
jfieldID &fld = fld6;
D2C_RESOLVE_STATIC_FIELD(clz, fld, "c/a/a/e", "Dialog", "I");
v7 = (jint) env->GetStaticIntField(clz,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("80:invoke-direct \x76\x31\x2c\x20\x76\x36\x2c\x20\x76\x32\x2c\x20\x4c\x61\x2f\x62\x2f\x61\x2f\x6b\x24\x61\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6e\x74\x65\x78\x74\x3b\x20\x49\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v6);
jclass &clz = cls9;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "a/b/a/k$a", "<init>", "(Landroid/content/Context;I)V");
jvalue args[] = {{.l = v0},{.i = v7}};
env->CallVoidMethodA(v6, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("86:invoke-virtual \x76\x31\x2c\x20\x76\x30\x2c\x20\x4c\x61\x2f\x62\x2f\x61\x2f\x6b\x24\x61\x3b\x2d\x3e\x62\x28\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x76\x69\x65\x77\x2f\x56\x69\x65\x77\x3b\x29\x4c\x61\x2f\x62\x2f\x61\x2f\x6b\x24\x61\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v6);
jclass &clz = cls9;
jmethodID &mid = mth7;
D2C_RESOLVE_METHOD(clz, mid, "a/b/a/k$a", "b", "(Landroid/view/View;)La/b/a/k$a;");
jvalue args[] = {{.l = v3}};
v2 = (jobject) env->CallObjectMethodA(v6, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
v15 = 17039370;
LOGD("92:invoke-virtual \x76\x31\x2c\x20\x76\x36\x2c\x20\x76\x37\x2c\x20\x4c\x61\x2f\x62\x2f\x61\x2f\x6b\x24\x61\x3b\x2d\x3e\x61\x28\x49\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x44\x69\x61\x6c\x6f\x67\x49\x6e\x74\x65\x72\x66\x61\x63\x65\x24\x4f\x6e\x43\x6c\x69\x63\x6b\x4c\x69\x73\x74\x65\x6e\x65\x72\x3b\x29\x4c\x61\x2f\x62\x2f\x61\x2f\x6b\x24\x61\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v6);
jclass &clz = cls9;
jmethodID &mid = mth8;
D2C_RESOLVE_METHOD(clz, mid, "a/b/a/k$a", "a", "(ILandroid/content/DialogInterface$OnClickListener;)La/b/a/k$a;");
jvalue args[] = {{.i = v15},{.l = v1}};
v2 = (jobject) env->CallObjectMethodA(v6, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
v15 = 0;
v15 = 0;
LOGD("9a:invoke-virtual \x76\x31\x2c\x20\x76\x36\x2c\x20\x4c\x61\x2f\x62\x2f\x61\x2f\x6b\x24\x61\x3b\x2d\x3e\x61\x28\x5a\x29\x4c\x61\x2f\x62\x2f\x61\x2f\x6b\x24\x61\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v6);
jclass &clz = cls9;
jmethodID &mid = mth9;
D2C_RESOLVE_METHOD(clz, mid, "a/b/a/k$a", "a", "(Z)La/b/a/k$a;");
jvalue args[] = {{.z = (jboolean) v15}};
v2 = (jobject) env->CallObjectMethodA(v6, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
LOGD("a0:invoke-virtual \x76\x31\x2c\x20\x4c\x61\x2f\x62\x2f\x61\x2f\x6b\x24\x61\x3b\x2d\x3e\x61\x28\x29\x4c\x61\x2f\x62\x2f\x61\x2f\x6b\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v6);
jclass &clz = cls9;
jmethodID &mid = mth10;
D2C_RESOLVE_METHOD(clz, mid, "a/b/a/k$a", "a", "()La/b/a/k;");
jvalue args[] = {};
v2 = (jobject) env->CallObjectMethodA(v6, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("a6:move-result-object \x76\x37");
if (v1) {
LOGD("env->DeleteLocalRef(%p):v1", v1);
env->DeleteLocalRef(v1);
}
v1 = (jobject) v2;
LOGD("a8:invoke-virtual \x76\x37\x2c\x20\x76\x36\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x61\x70\x70\x2f\x44\x69\x61\x6c\x6f\x67\x3b\x2d\x3e\x73\x65\x74\x43\x61\x6e\x63\x65\x6c\x65\x64\x4f\x6e\x54\x6f\x75\x63\x68\x4f\x75\x74\x73\x69\x64\x65\x28\x5a\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v1);
jclass &clz = cls11;
jmethodID &mid = mth11;
D2C_RESOLVE_METHOD(clz, mid, "android/app/Dialog", "setCanceledOnTouchOutside", "(Z)V");
jvalue args[] = {{.z = (jboolean) v15}};
env->CallVoidMethodA(v1, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
return (jobject) v1;
EX_UnwindBlock: return NULL;
}
