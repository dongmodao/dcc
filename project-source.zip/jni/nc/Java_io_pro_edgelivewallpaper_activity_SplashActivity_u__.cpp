#include "Dex2C.h"

/* Lio/pro/edgelivewallpaper/activity/SplashActivity;->u()V */
extern "C" JNIEXPORT void JNICALL
Java_io_pro_edgelivewallpaper_activity_SplashActivity_u__(JNIEnv *env, jobject thiz){
jobject v0 = NULL;
jobject v1 = NULL;
jobject v2 = NULL;
jint v3;
jobject v4 = NULL;
jobject v5 = NULL;
jlong v6;
jclass cls0 = NULL,cls1 = NULL,cls2 = NULL,cls3 = NULL;
jfieldID fld0 = NULL;
jmethodID mth0 = NULL, mth1 = NULL, mth2 = NULL, mth3 = NULL, mth4 = NULL;
v0 = (jobject)env->NewLocalRef(thiz);
L0:
LOGD("0:iget-object \x76\x30\x2c\x20\x76\x33\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x6c\x69\x76\x65\x77\x61\x6c\x6c\x70\x61\x70\x65\x72\x2f\x61\x63\x74\x69\x76\x69\x74\x79\x2f\x53\x70\x6c\x61\x73\x68\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x2d\x3e\x64\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x49\x6d\x61\x67\x65\x56\x69\x65\x77\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jfieldID &fld = fld0;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edgelivewallpaper/activity/SplashActivity", "d", "Landroid/widget/ImageView;");
v1 = (jobject) env->GetObjectField(v0,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
v2 = (jobject) v1;
v3 = 2;
LOGD("6:new-array \x76\x31\x2c\x20\x76\x31\x2c\x20\x5b\x46");
{
#define EX_HANDLE EX_UnwindBlock
if (v3 < 0) {
d2c_throw_exception(env, "java/lang/NegativeArraySizeException", "negative array size");
goto EX_HANDLE;
}
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
v4 = (jarray) env->NewFloatArray((jint) v3);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("a:fill-array-data \x76\x31\x2c\x20\x2b\x31\x62\x20\x28\x30\x78\x33\x35\x29");
{
static const unsigned char data[] = {0, 0, 0, 0, 0, 0, 128, 63};
env->SetFloatArrayRegion((jfloatArray) v4, 0, 2, (const jfloat *) data);
}
LOGD("10:const-string \x76\x32\x2c\x20\x27\x61\x6c\x70\x68\x61\x27");
if (v5) {
LOGD("env->DeleteLocalRef(%p):v5", v5);
env->DeleteLocalRef(v5);
}
v5 = (jstring) env->NewStringUTF("\x61\x6c\x70\x68\x61");
LOGD("14:invoke-static \x76\x30\x2c\x20\x76\x32\x2c\x20\x76\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x61\x6e\x69\x6d\x61\x74\x69\x6f\x6e\x2f\x4f\x62\x6a\x65\x63\x74\x41\x6e\x69\x6d\x61\x74\x6f\x72\x3b\x2d\x3e\x6f\x66\x46\x6c\x6f\x61\x74\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x20\x5b\x46\x29\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x61\x6e\x69\x6d\x61\x74\x69\x6f\x6e\x2f\x4f\x62\x6a\x65\x63\x74\x41\x6e\x69\x6d\x61\x74\x6f\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls2;
jmethodID &mid = mth0;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "android/animation/ObjectAnimator", "ofFloat", "(Ljava/lang/Object;Ljava/lang/String;[F)Landroid/animation/ObjectAnimator;");
jvalue args[] = {{.l = v2},{.l = v5},{.l = v4}};
v1 = (jobject) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("1a:move-result-object \x76\x30");
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
v2 = (jobject) v1;
v6 = 3000;
LOGD("20:invoke-virtual \x76\x30\x2c\x20\x76\x31\x2c\x20\x76\x32\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x61\x6e\x69\x6d\x61\x74\x69\x6f\x6e\x2f\x4f\x62\x6a\x65\x63\x74\x41\x6e\x69\x6d\x61\x74\x6f\x72\x3b\x2d\x3e\x73\x65\x74\x44\x75\x72\x61\x74\x69\x6f\x6e\x28\x4a\x29\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x61\x6e\x69\x6d\x61\x74\x69\x6f\x6e\x2f\x4f\x62\x6a\x65\x63\x74\x41\x6e\x69\x6d\x61\x74\x6f\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
jclass &clz = cls2;
jmethodID &mid = mth1;
D2C_RESOLVE_METHOD(clz, mid, "android/animation/ObjectAnimator", "setDuration", "(J)Landroid/animation/ObjectAnimator;");
jvalue args[] = {{.j = (jlong) v6}};
v1 = (jobject) env->CallObjectMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v1) {
LOGD("env->DeleteLocalRef(%p):v1", v1);
env->DeleteLocalRef(v1);
}
LOGD("26:new-instance \x76\x31\x2c\x20\x4c\x64\x2f\x62\x2f\x62\x2f\x61\x2f\x68\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
jclass &clz = cls3;
D2C_RESOLVE_CLASS(clz,"d/b/b/a/h");
v4 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("2a:invoke-direct \x76\x31\x2c\x20\x76\x33\x2c\x20\x4c\x64\x2f\x62\x2f\x62\x2f\x61\x2f\x68\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x6c\x69\x76\x65\x77\x61\x6c\x6c\x70\x61\x70\x65\x72\x2f\x61\x63\x74\x69\x76\x69\x74\x79\x2f\x53\x70\x6c\x61\x73\x68\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v4);
jclass &clz = cls3;
jmethodID &mid = mth2;
D2C_RESOLVE_METHOD(clz, mid, "d/b/b/a/h", "<init>", "(Lio/pro/edgelivewallpaper/activity/SplashActivity;)V");
jvalue args[] = {{.l = v0}};
env->CallVoidMethodA(v4, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("30:invoke-virtual \x76\x30\x2c\x20\x76\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x61\x6e\x69\x6d\x61\x74\x69\x6f\x6e\x2f\x4f\x62\x6a\x65\x63\x74\x41\x6e\x69\x6d\x61\x74\x6f\x72\x3b\x2d\x3e\x61\x64\x64\x4c\x69\x73\x74\x65\x6e\x65\x72\x28\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x61\x6e\x69\x6d\x61\x74\x69\x6f\x6e\x2f\x41\x6e\x69\x6d\x61\x74\x6f\x72\x24\x41\x6e\x69\x6d\x61\x74\x6f\x72\x4c\x69\x73\x74\x65\x6e\x65\x72\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
jclass &clz = cls2;
jmethodID &mid = mth3;
D2C_RESOLVE_METHOD(clz, mid, "android/animation/ObjectAnimator", "addListener", "(Landroid/animation/Animator$AnimatorListener;)V");
jvalue args[] = {{.l = v4}};
env->CallVoidMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("36:invoke-virtual \x76\x30\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x61\x6e\x69\x6d\x61\x74\x69\x6f\x6e\x2f\x4f\x62\x6a\x65\x63\x74\x41\x6e\x69\x6d\x61\x74\x6f\x72\x3b\x2d\x3e\x73\x74\x61\x72\x74\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
jclass &clz = cls2;
jmethodID &mid = mth4;
D2C_RESOLVE_METHOD(clz, mid, "android/animation/ObjectAnimator", "start", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
return;
EX_UnwindBlock: return;
}
