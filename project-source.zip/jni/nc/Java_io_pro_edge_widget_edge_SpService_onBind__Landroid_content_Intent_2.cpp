#include "Dex2C.h"

/* Lio/pro/edge/widget/edge/SpService;->onBind(Landroid/content/Intent;)Landroid/os/IBinder; */
extern "C" JNIEXPORT jobject JNICALL
Java_io_pro_edge_widget_edge_SpService_onBind__Landroid_content_Intent_2(JNIEnv *env, jobject thiz, jobject p1){
jobject v0 = NULL;
jobject v1 = NULL;
v0 = (jobject)env->NewLocalRef(thiz);
v1 = (jobject)env->NewLocalRef(p1);
L0:
if (v1) {
LOGD("env->DeleteLocalRef(%p):v1", v1);
env->DeleteLocalRef(v1);
}
v1 = 0;
return (jobject) v1;
EX_UnwindBlock: return NULL;
}
