#include "Dex2C.h"

/* Lio/pro/edge/widget/event/utils/InUtils;->d(Landroid/content/Context;)Ljava/lang/String; */
extern "C" JNIEXPORT jstring JNICALL
Java_io_pro_edge_widget_event_utils_InUtils_d__Landroid_content_Context_2(JNIEnv *env, jobject thiz, jobject p2){
jobject v0 = NULL;
jobject v1 = NULL;
jobject v2 = NULL;
jobject v3 = NULL;
jint v4;
jint v5;
jint v6;
jthrowable exception;
jclass cls0 = NULL,cls1 = NULL,cls2 = NULL,cls3 = NULL;
jmethodID mth0 = NULL, mth1 = NULL, mth2 = NULL, mth3 = NULL, mth4 = NULL;
v0 = (jobject)env->NewLocalRef(p2);
L0:
LOGD("0:const-string \x76\x30\x2c\x20\x27\x2d\x31\x27");
if (v1) {
LOGD("env->DeleteLocalRef(%p):v1", v1);
env->DeleteLocalRef(v1);
}
v1 = (jstring) env->NewStringUTF("\x2d\x31");
L1:
LOGD("4:invoke-virtual \x76\x32\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6e\x74\x65\x78\x74\x3b\x2d\x3e\x67\x65\x74\x41\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x43\x6f\x6e\x74\x65\x78\x74\x28\x29\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6e\x74\x65\x78\x74\x3b");
{
#define EX_HANDLE EX_LandingPad_1
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jmethodID &mid = mth0;
D2C_RESOLVE_METHOD(clz, mid, "android/content/Context", "getApplicationContext", "()Landroid/content/Context;");
jvalue args[] = {};
v2 = (jobject) env->CallObjectMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L2:
LOGD("a:move-result-object \x76\x32");
if (v0) {
LOGD("env->DeleteLocalRef(%p):v0", v0);
env->DeleteLocalRef(v0);
}
v0 = (jobject) v2;
L3:
LOGD("c:const-string \x76\x31\x2c\x20\x27\x63\x6f\x6e\x6e\x65\x63\x74\x69\x76\x69\x74\x79\x27");
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
v3 = (jstring) env->NewStringUTF("\x63\x6f\x6e\x6e\x65\x63\x74\x69\x76\x69\x74\x79");
L4:
LOGD("10:invoke-virtual \x76\x32\x2c\x20\x76\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6e\x74\x65\x78\x74\x3b\x2d\x3e\x67\x65\x74\x53\x79\x73\x74\x65\x6d\x53\x65\x72\x76\x69\x63\x65\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b");
{
#define EX_HANDLE EX_LandingPad_1
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jmethodID &mid = mth1;
D2C_RESOLVE_METHOD(clz, mid, "android/content/Context", "getSystemService", "(Ljava/lang/String;)Ljava/lang/Object;");
jvalue args[] = {{.l = v3}};
v2 = (jobject) env->CallObjectMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L5:
LOGD("16:move-result-object \x76\x32");
if (v0) {
LOGD("env->DeleteLocalRef(%p):v0", v0);
env->DeleteLocalRef(v0);
}
v0 = (jobject) v2;
L6:
LOGD("18:check-cast \x76\x32\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x6e\x65\x74\x2f\x43\x6f\x6e\x6e\x65\x63\x74\x69\x76\x69\x74\x79\x4d\x61\x6e\x61\x67\x65\x72\x3b");
{
#define EX_HANDLE EX_LandingPad_1
jclass &clz = cls1;
D2C_RESOLVE_CLASS(clz,"android/net/ConnectivityManager");
D2C_CHECK_CAST(v0, clz, "android/net/ConnectivityManager");
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L7:
LOGD("1c:if-nez \x76\x32\x2c\x20\x2b\x33");
if(v0 != NULL){
goto L9;
}
else {
goto L8;
}
L8:
return (jstring) v1;
L9:
LOGD("22:invoke-virtual \x76\x32\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x6e\x65\x74\x2f\x43\x6f\x6e\x6e\x65\x63\x74\x69\x76\x69\x74\x79\x4d\x61\x6e\x61\x67\x65\x72\x3b\x2d\x3e\x67\x65\x74\x41\x63\x74\x69\x76\x65\x4e\x65\x74\x77\x6f\x72\x6b\x49\x6e\x66\x6f\x28\x29\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x6e\x65\x74\x2f\x4e\x65\x74\x77\x6f\x72\x6b\x49\x6e\x66\x6f\x3b");
{
#define EX_HANDLE EX_LandingPad_1
D2C_NOT_NULL(v0);
jclass &clz = cls1;
jmethodID &mid = mth2;
D2C_RESOLVE_METHOD(clz, mid, "android/net/ConnectivityManager", "getActiveNetworkInfo", "()Landroid/net/NetworkInfo;");
jvalue args[] = {};
v2 = (jobject) env->CallObjectMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L10:
LOGD("28:move-result-object \x76\x32");
if (v0) {
LOGD("env->DeleteLocalRef(%p):v0", v0);
env->DeleteLocalRef(v0);
}
v0 = (jobject) v2;
LOGD("2a:if-eqz \x76\x32\x2c\x20\x2b\x31\x35");
if(v0 == NULL){
goto L19;
}
else {
goto L11;
}
L11:
LOGD("2e:invoke-virtual \x76\x32\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x6e\x65\x74\x2f\x4e\x65\x74\x77\x6f\x72\x6b\x49\x6e\x66\x6f\x3b\x2d\x3e\x67\x65\x74\x54\x79\x70\x65\x28\x29\x49");
{
#define EX_HANDLE EX_LandingPad_1
D2C_NOT_NULL(v0);
jclass &clz = cls2;
jmethodID &mid = mth3;
D2C_RESOLVE_METHOD(clz, mid, "android/net/NetworkInfo", "getType", "()I");
jvalue args[] = {};
v4 = (jint) env->CallIntMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L12:
LOGD("34:move-result \x76\x32");
v5 = (jint) v4;
LOGD("36:if-nez \x76\x32\x2c\x20\x2b\x35");
if(v5 != 0){
goto L15;
}
else {
goto L13;
}
L13:
LOGD("3a:const-string \x76\x32\x2c\x20\x27\x31\x27");
if (v0) {
LOGD("env->DeleteLocalRef(%p):v0", v0);
env->DeleteLocalRef(v0);
}
v0 = (jstring) env->NewStringUTF("\x31");
L14:
return (jstring) v0;
L15:
v6 = 1;
LOGD("42:if-ne \x76\x32\x2c\x20\x76\x31\x2c\x20\x2b\x39");
if(v5 != v6) {
goto L19;
}
else {
goto L16;
}
L16:
LOGD("46:const-string \x76\x32\x2c\x20\x27\x32\x27");
if (v0) {
LOGD("env->DeleteLocalRef(%p):v0", v0);
env->DeleteLocalRef(v0);
}
v0 = (jstring) env->NewStringUTF("\x32");
L17:
return (jstring) v0;
L18:
LOGD("4c:move-exception \x76\x32");
if (v0) {
LOGD("env->DeleteLocalRef(%p):v0", v0);
env->DeleteLocalRef(v0);
}
v0 = exception;
LOGD("4e:invoke-virtual \x76\x32\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x54\x68\x72\x6f\x77\x61\x62\x6c\x65\x3b\x2d\x3e\x70\x72\x69\x6e\x74\x53\x74\x61\x63\x6b\x54\x72\x61\x63\x65\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls3;
jmethodID &mid = mth4;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/Throwable", "printStackTrace", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L19:
return (jstring) v1;

EX_LandingPad_1:
D2C_GET_PENDING_EX
if(d2c_is_instance_of(env, exception, "java/lang/Throwable")) {
goto L18;
}
D2C_GOTO_UNWINDBLOCK
EX_UnwindBlock: return NULL;
}
