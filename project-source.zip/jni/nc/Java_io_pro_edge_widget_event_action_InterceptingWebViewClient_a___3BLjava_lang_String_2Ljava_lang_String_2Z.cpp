#include "Dex2C.h"

/* Lio/pro/edge/widget/event/action/InterceptingWebViewClient;->a([BLjava/lang/String;Ljava/lang/String;Z)Ljava/io/InputStream; */
extern "C" JNIEXPORT jobject JNICALL
Java_io_pro_edge_widget_event_action_InterceptingWebViewClient_a___3BLjava_lang_String_2Ljava_lang_String_2Z(JNIEnv *env, jobject thiz, jarray p2, jstring p3, jstring p4, jboolean p5){
jobject v0 = NULL;
jobject v1 = NULL;
jobject v2 = NULL;
jobject v3 = NULL;
jint v4;
jobject v5 = NULL;
jint v6;
jint v7;
jobject v8 = NULL;
jclass cls0 = NULL,cls1 = NULL,cls2 = NULL,cls3 = NULL,cls4 = NULL,cls5 = NULL;
jfieldID fld0 = NULL,fld1 = NULL,fld2 = NULL;
jmethodID mth0 = NULL, mth1 = NULL, mth2 = NULL, mth3 = NULL, mth4 = NULL, mth5 = NULL;
v0 = (jobject)env->NewLocalRef(thiz);
v1 = (jobject)env->NewLocalRef(p2);
v2 = (jobject)env->NewLocalRef(p3);
v3 = (jobject)env->NewLocalRef(p4);
v4 = (jint)p5;
L0:
LOGD("0:const-string \x76\x30\x2c\x20\x27\x74\x65\x78\x74\x2f\x68\x74\x6d\x6c\x27");
if (v5) {
LOGD("env->DeleteLocalRef(%p):v5", v5);
env->DeleteLocalRef(v5);
}
v5 = (jstring) env->NewStringUTF("\x74\x65\x78\x74\x2f\x68\x74\x6d\x6c");
LOGD("4:invoke-virtual \x76\x33\x2c\x20\x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x65\x71\x75\x61\x6c\x73\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
jclass &clz = cls0;
jmethodID &mid = mth0;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "equals", "(Ljava/lang/Object;)Z");
jvalue args[] = {{.l = v5}};
v6 = (jboolean) env->CallBooleanMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("a:move-result \x76\x33");
v7 = (jint) v6;
LOGD("c:if-eqz \x76\x33\x2c\x20\x2b\x32\x33");
if(v7 == 0){
goto L5;
}
else {
goto L1;
}
L1:
LOGD("10:iget-object \x76\x33\x2c\x20\x76\x31\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x44\x6f\x77\x6e\x6c\x6f\x61\x64\x43\x6c\x69\x65\x6e\x74\x3b\x2d\x3e\x65\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x57\x6f\x72\x6b\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls1;
jfieldID &fld = fld0;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/action/DownloadClient", "e", "Lio/pro/edge/widget/event/action/Worker;");
v8 = (jobject) env->GetObjectField(v0,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
v2 = (jobject) v8;
LOGD("14:if-eqz \x76\x33\x2c\x20\x2b\x31\x66");
if(v2 == NULL){
goto L5;
}
else {
goto L2;
}
L2:
LOGD("18:iget-object \x76\x33\x2c\x20\x76\x33\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x57\x6f\x72\x6b\x65\x72\x3b\x2d\x3e\x62\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x4d\x79\x57\x6f\x72\x6b\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
jclass &clz = cls2;
jfieldID &fld = fld1;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/action/Worker", "b", "Lio/pro/edge/widget/event/MyWorker;");
v8 = (jobject) env->GetObjectField(v2,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
v2 = (jobject) v8;
LOGD("1c:if-eqz \x76\x33\x2c\x20\x2b\x31\x62");
if(v2 == NULL){
goto L5;
}
else {
goto L3;
}
L3:
LOGD("20:if-nez \x76\x35\x2c\x20\x2b\x31\x39");
if(v4 != 0){
goto L5;
}
else {
goto L4;
}
L4:
LOGD("24:new-instance \x76\x33\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
jclass &clz = cls0;
D2C_RESOLVE_CLASS(clz,"java/lang/String");
v2 = (jstring) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("28:invoke-direct \x76\x33\x2c\x20\x76\x32\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x5b\x42\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
jclass &clz = cls0;
jmethodID &mid = mth1;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "<init>", "([B)V");
jvalue args[] = {{.l = v1}};
env->CallVoidMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("2e:invoke-virtual \x76\x33\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x67\x65\x74\x42\x79\x74\x65\x73\x28\x29\x5b\x42");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
jclass &clz = cls0;
jmethodID &mid = mth2;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "getBytes", "()[B");
jvalue args[] = {};
v8 = (jarray) env->CallObjectMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("34:move-result-object \x76\x32");
if (v1) {
LOGD("env->DeleteLocalRef(%p):v1", v1);
env->DeleteLocalRef(v1);
}
v1 = (jobject) v8;
LOGD("36:iget-object \x76\x33\x2c\x20\x76\x31\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x44\x6f\x77\x6e\x6c\x6f\x61\x64\x43\x6c\x69\x65\x6e\x74\x3b\x2d\x3e\x65\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x57\x6f\x72\x6b\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls1;
jfieldID &fld = fld0;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/action/DownloadClient", "e", "Lio/pro/edge/widget/event/action/Worker;");
v8 = (jobject) env->GetObjectField(v0,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
v2 = (jobject) v8;
LOGD("3a:iget-object \x76\x33\x2c\x20\x76\x33\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x57\x6f\x72\x6b\x65\x72\x3b\x2d\x3e\x62\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x4d\x79\x57\x6f\x72\x6b\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
jclass &clz = cls2;
jfieldID &fld = fld1;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/action/Worker", "b", "Lio/pro/edge/widget/event/MyWorker;");
v8 = (jobject) env->GetObjectField(v2,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
v2 = (jobject) v8;
LOGD("3e:iget-object \x76\x33\x2c\x20\x76\x33\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x4d\x79\x57\x6f\x72\x6b\x65\x72\x3b\x2d\x3e\x74\x20\x4c\x6f\x72\x67\x2f\x6a\x73\x6f\x6e\x2f\x4a\x53\x4f\x4e\x4f\x62\x6a\x65\x63\x74\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
jclass &clz = cls3;
jfieldID &fld = fld2;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/MyWorker", "t", "Lorg/json/JSONObject;");
v8 = (jobject) env->GetObjectField(v2,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
v2 = (jobject) v8;
LOGD("42:invoke-static \x76\x32\x2c\x20\x76\x33\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x55\x74\x69\x6c\x73\x3b\x2d\x3e\x61\x28\x5b\x42\x20\x4c\x6f\x72\x67\x2f\x6a\x73\x6f\x6e\x2f\x4a\x53\x4f\x4e\x4f\x62\x6a\x65\x63\x74\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls4;
jmethodID &mid = mth3;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "io/pro/edge/widget/event/net/ResponseUtils", "a", "([BLorg/json/JSONObject;)Ljava/lang/String;");
jvalue args[] = {{.l = v1},{.l = v2}};
v8 = (jstring) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("48:move-result-object \x76\x32");
if (v1) {
LOGD("env->DeleteLocalRef(%p):v1", v1);
env->DeleteLocalRef(v1);
}
v1 = (jobject) v8;
LOGD("4a:invoke-virtual \x76\x32\x2c\x20\x76\x34\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x67\x65\x74\x42\x79\x74\x65\x73\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x5b\x42");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v1);
jclass &clz = cls0;
jmethodID &mid = mth4;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "getBytes", "(Ljava/lang/String;)[B");
jvalue args[] = {{.l = v3}};
v8 = (jarray) env->CallObjectMethodA(v1, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("50:move-result-object \x76\x32");
if (v1) {
LOGD("env->DeleteLocalRef(%p):v1", v1);
env->DeleteLocalRef(v1);
}
v1 = (jobject) v8;
L5:
LOGD("52:new-instance \x76\x33\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x69\x6f\x2f\x42\x79\x74\x65\x41\x72\x72\x61\x79\x49\x6e\x70\x75\x74\x53\x74\x72\x65\x61\x6d\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
jclass &clz = cls5;
D2C_RESOLVE_CLASS(clz,"java/io/ByteArrayInputStream");
v2 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("56:invoke-direct \x76\x33\x2c\x20\x76\x32\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x69\x6f\x2f\x42\x79\x74\x65\x41\x72\x72\x61\x79\x49\x6e\x70\x75\x74\x53\x74\x72\x65\x61\x6d\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x5b\x42\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
jclass &clz = cls5;
jmethodID &mid = mth5;
D2C_RESOLVE_METHOD(clz, mid, "java/io/ByteArrayInputStream", "<init>", "([B)V");
jvalue args[] = {{.l = v1}};
env->CallVoidMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
return (jobject) v2;
EX_UnwindBlock: return NULL;
}
