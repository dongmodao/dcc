#include "Dex2C.h"

/* Lio/pro/edge/widget/event/action/Worker;->run()V */
extern "C" JNIEXPORT void JNICALL
Java_io_pro_edge_widget_event_action_Worker_run__(JNIEnv *env, jobject thiz){
jobject v0 = NULL;
jobject v1 = NULL;
jobject v2 = NULL;
jint v3;
jint v4;
jobject v5 = NULL;
jthrowable exception;
jclass cls0 = NULL,cls1 = NULL,cls2 = NULL,cls3 = NULL,cls4 = NULL;
jfieldID fld0 = NULL,fld1 = NULL,fld2 = NULL,fld3 = NULL,fld4 = NULL;
jmethodID mth0 = NULL, mth1 = NULL, mth2 = NULL, mth3 = NULL, mth4 = NULL, mth5 = NULL, mth6 = NULL, mth7 = NULL, mth8 = NULL, mth9 = NULL;
v0 = (jobject)env->NewLocalRef(thiz);
L0:
LOGD("0:iget-object \x76\x30\x2c\x20\x76\x32\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x57\x6f\x72\x6b\x65\x72\x3b\x2d\x3e\x63\x20\x4c\x6f\x72\x67\x2f\x6a\x73\x6f\x6e\x2f\x4a\x53\x4f\x4e\x4f\x62\x6a\x65\x63\x74\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jfieldID &fld = fld0;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/action/Worker", "c", "Lorg/json/JSONObject;");
v1 = (jobject) env->GetObjectField(v0,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
v2 = (jobject) v1;
LOGD("4:if-eqz \x76\x30\x2c\x20\x2b\x33\x62");
if(v2 == NULL){
goto L14;
}
else {
goto L1;
}
L1:
LOGD("8:iget-object \x76\x30\x2c\x20\x76\x32\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x57\x6f\x72\x6b\x65\x72\x3b\x2d\x3e\x62\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x4d\x79\x57\x6f\x72\x6b\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jfieldID &fld = fld1;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/action/Worker", "b", "Lio/pro/edge/widget/event/MyWorker;");
v1 = (jobject) env->GetObjectField(v0,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
v2 = (jobject) v1;
LOGD("c:if-nez \x76\x30\x2c\x20\x2b\x33");
if(v2 != NULL){
goto L3;
}
else {
goto L2;
}
L2:
goto L14;
L3:
LOGD("12:invoke-static \x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x43\x6f\x6f\x6b\x69\x65\x4d\x61\x6e\x61\x67\x65\x72\x3b\x2d\x3e\x67\x65\x74\x49\x6e\x73\x74\x61\x6e\x63\x65\x28\x29\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x43\x6f\x6f\x6b\x69\x65\x4d\x61\x6e\x61\x67\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls1;
jmethodID &mid = mth0;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "android/webkit/CookieManager", "getInstance", "()Landroid/webkit/CookieManager;");
jvalue args[] = {};
v1 = (jobject) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("18:move-result-object \x76\x30");
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
v2 = (jobject) v1;
LOGD("1a:invoke-virtual \x76\x30\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x43\x6f\x6f\x6b\x69\x65\x4d\x61\x6e\x61\x67\x65\x72\x3b\x2d\x3e\x72\x65\x6d\x6f\x76\x65\x41\x6c\x6c\x43\x6f\x6f\x6b\x69\x65\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
jclass &clz = cls1;
jmethodID &mid = mth1;
D2C_RESOLVE_METHOD(clz, mid, "android/webkit/CookieManager", "removeAllCookie", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L4:
LOGD("20:invoke-virtual \x76\x32\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x57\x6f\x72\x6b\x65\x72\x3b\x2d\x3e\x62\x28\x29\x56");
{
#define EX_HANDLE EX_LandingPad_4
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jmethodID &mid = mth2;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/event/action/Worker", "b", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L5:
LOGD("26:invoke-virtual \x76\x32\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x57\x6f\x72\x6b\x65\x72\x3b\x2d\x3e\x63\x28\x29\x56");
{
#define EX_HANDLE EX_LandingPad_4
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jmethodID &mid = mth3;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/event/action/Worker", "c", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L6:
goto L8;
L7:
LOGD("2e:move-exception \x76\x30");
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
v2 = exception;
LOGD("30:invoke-virtual \x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x54\x68\x72\x6f\x77\x61\x62\x6c\x65\x3b\x2d\x3e\x70\x72\x69\x6e\x74\x53\x74\x61\x63\x6b\x54\x72\x61\x63\x65\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
jclass &clz = cls2;
jmethodID &mid = mth4;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/Throwable", "printStackTrace", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L8:
LOGD("36:iget-object \x76\x30\x2c\x20\x76\x32\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x57\x6f\x72\x6b\x65\x72\x3b\x2d\x3e\x76\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6e\x74\x65\x78\x74\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jfieldID &fld = fld2;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/action/Worker", "v", "Landroid/content/Context;");
v1 = (jobject) env->GetObjectField(v0,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
v2 = (jobject) v1;
LOGD("3a:invoke-static \x76\x30\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x75\x74\x69\x6c\x73\x2f\x49\x6e\x55\x74\x69\x6c\x73\x3b\x2d\x3e\x67\x28\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6e\x74\x65\x78\x74\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls3;
jmethodID &mid = mth5;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "io/pro/edge/widget/event/utils/InUtils", "g", "(Landroid/content/Context;)Z");
jvalue args[] = {{.l = v2}};
v3 = (jboolean) env->CallStaticBooleanMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("40:move-result \x76\x30");
v4 = (jint) v3;
LOGD("42:if-nez \x76\x30\x2c\x20\x2b\x38");
if(v4 != 0){
goto L10;
}
else {
goto L9;
}
L9:
LOGD("46:iget-object \x76\x30\x2c\x20\x76\x32\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x57\x6f\x72\x6b\x65\x72\x3b\x2d\x3e\x45\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x52\x75\x6e\x6e\x61\x62\x6c\x65\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jfieldID &fld = fld3;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/action/Worker", "E", "Ljava/lang/Runnable;");
v1 = (jobject) env->GetObjectField(v0,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
v2 = (jobject) v1;
LOGD("4a:invoke-interface \x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x52\x75\x6e\x6e\x61\x62\x6c\x65\x3b\x2d\x3e\x72\x75\x6e\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
jclass &clz = cls4;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/Runnable", "run", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
return;
L10:
LOGD("52:iget \x76\x30\x2c\x20\x76\x32\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x57\x6f\x72\x6b\x65\x72\x3b\x2d\x3e\x74\x20\x49");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jfieldID &fld = fld4;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/action/Worker", "t", "I");
v4 = (jint) env->GetIntField(v0,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("56:if-nez \x76\x30\x2c\x20\x2b\x61");
if(v4 != 0){
goto L12;
}
else {
goto L11;
}
L11:
LOGD("5a:iget-object \x76\x30\x2c\x20\x76\x32\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x57\x6f\x72\x6b\x65\x72\x3b\x2d\x3e\x76\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6e\x74\x65\x78\x74\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jfieldID &fld = fld2;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/action/Worker", "v", "Landroid/content/Context;");
v1 = (jobject) env->GetObjectField(v0,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
v2 = (jobject) v1;
LOGD("5e:iget-object \x76\x31\x2c\x20\x76\x32\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x57\x6f\x72\x6b\x65\x72\x3b\x2d\x3e\x45\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x52\x75\x6e\x6e\x61\x62\x6c\x65\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jfieldID &fld = fld3;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/action/Worker", "E", "Ljava/lang/Runnable;");
v1 = (jobject) env->GetObjectField(v0,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v5) {
LOGD("env->DeleteLocalRef(%p):v5", v5);
env->DeleteLocalRef(v5);
}
v5 = (jobject) v1;
LOGD("62:invoke-static \x76\x30\x2c\x20\x76\x31\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x75\x74\x69\x6c\x73\x2f\x49\x6e\x55\x74\x69\x6c\x73\x3b\x2d\x3e\x63\x28\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6e\x74\x65\x78\x74\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x52\x75\x6e\x6e\x61\x62\x6c\x65\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls3;
jmethodID &mid = mth7;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "io/pro/edge/widget/event/utils/InUtils", "c", "(Landroid/content/Context;Ljava/lang/Runnable;)V");
jvalue args[] = {{.l = v2},{.l = v5}};
env->CallStaticVoidMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
goto L13;
L12:
LOGD("6a:iget-object \x76\x30\x2c\x20\x76\x32\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x57\x6f\x72\x6b\x65\x72\x3b\x2d\x3e\x76\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6e\x74\x65\x78\x74\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jfieldID &fld = fld2;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/action/Worker", "v", "Landroid/content/Context;");
v1 = (jobject) env->GetObjectField(v0,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
v2 = (jobject) v1;
LOGD("6e:iget-object \x76\x31\x2c\x20\x76\x32\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x57\x6f\x72\x6b\x65\x72\x3b\x2d\x3e\x45\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x52\x75\x6e\x6e\x61\x62\x6c\x65\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jfieldID &fld = fld3;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/action/Worker", "E", "Ljava/lang/Runnable;");
v1 = (jobject) env->GetObjectField(v0,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v5) {
LOGD("env->DeleteLocalRef(%p):v5", v5);
env->DeleteLocalRef(v5);
}
v5 = (jobject) v1;
LOGD("72:invoke-static \x76\x30\x2c\x20\x76\x31\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x75\x74\x69\x6c\x73\x2f\x49\x6e\x55\x74\x69\x6c\x73\x3b\x2d\x3e\x61\x28\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6e\x74\x65\x78\x74\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x52\x75\x6e\x6e\x61\x62\x6c\x65\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls3;
jmethodID &mid = mth8;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "io/pro/edge/widget/event/utils/InUtils", "a", "(Landroid/content/Context;Ljava/lang/Runnable;)V");
jvalue args[] = {{.l = v2},{.l = v5}};
env->CallStaticVoidMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L13:
return;
L14:
LOGD("7a:invoke-virtual \x76\x32\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x57\x6f\x72\x6b\x65\x72\x3b\x2d\x3e\x61\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jmethodID &mid = mth9;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/event/action/Worker", "a", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
return;

EX_LandingPad_4:
D2C_GET_PENDING_EX
if(d2c_is_instance_of(env, exception, "java/lang/Throwable")) {
goto L7;
}
D2C_GOTO_UNWINDBLOCK
EX_UnwindBlock: return;
}
