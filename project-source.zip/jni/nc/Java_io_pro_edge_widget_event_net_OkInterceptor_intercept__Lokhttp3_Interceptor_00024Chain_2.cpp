#include "Dex2C.h"

/* Lio/pro/edge/widget/event/net/OkInterceptor;->intercept(Lokhttp3/Interceptor$Chain;)Lokhttp3/Response; */
extern "C" JNIEXPORT jobject JNICALL
Java_io_pro_edge_widget_event_net_OkInterceptor_intercept__Lokhttp3_Interceptor_00024Chain_2(JNIEnv *env, jobject thiz, jobject p24){
jobject v0 = NULL;
jobject v1 = NULL;
jobject v2 = NULL;
jobject v3 = NULL;
jobject v4 = NULL;
jint v5;
jint v6;
jobject v7 = NULL;
jobject v8 = NULL;
jobject v9 = NULL;
jobject v10 = NULL;
jint v11;
jint v12;
jobject v13 = NULL;
jint v14;
jobject v15 = NULL;
jobject v16 = NULL;
jobject v17 = NULL;
jobject v18 = NULL;
jint v19;
jobject v20 = NULL;
jobject v21 = NULL;
jobject v22 = NULL;
jint v23;
jlong v24;
jlong v25;
jobject v26 = NULL;
jlong v27;
jlong v28;
jobject v29 = NULL;
jlong v30;
jint v31;
jint v32;
jint v33;
jobject v34 = NULL;
jlong v35;
jlong v36;
jlong v37;
jobject v38 = NULL;
jlong v39;
jobject v40 = NULL;
jint v41;
jint v42;
jobject v43 = NULL;
jlong v44;
jint v45;
jint v46;
jthrowable exception;
jclass cls0 = NULL,cls1 = NULL,cls2 = NULL,cls3 = NULL,cls4 = NULL,cls5 = NULL,cls6 = NULL,cls7 = NULL,cls8 = NULL,cls9 = NULL,cls10 = NULL,cls11 = NULL,cls12 = NULL,cls13 = NULL,cls14 = NULL,cls15 = NULL,cls16 = NULL,cls17 = NULL,cls18 = NULL,cls19 = NULL,cls20 = NULL,cls21 = NULL,cls22 = NULL;
jfieldID fld0 = NULL,fld1 = NULL,fld2 = NULL,fld3 = NULL,fld4 = NULL,fld5 = NULL,fld6 = NULL,fld7 = NULL,fld8 = NULL;
jmethodID mth0 = NULL, mth1 = NULL, mth2 = NULL, mth3 = NULL, mth4 = NULL, mth5 = NULL, mth6 = NULL, mth7 = NULL, mth8 = NULL, mth9 = NULL, mth10 = NULL, mth11 = NULL, mth12 = NULL, mth13 = NULL, mth14 = NULL, mth15 = NULL, mth16 = NULL, mth17 = NULL, mth18 = NULL, mth19 = NULL, mth20 = NULL, mth21 = NULL, mth22 = NULL, mth23 = NULL, mth24 = NULL, mth25 = NULL, mth26 = NULL, mth27 = NULL, mth28 = NULL, mth29 = NULL, mth30 = NULL, mth31 = NULL, mth32 = NULL, mth33 = NULL, mth34 = NULL, mth35 = NULL, mth36 = NULL, mth37 = NULL, mth38 = NULL, mth39 = NULL, mth40 = NULL, mth41 = NULL, mth42 = NULL, mth43 = NULL, mth44 = NULL, mth45 = NULL, mth46 = NULL, mth47 = NULL, mth48 = NULL, mth49 = NULL, mth50 = NULL, mth51 = NULL, mth52 = NULL;
v0 = (jobject)env->NewLocalRef(thiz);
v1 = (jobject)env->NewLocalRef(p24);
L0:
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
v2 = (jobject) env->NewLocalRef(v0);
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
v3 = (jobject) env->NewLocalRef(v1);
LOGD("8:sget-object \x76\x32\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x3b\x2d\x3e\x62\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x63\x6f\x6e\x63\x75\x72\x72\x65\x6e\x74\x2f\x61\x74\x6f\x6d\x69\x63\x2f\x41\x74\x6f\x6d\x69\x63\x49\x6e\x74\x65\x67\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
jclass &clz = cls0;
jfieldID &fld = fld0;
D2C_RESOLVE_STATIC_FIELD(clz, fld, "io/pro/edge/widget/event/net/OkInterceptor", "b", "Ljava/util/concurrent/atomic/AtomicInteger;");
v4 = (jobject) env->GetStaticObjectField(clz,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("c:invoke-virtual \x76\x32\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x63\x6f\x6e\x63\x75\x72\x72\x65\x6e\x74\x2f\x61\x74\x6f\x6d\x69\x63\x2f\x41\x74\x6f\x6d\x69\x63\x49\x6e\x74\x65\x67\x65\x72\x3b\x2d\x3e\x67\x65\x74\x41\x6e\x64\x49\x6e\x63\x72\x65\x6d\x65\x6e\x74\x28\x29\x49");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v4);
jclass &clz = cls1;
jmethodID &mid = mth0;
D2C_RESOLVE_METHOD(clz, mid, "java/util/concurrent/atomic/AtomicInteger", "getAndIncrement", "()I");
jvalue args[] = {};
v5 = (jint) env->CallIntMethodA(v4, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("12:move-result \x76\x32");
v6 = (jint) v5;
LOGD("14:iget-object \x76\x33\x2c\x20\x76\x31\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x3b\x2d\x3e\x65\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x65\x76\x65\x6c\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
jclass &clz = cls0;
jfieldID &fld = fld1;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/net/OkInterceptor", "e", "Lio/pro/edge/widget/event/net/OkInterceptor$Level;");
v7 = (jobject) env->GetObjectField(v2,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jobject) v7;
LOGD("18:invoke-interface/range \x76\x32\x34\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x43\x68\x61\x69\x6e\x3b\x2d\x3e\x72\x65\x71\x75\x65\x73\x74\x28\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x71\x75\x65\x73\x74\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v1);
jclass &clz = cls2;
jmethodID &mid = mth1;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Interceptor$Chain", "request", "()Lokhttp3/Request;");
jvalue args[] = {};
v7 = (jobject) env->CallObjectMethodA(v1, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("1e:move-result-object \x76\x34");
if (v9) {
LOGD("env->DeleteLocalRef(%p):v9", v9);
env->DeleteLocalRef(v9);
}
v9 = (jobject) v7;
LOGD("20:sget-object \x76\x35\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x65\x76\x65\x6c\x3b\x2d\x3e\x4e\x4f\x4e\x45\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x65\x76\x65\x6c\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v10) {
LOGD("env->DeleteLocalRef(%p):v10", v10);
env->DeleteLocalRef(v10);
}
jclass &clz = cls3;
jfieldID &fld = fld2;
D2C_RESOLVE_STATIC_FIELD(clz, fld, "io/pro/edge/widget/event/net/OkInterceptor$Level", "NONE", "Lio/pro/edge/widget/event/net/OkInterceptor$Level;");
v10 = (jobject) env->GetStaticObjectField(clz,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("24:if-ne \x76\x33\x2c\x20\x76\x35\x2c\x20\x2b\x37");
if(!d2c_is_same_object(env,v8,v10)) {
goto L2;
}
else {
goto L1;
}
L1:
LOGD("28:invoke-interface \x76\x30\x2c\x20\x76\x34\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x43\x68\x61\x69\x6e\x3b\x2d\x3e\x70\x72\x6f\x63\x65\x65\x64\x28\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x71\x75\x65\x73\x74\x3b\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls2;
jmethodID &mid = mth2;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Interceptor$Chain", "proceed", "(Lokhttp3/Request;)Lokhttp3/Response;");
jvalue args[] = {{.l = v9}};
v7 = (jobject) env->CallObjectMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("2e:move-result-object \x76\x30");
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
v3 = (jobject) v7;
return (jobject) v3;
L2:
LOGD("32:sget-object \x76\x35\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x65\x76\x65\x6c\x3b\x2d\x3e\x42\x4f\x44\x59\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x65\x76\x65\x6c\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v10) {
LOGD("env->DeleteLocalRef(%p):v10", v10);
env->DeleteLocalRef(v10);
}
jclass &clz = cls3;
jfieldID &fld = fld3;
D2C_RESOLVE_STATIC_FIELD(clz, fld, "io/pro/edge/widget/event/net/OkInterceptor$Level", "BODY", "Lio/pro/edge/widget/event/net/OkInterceptor$Level;");
v10 = (jobject) env->GetStaticObjectField(clz,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
v11 = 1;
LOGD("38:if-ne \x76\x33\x2c\x20\x76\x35\x2c\x20\x2b\x34");
if(!d2c_is_same_object(env,v8,v10)) {
goto L4;
}
else {
goto L3;
}
L3:
v12 = 1;
goto L5;
L4:
v12 = 0;
L5:
LOGD("42:if-nez \x76\x35\x2c\x20\x2b\x39");
if(v12 != 0){
goto L9;
}
else {
goto L6;
}
L6:
LOGD("46:sget-object \x76\x38\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x65\x76\x65\x6c\x3b\x2d\x3e\x48\x45\x41\x44\x45\x52\x53\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x65\x76\x65\x6c\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v13) {
LOGD("env->DeleteLocalRef(%p):v13", v13);
env->DeleteLocalRef(v13);
}
jclass &clz = cls3;
jfieldID &fld = fld4;
D2C_RESOLVE_STATIC_FIELD(clz, fld, "io/pro/edge/widget/event/net/OkInterceptor$Level", "HEADERS", "Lio/pro/edge/widget/event/net/OkInterceptor$Level;");
v13 = (jobject) env->GetStaticObjectField(clz,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("4a:if-ne \x76\x33\x2c\x20\x76\x38\x2c\x20\x2b\x33");
if(!d2c_is_same_object(env,v8,v13)) {
goto L8;
}
else {
goto L7;
}
L7:
goto L9;
L8:
v14 = 0;
goto L10;
L9:
v14 = 1;
L10:
LOGD("56:invoke-virtual \x76\x34\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x71\x75\x65\x73\x74\x3b\x2d\x3e\x62\x6f\x64\x79\x28\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x71\x75\x65\x73\x74\x42\x6f\x64\x79\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v9);
jclass &clz = cls4;
jmethodID &mid = mth3;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Request", "body", "()Lokhttp3/RequestBody;");
jvalue args[] = {};
v7 = (jobject) env->CallObjectMethodA(v9, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("5c:move-result-object \x76\x39");
if (v15) {
LOGD("env->DeleteLocalRef(%p):v15", v15);
env->DeleteLocalRef(v15);
}
v15 = (jobject) v7;
LOGD("5e:if-eqz \x76\x39\x2c\x20\x2b\x33");
if(v15 == NULL){
goto L12;
}
else {
goto L11;
}
L11:
goto L13;
L12:
v11 = 0;
L13:
LOGD("66:invoke-interface/range \x76\x32\x34\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x43\x68\x61\x69\x6e\x3b\x2d\x3e\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x28\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v1);
jclass &clz = cls2;
jmethodID &mid = mth4;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Interceptor$Chain", "connection", "()Lokhttp3/Connection;");
jvalue args[] = {};
v7 = (jobject) env->CallObjectMethodA(v1, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("6c:move-result-object \x76\x31\x30");
if (v16) {
LOGD("env->DeleteLocalRef(%p):v16", v16);
env->DeleteLocalRef(v16);
}
v16 = (jobject) v7;
LOGD("6e:new-instance \x76\x31\x31\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v17) {
LOGD("env->DeleteLocalRef(%p):v17", v17);
env->DeleteLocalRef(v17);
}
jclass &clz = cls5;
D2C_RESOLVE_CLASS(clz,"java/lang/StringBuilder");
v17 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("72:invoke-direct \x76\x31\x31\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v17);
jclass &clz = cls5;
jmethodID &mid = mth5;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "<init>", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v17, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("78:const-string \x76\x31\x32\x2c\x20\x27\x2d\x2d\x3e\x20\x27");
if (v18) {
LOGD("env->DeleteLocalRef(%p):v18", v18);
env->DeleteLocalRef(v18);
}
v18 = (jstring) env->NewStringUTF("\x2d\x2d\x3e\x20");
LOGD("7c:invoke-virtual \x76\x31\x31\x2c\x20\x76\x31\x32\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v17);
jclass &clz = cls5;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v18}};
v7 = (jobject) env->CallObjectMethodA(v17, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("82:invoke-virtual \x76\x34\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x71\x75\x65\x73\x74\x3b\x2d\x3e\x6d\x65\x74\x68\x6f\x64\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v9);
jclass &clz = cls4;
jmethodID &mid = mth7;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Request", "method", "()Ljava/lang/String;");
jvalue args[] = {};
v7 = (jstring) env->CallObjectMethodA(v9, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("88:move-result-object \x76\x31\x32");
if (v18) {
LOGD("env->DeleteLocalRef(%p):v18", v18);
env->DeleteLocalRef(v18);
}
v18 = (jobject) v7;
LOGD("8a:invoke-virtual \x76\x31\x31\x2c\x20\x76\x31\x32\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v17);
jclass &clz = cls5;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v18}};
v7 = (jobject) env->CallObjectMethodA(v17, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
v19 = 32;
LOGD("94:invoke-virtual \x76\x31\x31\x2c\x20\x76\x31\x32\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x43\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v17);
jclass &clz = cls5;
jmethodID &mid = mth8;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(C)Ljava/lang/StringBuilder;");
jvalue args[] = {{.c = (jchar) v19}};
v7 = (jobject) env->CallObjectMethodA(v17, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("9a:invoke-virtual \x76\x34\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x71\x75\x65\x73\x74\x3b\x2d\x3e\x75\x72\x6c\x28\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x48\x74\x74\x70\x55\x72\x6c\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v9);
jclass &clz = cls4;
jmethodID &mid = mth9;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Request", "url", "()Lokhttp3/HttpUrl;");
jvalue args[] = {};
v7 = (jobject) env->CallObjectMethodA(v9, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("a0:move-result-object \x76\x31\x33");
if (v20) {
LOGD("env->DeleteLocalRef(%p):v20", v20);
env->DeleteLocalRef(v20);
}
v20 = (jobject) v7;
LOGD("a2:invoke-virtual \x76\x31\x31\x2c\x20\x76\x31\x33\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v17);
jclass &clz = cls5;
jmethodID &mid = mth10;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/Object;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v20}};
v7 = (jobject) env->CallObjectMethodA(v17, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("a8:const-string \x76\x31\x33\x2c\x20\x27\x27");
if (v20) {
LOGD("env->DeleteLocalRef(%p):v20", v20);
env->DeleteLocalRef(v20);
}
v20 = (jstring) env->NewStringUTF("");
LOGD("ac:if-eqz \x76\x31\x30\x2c\x20\x2b\x31\x38");
if(v16 == NULL){
goto L15;
}
else {
goto L14;
}
L14:
LOGD("b0:new-instance \x76\x31\x34\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v21) {
LOGD("env->DeleteLocalRef(%p):v21", v21);
env->DeleteLocalRef(v21);
}
jclass &clz = cls5;
D2C_RESOLVE_CLASS(clz,"java/lang/StringBuilder");
v21 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("b4:invoke-direct \x76\x31\x34\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v21);
jclass &clz = cls5;
jmethodID &mid = mth5;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "<init>", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v21, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("ba:const-string \x76\x31\x35\x2c\x20\x27\x20\x27");
if (v22) {
LOGD("env->DeleteLocalRef(%p):v22", v22);
env->DeleteLocalRef(v22);
}
v22 = (jstring) env->NewStringUTF("\x20");
LOGD("be:invoke-virtual \x76\x31\x34\x2c\x20\x76\x31\x35\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v21);
jclass &clz = cls5;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v22}};
v7 = (jobject) env->CallObjectMethodA(v21, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("c4:invoke-interface \x76\x31\x30\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x3b\x2d\x3e\x70\x72\x6f\x74\x6f\x63\x6f\x6c\x28\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x50\x72\x6f\x74\x6f\x63\x6f\x6c\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v16);
jclass &clz = cls6;
jmethodID &mid = mth11;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Connection", "protocol", "()Lokhttp3/Protocol;");
jvalue args[] = {};
v7 = (jobject) env->CallObjectMethodA(v16, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("ca:move-result-object \x76\x31\x30");
if (v16) {
LOGD("env->DeleteLocalRef(%p):v16", v16);
env->DeleteLocalRef(v16);
}
v16 = (jobject) v7;
LOGD("cc:invoke-virtual \x76\x31\x34\x2c\x20\x76\x31\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v21);
jclass &clz = cls5;
jmethodID &mid = mth10;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/Object;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v16}};
v7 = (jobject) env->CallObjectMethodA(v21, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("d2:invoke-virtual \x76\x31\x34\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x74\x6f\x53\x74\x72\x69\x6e\x67\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v21);
jclass &clz = cls5;
jmethodID &mid = mth12;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "toString", "()Ljava/lang/String;");
jvalue args[] = {};
v7 = (jstring) env->CallObjectMethodA(v21, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("d8:move-result-object \x76\x31\x30");
if (v16) {
LOGD("env->DeleteLocalRef(%p):v16", v16);
env->DeleteLocalRef(v16);
}
v16 = (jobject) v7;
goto L16;
L15:
if (v16) {
LOGD("env->DeleteLocalRef(%p):v16", v16);
env->DeleteLocalRef(v16);
}
v16 = (jobject) env->NewLocalRef(v20);
L16:
LOGD("de:invoke-virtual \x76\x31\x31\x2c\x20\x76\x31\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v17);
jclass &clz = cls5;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v16}};
v7 = (jobject) env->CallObjectMethodA(v17, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("e4:invoke-virtual \x76\x31\x31\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x74\x6f\x53\x74\x72\x69\x6e\x67\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v17);
jclass &clz = cls5;
jmethodID &mid = mth12;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "toString", "()Ljava/lang/String;");
jvalue args[] = {};
v7 = (jstring) env->CallObjectMethodA(v17, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("ea:move-result-object \x76\x31\x30");
if (v16) {
LOGD("env->DeleteLocalRef(%p):v16", v16);
env->DeleteLocalRef(v16);
}
v16 = (jobject) v7;
LOGD("ec:const-string \x76\x31\x31\x2c\x20\x27\x2d\x62\x79\x74\x65\x20\x62\x6f\x64\x79\x29\x27");
if (v17) {
LOGD("env->DeleteLocalRef(%p):v17", v17);
env->DeleteLocalRef(v17);
}
v17 = (jstring) env->NewStringUTF("\x2d\x62\x79\x74\x65\x20\x62\x6f\x64\x79\x29");
LOGD("f0:const-string \x76\x31\x34\x2c\x20\x27\x20\x28\x27");
if (v21) {
LOGD("env->DeleteLocalRef(%p):v21", v21);
env->DeleteLocalRef(v21);
}
v21 = (jstring) env->NewStringUTF("\x20\x28");
LOGD("f4:if-nez \x76\x38\x2c\x20\x2b\x32\x30");
if(v14 != 0){
goto L19;
}
else {
goto L17;
}
L17:
LOGD("f8:if-eqz \x76\x36\x2c\x20\x2b\x31\x65");
if(v11 == 0){
goto L19;
}
else {
goto L18;
}
L18:
LOGD("fc:new-instance \x76\x31\x35\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v22) {
LOGD("env->DeleteLocalRef(%p):v22", v22);
env->DeleteLocalRef(v22);
}
jclass &clz = cls5;
D2C_RESOLVE_CLASS(clz,"java/lang/StringBuilder");
v22 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("100:invoke-direct \x76\x31\x35\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v22);
jclass &clz = cls5;
jmethodID &mid = mth5;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "<init>", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v22, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("106:invoke-virtual \x76\x31\x35\x2c\x20\x76\x31\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v22);
jclass &clz = cls5;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v16}};
v7 = (jobject) env->CallObjectMethodA(v22, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("10c:invoke-virtual \x76\x31\x35\x2c\x20\x76\x31\x34\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v22);
jclass &clz = cls5;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v21}};
v7 = (jobject) env->CallObjectMethodA(v22, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
v23 = v14;
LOGD("116:invoke-virtual \x76\x39\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x71\x75\x65\x73\x74\x42\x6f\x64\x79\x3b\x2d\x3e\x63\x6f\x6e\x74\x65\x6e\x74\x4c\x65\x6e\x67\x74\x68\x28\x29\x4a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v15);
jclass &clz = cls7;
jmethodID &mid = mth13;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/RequestBody", "contentLength", "()J");
jvalue args[] = {};
v24 = (jlong) env->CallLongMethodA(v15, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("11c:move-result-wide \x76\x37");
v25 = (jlong) v24;
LOGD("11e:invoke-virtual \x76\x31\x35\x2c\x20\x76\x37\x2c\x20\x76\x38\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4a\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v22);
jclass &clz = cls5;
jmethodID &mid = mth14;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(J)Ljava/lang/StringBuilder;");
jvalue args[] = {{.j = (jlong) v25}};
v7 = (jobject) env->CallObjectMethodA(v22, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("124:invoke-virtual \x76\x31\x35\x2c\x20\x76\x31\x31\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v22);
jclass &clz = cls5;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v17}};
v7 = (jobject) env->CallObjectMethodA(v22, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("12a:invoke-virtual \x76\x31\x35\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x74\x6f\x53\x74\x72\x69\x6e\x67\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v22);
jclass &clz = cls5;
jmethodID &mid = mth12;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "toString", "()Ljava/lang/String;");
jvalue args[] = {};
v7 = (jstring) env->CallObjectMethodA(v22, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("130:move-result-object \x76\x31\x30");
if (v16) {
LOGD("env->DeleteLocalRef(%p):v16", v16);
env->DeleteLocalRef(v16);
}
v16 = (jobject) v7;
goto L20;
L19:
v23 = v14;
L20:
LOGD("138:iget-object \x76\x37\x2c\x20\x76\x31\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x3b\x2d\x3e\x63\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x6f\x67\x67\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
jclass &clz = cls0;
jfieldID &fld = fld5;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/net/OkInterceptor", "c", "Lio/pro/edge/widget/event/net/OkInterceptor$Logger;");
v7 = (jobject) env->GetObjectField(v2,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v26) {
LOGD("env->DeleteLocalRef(%p):v26", v26);
env->DeleteLocalRef(v26);
}
v26 = (jobject) v7;
LOGD("13c:invoke-interface \x76\x37\x2c\x20\x76\x31\x33\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x6f\x67\x67\x65\x72\x3b\x2d\x3e\x61\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v26);
jclass &clz = cls8;
jmethodID &mid = mth15;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/event/net/OkInterceptor$Logger", "a", "(Ljava/lang/String;)V");
jvalue args[] = {{.l = v20}};
env->CallVoidMethodA(v26, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("142:iget-object \x76\x37\x2c\x20\x76\x31\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x3b\x2d\x3e\x63\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x6f\x67\x67\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
jclass &clz = cls0;
jfieldID &fld = fld5;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/net/OkInterceptor", "c", "Lio/pro/edge/widget/event/net/OkInterceptor$Logger;");
v7 = (jobject) env->GetObjectField(v2,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v26) {
LOGD("env->DeleteLocalRef(%p):v26", v26);
env->DeleteLocalRef(v26);
}
v26 = (jobject) v7;
LOGD("146:invoke-interface \x76\x37\x2c\x20\x76\x32\x2c\x20\x76\x31\x30\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x6f\x67\x67\x65\x72\x3b\x2d\x3e\x61\x28\x49\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v26);
jclass &clz = cls8;
jmethodID &mid = mth16;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/event/net/OkInterceptor$Logger", "a", "(ILjava/lang/String;)V");
jvalue args[] = {{.i = v6},{.l = v16}};
env->CallVoidMethodA(v26, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("14c:if-eqz \x76\x36\x2c\x20\x2b\x32\x37");
if(v11 == 0){
goto L23;
}
else {
goto L21;
}
L21:
LOGD("150:invoke-virtual \x76\x39\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x71\x75\x65\x73\x74\x42\x6f\x64\x79\x3b\x2d\x3e\x63\x6f\x6e\x74\x65\x6e\x74\x54\x79\x70\x65\x28\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x4d\x65\x64\x69\x61\x54\x79\x70\x65\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v15);
jclass &clz = cls7;
jmethodID &mid = mth17;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/RequestBody", "contentType", "()Lokhttp3/MediaType;");
jvalue args[] = {};
v7 = (jobject) env->CallObjectMethodA(v15, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("156:move-result-object \x76\x37");
if (v26) {
LOGD("env->DeleteLocalRef(%p):v26", v26);
env->DeleteLocalRef(v26);
}
v26 = (jobject) v7;
LOGD("158:if-eqz \x76\x37\x2c\x20\x2b\x32\x31");
if(v26 == NULL){
goto L23;
}
else {
goto L22;
}
L22:
LOGD("15c:iget-object \x76\x37\x2c\x20\x76\x31\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x3b\x2d\x3e\x63\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x6f\x67\x67\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
jclass &clz = cls0;
jfieldID &fld = fld5;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/net/OkInterceptor", "c", "Lio/pro/edge/widget/event/net/OkInterceptor$Logger;");
v7 = (jobject) env->GetObjectField(v2,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v26) {
LOGD("env->DeleteLocalRef(%p):v26", v26);
env->DeleteLocalRef(v26);
}
v26 = (jobject) v7;
LOGD("160:new-instance \x76\x38\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v13) {
LOGD("env->DeleteLocalRef(%p):v13", v13);
env->DeleteLocalRef(v13);
}
jclass &clz = cls5;
D2C_RESOLVE_CLASS(clz,"java/lang/StringBuilder");
v13 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("164:invoke-direct \x76\x38\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v13);
jclass &clz = cls5;
jmethodID &mid = mth5;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "<init>", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v13, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("16a:const-string \x76\x31\x30\x2c\x20\x27\x5b\x2b\x2b\x2b\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65\x3a\x20\x27");
if (v16) {
LOGD("env->DeleteLocalRef(%p):v16", v16);
env->DeleteLocalRef(v16);
}
v16 = (jstring) env->NewStringUTF("\x5b\x2b\x2b\x2b\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65\x3a\x20");
LOGD("16e:invoke-virtual \x76\x38\x2c\x20\x76\x31\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v13);
jclass &clz = cls5;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v16}};
v7 = (jobject) env->CallObjectMethodA(v13, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("174:invoke-virtual \x76\x39\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x71\x75\x65\x73\x74\x42\x6f\x64\x79\x3b\x2d\x3e\x63\x6f\x6e\x74\x65\x6e\x74\x54\x79\x70\x65\x28\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x4d\x65\x64\x69\x61\x54\x79\x70\x65\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v15);
jclass &clz = cls7;
jmethodID &mid = mth17;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/RequestBody", "contentType", "()Lokhttp3/MediaType;");
jvalue args[] = {};
v7 = (jobject) env->CallObjectMethodA(v15, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("17a:move-result-object \x76\x31\x30");
if (v16) {
LOGD("env->DeleteLocalRef(%p):v16", v16);
env->DeleteLocalRef(v16);
}
v16 = (jobject) v7;
LOGD("17c:invoke-virtual \x76\x38\x2c\x20\x76\x31\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v13);
jclass &clz = cls5;
jmethodID &mid = mth10;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/Object;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v16}};
v7 = (jobject) env->CallObjectMethodA(v13, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("182:const-string \x76\x31\x30\x2c\x20\x27\x5d\x27");
if (v16) {
LOGD("env->DeleteLocalRef(%p):v16", v16);
env->DeleteLocalRef(v16);
}
v16 = (jstring) env->NewStringUTF("\x5d");
LOGD("186:invoke-virtual \x76\x38\x2c\x20\x76\x31\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v13);
jclass &clz = cls5;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v16}};
v7 = (jobject) env->CallObjectMethodA(v13, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("18c:invoke-virtual \x76\x38\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x74\x6f\x53\x74\x72\x69\x6e\x67\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v13);
jclass &clz = cls5;
jmethodID &mid = mth12;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "toString", "()Ljava/lang/String;");
jvalue args[] = {};
v7 = (jstring) env->CallObjectMethodA(v13, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("192:move-result-object \x76\x38");
if (v13) {
LOGD("env->DeleteLocalRef(%p):v13", v13);
env->DeleteLocalRef(v13);
}
v13 = (jobject) v7;
LOGD("194:invoke-interface \x76\x37\x2c\x20\x76\x32\x2c\x20\x76\x38\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x6f\x67\x67\x65\x72\x3b\x2d\x3e\x61\x28\x49\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v26);
jclass &clz = cls8;
jmethodID &mid = mth16;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/event/net/OkInterceptor$Logger", "a", "(ILjava/lang/String;)V");
jvalue args[] = {{.i = v6},{.l = v13}};
env->CallVoidMethodA(v26, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L23:
LOGD("19a:const-string \x76\x37\x2c\x20\x27\x2d\x62\x79\x74\x65\x20\x62\x6f\x64\x79\x20\x6f\x6d\x69\x74\x74\x65\x64\x29\x27");
if (v26) {
LOGD("env->DeleteLocalRef(%p):v26", v26);
env->DeleteLocalRef(v26);
}
v26 = (jstring) env->NewStringUTF("\x2d\x62\x79\x74\x65\x20\x62\x6f\x64\x79\x20\x6f\x6d\x69\x74\x74\x65\x64\x29");
v27 = -1;
v27 = -1;
LOGD("1a2:if-eqz \x76\x31\x36\x2c\x20\x2b\x31\x33\x37");
if(v23 == 0){
goto L47;
}
else {
goto L24;
}
L24:
LOGD("1a6:if-eqz \x76\x36\x2c\x20\x2b\x34\x37");
if(v11 == 0){
goto L29;
}
else {
goto L25;
}
L25:
LOGD("1aa:invoke-virtual \x76\x39\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x71\x75\x65\x73\x74\x42\x6f\x64\x79\x3b\x2d\x3e\x63\x6f\x6e\x74\x65\x6e\x74\x54\x79\x70\x65\x28\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x4d\x65\x64\x69\x61\x54\x79\x70\x65\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v15);
jclass &clz = cls7;
jmethodID &mid = mth17;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/RequestBody", "contentType", "()Lokhttp3/MediaType;");
jvalue args[] = {};
v7 = (jobject) env->CallObjectMethodA(v15, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("1b0:move-result-object \x76\x38");
if (v13) {
LOGD("env->DeleteLocalRef(%p):v13", v13);
env->DeleteLocalRef(v13);
}
v13 = (jobject) v7;
LOGD("1b2:if-eqz \x76\x38\x2c\x20\x2b\x31\x63");
if(v13 == NULL){
goto L27;
}
else {
goto L26;
}
L26:
LOGD("1b6:iget-object \x76\x38\x2c\x20\x76\x31\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x3b\x2d\x3e\x63\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x6f\x67\x67\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
jclass &clz = cls0;
jfieldID &fld = fld5;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/net/OkInterceptor", "c", "Lio/pro/edge/widget/event/net/OkInterceptor$Logger;");
v7 = (jobject) env->GetObjectField(v2,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v13) {
LOGD("env->DeleteLocalRef(%p):v13", v13);
env->DeleteLocalRef(v13);
}
v13 = (jobject) v7;
LOGD("1ba:new-instance \x76\x31\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v16) {
LOGD("env->DeleteLocalRef(%p):v16", v16);
env->DeleteLocalRef(v16);
}
jclass &clz = cls5;
D2C_RESOLVE_CLASS(clz,"java/lang/StringBuilder");
v16 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("1be:invoke-direct \x76\x31\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v16);
jclass &clz = cls5;
jmethodID &mid = mth5;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "<init>", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v16, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("1c4:const-string \x76\x31\x35\x2c\x20\x27\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65\x3a\x20\x27");
if (v22) {
LOGD("env->DeleteLocalRef(%p):v22", v22);
env->DeleteLocalRef(v22);
}
v22 = (jstring) env->NewStringUTF("\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65\x3a\x20");
LOGD("1c8:invoke-virtual \x76\x31\x30\x2c\x20\x76\x31\x35\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v16);
jclass &clz = cls5;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v22}};
v7 = (jobject) env->CallObjectMethodA(v16, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("1ce:invoke-virtual \x76\x39\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x71\x75\x65\x73\x74\x42\x6f\x64\x79\x3b\x2d\x3e\x63\x6f\x6e\x74\x65\x6e\x74\x54\x79\x70\x65\x28\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x4d\x65\x64\x69\x61\x54\x79\x70\x65\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v15);
jclass &clz = cls7;
jmethodID &mid = mth17;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/RequestBody", "contentType", "()Lokhttp3/MediaType;");
jvalue args[] = {};
v7 = (jobject) env->CallObjectMethodA(v15, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("1d4:move-result-object \x76\x31\x35");
if (v22) {
LOGD("env->DeleteLocalRef(%p):v22", v22);
env->DeleteLocalRef(v22);
}
v22 = (jobject) v7;
LOGD("1d6:invoke-virtual \x76\x31\x30\x2c\x20\x76\x31\x35\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v16);
jclass &clz = cls5;
jmethodID &mid = mth10;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/Object;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v22}};
v7 = (jobject) env->CallObjectMethodA(v16, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("1dc:invoke-virtual \x76\x31\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x74\x6f\x53\x74\x72\x69\x6e\x67\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v16);
jclass &clz = cls5;
jmethodID &mid = mth12;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "toString", "()Ljava/lang/String;");
jvalue args[] = {};
v7 = (jstring) env->CallObjectMethodA(v16, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("1e2:move-result-object \x76\x31\x30");
if (v16) {
LOGD("env->DeleteLocalRef(%p):v16", v16);
env->DeleteLocalRef(v16);
}
v16 = (jobject) v7;
LOGD("1e4:invoke-interface \x76\x38\x2c\x20\x76\x32\x2c\x20\x76\x31\x30\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x6f\x67\x67\x65\x72\x3b\x2d\x3e\x61\x28\x49\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v13);
jclass &clz = cls8;
jmethodID &mid = mth16;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/event/net/OkInterceptor$Logger", "a", "(ILjava/lang/String;)V");
jvalue args[] = {{.i = v6},{.l = v16}};
env->CallVoidMethodA(v13, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L27:
LOGD("1ea:invoke-virtual \x76\x39\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x71\x75\x65\x73\x74\x42\x6f\x64\x79\x3b\x2d\x3e\x63\x6f\x6e\x74\x65\x6e\x74\x4c\x65\x6e\x67\x74\x68\x28\x29\x4a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v15);
jclass &clz = cls7;
jmethodID &mid = mth13;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/RequestBody", "contentLength", "()J");
jvalue args[] = {};
v24 = (jlong) env->CallLongMethodA(v15, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("1f0:move-result-wide \x76\x31\x39");
v28 = (jlong) v24;
LOGD("1f2:cmp-long \x76\x38\x2c\x20\x76\x31\x39\x2c\x20\x76\x31\x37");
v14 = (v28 == v27) ? 0 : (v28 > v27) ? 1 : -1;
LOGD("1f6:if-eqz \x76\x38\x2c\x20\x2b\x31\x66");
if(v14 == 0){
goto L29;
}
else {
goto L28;
}
L28:
LOGD("1fa:iget-object \x76\x38\x2c\x20\x76\x31\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x3b\x2d\x3e\x63\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x6f\x67\x67\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
jclass &clz = cls0;
jfieldID &fld = fld5;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/net/OkInterceptor", "c", "Lio/pro/edge/widget/event/net/OkInterceptor$Logger;");
v7 = (jobject) env->GetObjectField(v2,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v13) {
LOGD("env->DeleteLocalRef(%p):v13", v13);
env->DeleteLocalRef(v13);
}
v13 = (jobject) v7;
LOGD("1fe:new-instance \x76\x31\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v16) {
LOGD("env->DeleteLocalRef(%p):v16", v16);
env->DeleteLocalRef(v16);
}
jclass &clz = cls5;
D2C_RESOLVE_CLASS(clz,"java/lang/StringBuilder");
v16 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("202:invoke-direct \x76\x31\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v16);
jclass &clz = cls5;
jmethodID &mid = mth5;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "<init>", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v16, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("208:const-string \x76\x31\x35\x2c\x20\x27\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x4c\x65\x6e\x67\x74\x68\x3a\x20\x27");
if (v22) {
LOGD("env->DeleteLocalRef(%p):v22", v22);
env->DeleteLocalRef(v22);
}
v22 = (jstring) env->NewStringUTF("\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x4c\x65\x6e\x67\x74\x68\x3a\x20");
LOGD("20c:invoke-virtual \x76\x31\x30\x2c\x20\x76\x31\x35\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v16);
jclass &clz = cls5;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v22}};
v7 = (jobject) env->CallObjectMethodA(v16, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
if (v29) {
LOGD("env->DeleteLocalRef(%p):v29", v29);
env->DeleteLocalRef(v29);
}
v29 = (jobject) env->NewLocalRef(v20);
LOGD("216:invoke-virtual \x76\x39\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x71\x75\x65\x73\x74\x42\x6f\x64\x79\x3b\x2d\x3e\x63\x6f\x6e\x74\x65\x6e\x74\x4c\x65\x6e\x67\x74\x68\x28\x29\x4a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v15);
jclass &clz = cls7;
jmethodID &mid = mth13;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/RequestBody", "contentLength", "()J");
jvalue args[] = {};
v24 = (jlong) env->CallLongMethodA(v15, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("21c:move-result-wide \x76\x31\x32");
v30 = (jlong) v24;
LOGD("21e:invoke-virtual \x76\x31\x30\x2c\x20\x76\x31\x32\x2c\x20\x76\x31\x33\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4a\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v16);
jclass &clz = cls5;
jmethodID &mid = mth14;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(J)Ljava/lang/StringBuilder;");
jvalue args[] = {{.j = (jlong) v30}};
v7 = (jobject) env->CallObjectMethodA(v16, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("224:invoke-virtual \x76\x31\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x74\x6f\x53\x74\x72\x69\x6e\x67\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v16);
jclass &clz = cls5;
jmethodID &mid = mth12;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "toString", "()Ljava/lang/String;");
jvalue args[] = {};
v7 = (jstring) env->CallObjectMethodA(v16, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("22a:move-result-object \x76\x31\x30");
if (v16) {
LOGD("env->DeleteLocalRef(%p):v16", v16);
env->DeleteLocalRef(v16);
}
v16 = (jobject) v7;
LOGD("22c:invoke-interface \x76\x38\x2c\x20\x76\x32\x2c\x20\x76\x31\x30\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x6f\x67\x67\x65\x72\x3b\x2d\x3e\x61\x28\x49\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v13);
jclass &clz = cls8;
jmethodID &mid = mth16;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/event/net/OkInterceptor$Logger", "a", "(ILjava/lang/String;)V");
jvalue args[] = {{.i = v6},{.l = v16}};
env->CallVoidMethodA(v13, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
goto L30;
L29:
if (v29) {
LOGD("env->DeleteLocalRef(%p):v29", v29);
env->DeleteLocalRef(v29);
}
v29 = (jobject) env->NewLocalRef(v20);
L30:
LOGD("238:invoke-virtual \x76\x34\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x71\x75\x65\x73\x74\x3b\x2d\x3e\x68\x65\x61\x64\x65\x72\x73\x28\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x48\x65\x61\x64\x65\x72\x73\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v9);
jclass &clz = cls4;
jmethodID &mid = mth18;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Request", "headers", "()Lokhttp3/Headers;");
jvalue args[] = {};
v7 = (jobject) env->CallObjectMethodA(v9, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("23e:move-result-object \x76\x38");
if (v13) {
LOGD("env->DeleteLocalRef(%p):v13", v13);
env->DeleteLocalRef(v13);
}
v13 = (jobject) v7;
LOGD("240:invoke-virtual \x76\x38\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x48\x65\x61\x64\x65\x72\x73\x3b\x2d\x3e\x73\x69\x7a\x65\x28\x29\x49");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v13);
jclass &clz = cls9;
jmethodID &mid = mth19;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Headers", "size", "()I");
jvalue args[] = {};
v5 = (jint) env->CallIntMethodA(v13, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("246:move-result \x76\x31\x30");
v31 = (jint) v5;
v19 = 0;
L31:
LOGD("24a:if-ge \x76\x31\x32\x2c\x20\x76\x31\x30\x2c\x20\x2b\x31\x63");
if(v19 >= v31) {
goto L36;
}
else {
goto L32;
}
L32:
LOGD("24e:invoke-virtual \x76\x38\x2c\x20\x76\x31\x32\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x48\x65\x61\x64\x65\x72\x73\x3b\x2d\x3e\x6e\x61\x6d\x65\x28\x49\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v13);
jclass &clz = cls9;
jmethodID &mid = mth20;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Headers", "name", "(I)Ljava/lang/String;");
jvalue args[] = {{.i = v19}};
v7 = (jstring) env->CallObjectMethodA(v13, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("254:move-result-object \x76\x31\x33");
if (v20) {
LOGD("env->DeleteLocalRef(%p):v20", v20);
env->DeleteLocalRef(v20);
}
v20 = (jobject) v7;
LOGD("256:const-string \x76\x31\x35\x2c\x20\x27\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65\x27");
if (v22) {
LOGD("env->DeleteLocalRef(%p):v22", v22);
env->DeleteLocalRef(v22);
}
v22 = (jstring) env->NewStringUTF("\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65");
LOGD("25a:invoke-virtual \x76\x31\x35\x2c\x20\x76\x31\x33\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x65\x71\x75\x61\x6c\x73\x49\x67\x6e\x6f\x72\x65\x43\x61\x73\x65\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v22);
jclass &clz = cls10;
jmethodID &mid = mth21;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "equalsIgnoreCase", "(Ljava/lang/String;)Z");
jvalue args[] = {{.l = v20}};
v5 = (jboolean) env->CallBooleanMethodA(v22, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("260:move-result \x76\x31\x35");
v32 = (jint) v5;
LOGD("262:if-nez \x76\x31\x35\x2c\x20\x2b\x64");
if(v32 != 0){
goto L35;
}
else {
goto L33;
}
L33:
LOGD("266:const-string \x76\x31\x35\x2c\x20\x27\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x4c\x65\x6e\x67\x74\x68\x27");
if (v22) {
LOGD("env->DeleteLocalRef(%p):v22", v22);
env->DeleteLocalRef(v22);
}
v22 = (jstring) env->NewStringUTF("\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x4c\x65\x6e\x67\x74\x68");
LOGD("26a:invoke-virtual \x76\x31\x35\x2c\x20\x76\x31\x33\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x65\x71\x75\x61\x6c\x73\x49\x67\x6e\x6f\x72\x65\x43\x61\x73\x65\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v22);
jclass &clz = cls10;
jmethodID &mid = mth21;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "equalsIgnoreCase", "(Ljava/lang/String;)Z");
jvalue args[] = {{.l = v20}};
v5 = (jboolean) env->CallBooleanMethodA(v22, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("270:move-result \x76\x31\x33");
v33 = (jint) v5;
LOGD("272:if-nez \x76\x31\x33\x2c\x20\x2b\x35");
if(v33 != 0){
goto L35;
}
else {
goto L34;
}
L34:
LOGD("276:invoke-virtual \x76\x31\x2c\x20\x76\x32\x2c\x20\x76\x38\x2c\x20\x76\x31\x32\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x3b\x2d\x3e\x61\x28\x49\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x48\x65\x61\x64\x65\x72\x73\x3b\x20\x49\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
jclass &clz = cls0;
jmethodID &mid = mth22;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/event/net/OkInterceptor", "a", "(ILokhttp3/Headers;I)V");
jvalue args[] = {{.i = v6},{.l = v13},{.i = v19}};
env->CallVoidMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L35:
LOGD("27c:add-int/lit8 \x76\x31\x32\x2c\x20\x76\x31\x32\x2c\x20\x31");
v19 = (v19 + 1);
goto L31;
L36:
LOGD("282:const-string \x76\x38\x2c\x20\x27\x2d\x2d\x3e\x20\x45\x4e\x44\x20\x27");
if (v13) {
LOGD("env->DeleteLocalRef(%p):v13", v13);
env->DeleteLocalRef(v13);
}
v13 = (jstring) env->NewStringUTF("\x2d\x2d\x3e\x20\x45\x4e\x44\x20");
LOGD("286:if-eqz \x76\x35\x2c\x20\x2b\x61\x62");
if(v12 == 0){
goto L46;
}
else {
goto L37;
}
L37:
LOGD("28a:if-nez \x76\x36\x2c\x20\x2b\x34");
if(v11 != 0){
goto L39;
}
else {
goto L38;
}
L38:
goto L46;
L39:
LOGD("292:invoke-virtual \x76\x34\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x71\x75\x65\x73\x74\x3b\x2d\x3e\x68\x65\x61\x64\x65\x72\x73\x28\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x48\x65\x61\x64\x65\x72\x73\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v9);
jclass &clz = cls4;
jmethodID &mid = mth18;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Request", "headers", "()Lokhttp3/Headers;");
jvalue args[] = {};
v7 = (jobject) env->CallObjectMethodA(v9, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("298:move-result-object \x76\x36");
if (v34) {
LOGD("env->DeleteLocalRef(%p):v34", v34);
env->DeleteLocalRef(v34);
}
v34 = (jobject) v7;
LOGD("29a:invoke-static \x76\x36\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x3b\x2d\x3e\x61\x28\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x48\x65\x61\x64\x65\x72\x73\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls0;
jmethodID &mid = mth23;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "io/pro/edge/widget/event/net/OkInterceptor", "a", "(Lokhttp3/Headers;)Z");
jvalue args[] = {{.l = v34}};
v5 = (jboolean) env->CallStaticBooleanMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("2a0:move-result \x76\x36");
v11 = (jint) v5;
LOGD("2a2:if-eqz \x76\x36\x2c\x20\x2b\x32\x33");
if(v11 == 0){
goto L41;
}
else {
goto L40;
}
L40:
LOGD("2a6:iget-object \x76\x36\x2c\x20\x76\x31\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x3b\x2d\x3e\x63\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x6f\x67\x67\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
jclass &clz = cls0;
jfieldID &fld = fld5;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/net/OkInterceptor", "c", "Lio/pro/edge/widget/event/net/OkInterceptor$Logger;");
v7 = (jobject) env->GetObjectField(v2,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v34) {
LOGD("env->DeleteLocalRef(%p):v34", v34);
env->DeleteLocalRef(v34);
}
v34 = (jobject) v7;
LOGD("2aa:new-instance \x76\x39\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v15) {
LOGD("env->DeleteLocalRef(%p):v15", v15);
env->DeleteLocalRef(v15);
}
jclass &clz = cls5;
D2C_RESOLVE_CLASS(clz,"java/lang/StringBuilder");
v15 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("2ae:invoke-direct \x76\x39\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v15);
jclass &clz = cls5;
jmethodID &mid = mth5;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "<init>", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v15, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("2b4:invoke-virtual \x76\x39\x2c\x20\x76\x38\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v15);
jclass &clz = cls5;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v13}};
v7 = (jobject) env->CallObjectMethodA(v15, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("2ba:invoke-virtual \x76\x34\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x71\x75\x65\x73\x74\x3b\x2d\x3e\x6d\x65\x74\x68\x6f\x64\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v9);
jclass &clz = cls4;
jmethodID &mid = mth7;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Request", "method", "()Ljava/lang/String;");
jvalue args[] = {};
v7 = (jstring) env->CallObjectMethodA(v9, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("2c0:move-result-object \x76\x38");
if (v13) {
LOGD("env->DeleteLocalRef(%p):v13", v13);
env->DeleteLocalRef(v13);
}
v13 = (jobject) v7;
LOGD("2c2:invoke-virtual \x76\x39\x2c\x20\x76\x38\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v15);
jclass &clz = cls5;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v13}};
v7 = (jobject) env->CallObjectMethodA(v15, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("2c8:const-string \x76\x38\x2c\x20\x27\x20\x28\x65\x6e\x63\x6f\x64\x65\x64\x20\x62\x6f\x64\x79\x20\x6f\x6d\x69\x74\x74\x65\x64\x29\x27");
if (v13) {
LOGD("env->DeleteLocalRef(%p):v13", v13);
env->DeleteLocalRef(v13);
}
v13 = (jstring) env->NewStringUTF("\x20\x28\x65\x6e\x63\x6f\x64\x65\x64\x20\x62\x6f\x64\x79\x20\x6f\x6d\x69\x74\x74\x65\x64\x29");
LOGD("2cc:invoke-virtual \x76\x39\x2c\x20\x76\x38\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v15);
jclass &clz = cls5;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v13}};
v7 = (jobject) env->CallObjectMethodA(v15, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("2d2:invoke-virtual \x76\x39\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x74\x6f\x53\x74\x72\x69\x6e\x67\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v15);
jclass &clz = cls5;
jmethodID &mid = mth12;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "toString", "()Ljava/lang/String;");
jvalue args[] = {};
v7 = (jstring) env->CallObjectMethodA(v15, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("2d8:move-result-object \x76\x38");
if (v13) {
LOGD("env->DeleteLocalRef(%p):v13", v13);
env->DeleteLocalRef(v13);
}
v13 = (jobject) v7;
LOGD("2da:invoke-interface \x76\x36\x2c\x20\x76\x32\x2c\x20\x76\x38\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x6f\x67\x67\x65\x72\x3b\x2d\x3e\x61\x28\x49\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v34);
jclass &clz = cls8;
jmethodID &mid = mth16;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/event/net/OkInterceptor$Logger", "a", "(ILjava/lang/String;)V");
jvalue args[] = {{.i = v6},{.l = v13}};
env->CallVoidMethodA(v34, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v20) {
LOGD("env->DeleteLocalRef(%p):v20", v20);
env->DeleteLocalRef(v20);
}
v20 = (jobject) env->NewLocalRef(v29);
goto L47;
L41:
LOGD("2e8:new-instance \x76\x36\x2c\x20\x4c\x6f\x6b\x69\x6f\x2f\x42\x75\x66\x66\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v34) {
LOGD("env->DeleteLocalRef(%p):v34", v34);
env->DeleteLocalRef(v34);
}
jclass &clz = cls11;
D2C_RESOLVE_CLASS(clz,"okio/Buffer");
v34 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("2ec:invoke-direct \x76\x36\x2c\x20\x4c\x6f\x6b\x69\x6f\x2f\x42\x75\x66\x66\x65\x72\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v34);
jclass &clz = cls11;
jmethodID &mid = mth24;
D2C_RESOLVE_METHOD(clz, mid, "okio/Buffer", "<init>", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v34, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("2f2:invoke-virtual \x76\x39\x2c\x20\x76\x36\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x71\x75\x65\x73\x74\x42\x6f\x64\x79\x3b\x2d\x3e\x77\x72\x69\x74\x65\x54\x6f\x28\x4c\x6f\x6b\x69\x6f\x2f\x42\x75\x66\x66\x65\x72\x65\x64\x53\x69\x6e\x6b\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v15);
jclass &clz = cls7;
jmethodID &mid = mth25;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/RequestBody", "writeTo", "(Lokio/BufferedSink;)V");
jvalue args[] = {{.l = v34}};
env->CallVoidMethodA(v15, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("2f8:sget-object \x76\x31\x30\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x3b\x2d\x3e\x61\x20\x4c\x6a\x61\x76\x61\x2f\x6e\x69\x6f\x2f\x63\x68\x61\x72\x73\x65\x74\x2f\x43\x68\x61\x72\x73\x65\x74\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v16) {
LOGD("env->DeleteLocalRef(%p):v16", v16);
env->DeleteLocalRef(v16);
}
jclass &clz = cls0;
jfieldID &fld = fld6;
D2C_RESOLVE_STATIC_FIELD(clz, fld, "io/pro/edge/widget/event/net/OkInterceptor", "a", "Ljava/nio/charset/Charset;");
v16 = (jobject) env->GetStaticObjectField(clz,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("2fc:invoke-virtual \x76\x39\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x71\x75\x65\x73\x74\x42\x6f\x64\x79\x3b\x2d\x3e\x63\x6f\x6e\x74\x65\x6e\x74\x54\x79\x70\x65\x28\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x4d\x65\x64\x69\x61\x54\x79\x70\x65\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v15);
jclass &clz = cls7;
jmethodID &mid = mth17;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/RequestBody", "contentType", "()Lokhttp3/MediaType;");
jvalue args[] = {};
v7 = (jobject) env->CallObjectMethodA(v15, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("302:move-result-object \x76\x31\x32");
if (v18) {
LOGD("env->DeleteLocalRef(%p):v18", v18);
env->DeleteLocalRef(v18);
}
v18 = (jobject) v7;
LOGD("304:if-eqz \x76\x31\x32\x2c\x20\x2b\x38");
if(v18 == NULL){
goto L43;
}
else {
goto L42;
}
L42:
LOGD("308:sget-object \x76\x31\x30\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x3b\x2d\x3e\x61\x20\x4c\x6a\x61\x76\x61\x2f\x6e\x69\x6f\x2f\x63\x68\x61\x72\x73\x65\x74\x2f\x43\x68\x61\x72\x73\x65\x74\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v16) {
LOGD("env->DeleteLocalRef(%p):v16", v16);
env->DeleteLocalRef(v16);
}
jclass &clz = cls0;
jfieldID &fld = fld6;
D2C_RESOLVE_STATIC_FIELD(clz, fld, "io/pro/edge/widget/event/net/OkInterceptor", "a", "Ljava/nio/charset/Charset;");
v16 = (jobject) env->GetStaticObjectField(clz,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("30c:invoke-virtual \x76\x31\x32\x2c\x20\x76\x31\x30\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x4d\x65\x64\x69\x61\x54\x79\x70\x65\x3b\x2d\x3e\x63\x68\x61\x72\x73\x65\x74\x28\x4c\x6a\x61\x76\x61\x2f\x6e\x69\x6f\x2f\x63\x68\x61\x72\x73\x65\x74\x2f\x43\x68\x61\x72\x73\x65\x74\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6e\x69\x6f\x2f\x63\x68\x61\x72\x73\x65\x74\x2f\x43\x68\x61\x72\x73\x65\x74\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v18);
jclass &clz = cls12;
jmethodID &mid = mth26;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/MediaType", "charset", "(Ljava/nio/charset/Charset;)Ljava/nio/charset/Charset;");
jvalue args[] = {{.l = v16}};
v7 = (jobject) env->CallObjectMethodA(v18, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("312:move-result-object \x76\x31\x30");
if (v16) {
LOGD("env->DeleteLocalRef(%p):v16", v16);
env->DeleteLocalRef(v16);
}
v16 = (jobject) v7;
L43:
LOGD("314:iget-object \x76\x31\x32\x2c\x20\x76\x31\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x3b\x2d\x3e\x63\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x6f\x67\x67\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
jclass &clz = cls0;
jfieldID &fld = fld5;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/net/OkInterceptor", "c", "Lio/pro/edge/widget/event/net/OkInterceptor$Logger;");
v7 = (jobject) env->GetObjectField(v2,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v18) {
LOGD("env->DeleteLocalRef(%p):v18", v18);
env->DeleteLocalRef(v18);
}
v18 = (jobject) v7;
if (v20) {
LOGD("env->DeleteLocalRef(%p):v20", v20);
env->DeleteLocalRef(v20);
}
v20 = (jobject) env->NewLocalRef(v29);
LOGD("31c:invoke-interface \x76\x31\x32\x2c\x20\x76\x32\x2c\x20\x76\x31\x33\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x6f\x67\x67\x65\x72\x3b\x2d\x3e\x61\x28\x49\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v18);
jclass &clz = cls8;
jmethodID &mid = mth16;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/event/net/OkInterceptor$Logger", "a", "(ILjava/lang/String;)V");
jvalue args[] = {{.i = v6},{.l = v20}};
env->CallVoidMethodA(v18, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("322:invoke-static \x76\x36\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x3b\x2d\x3e\x61\x28\x4c\x6f\x6b\x69\x6f\x2f\x42\x75\x66\x66\x65\x72\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls0;
jmethodID &mid = mth27;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "io/pro/edge/widget/event/net/OkInterceptor", "a", "(Lokio/Buffer;)Z");
jvalue args[] = {{.l = v34}};
v5 = (jboolean) env->CallStaticBooleanMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("328:move-result \x76\x31\x32");
v19 = (jint) v5;
LOGD("32a:if-eqz \x76\x31\x32\x2c\x20\x2b\x33\x31");
if(v19 == 0){
goto L45;
}
else {
goto L44;
}
L44:
LOGD("32e:iget-object \x76\x31\x32\x2c\x20\x76\x31\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x3b\x2d\x3e\x63\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x6f\x67\x67\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
jclass &clz = cls0;
jfieldID &fld = fld5;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/net/OkInterceptor", "c", "Lio/pro/edge/widget/event/net/OkInterceptor$Logger;");
v7 = (jobject) env->GetObjectField(v2,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v18) {
LOGD("env->DeleteLocalRef(%p):v18", v18);
env->DeleteLocalRef(v18);
}
v18 = (jobject) v7;
LOGD("332:invoke-virtual \x76\x36\x2c\x20\x76\x31\x30\x2c\x20\x4c\x6f\x6b\x69\x6f\x2f\x42\x75\x66\x66\x65\x72\x3b\x2d\x3e\x72\x65\x61\x64\x53\x74\x72\x69\x6e\x67\x28\x4c\x6a\x61\x76\x61\x2f\x6e\x69\x6f\x2f\x63\x68\x61\x72\x73\x65\x74\x2f\x43\x68\x61\x72\x73\x65\x74\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v34);
jclass &clz = cls11;
jmethodID &mid = mth28;
D2C_RESOLVE_METHOD(clz, mid, "okio/Buffer", "readString", "(Ljava/nio/charset/Charset;)Ljava/lang/String;");
jvalue args[] = {{.l = v16}};
v7 = (jstring) env->CallObjectMethodA(v34, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("338:move-result-object \x76\x36");
if (v34) {
LOGD("env->DeleteLocalRef(%p):v34", v34);
env->DeleteLocalRef(v34);
}
v34 = (jobject) v7;
LOGD("33a:invoke-interface \x76\x31\x32\x2c\x20\x76\x32\x2c\x20\x76\x36\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x6f\x67\x67\x65\x72\x3b\x2d\x3e\x61\x28\x49\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v18);
jclass &clz = cls8;
jmethodID &mid = mth16;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/event/net/OkInterceptor$Logger", "a", "(ILjava/lang/String;)V");
jvalue args[] = {{.i = v6},{.l = v34}};
env->CallVoidMethodA(v18, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("340:iget-object \x76\x36\x2c\x20\x76\x31\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x3b\x2d\x3e\x63\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x6f\x67\x67\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
jclass &clz = cls0;
jfieldID &fld = fld5;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/net/OkInterceptor", "c", "Lio/pro/edge/widget/event/net/OkInterceptor$Logger;");
v7 = (jobject) env->GetObjectField(v2,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v34) {
LOGD("env->DeleteLocalRef(%p):v34", v34);
env->DeleteLocalRef(v34);
}
v34 = (jobject) v7;
LOGD("344:new-instance \x76\x31\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v16) {
LOGD("env->DeleteLocalRef(%p):v16", v16);
env->DeleteLocalRef(v16);
}
jclass &clz = cls5;
D2C_RESOLVE_CLASS(clz,"java/lang/StringBuilder");
v16 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("348:invoke-direct \x76\x31\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v16);
jclass &clz = cls5;
jmethodID &mid = mth5;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "<init>", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v16, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("34e:invoke-virtual \x76\x31\x30\x2c\x20\x76\x38\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v16);
jclass &clz = cls5;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v13}};
v7 = (jobject) env->CallObjectMethodA(v16, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("354:invoke-virtual \x76\x34\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x71\x75\x65\x73\x74\x3b\x2d\x3e\x6d\x65\x74\x68\x6f\x64\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v9);
jclass &clz = cls4;
jmethodID &mid = mth7;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Request", "method", "()Ljava/lang/String;");
jvalue args[] = {};
v7 = (jstring) env->CallObjectMethodA(v9, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("35a:move-result-object \x76\x38");
if (v13) {
LOGD("env->DeleteLocalRef(%p):v13", v13);
env->DeleteLocalRef(v13);
}
v13 = (jobject) v7;
LOGD("35c:invoke-virtual \x76\x31\x30\x2c\x20\x76\x38\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v16);
jclass &clz = cls5;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v13}};
v7 = (jobject) env->CallObjectMethodA(v16, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("362:invoke-virtual \x76\x31\x30\x2c\x20\x76\x31\x34\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v16);
jclass &clz = cls5;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v21}};
v7 = (jobject) env->CallObjectMethodA(v16, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("368:invoke-virtual \x76\x39\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x71\x75\x65\x73\x74\x42\x6f\x64\x79\x3b\x2d\x3e\x63\x6f\x6e\x74\x65\x6e\x74\x4c\x65\x6e\x67\x74\x68\x28\x29\x4a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v15);
jclass &clz = cls7;
jmethodID &mid = mth13;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/RequestBody", "contentLength", "()J");
jvalue args[] = {};
v24 = (jlong) env->CallLongMethodA(v15, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("36e:move-result-wide \x76\x38");
v35 = (jlong) v24;
LOGD("370:invoke-virtual \x76\x31\x30\x2c\x20\x76\x38\x2c\x20\x76\x39\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4a\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v16);
jclass &clz = cls5;
jmethodID &mid = mth14;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(J)Ljava/lang/StringBuilder;");
jvalue args[] = {{.j = (jlong) v35}};
v7 = (jobject) env->CallObjectMethodA(v16, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("376:invoke-virtual \x76\x31\x30\x2c\x20\x76\x31\x31\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v16);
jclass &clz = cls5;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v17}};
v7 = (jobject) env->CallObjectMethodA(v16, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("37c:invoke-virtual \x76\x31\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x74\x6f\x53\x74\x72\x69\x6e\x67\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v16);
jclass &clz = cls5;
jmethodID &mid = mth12;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "toString", "()Ljava/lang/String;");
jvalue args[] = {};
v7 = (jstring) env->CallObjectMethodA(v16, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("382:move-result-object \x76\x38");
if (v13) {
LOGD("env->DeleteLocalRef(%p):v13", v13);
env->DeleteLocalRef(v13);
}
v13 = (jobject) v7;
LOGD("384:invoke-interface \x76\x36\x2c\x20\x76\x32\x2c\x20\x76\x38\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x6f\x67\x67\x65\x72\x3b\x2d\x3e\x61\x28\x49\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v34);
jclass &clz = cls8;
jmethodID &mid = mth16;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/event/net/OkInterceptor$Logger", "a", "(ILjava/lang/String;)V");
jvalue args[] = {{.i = v6},{.l = v13}};
env->CallVoidMethodA(v34, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
goto L47;
L45:
LOGD("38c:iget-object \x76\x36\x2c\x20\x76\x31\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x3b\x2d\x3e\x63\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x6f\x67\x67\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
jclass &clz = cls0;
jfieldID &fld = fld5;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/net/OkInterceptor", "c", "Lio/pro/edge/widget/event/net/OkInterceptor$Logger;");
v7 = (jobject) env->GetObjectField(v2,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v34) {
LOGD("env->DeleteLocalRef(%p):v34", v34);
env->DeleteLocalRef(v34);
}
v34 = (jobject) v7;
LOGD("390:new-instance \x76\x31\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v16) {
LOGD("env->DeleteLocalRef(%p):v16", v16);
env->DeleteLocalRef(v16);
}
jclass &clz = cls5;
D2C_RESOLVE_CLASS(clz,"java/lang/StringBuilder");
v16 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("394:invoke-direct \x76\x31\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v16);
jclass &clz = cls5;
jmethodID &mid = mth5;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "<init>", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v16, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("39a:invoke-virtual \x76\x31\x30\x2c\x20\x76\x38\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v16);
jclass &clz = cls5;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v13}};
v7 = (jobject) env->CallObjectMethodA(v16, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("3a0:invoke-virtual \x76\x34\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x71\x75\x65\x73\x74\x3b\x2d\x3e\x6d\x65\x74\x68\x6f\x64\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v9);
jclass &clz = cls4;
jmethodID &mid = mth7;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Request", "method", "()Ljava/lang/String;");
jvalue args[] = {};
v7 = (jstring) env->CallObjectMethodA(v9, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("3a6:move-result-object \x76\x38");
if (v13) {
LOGD("env->DeleteLocalRef(%p):v13", v13);
env->DeleteLocalRef(v13);
}
v13 = (jobject) v7;
LOGD("3a8:invoke-virtual \x76\x31\x30\x2c\x20\x76\x38\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v16);
jclass &clz = cls5;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v13}};
v7 = (jobject) env->CallObjectMethodA(v16, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("3ae:const-string \x76\x38\x2c\x20\x27\x20\x28\x62\x69\x6e\x61\x72\x79\x20\x27");
if (v13) {
LOGD("env->DeleteLocalRef(%p):v13", v13);
env->DeleteLocalRef(v13);
}
v13 = (jstring) env->NewStringUTF("\x20\x28\x62\x69\x6e\x61\x72\x79\x20");
LOGD("3b2:invoke-virtual \x76\x31\x30\x2c\x20\x76\x38\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v16);
jclass &clz = cls5;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v13}};
v7 = (jobject) env->CallObjectMethodA(v16, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("3b8:invoke-virtual \x76\x39\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x71\x75\x65\x73\x74\x42\x6f\x64\x79\x3b\x2d\x3e\x63\x6f\x6e\x74\x65\x6e\x74\x4c\x65\x6e\x67\x74\x68\x28\x29\x4a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v15);
jclass &clz = cls7;
jmethodID &mid = mth13;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/RequestBody", "contentLength", "()J");
jvalue args[] = {};
v24 = (jlong) env->CallLongMethodA(v15, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("3be:move-result-wide \x76\x38");
v35 = (jlong) v24;
LOGD("3c0:invoke-virtual \x76\x31\x30\x2c\x20\x76\x38\x2c\x20\x76\x39\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4a\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v16);
jclass &clz = cls5;
jmethodID &mid = mth14;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(J)Ljava/lang/StringBuilder;");
jvalue args[] = {{.j = (jlong) v35}};
v7 = (jobject) env->CallObjectMethodA(v16, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("3c6:invoke-virtual \x76\x31\x30\x2c\x20\x76\x37\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v16);
jclass &clz = cls5;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v26}};
v7 = (jobject) env->CallObjectMethodA(v16, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("3cc:invoke-virtual \x76\x31\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x74\x6f\x53\x74\x72\x69\x6e\x67\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v16);
jclass &clz = cls5;
jmethodID &mid = mth12;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "toString", "()Ljava/lang/String;");
jvalue args[] = {};
v7 = (jstring) env->CallObjectMethodA(v16, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("3d2:move-result-object \x76\x38");
if (v13) {
LOGD("env->DeleteLocalRef(%p):v13", v13);
env->DeleteLocalRef(v13);
}
v13 = (jobject) v7;
LOGD("3d4:invoke-interface \x76\x36\x2c\x20\x76\x32\x2c\x20\x76\x38\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x6f\x67\x67\x65\x72\x3b\x2d\x3e\x61\x28\x49\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v34);
jclass &clz = cls8;
jmethodID &mid = mth16;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/event/net/OkInterceptor$Logger", "a", "(ILjava/lang/String;)V");
jvalue args[] = {{.i = v6},{.l = v13}};
env->CallVoidMethodA(v34, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
goto L47;
L46:
if (v20) {
LOGD("env->DeleteLocalRef(%p):v20", v20);
env->DeleteLocalRef(v20);
}
v20 = (jobject) env->NewLocalRef(v29);
LOGD("3e0:iget-object \x76\x36\x2c\x20\x76\x31\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x3b\x2d\x3e\x63\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x6f\x67\x67\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
jclass &clz = cls0;
jfieldID &fld = fld5;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/net/OkInterceptor", "c", "Lio/pro/edge/widget/event/net/OkInterceptor$Logger;");
v7 = (jobject) env->GetObjectField(v2,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v34) {
LOGD("env->DeleteLocalRef(%p):v34", v34);
env->DeleteLocalRef(v34);
}
v34 = (jobject) v7;
LOGD("3e4:new-instance \x76\x39\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v15) {
LOGD("env->DeleteLocalRef(%p):v15", v15);
env->DeleteLocalRef(v15);
}
jclass &clz = cls5;
D2C_RESOLVE_CLASS(clz,"java/lang/StringBuilder");
v15 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("3e8:invoke-direct \x76\x39\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v15);
jclass &clz = cls5;
jmethodID &mid = mth5;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "<init>", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v15, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("3ee:invoke-virtual \x76\x39\x2c\x20\x76\x38\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v15);
jclass &clz = cls5;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v13}};
v7 = (jobject) env->CallObjectMethodA(v15, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("3f4:invoke-virtual \x76\x34\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x71\x75\x65\x73\x74\x3b\x2d\x3e\x6d\x65\x74\x68\x6f\x64\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v9);
jclass &clz = cls4;
jmethodID &mid = mth7;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Request", "method", "()Ljava/lang/String;");
jvalue args[] = {};
v7 = (jstring) env->CallObjectMethodA(v9, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("3fa:move-result-object \x76\x38");
if (v13) {
LOGD("env->DeleteLocalRef(%p):v13", v13);
env->DeleteLocalRef(v13);
}
v13 = (jobject) v7;
LOGD("3fc:invoke-virtual \x76\x39\x2c\x20\x76\x38\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v15);
jclass &clz = cls5;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v13}};
v7 = (jobject) env->CallObjectMethodA(v15, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("402:invoke-virtual \x76\x39\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x74\x6f\x53\x74\x72\x69\x6e\x67\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v15);
jclass &clz = cls5;
jmethodID &mid = mth12;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "toString", "()Ljava/lang/String;");
jvalue args[] = {};
v7 = (jstring) env->CallObjectMethodA(v15, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("408:move-result-object \x76\x38");
if (v13) {
LOGD("env->DeleteLocalRef(%p):v13", v13);
env->DeleteLocalRef(v13);
}
v13 = (jobject) v7;
LOGD("40a:invoke-interface \x76\x36\x2c\x20\x76\x32\x2c\x20\x76\x38\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x6f\x67\x67\x65\x72\x3b\x2d\x3e\x61\x28\x49\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v34);
jclass &clz = cls8;
jmethodID &mid = mth16;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/event/net/OkInterceptor$Logger", "a", "(ILjava/lang/String;)V");
jvalue args[] = {{.i = v6},{.l = v13}};
env->CallVoidMethodA(v34, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L47:
LOGD("410:invoke-static \x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x79\x73\x74\x65\x6d\x3b\x2d\x3e\x6e\x61\x6e\x6f\x54\x69\x6d\x65\x28\x29\x4a");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls13;
jmethodID &mid = mth29;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "java/lang/System", "nanoTime", "()J");
jvalue args[] = {};
v24 = (jlong) env->CallStaticLongMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("416:move-result-wide \x76\x38");
v35 = (jlong) v24;
L48:
LOGD("418:invoke-interface \x76\x30\x2c\x20\x76\x34\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x43\x68\x61\x69\x6e\x3b\x2d\x3e\x70\x72\x6f\x63\x65\x65\x64\x28\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x71\x75\x65\x73\x74\x3b\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x3b");
{
#define EX_HANDLE EX_LandingPad_48
D2C_NOT_NULL(v3);
jclass &clz = cls2;
jmethodID &mid = mth2;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Interceptor$Chain", "proceed", "(Lokhttp3/Request;)Lokhttp3/Response;");
jvalue args[] = {{.l = v9}};
v7 = (jobject) env->CallObjectMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L49:
LOGD("41e:move-result-object \x76\x30");
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
v3 = (jobject) v7;
LOGD("420:sget-object \x76\x34\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x63\x6f\x6e\x63\x75\x72\x72\x65\x6e\x74\x2f\x54\x69\x6d\x65\x55\x6e\x69\x74\x3b\x2d\x3e\x4e\x41\x4e\x4f\x53\x45\x43\x4f\x4e\x44\x53\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x63\x6f\x6e\x63\x75\x72\x72\x65\x6e\x74\x2f\x54\x69\x6d\x65\x55\x6e\x69\x74\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v9) {
LOGD("env->DeleteLocalRef(%p):v9", v9);
env->DeleteLocalRef(v9);
}
jclass &clz = cls14;
jfieldID &fld = fld7;
D2C_RESOLVE_STATIC_FIELD(clz, fld, "java/util/concurrent/TimeUnit", "NANOSECONDS", "Ljava/util/concurrent/TimeUnit;");
v9 = (jobject) env->GetStaticObjectField(clz,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("424:invoke-static \x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x79\x73\x74\x65\x6d\x3b\x2d\x3e\x6e\x61\x6e\x6f\x54\x69\x6d\x65\x28\x29\x4a");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls13;
jmethodID &mid = mth29;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "java/lang/System", "nanoTime", "()J");
jvalue args[] = {};
v24 = (jlong) env->CallStaticLongMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("42a:move-result-wide \x76\x32\x31");
v36 = (jlong) v24;
LOGD("42c:sub-long \x76\x38\x2c\x20\x76\x32\x31\x2c\x20\x76\x38");
v35 = (v36 - v35);
LOGD("430:invoke-virtual \x76\x34\x2c\x20\x76\x38\x2c\x20\x76\x39\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x63\x6f\x6e\x63\x75\x72\x72\x65\x6e\x74\x2f\x54\x69\x6d\x65\x55\x6e\x69\x74\x3b\x2d\x3e\x74\x6f\x4d\x69\x6c\x6c\x69\x73\x28\x4a\x29\x4a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v9);
jclass &clz = cls14;
jmethodID &mid = mth30;
D2C_RESOLVE_METHOD(clz, mid, "java/util/concurrent/TimeUnit", "toMillis", "(J)J");
jvalue args[] = {{.j = (jlong) v35}};
v24 = (jlong) env->CallLongMethodA(v9, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("436:move-result-wide \x76\x38");
v35 = (jlong) v24;
LOGD("438:invoke-virtual \x76\x30\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x3b\x2d\x3e\x62\x6f\x64\x79\x28\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x42\x6f\x64\x79\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls15;
jmethodID &mid = mth31;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Response", "body", "()Lokhttp3/ResponseBody;");
jvalue args[] = {};
v7 = (jobject) env->CallObjectMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("43e:move-result-object \x76\x34");
if (v9) {
LOGD("env->DeleteLocalRef(%p):v9", v9);
env->DeleteLocalRef(v9);
}
v9 = (jobject) v7;
if (v34) {
LOGD("env->DeleteLocalRef(%p):v34", v34);
env->DeleteLocalRef(v34);
}
v34 = (jobject) env->NewLocalRef(v17);
LOGD("442:invoke-virtual \x76\x34\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x42\x6f\x64\x79\x3b\x2d\x3e\x63\x6f\x6e\x74\x65\x6e\x74\x4c\x65\x6e\x67\x74\x68\x28\x29\x4a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v9);
jclass &clz = cls16;
jmethodID &mid = mth32;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/ResponseBody", "contentLength", "()J");
jvalue args[] = {};
v24 = (jlong) env->CallLongMethodA(v9, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("448:move-result-wide \x76\x31\x30");
v37 = (jlong) v24;
LOGD("44a:cmp-long \x76\x31\x32\x2c\x20\x76\x31\x30\x2c\x20\x76\x31\x37");
v19 = (v37 == v27) ? 0 : (v37 > v27) ? 1 : -1;
LOGD("44e:if-eqz \x76\x31\x32\x2c\x20\x2b\x31\x34");
if(v19 == 0){
goto L51;
}
else {
goto L50;
}
L50:
LOGD("452:new-instance \x76\x31\x32\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v18) {
LOGD("env->DeleteLocalRef(%p):v18", v18);
env->DeleteLocalRef(v18);
}
jclass &clz = cls5;
D2C_RESOLVE_CLASS(clz,"java/lang/StringBuilder");
v18 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("456:invoke-direct \x76\x31\x32\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v18);
jclass &clz = cls5;
jmethodID &mid = mth5;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "<init>", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v18, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("45c:invoke-virtual \x76\x31\x32\x2c\x20\x76\x31\x30\x2c\x20\x76\x31\x31\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4a\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v18);
jclass &clz = cls5;
jmethodID &mid = mth14;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(J)Ljava/lang/StringBuilder;");
jvalue args[] = {{.j = (jlong) v37}};
v7 = (jobject) env->CallObjectMethodA(v18, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("462:const-string \x76\x31\x35\x2c\x20\x27\x2d\x62\x79\x74\x65\x27");
if (v22) {
LOGD("env->DeleteLocalRef(%p):v22", v22);
env->DeleteLocalRef(v22);
}
v22 = (jstring) env->NewStringUTF("\x2d\x62\x79\x74\x65");
LOGD("466:invoke-virtual \x76\x31\x32\x2c\x20\x76\x31\x35\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v18);
jclass &clz = cls5;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v22}};
v7 = (jobject) env->CallObjectMethodA(v18, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("46c:invoke-virtual \x76\x31\x32\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x74\x6f\x53\x74\x72\x69\x6e\x67\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v18);
jclass &clz = cls5;
jmethodID &mid = mth12;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "toString", "()Ljava/lang/String;");
jvalue args[] = {};
v7 = (jstring) env->CallObjectMethodA(v18, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("472:move-result-object \x76\x31\x32");
if (v18) {
LOGD("env->DeleteLocalRef(%p):v18", v18);
env->DeleteLocalRef(v18);
}
v18 = (jobject) v7;
goto L52;
L51:
LOGD("476:const-string \x76\x31\x32\x2c\x20\x27\x75\x6e\x6b\x6e\x6f\x77\x6e\x2d\x6c\x65\x6e\x67\x74\x68\x27");
if (v18) {
LOGD("env->DeleteLocalRef(%p):v18", v18);
env->DeleteLocalRef(v18);
}
v18 = (jstring) env->NewStringUTF("\x75\x6e\x6b\x6e\x6f\x77\x6e\x2d\x6c\x65\x6e\x67\x74\x68");
L52:
LOGD("47a:sget-object \x76\x31\x35\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x65\x76\x65\x6c\x3b\x2d\x3e\x42\x41\x53\x49\x43\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x65\x76\x65\x6c\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v22) {
LOGD("env->DeleteLocalRef(%p):v22", v22);
env->DeleteLocalRef(v22);
}
jclass &clz = cls3;
jfieldID &fld = fld8;
D2C_RESOLVE_STATIC_FIELD(clz, fld, "io/pro/edge/widget/event/net/OkInterceptor$Level", "BASIC", "Lio/pro/edge/widget/event/net/OkInterceptor$Level;");
v22 = (jobject) env->GetStaticObjectField(clz,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v38) {
LOGD("env->DeleteLocalRef(%p):v38", v38);
env->DeleteLocalRef(v38);
}
v38 = (jobject) env->NewLocalRef(v34);
LOGD("482:const-string \x76\x36\x2c\x20\x27\x20\x62\x6f\x64\x79\x27");
if (v34) {
LOGD("env->DeleteLocalRef(%p):v34", v34);
env->DeleteLocalRef(v34);
}
v34 = (jstring) env->NewStringUTF("\x20\x62\x6f\x64\x79");
v39 = v37;
LOGD("48a:const-string \x76\x31\x30\x2c\x20\x27\x2c\x20\x27");
if (v16) {
LOGD("env->DeleteLocalRef(%p):v16", v16);
env->DeleteLocalRef(v16);
}
v16 = (jstring) env->NewStringUTF("\x2c\x20");
LOGD("48e:const-string \x76\x31\x31\x2c\x20\x27\x6d\x73\x27");
if (v17) {
LOGD("env->DeleteLocalRef(%p):v17", v17);
env->DeleteLocalRef(v17);
}
v17 = (jstring) env->NewStringUTF("\x6d\x73");
if (v40) {
LOGD("env->DeleteLocalRef(%p):v40", v40);
env->DeleteLocalRef(v40);
}
v40 = (jobject) env->NewLocalRef(v26);
LOGD("496:const-string \x76\x37\x2c\x20\x27\x3c\x2d\x2d\x20\x27");
if (v26) {
LOGD("env->DeleteLocalRef(%p):v26", v26);
env->DeleteLocalRef(v26);
}
v26 = (jstring) env->NewStringUTF("\x3c\x2d\x2d\x20");
LOGD("49a:if-ne \x76\x33\x2c\x20\x76\x31\x35\x2c\x20\x2b\x37\x33");
if(!d2c_is_same_object(env,v8,v22)) {
goto L61;
}
else {
goto L53;
}
L53:
LOGD("49e:invoke-virtual \x76\x30\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x3b\x2d\x3e\x63\x6f\x64\x65\x28\x29\x49");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls15;
jmethodID &mid = mth33;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Response", "code", "()I");
jvalue args[] = {};
v5 = (jint) env->CallIntMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("4a4:move-result \x76\x33");
v41 = (jint) v5;
v32 = 302;
LOGD("4aa:if-ne \x76\x33\x2c\x20\x76\x31\x35\x2c\x20\x2b\x36\x62");
if(v41 != v32) {
goto L61;
}
else {
goto L54;
}
L54:
LOGD("4ae:iget-object \x76\x33\x2c\x20\x76\x31\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x3b\x2d\x3e\x63\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x6f\x67\x67\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
jclass &clz = cls0;
jfieldID &fld = fld5;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/net/OkInterceptor", "c", "Lio/pro/edge/widget/event/net/OkInterceptor$Logger;");
v7 = (jobject) env->GetObjectField(v2,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jobject) v7;
LOGD("4b2:new-instance \x76\x31\x35\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v22) {
LOGD("env->DeleteLocalRef(%p):v22", v22);
env->DeleteLocalRef(v22);
}
jclass &clz = cls5;
D2C_RESOLVE_CLASS(clz,"java/lang/StringBuilder");
v22 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("4b6:invoke-direct \x76\x31\x35\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v22);
jclass &clz = cls5;
jmethodID &mid = mth5;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "<init>", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v22, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("4bc:invoke-virtual \x76\x31\x35\x2c\x20\x76\x37\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v22);
jclass &clz = cls5;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v26}};
v7 = (jobject) env->CallObjectMethodA(v22, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("4c2:invoke-virtual \x76\x30\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x3b\x2d\x3e\x63\x6f\x64\x65\x28\x29\x49");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls15;
jmethodID &mid = mth33;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Response", "code", "()I");
jvalue args[] = {};
v5 = (jint) env->CallIntMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("4c8:move-result \x76\x37");
v42 = (jint) v5;
LOGD("4ca:invoke-virtual \x76\x31\x35\x2c\x20\x76\x37\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x49\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v22);
jclass &clz = cls5;
jmethodID &mid = mth34;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(I)Ljava/lang/StringBuilder;");
jvalue args[] = {{.i = v42}};
v7 = (jobject) env->CallObjectMethodA(v22, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("4d0:invoke-virtual \x76\x30\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x3b\x2d\x3e\x6d\x65\x73\x73\x61\x67\x65\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls15;
jmethodID &mid = mth35;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Response", "message", "()Ljava/lang/String;");
jvalue args[] = {};
v7 = (jstring) env->CallObjectMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("4d6:move-result-object \x76\x37");
if (v26) {
LOGD("env->DeleteLocalRef(%p):v26", v26);
env->DeleteLocalRef(v26);
}
v26 = (jobject) v7;
LOGD("4d8:invoke-virtual \x76\x37\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x69\x73\x45\x6d\x70\x74\x79\x28\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v26);
jclass &clz = cls10;
jmethodID &mid = mth36;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "isEmpty", "()Z");
jvalue args[] = {};
v5 = (jboolean) env->CallBooleanMethodA(v26, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("4de:move-result \x76\x37");
v42 = (jint) v5;
LOGD("4e0:if-eqz \x76\x37\x2c\x20\x2b\x35");
if(v42 == 0){
goto L56;
}
else {
goto L55;
}
L55:
if (v43) {
LOGD("env->DeleteLocalRef(%p):v43", v43);
env->DeleteLocalRef(v43);
}
v43 = (jobject) env->NewLocalRef(v20);
goto L57;
L56:
LOGD("4ea:new-instance \x76\x37\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v26) {
LOGD("env->DeleteLocalRef(%p):v26", v26);
env->DeleteLocalRef(v26);
}
jclass &clz = cls5;
D2C_RESOLVE_CLASS(clz,"java/lang/StringBuilder");
v26 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("4ee:invoke-direct \x76\x37\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v26);
jclass &clz = cls5;
jmethodID &mid = mth5;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "<init>", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v26, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v43) {
LOGD("env->DeleteLocalRef(%p):v43", v43);
env->DeleteLocalRef(v43);
}
v43 = (jobject) env->NewLocalRef(v20);
v33 = 32;
LOGD("4fc:invoke-virtual \x76\x37\x2c\x20\x76\x31\x33\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x43\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v26);
jclass &clz = cls5;
jmethodID &mid = mth8;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(C)Ljava/lang/StringBuilder;");
jvalue args[] = {{.c = (jchar) v33}};
v7 = (jobject) env->CallObjectMethodA(v26, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("502:invoke-virtual \x76\x30\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x3b\x2d\x3e\x6d\x65\x73\x73\x61\x67\x65\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls15;
jmethodID &mid = mth35;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Response", "message", "()Ljava/lang/String;");
jvalue args[] = {};
v7 = (jstring) env->CallObjectMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("508:move-result-object \x76\x31\x33");
if (v20) {
LOGD("env->DeleteLocalRef(%p):v20", v20);
env->DeleteLocalRef(v20);
}
v20 = (jobject) v7;
LOGD("50a:invoke-virtual \x76\x37\x2c\x20\x76\x31\x33\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v26);
jclass &clz = cls5;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v20}};
v7 = (jobject) env->CallObjectMethodA(v26, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("510:invoke-virtual \x76\x37\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x74\x6f\x53\x74\x72\x69\x6e\x67\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v26);
jclass &clz = cls5;
jmethodID &mid = mth12;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "toString", "()Ljava/lang/String;");
jvalue args[] = {};
v7 = (jstring) env->CallObjectMethodA(v26, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("516:move-result-object \x76\x31\x33");
if (v20) {
LOGD("env->DeleteLocalRef(%p):v20", v20);
env->DeleteLocalRef(v20);
}
v20 = (jobject) v7;
L57:
LOGD("518:invoke-virtual \x76\x31\x35\x2c\x20\x76\x31\x33\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v22);
jclass &clz = cls5;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v20}};
v7 = (jobject) env->CallObjectMethodA(v22, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("51e:invoke-virtual \x76\x31\x35\x2c\x20\x76\x31\x34\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v22);
jclass &clz = cls5;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v21}};
v7 = (jobject) env->CallObjectMethodA(v22, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("524:invoke-virtual \x76\x31\x35\x2c\x20\x76\x38\x2c\x20\x76\x39\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4a\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v22);
jclass &clz = cls5;
jmethodID &mid = mth14;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(J)Ljava/lang/StringBuilder;");
jvalue args[] = {{.j = (jlong) v35}};
v7 = (jobject) env->CallObjectMethodA(v22, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("52a:invoke-virtual \x76\x31\x35\x2c\x20\x76\x31\x31\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v22);
jclass &clz = cls5;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v17}};
v7 = (jobject) env->CallObjectMethodA(v22, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("530:if-nez \x76\x31\x36\x2c\x20\x2b\x31\x35");
if(v23 != 0){
goto L59;
}
else {
goto L58;
}
L58:
LOGD("534:new-instance \x76\x37\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v26) {
LOGD("env->DeleteLocalRef(%p):v26", v26);
env->DeleteLocalRef(v26);
}
jclass &clz = cls5;
D2C_RESOLVE_CLASS(clz,"java/lang/StringBuilder");
v26 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("538:invoke-direct \x76\x37\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v26);
jclass &clz = cls5;
jmethodID &mid = mth5;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "<init>", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v26, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("53e:invoke-virtual \x76\x37\x2c\x20\x76\x31\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v26);
jclass &clz = cls5;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v16}};
v7 = (jobject) env->CallObjectMethodA(v26, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("544:invoke-virtual \x76\x37\x2c\x20\x76\x31\x32\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v26);
jclass &clz = cls5;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v18}};
v7 = (jobject) env->CallObjectMethodA(v26, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("54a:invoke-virtual \x76\x37\x2c\x20\x76\x36\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v26);
jclass &clz = cls5;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v34}};
v7 = (jobject) env->CallObjectMethodA(v26, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("550:invoke-virtual \x76\x37\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x74\x6f\x53\x74\x72\x69\x6e\x67\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v26);
jclass &clz = cls5;
jmethodID &mid = mth12;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "toString", "()Ljava/lang/String;");
jvalue args[] = {};
v7 = (jstring) env->CallObjectMethodA(v26, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("556:move-result-object \x76\x31\x33");
if (v20) {
LOGD("env->DeleteLocalRef(%p):v20", v20);
env->DeleteLocalRef(v20);
}
v20 = (jobject) v7;
goto L60;
L59:
if (v20) {
LOGD("env->DeleteLocalRef(%p):v20", v20);
env->DeleteLocalRef(v20);
}
v20 = (jobject) env->NewLocalRef(v43);
L60:
LOGD("55e:invoke-virtual \x76\x31\x35\x2c\x20\x76\x31\x33\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v22);
jclass &clz = cls5;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v20}};
v7 = (jobject) env->CallObjectMethodA(v22, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
v11 = 41;
LOGD("568:invoke-virtual \x76\x31\x35\x2c\x20\x76\x36\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x43\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v22);
jclass &clz = cls5;
jmethodID &mid = mth8;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(C)Ljava/lang/StringBuilder;");
jvalue args[] = {{.c = (jchar) v11}};
v7 = (jobject) env->CallObjectMethodA(v22, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("56e:invoke-virtual \x76\x31\x35\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x74\x6f\x53\x74\x72\x69\x6e\x67\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v22);
jclass &clz = cls5;
jmethodID &mid = mth12;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "toString", "()Ljava/lang/String;");
jvalue args[] = {};
v7 = (jstring) env->CallObjectMethodA(v22, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("574:move-result-object \x76\x36");
if (v34) {
LOGD("env->DeleteLocalRef(%p):v34", v34);
env->DeleteLocalRef(v34);
}
v34 = (jobject) v7;
LOGD("576:invoke-interface \x76\x33\x2c\x20\x76\x32\x2c\x20\x76\x36\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x6f\x67\x67\x65\x72\x3b\x2d\x3e\x61\x28\x49\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v8);
jclass &clz = cls8;
jmethodID &mid = mth16;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/event/net/OkInterceptor$Logger", "a", "(ILjava/lang/String;)V");
jvalue args[] = {{.i = v6},{.l = v34}};
env->CallVoidMethodA(v8, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
goto L68;
L61:
if (v43) {
LOGD("env->DeleteLocalRef(%p):v43", v43);
env->DeleteLocalRef(v43);
}
v43 = (jobject) env->NewLocalRef(v20);
LOGD("584:iget-object \x76\x33\x2c\x20\x76\x31\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x3b\x2d\x3e\x63\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x6f\x67\x67\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
jclass &clz = cls0;
jfieldID &fld = fld5;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/net/OkInterceptor", "c", "Lio/pro/edge/widget/event/net/OkInterceptor$Logger;");
v7 = (jobject) env->GetObjectField(v2,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jobject) v7;
LOGD("588:new-instance \x76\x31\x33\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v20) {
LOGD("env->DeleteLocalRef(%p):v20", v20);
env->DeleteLocalRef(v20);
}
jclass &clz = cls5;
D2C_RESOLVE_CLASS(clz,"java/lang/StringBuilder");
v20 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("58c:invoke-direct \x76\x31\x33\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v20);
jclass &clz = cls5;
jmethodID &mid = mth5;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "<init>", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v20, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("592:invoke-virtual \x76\x31\x33\x2c\x20\x76\x37\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v20);
jclass &clz = cls5;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v26}};
v7 = (jobject) env->CallObjectMethodA(v20, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("598:invoke-virtual \x76\x30\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x3b\x2d\x3e\x63\x6f\x64\x65\x28\x29\x49");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls15;
jmethodID &mid = mth33;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Response", "code", "()I");
jvalue args[] = {};
v5 = (jint) env->CallIntMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("59e:move-result \x76\x37");
v42 = (jint) v5;
LOGD("5a0:invoke-virtual \x76\x31\x33\x2c\x20\x76\x37\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x49\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v20);
jclass &clz = cls5;
jmethodID &mid = mth34;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(I)Ljava/lang/StringBuilder;");
jvalue args[] = {{.i = v42}};
v7 = (jobject) env->CallObjectMethodA(v20, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("5a6:invoke-virtual \x76\x30\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x3b\x2d\x3e\x6d\x65\x73\x73\x61\x67\x65\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls15;
jmethodID &mid = mth35;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Response", "message", "()Ljava/lang/String;");
jvalue args[] = {};
v7 = (jstring) env->CallObjectMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("5ac:move-result-object \x76\x37");
if (v26) {
LOGD("env->DeleteLocalRef(%p):v26", v26);
env->DeleteLocalRef(v26);
}
v26 = (jobject) v7;
LOGD("5ae:invoke-virtual \x76\x37\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x69\x73\x45\x6d\x70\x74\x79\x28\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v26);
jclass &clz = cls10;
jmethodID &mid = mth36;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "isEmpty", "()Z");
jvalue args[] = {};
v5 = (jboolean) env->CallBooleanMethodA(v26, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("5b4:move-result \x76\x37");
v42 = (jint) v5;
LOGD("5b6:if-eqz \x76\x37\x2c\x20\x2b\x35");
if(v42 == 0){
goto L63;
}
else {
goto L62;
}
L62:
if (v26) {
LOGD("env->DeleteLocalRef(%p):v26", v26);
env->DeleteLocalRef(v26);
}
v26 = (jobject) env->NewLocalRef(v43);
goto L64;
L63:
LOGD("5c0:new-instance \x76\x37\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v26) {
LOGD("env->DeleteLocalRef(%p):v26", v26);
env->DeleteLocalRef(v26);
}
jclass &clz = cls5;
D2C_RESOLVE_CLASS(clz,"java/lang/StringBuilder");
v26 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("5c4:invoke-direct \x76\x37\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v26);
jclass &clz = cls5;
jmethodID &mid = mth5;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "<init>", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v26, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
v32 = 32;
LOGD("5ce:invoke-virtual \x76\x37\x2c\x20\x76\x31\x35\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x43\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v26);
jclass &clz = cls5;
jmethodID &mid = mth8;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(C)Ljava/lang/StringBuilder;");
jvalue args[] = {{.c = (jchar) v32}};
v7 = (jobject) env->CallObjectMethodA(v26, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("5d4:invoke-virtual \x76\x30\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x3b\x2d\x3e\x6d\x65\x73\x73\x61\x67\x65\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls15;
jmethodID &mid = mth35;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Response", "message", "()Ljava/lang/String;");
jvalue args[] = {};
v7 = (jstring) env->CallObjectMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("5da:move-result-object \x76\x31\x35");
if (v22) {
LOGD("env->DeleteLocalRef(%p):v22", v22);
env->DeleteLocalRef(v22);
}
v22 = (jobject) v7;
LOGD("5dc:invoke-virtual \x76\x37\x2c\x20\x76\x31\x35\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v26);
jclass &clz = cls5;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v22}};
v7 = (jobject) env->CallObjectMethodA(v26, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("5e2:invoke-virtual \x76\x37\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x74\x6f\x53\x74\x72\x69\x6e\x67\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v26);
jclass &clz = cls5;
jmethodID &mid = mth12;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "toString", "()Ljava/lang/String;");
jvalue args[] = {};
v7 = (jstring) env->CallObjectMethodA(v26, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("5e8:move-result-object \x76\x37");
if (v26) {
LOGD("env->DeleteLocalRef(%p):v26", v26);
env->DeleteLocalRef(v26);
}
v26 = (jobject) v7;
L64:
LOGD("5ea:invoke-virtual \x76\x31\x33\x2c\x20\x76\x37\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v20);
jclass &clz = cls5;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v26}};
v7 = (jobject) env->CallObjectMethodA(v20, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
v42 = 32;
LOGD("5f4:invoke-virtual \x76\x31\x33\x2c\x20\x76\x37\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x43\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v20);
jclass &clz = cls5;
jmethodID &mid = mth8;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(C)Ljava/lang/StringBuilder;");
jvalue args[] = {{.c = (jchar) v42}};
v7 = (jobject) env->CallObjectMethodA(v20, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("5fa:invoke-virtual \x76\x30\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x3b\x2d\x3e\x72\x65\x71\x75\x65\x73\x74\x28\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x71\x75\x65\x73\x74\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls15;
jmethodID &mid = mth37;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Response", "request", "()Lokhttp3/Request;");
jvalue args[] = {};
v7 = (jobject) env->CallObjectMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("600:move-result-object \x76\x37");
if (v26) {
LOGD("env->DeleteLocalRef(%p):v26", v26);
env->DeleteLocalRef(v26);
}
v26 = (jobject) v7;
LOGD("602:invoke-virtual \x76\x37\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x71\x75\x65\x73\x74\x3b\x2d\x3e\x75\x72\x6c\x28\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x48\x74\x74\x70\x55\x72\x6c\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v26);
jclass &clz = cls4;
jmethodID &mid = mth9;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Request", "url", "()Lokhttp3/HttpUrl;");
jvalue args[] = {};
v7 = (jobject) env->CallObjectMethodA(v26, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("608:move-result-object \x76\x37");
if (v26) {
LOGD("env->DeleteLocalRef(%p):v26", v26);
env->DeleteLocalRef(v26);
}
v26 = (jobject) v7;
LOGD("60a:invoke-virtual \x76\x31\x33\x2c\x20\x76\x37\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v20);
jclass &clz = cls5;
jmethodID &mid = mth10;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/Object;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v26}};
v7 = (jobject) env->CallObjectMethodA(v20, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("610:invoke-virtual \x76\x31\x33\x2c\x20\x76\x31\x34\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v20);
jclass &clz = cls5;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v21}};
v7 = (jobject) env->CallObjectMethodA(v20, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("616:invoke-virtual \x76\x31\x33\x2c\x20\x76\x38\x2c\x20\x76\x39\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4a\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v20);
jclass &clz = cls5;
jmethodID &mid = mth14;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(J)Ljava/lang/StringBuilder;");
jvalue args[] = {{.j = (jlong) v35}};
v7 = (jobject) env->CallObjectMethodA(v20, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("61c:invoke-virtual \x76\x31\x33\x2c\x20\x76\x31\x31\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v20);
jclass &clz = cls5;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v17}};
v7 = (jobject) env->CallObjectMethodA(v20, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("622:if-nez \x76\x31\x36\x2c\x20\x2b\x31\x35");
if(v23 != 0){
goto L66;
}
else {
goto L65;
}
L65:
LOGD("626:new-instance \x76\x37\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v26) {
LOGD("env->DeleteLocalRef(%p):v26", v26);
env->DeleteLocalRef(v26);
}
jclass &clz = cls5;
D2C_RESOLVE_CLASS(clz,"java/lang/StringBuilder");
v26 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("62a:invoke-direct \x76\x37\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v26);
jclass &clz = cls5;
jmethodID &mid = mth5;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "<init>", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v26, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("630:invoke-virtual \x76\x37\x2c\x20\x76\x31\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v26);
jclass &clz = cls5;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v16}};
v7 = (jobject) env->CallObjectMethodA(v26, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("636:invoke-virtual \x76\x37\x2c\x20\x76\x31\x32\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v26);
jclass &clz = cls5;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v18}};
v7 = (jobject) env->CallObjectMethodA(v26, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("63c:invoke-virtual \x76\x37\x2c\x20\x76\x36\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v26);
jclass &clz = cls5;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v34}};
v7 = (jobject) env->CallObjectMethodA(v26, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("642:invoke-virtual \x76\x37\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x74\x6f\x53\x74\x72\x69\x6e\x67\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v26);
jclass &clz = cls5;
jmethodID &mid = mth12;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "toString", "()Ljava/lang/String;");
jvalue args[] = {};
v7 = (jstring) env->CallObjectMethodA(v26, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("648:move-result-object \x76\x36");
if (v34) {
LOGD("env->DeleteLocalRef(%p):v34", v34);
env->DeleteLocalRef(v34);
}
v34 = (jobject) v7;
goto L67;
L66:
if (v34) {
LOGD("env->DeleteLocalRef(%p):v34", v34);
env->DeleteLocalRef(v34);
}
v34 = (jobject) env->NewLocalRef(v43);
L67:
LOGD("650:invoke-virtual \x76\x31\x33\x2c\x20\x76\x36\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v20);
jclass &clz = cls5;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v34}};
v7 = (jobject) env->CallObjectMethodA(v20, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
v11 = 41;
LOGD("65a:invoke-virtual \x76\x31\x33\x2c\x20\x76\x36\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x43\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v20);
jclass &clz = cls5;
jmethodID &mid = mth8;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(C)Ljava/lang/StringBuilder;");
jvalue args[] = {{.c = (jchar) v11}};
v7 = (jobject) env->CallObjectMethodA(v20, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("660:invoke-virtual \x76\x31\x33\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x74\x6f\x53\x74\x72\x69\x6e\x67\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v20);
jclass &clz = cls5;
jmethodID &mid = mth12;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "toString", "()Ljava/lang/String;");
jvalue args[] = {};
v7 = (jstring) env->CallObjectMethodA(v20, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("666:move-result-object \x76\x36");
if (v34) {
LOGD("env->DeleteLocalRef(%p):v34", v34);
env->DeleteLocalRef(v34);
}
v34 = (jobject) v7;
LOGD("668:invoke-interface \x76\x33\x2c\x20\x76\x32\x2c\x20\x76\x36\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x6f\x67\x67\x65\x72\x3b\x2d\x3e\x61\x28\x49\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v8);
jclass &clz = cls8;
jmethodID &mid = mth16;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/event/net/OkInterceptor$Logger", "a", "(ILjava/lang/String;)V");
jvalue args[] = {{.i = v6},{.l = v34}};
env->CallVoidMethodA(v8, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L68:
LOGD("66e:if-eqz \x76\x31\x36\x2c\x20\x2b\x31\x34\x38");
if(v23 == 0){
goto L105;
}
else {
goto L69;
}
L69:
LOGD("672:invoke-virtual \x76\x30\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x3b\x2d\x3e\x68\x65\x61\x64\x65\x72\x73\x28\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x48\x65\x61\x64\x65\x72\x73\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls15;
jmethodID &mid = mth38;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Response", "headers", "()Lokhttp3/Headers;");
jvalue args[] = {};
v7 = (jobject) env->CallObjectMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("678:move-result-object \x76\x33");
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jobject) v7;
LOGD("67a:invoke-virtual \x76\x33\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x48\x65\x61\x64\x65\x72\x73\x3b\x2d\x3e\x73\x69\x7a\x65\x28\x29\x49");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v8);
jclass &clz = cls9;
jmethodID &mid = mth19;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Headers", "size", "()I");
jvalue args[] = {};
v5 = (jint) env->CallIntMethodA(v8, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("680:move-result \x76\x36");
v11 = (jint) v5;
v42 = 0;
L70:
LOGD("684:if-ge \x76\x37\x2c\x20\x76\x36\x2c\x20\x2b\x38");
if(v42 >= v11) {
goto L72;
}
else {
goto L71;
}
L71:
LOGD("688:invoke-virtual \x76\x31\x2c\x20\x76\x32\x2c\x20\x76\x33\x2c\x20\x76\x37\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x3b\x2d\x3e\x61\x28\x49\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x48\x65\x61\x64\x65\x72\x73\x3b\x20\x49\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
jclass &clz = cls0;
jmethodID &mid = mth22;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/event/net/OkInterceptor", "a", "(ILokhttp3/Headers;I)V");
jvalue args[] = {{.i = v6},{.l = v8},{.i = v42}};
env->CallVoidMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("68e:add-int/lit8 \x76\x37\x2c\x20\x76\x37\x2c\x20\x31");
v42 = (v42 + 1);
goto L70;
L72:
LOGD("694:if-eqz \x76\x35\x2c\x20\x2b\x31\x32\x62");
if(v12 == 0){
goto L104;
}
else {
goto L73;
}
L73:
LOGD("698:invoke-static \x76\x30\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x69\x6e\x74\x65\x72\x6e\x61\x6c\x2f\x68\x74\x74\x70\x2f\x48\x74\x74\x70\x48\x65\x61\x64\x65\x72\x73\x3b\x2d\x3e\x68\x61\x73\x42\x6f\x64\x79\x28\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls17;
jmethodID &mid = mth39;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "okhttp3/internal/http/HttpHeaders", "hasBody", "(Lokhttp3/Response;)Z");
jvalue args[] = {{.l = v3}};
v5 = (jboolean) env->CallStaticBooleanMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("69e:move-result \x76\x35");
v12 = (jint) v5;
LOGD("6a0:if-nez \x76\x35\x2c\x20\x2b\x34");
if(v12 != 0){
goto L75;
}
else {
goto L74;
}
L74:
goto L104;
L75:
LOGD("6a8:invoke-virtual \x76\x30\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x3b\x2d\x3e\x68\x65\x61\x64\x65\x72\x73\x28\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x48\x65\x61\x64\x65\x72\x73\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls15;
jmethodID &mid = mth38;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Response", "headers", "()Lokhttp3/Headers;");
jvalue args[] = {};
v7 = (jobject) env->CallObjectMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("6ae:move-result-object \x76\x35");
if (v10) {
LOGD("env->DeleteLocalRef(%p):v10", v10);
env->DeleteLocalRef(v10);
}
v10 = (jobject) v7;
LOGD("6b0:invoke-static \x76\x35\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x3b\x2d\x3e\x61\x28\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x48\x65\x61\x64\x65\x72\x73\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls0;
jmethodID &mid = mth23;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "io/pro/edge/widget/event/net/OkInterceptor", "a", "(Lokhttp3/Headers;)Z");
jvalue args[] = {{.l = v10}};
v5 = (jboolean) env->CallStaticBooleanMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("6b6:move-result \x76\x35");
v12 = (jint) v5;
LOGD("6b8:if-eqz \x76\x35\x2c\x20\x2b\x62");
if(v12 == 0){
goto L77;
}
else {
goto L76;
}
L76:
LOGD("6bc:iget-object \x76\x33\x2c\x20\x76\x31\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x3b\x2d\x3e\x63\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x6f\x67\x67\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
jclass &clz = cls0;
jfieldID &fld = fld5;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/net/OkInterceptor", "c", "Lio/pro/edge/widget/event/net/OkInterceptor$Logger;");
v7 = (jobject) env->GetObjectField(v2,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jobject) v7;
LOGD("6c0:const-string \x76\x34\x2c\x20\x27\x3c\x2d\x2d\x20\x45\x4e\x44\x20\x48\x54\x54\x50\x20\x28\x65\x6e\x63\x6f\x64\x65\x64\x20\x62\x6f\x64\x79\x20\x6f\x6d\x69\x74\x74\x65\x64\x29\x27");
if (v9) {
LOGD("env->DeleteLocalRef(%p):v9", v9);
env->DeleteLocalRef(v9);
}
v9 = (jstring) env->NewStringUTF("\x3c\x2d\x2d\x20\x45\x4e\x44\x20\x48\x54\x54\x50\x20\x28\x65\x6e\x63\x6f\x64\x65\x64\x20\x62\x6f\x64\x79\x20\x6f\x6d\x69\x74\x74\x65\x64\x29");
LOGD("6c4:invoke-interface \x76\x33\x2c\x20\x76\x32\x2c\x20\x76\x34\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x6f\x67\x67\x65\x72\x3b\x2d\x3e\x61\x28\x49\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v8);
jclass &clz = cls8;
jmethodID &mid = mth16;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/event/net/OkInterceptor$Logger", "a", "(ILjava/lang/String;)V");
jvalue args[] = {{.i = v6},{.l = v9}};
env->CallVoidMethodA(v8, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
goto L105;
L77:
LOGD("6ce:invoke-virtual \x76\x34\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x42\x6f\x64\x79\x3b\x2d\x3e\x73\x6f\x75\x72\x63\x65\x28\x29\x4c\x6f\x6b\x69\x6f\x2f\x42\x75\x66\x66\x65\x72\x65\x64\x53\x6f\x75\x72\x63\x65\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v9);
jclass &clz = cls16;
jmethodID &mid = mth40;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/ResponseBody", "source", "()Lokio/BufferedSource;");
jvalue args[] = {};
v7 = (jobject) env->CallObjectMethodA(v9, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("6d4:move-result-object \x76\x35");
if (v10) {
LOGD("env->DeleteLocalRef(%p):v10", v10);
env->DeleteLocalRef(v10);
}
v10 = (jobject) v7;
v44 = 9223372036854775807;
LOGD("6e0:invoke-interface \x76\x35\x2c\x20\x76\x36\x2c\x20\x76\x37\x2c\x20\x4c\x6f\x6b\x69\x6f\x2f\x42\x75\x66\x66\x65\x72\x65\x64\x53\x6f\x75\x72\x63\x65\x3b\x2d\x3e\x72\x65\x71\x75\x65\x73\x74\x28\x4a\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v10);
jclass &clz = cls18;
jmethodID &mid = mth41;
D2C_RESOLVE_METHOD(clz, mid, "okio/BufferedSource", "request", "(J)Z");
jvalue args[] = {{.j = (jlong) v44}};
v5 = (jboolean) env->CallBooleanMethodA(v10, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("6e6:invoke-interface \x76\x35\x2c\x20\x4c\x6f\x6b\x69\x6f\x2f\x42\x75\x66\x66\x65\x72\x65\x64\x53\x6f\x75\x72\x63\x65\x3b\x2d\x3e\x62\x75\x66\x66\x65\x72\x28\x29\x4c\x6f\x6b\x69\x6f\x2f\x42\x75\x66\x66\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v10);
jclass &clz = cls18;
jmethodID &mid = mth42;
D2C_RESOLVE_METHOD(clz, mid, "okio/BufferedSource", "buffer", "()Lokio/Buffer;");
jvalue args[] = {};
v7 = (jobject) env->CallObjectMethodA(v10, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("6ec:move-result-object \x76\x35");
if (v10) {
LOGD("env->DeleteLocalRef(%p):v10", v10);
env->DeleteLocalRef(v10);
}
v10 = (jobject) v7;
LOGD("6ee:const-string \x76\x36\x2c\x20\x27\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x45\x6e\x63\x6f\x64\x69\x6e\x67\x27");
if (v34) {
LOGD("env->DeleteLocalRef(%p):v34", v34);
env->DeleteLocalRef(v34);
}
v34 = (jstring) env->NewStringUTF("\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x45\x6e\x63\x6f\x64\x69\x6e\x67");
LOGD("6f2:invoke-virtual \x76\x33\x2c\x20\x76\x36\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x48\x65\x61\x64\x65\x72\x73\x3b\x2d\x3e\x67\x65\x74\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v8);
jclass &clz = cls9;
jmethodID &mid = mth43;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Headers", "get", "(Ljava/lang/String;)Ljava/lang/String;");
jvalue args[] = {{.l = v34}};
v7 = (jstring) env->CallObjectMethodA(v8, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("6f8:move-result-object \x76\x33");
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jobject) v7;
LOGD("6fa:const-string \x76\x36\x2c\x20\x27\x67\x7a\x69\x70\x27");
if (v34) {
LOGD("env->DeleteLocalRef(%p):v34", v34);
env->DeleteLocalRef(v34);
}
v34 = (jstring) env->NewStringUTF("\x67\x7a\x69\x70");
LOGD("6fe:invoke-virtual \x76\x36\x2c\x20\x76\x33\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x65\x71\x75\x61\x6c\x73\x49\x67\x6e\x6f\x72\x65\x43\x61\x73\x65\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v34);
jclass &clz = cls10;
jmethodID &mid = mth21;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "equalsIgnoreCase", "(Ljava/lang/String;)Z");
jvalue args[] = {{.l = v8}};
v5 = (jboolean) env->CallBooleanMethodA(v34, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("704:move-result \x76\x33");
v41 = (jint) v5;
if (v34) {
LOGD("env->DeleteLocalRef(%p):v34", v34);
env->DeleteLocalRef(v34);
}
v34 = 0;
if (v34) {
LOGD("env->DeleteLocalRef(%p):v34", v34);
env->DeleteLocalRef(v34);
}
v34 = 0;
LOGD("708:if-eqz \x76\x33\x2c\x20\x2b\x32\x39");
if(v41 == 0){
goto L92;
}
else {
goto L78;
}
L78:
LOGD("70c:invoke-virtual \x76\x35\x2c\x20\x4c\x6f\x6b\x69\x6f\x2f\x42\x75\x66\x66\x65\x72\x3b\x2d\x3e\x73\x69\x7a\x65\x28\x29\x4a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v10);
jclass &clz = cls11;
jmethodID &mid = mth44;
D2C_RESOLVE_METHOD(clz, mid, "okio/Buffer", "size", "()J");
jvalue args[] = {};
v24 = (jlong) env->CallLongMethodA(v10, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("712:move-result-wide \x76\x37");
v25 = (jlong) v24;
LOGD("714:invoke-static \x76\x37\x2c\x20\x76\x38\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4c\x6f\x6e\x67\x3b\x2d\x3e\x76\x61\x6c\x75\x65\x4f\x66\x28\x4a\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4c\x6f\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls19;
jmethodID &mid = mth45;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "java/lang/Long", "valueOf", "(J)Ljava/lang/Long;");
jvalue args[] = {{.j = (jlong) v25}};
v7 = (jobject) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("71a:move-result-object \x76\x33");
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jobject) v7;
L79:
LOGD("71c:new-instance \x76\x37\x2c\x20\x4c\x6f\x6b\x69\x6f\x2f\x47\x7a\x69\x70\x53\x6f\x75\x72\x63\x65\x3b");
{
#define EX_HANDLE EX_LandingPad_79
if (v26) {
LOGD("env->DeleteLocalRef(%p):v26", v26);
env->DeleteLocalRef(v26);
}
jclass &clz = cls20;
D2C_RESOLVE_CLASS(clz,"okio/GzipSource");
v26 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L80:
LOGD("720:invoke-virtual \x76\x35\x2c\x20\x4c\x6f\x6b\x69\x6f\x2f\x42\x75\x66\x66\x65\x72\x3b\x2d\x3e\x63\x6c\x6f\x6e\x65\x28\x29\x4c\x6f\x6b\x69\x6f\x2f\x42\x75\x66\x66\x65\x72\x3b");
{
#define EX_HANDLE EX_LandingPad_79
D2C_NOT_NULL(v10);
jclass &clz = cls11;
jmethodID &mid = mth46;
D2C_RESOLVE_METHOD(clz, mid, "okio/Buffer", "clone", "()Lokio/Buffer;");
jvalue args[] = {};
v7 = (jobject) env->CallObjectMethodA(v10, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L81:
LOGD("726:move-result-object \x76\x35");
if (v10) {
LOGD("env->DeleteLocalRef(%p):v10", v10);
env->DeleteLocalRef(v10);
}
v10 = (jobject) v7;
L82:
LOGD("728:invoke-direct \x76\x37\x2c\x20\x76\x35\x2c\x20\x4c\x6f\x6b\x69\x6f\x2f\x47\x7a\x69\x70\x53\x6f\x75\x72\x63\x65\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x4c\x6f\x6b\x69\x6f\x2f\x53\x6f\x75\x72\x63\x65\x3b\x29\x56");
{
#define EX_HANDLE EX_LandingPad_79
D2C_NOT_NULL(v26);
jclass &clz = cls20;
jmethodID &mid = mth47;
D2C_RESOLVE_METHOD(clz, mid, "okio/GzipSource", "<init>", "(Lokio/Source;)V");
jvalue args[] = {{.l = v10}};
env->CallVoidMethodA(v26, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L83:
LOGD("72e:new-instance \x76\x35\x2c\x20\x4c\x6f\x6b\x69\x6f\x2f\x42\x75\x66\x66\x65\x72\x3b");
{
#define EX_HANDLE EX_LandingPad_83
if (v10) {
LOGD("env->DeleteLocalRef(%p):v10", v10);
env->DeleteLocalRef(v10);
}
jclass &clz = cls11;
D2C_RESOLVE_CLASS(clz,"okio/Buffer");
v10 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L84:
LOGD("732:invoke-direct \x76\x35\x2c\x20\x4c\x6f\x6b\x69\x6f\x2f\x42\x75\x66\x66\x65\x72\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x29\x56");
{
#define EX_HANDLE EX_LandingPad_83
D2C_NOT_NULL(v10);
jclass &clz = cls11;
jmethodID &mid = mth24;
D2C_RESOLVE_METHOD(clz, mid, "okio/Buffer", "<init>", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v10, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L85:
LOGD("738:invoke-virtual \x76\x35\x2c\x20\x76\x37\x2c\x20\x4c\x6f\x6b\x69\x6f\x2f\x42\x75\x66\x66\x65\x72\x3b\x2d\x3e\x77\x72\x69\x74\x65\x41\x6c\x6c\x28\x4c\x6f\x6b\x69\x6f\x2f\x53\x6f\x75\x72\x63\x65\x3b\x29\x4a");
{
#define EX_HANDLE EX_LandingPad_83
D2C_NOT_NULL(v10);
jclass &clz = cls11;
jmethodID &mid = mth48;
D2C_RESOLVE_METHOD(clz, mid, "okio/Buffer", "writeAll", "(Lokio/Source;)J");
jvalue args[] = {{.l = v26}};
v24 = (jlong) env->CallLongMethodA(v10, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L86:
LOGD("73e:invoke-virtual \x76\x37\x2c\x20\x4c\x6f\x6b\x69\x6f\x2f\x47\x7a\x69\x70\x53\x6f\x75\x72\x63\x65\x3b\x2d\x3e\x63\x6c\x6f\x73\x65\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v26);
jclass &clz = cls20;
jmethodID &mid = mth49;
D2C_RESOLVE_METHOD(clz, mid, "okio/GzipSource", "close", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v26, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
goto L93;
L87:
LOGD("746:move-exception \x76\x30");
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
v3 = exception;
if (v34) {
LOGD("env->DeleteLocalRef(%p):v34", v34);
env->DeleteLocalRef(v34);
}
v34 = (jobject) env->NewLocalRef(v26);
goto L89;
L88:
LOGD("74c:move-exception \x76\x30");
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
v3 = exception;
L89:
LOGD("74e:if-eqz \x76\x36\x2c\x20\x2b\x35");
if(v34 == NULL){
goto L91;
}
else {
goto L90;
}
L90:
LOGD("752:invoke-virtual \x76\x36\x2c\x20\x4c\x6f\x6b\x69\x6f\x2f\x47\x7a\x69\x70\x53\x6f\x75\x72\x63\x65\x3b\x2d\x3e\x63\x6c\x6f\x73\x65\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v34);
jclass &clz = cls20;
jmethodID &mid = mth49;
D2C_RESOLVE_METHOD(clz, mid, "okio/GzipSource", "close", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v34, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L91:
LOGD("758:throw \x76\x30");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
env->Throw((jthrowable) v3);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L92:
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jobject) env->NewLocalRef(v34);
L93:
LOGD("75c:sget-object \x76\x36\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x3b\x2d\x3e\x61\x20\x4c\x6a\x61\x76\x61\x2f\x6e\x69\x6f\x2f\x63\x68\x61\x72\x73\x65\x74\x2f\x43\x68\x61\x72\x73\x65\x74\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v34) {
LOGD("env->DeleteLocalRef(%p):v34", v34);
env->DeleteLocalRef(v34);
}
jclass &clz = cls0;
jfieldID &fld = fld6;
D2C_RESOLVE_STATIC_FIELD(clz, fld, "io/pro/edge/widget/event/net/OkInterceptor", "a", "Ljava/nio/charset/Charset;");
v34 = (jobject) env->GetStaticObjectField(clz,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("760:invoke-virtual \x76\x34\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x42\x6f\x64\x79\x3b\x2d\x3e\x63\x6f\x6e\x74\x65\x6e\x74\x54\x79\x70\x65\x28\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x4d\x65\x64\x69\x61\x54\x79\x70\x65\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v9);
jclass &clz = cls16;
jmethodID &mid = mth50;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/ResponseBody", "contentType", "()Lokhttp3/MediaType;");
jvalue args[] = {};
v7 = (jobject) env->CallObjectMethodA(v9, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("766:move-result-object \x76\x34");
if (v9) {
LOGD("env->DeleteLocalRef(%p):v9", v9);
env->DeleteLocalRef(v9);
}
v9 = (jobject) v7;
LOGD("768:if-eqz \x76\x34\x2c\x20\x2b\x38");
if(v9 == NULL){
goto L95;
}
else {
goto L94;
}
L94:
LOGD("76c:sget-object \x76\x36\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x3b\x2d\x3e\x61\x20\x4c\x6a\x61\x76\x61\x2f\x6e\x69\x6f\x2f\x63\x68\x61\x72\x73\x65\x74\x2f\x43\x68\x61\x72\x73\x65\x74\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v34) {
LOGD("env->DeleteLocalRef(%p):v34", v34);
env->DeleteLocalRef(v34);
}
jclass &clz = cls0;
jfieldID &fld = fld6;
D2C_RESOLVE_STATIC_FIELD(clz, fld, "io/pro/edge/widget/event/net/OkInterceptor", "a", "Ljava/nio/charset/Charset;");
v34 = (jobject) env->GetStaticObjectField(clz,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("770:invoke-virtual \x76\x34\x2c\x20\x76\x36\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x4d\x65\x64\x69\x61\x54\x79\x70\x65\x3b\x2d\x3e\x63\x68\x61\x72\x73\x65\x74\x28\x4c\x6a\x61\x76\x61\x2f\x6e\x69\x6f\x2f\x63\x68\x61\x72\x73\x65\x74\x2f\x43\x68\x61\x72\x73\x65\x74\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6e\x69\x6f\x2f\x63\x68\x61\x72\x73\x65\x74\x2f\x43\x68\x61\x72\x73\x65\x74\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v9);
jclass &clz = cls12;
jmethodID &mid = mth26;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/MediaType", "charset", "(Ljava/nio/charset/Charset;)Ljava/nio/charset/Charset;");
jvalue args[] = {{.l = v34}};
v7 = (jobject) env->CallObjectMethodA(v9, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("776:move-result-object \x76\x36");
if (v34) {
LOGD("env->DeleteLocalRef(%p):v34", v34);
env->DeleteLocalRef(v34);
}
v34 = (jobject) v7;
L95:
LOGD("778:invoke-static \x76\x35\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x3b\x2d\x3e\x61\x28\x4c\x6f\x6b\x69\x6f\x2f\x42\x75\x66\x66\x65\x72\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls0;
jmethodID &mid = mth27;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "io/pro/edge/widget/event/net/OkInterceptor", "a", "(Lokio/Buffer;)Z");
jvalue args[] = {{.l = v10}};
v5 = (jboolean) env->CallStaticBooleanMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("77e:move-result \x76\x34");
v45 = (jint) v5;
LOGD("780:if-nez \x76\x34\x2c\x20\x2b\x34\x30");
if(v45 != 0){
goto L99;
}
else {
goto L96;
}
L96:
LOGD("784:iget-object \x76\x33\x2c\x20\x76\x31\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x3b\x2d\x3e\x63\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x6f\x67\x67\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
jclass &clz = cls0;
jfieldID &fld = fld5;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/net/OkInterceptor", "c", "Lio/pro/edge/widget/event/net/OkInterceptor$Logger;");
v7 = (jobject) env->GetObjectField(v2,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jobject) v7;
if (v9) {
LOGD("env->DeleteLocalRef(%p):v9", v9);
env->DeleteLocalRef(v9);
}
v9 = (jobject) env->NewLocalRef(v43);
LOGD("78c:invoke-interface \x76\x33\x2c\x20\x76\x32\x2c\x20\x76\x34\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x6f\x67\x67\x65\x72\x3b\x2d\x3e\x61\x28\x49\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v8);
jclass &clz = cls8;
jmethodID &mid = mth16;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/event/net/OkInterceptor$Logger", "a", "(ILjava/lang/String;)V");
jvalue args[] = {{.i = v6},{.l = v9}};
env->CallVoidMethodA(v8, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("792:iget-object \x76\x33\x2c\x20\x76\x31\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x3b\x2d\x3e\x63\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x6f\x67\x67\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
jclass &clz = cls0;
jfieldID &fld = fld5;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/net/OkInterceptor", "c", "Lio/pro/edge/widget/event/net/OkInterceptor$Logger;");
v7 = (jobject) env->GetObjectField(v2,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jobject) v7;
LOGD("796:new-instance \x76\x36\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v34) {
LOGD("env->DeleteLocalRef(%p):v34", v34);
env->DeleteLocalRef(v34);
}
jclass &clz = cls5;
D2C_RESOLVE_CLASS(clz,"java/lang/StringBuilder");
v34 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("79a:invoke-direct \x76\x36\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v34);
jclass &clz = cls5;
jmethodID &mid = mth5;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "<init>", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v34, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("7a0:const-string \x76\x37\x2c\x20\x27\x3c\x2d\x2d\x20\x45\x4e\x44\x20\x48\x54\x54\x50\x20\x28\x62\x69\x6e\x61\x72\x79\x20\x27");
if (v26) {
LOGD("env->DeleteLocalRef(%p):v26", v26);
env->DeleteLocalRef(v26);
}
v26 = (jstring) env->NewStringUTF("\x3c\x2d\x2d\x20\x45\x4e\x44\x20\x48\x54\x54\x50\x20\x28\x62\x69\x6e\x61\x72\x79\x20");
LOGD("7a4:invoke-virtual \x76\x36\x2c\x20\x76\x37\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v34);
jclass &clz = cls5;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v26}};
v7 = (jobject) env->CallObjectMethodA(v34, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("7aa:invoke-virtual \x76\x35\x2c\x20\x4c\x6f\x6b\x69\x6f\x2f\x42\x75\x66\x66\x65\x72\x3b\x2d\x3e\x73\x69\x7a\x65\x28\x29\x4a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v10);
jclass &clz = cls11;
jmethodID &mid = mth44;
D2C_RESOLVE_METHOD(clz, mid, "okio/Buffer", "size", "()J");
jvalue args[] = {};
v24 = (jlong) env->CallLongMethodA(v10, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("7b0:move-result-wide \x76\x37");
v25 = (jlong) v24;
LOGD("7b2:invoke-virtual \x76\x36\x2c\x20\x76\x37\x2c\x20\x76\x38\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4a\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v34);
jclass &clz = cls5;
jmethodID &mid = mth14;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(J)Ljava/lang/StringBuilder;");
jvalue args[] = {{.j = (jlong) v25}};
v7 = (jobject) env->CallObjectMethodA(v34, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
if (v10) {
LOGD("env->DeleteLocalRef(%p):v10", v10);
env->DeleteLocalRef(v10);
}
v10 = (jobject) env->NewLocalRef(v40);
LOGD("7bc:invoke-virtual \x76\x36\x2c\x20\x76\x35\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v34);
jclass &clz = cls5;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v10}};
v7 = (jobject) env->CallObjectMethodA(v34, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("7c2:invoke-virtual \x76\x36\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x74\x6f\x53\x74\x72\x69\x6e\x67\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v34);
jclass &clz = cls5;
jmethodID &mid = mth12;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "toString", "()Ljava/lang/String;");
jvalue args[] = {};
v7 = (jstring) env->CallObjectMethodA(v34, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("7c8:move-result-object \x76\x35");
if (v10) {
LOGD("env->DeleteLocalRef(%p):v10", v10);
env->DeleteLocalRef(v10);
}
v10 = (jobject) v7;
LOGD("7ca:invoke-interface \x76\x33\x2c\x20\x76\x32\x2c\x20\x76\x35\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x6f\x67\x67\x65\x72\x3b\x2d\x3e\x61\x28\x49\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v8);
jclass &clz = cls8;
jmethodID &mid = mth16;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/event/net/OkInterceptor$Logger", "a", "(ILjava/lang/String;)V");
jvalue args[] = {{.i = v6},{.l = v10}};
env->CallVoidMethodA(v8, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("7d0:iget-object \x76\x32\x2c\x20\x76\x31\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x3b\x2d\x3e\x63\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x6f\x67\x67\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
jclass &clz = cls0;
jfieldID &fld = fld5;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/net/OkInterceptor", "c", "Lio/pro/edge/widget/event/net/OkInterceptor$Logger;");
v7 = (jobject) env->GetObjectField(v2,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
v4 = (jobject) v7;
LOGD("7d4:invoke-interface \x76\x32\x2c\x20\x76\x34\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x6f\x67\x67\x65\x72\x3b\x2d\x3e\x61\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v4);
jclass &clz = cls8;
jmethodID &mid = mth15;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/event/net/OkInterceptor$Logger", "a", "(Ljava/lang/String;)V");
jvalue args[] = {{.l = v9}};
env->CallVoidMethodA(v4, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("7da:iget-object \x76\x32\x2c\x20\x76\x31\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x3b\x2d\x3e\x63\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x6f\x67\x67\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
jclass &clz = cls0;
jfieldID &fld = fld5;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/net/OkInterceptor", "c", "Lio/pro/edge/widget/event/net/OkInterceptor$Logger;");
v7 = (jobject) env->GetObjectField(v2,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
v4 = (jobject) v7;
LOGD("7de:instance-of \x76\x33\x2c\x20\x76\x32\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x45\x61\x73\x79\x4c\x6f\x67\x67\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls21;
D2C_RESOLVE_CLASS(clz,"io/pro/edge/widget/event/net/OkInterceptor$EasyLogger");
v41 = d2c_is_instance_of(env, v4, clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("7e2:if-eqz \x76\x33\x2c\x20\x2b\x65");
if(v41 == 0){
goto L98;
}
else {
goto L97;
}
L97:
LOGD("7e6:check-cast \x76\x32\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x45\x61\x73\x79\x4c\x6f\x67\x67\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls21;
D2C_RESOLVE_CLASS(clz,"io/pro/edge/widget/event/net/OkInterceptor$EasyLogger");
D2C_CHECK_CAST(v4, clz, "io/pro/edge/widget/event/net/OkInterceptor$EasyLogger");
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("7ea:invoke-static \x76\x32\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x45\x61\x73\x79\x4c\x6f\x67\x67\x65\x72\x3b\x2d\x3e\x61\x28\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x45\x61\x73\x79\x4c\x6f\x67\x67\x65\x72\x3b\x29\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x75\x74\x69\x6c\x73\x2f\x54\x72\x61\x6e\x73\x66\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls21;
jmethodID &mid = mth51;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "io/pro/edge/widget/event/net/OkInterceptor$EasyLogger", "a", "(Lio/pro/edge/widget/event/net/OkInterceptor$EasyLogger;)Lio/pro/edge/widget/event/utils/Transfer;");
jvalue args[] = {{.l = v4}};
v7 = (jobject) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("7f0:move-result-object \x76\x32");
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
v4 = (jobject) v7;
v41 = 0;
LOGD("7f4:new-array \x76\x33\x2c\x20\x76\x33\x2c\x20\x5b\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v41 < 0) {
d2c_throw_exception(env, "java/lang/NegativeArraySizeException", "negative array size");
goto EX_HANDLE;
}
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
jclass &clz = cls10;
D2C_RESOLVE_CLASS(clz,"java/lang/String");
v8 = env->NewObjectArray((jint) v41, clz, NULL);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("7f8:invoke-virtual \x76\x32\x2c\x20\x76\x33\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x75\x74\x69\x6c\x73\x2f\x54\x72\x61\x6e\x73\x66\x65\x72\x3b\x2d\x3e\x61\x28\x5b\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v4);
jclass &clz = cls22;
jmethodID &mid = mth52;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/event/utils/Transfer", "a", "([Ljava/lang/String;)V");
jvalue args[] = {{.l = v8}};
env->CallVoidMethodA(v4, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L98:
return (jobject) v3;
L99:
if (v9) {
LOGD("env->DeleteLocalRef(%p):v9", v9);
env->DeleteLocalRef(v9);
}
v9 = (jobject) env->NewLocalRef(v43);
v25 = 0;
LOGD("808:cmp-long \x76\x39\x2c\x20\x76\x31\x38\x2c\x20\x76\x37");
v46 = (v39 == v25) ? 0 : (v39 > v25) ? 1 : -1;
LOGD("80c:if-eqz \x76\x39\x2c\x20\x2b\x32\x35");
if(v46 == 0){
goto L101;
}
else {
goto L100;
}
L100:
LOGD("810:iget-object \x76\x37\x2c\x20\x76\x31\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x3b\x2d\x3e\x63\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x6f\x67\x67\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
jclass &clz = cls0;
jfieldID &fld = fld5;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/net/OkInterceptor", "c", "Lio/pro/edge/widget/event/net/OkInterceptor$Logger;");
v7 = (jobject) env->GetObjectField(v2,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v26) {
LOGD("env->DeleteLocalRef(%p):v26", v26);
env->DeleteLocalRef(v26);
}
v26 = (jobject) v7;
LOGD("814:invoke-interface \x76\x37\x2c\x20\x76\x32\x2c\x20\x76\x34\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x6f\x67\x67\x65\x72\x3b\x2d\x3e\x61\x28\x49\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v26);
jclass &clz = cls8;
jmethodID &mid = mth16;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/event/net/OkInterceptor$Logger", "a", "(ILjava/lang/String;)V");
jvalue args[] = {{.i = v6},{.l = v9}};
env->CallVoidMethodA(v26, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("81a:iget-object \x76\x37\x2c\x20\x76\x31\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x3b\x2d\x3e\x63\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x6f\x67\x67\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
jclass &clz = cls0;
jfieldID &fld = fld5;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/net/OkInterceptor", "c", "Lio/pro/edge/widget/event/net/OkInterceptor$Logger;");
v7 = (jobject) env->GetObjectField(v2,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v26) {
LOGD("env->DeleteLocalRef(%p):v26", v26);
env->DeleteLocalRef(v26);
}
v26 = (jobject) v7;
LOGD("81e:new-instance \x76\x38\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v13) {
LOGD("env->DeleteLocalRef(%p):v13", v13);
env->DeleteLocalRef(v13);
}
jclass &clz = cls5;
D2C_RESOLVE_CLASS(clz,"java/lang/StringBuilder");
v13 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("822:invoke-direct \x76\x38\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v13);
jclass &clz = cls5;
jmethodID &mid = mth5;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "<init>", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v13, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("828:const-string \x76\x39\x2c\x20\x27\x5b\x2a\x43\x4f\x4e\x54\x45\x4e\x54\x2a\x5d\x20\x27");
if (v15) {
LOGD("env->DeleteLocalRef(%p):v15", v15);
env->DeleteLocalRef(v15);
}
v15 = (jstring) env->NewStringUTF("\x5b\x2a\x43\x4f\x4e\x54\x45\x4e\x54\x2a\x5d\x20");
LOGD("82c:invoke-virtual \x76\x38\x2c\x20\x76\x39\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v13);
jclass &clz = cls5;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v15}};
v7 = (jobject) env->CallObjectMethodA(v13, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("832:invoke-virtual \x76\x35\x2c\x20\x4c\x6f\x6b\x69\x6f\x2f\x42\x75\x66\x66\x65\x72\x3b\x2d\x3e\x63\x6c\x6f\x6e\x65\x28\x29\x4c\x6f\x6b\x69\x6f\x2f\x42\x75\x66\x66\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v10);
jclass &clz = cls11;
jmethodID &mid = mth46;
D2C_RESOLVE_METHOD(clz, mid, "okio/Buffer", "clone", "()Lokio/Buffer;");
jvalue args[] = {};
v7 = (jobject) env->CallObjectMethodA(v10, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("838:move-result-object \x76\x39");
if (v15) {
LOGD("env->DeleteLocalRef(%p):v15", v15);
env->DeleteLocalRef(v15);
}
v15 = (jobject) v7;
LOGD("83a:invoke-virtual \x76\x39\x2c\x20\x76\x36\x2c\x20\x4c\x6f\x6b\x69\x6f\x2f\x42\x75\x66\x66\x65\x72\x3b\x2d\x3e\x72\x65\x61\x64\x53\x74\x72\x69\x6e\x67\x28\x4c\x6a\x61\x76\x61\x2f\x6e\x69\x6f\x2f\x63\x68\x61\x72\x73\x65\x74\x2f\x43\x68\x61\x72\x73\x65\x74\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v15);
jclass &clz = cls11;
jmethodID &mid = mth28;
D2C_RESOLVE_METHOD(clz, mid, "okio/Buffer", "readString", "(Ljava/nio/charset/Charset;)Ljava/lang/String;");
jvalue args[] = {{.l = v34}};
v7 = (jstring) env->CallObjectMethodA(v15, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("840:move-result-object \x76\x36");
if (v34) {
LOGD("env->DeleteLocalRef(%p):v34", v34);
env->DeleteLocalRef(v34);
}
v34 = (jobject) v7;
LOGD("842:invoke-virtual \x76\x38\x2c\x20\x76\x36\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v13);
jclass &clz = cls5;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v34}};
v7 = (jobject) env->CallObjectMethodA(v13, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("848:invoke-virtual \x76\x38\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x74\x6f\x53\x74\x72\x69\x6e\x67\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v13);
jclass &clz = cls5;
jmethodID &mid = mth12;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "toString", "()Ljava/lang/String;");
jvalue args[] = {};
v7 = (jstring) env->CallObjectMethodA(v13, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("84e:move-result-object \x76\x36");
if (v34) {
LOGD("env->DeleteLocalRef(%p):v34", v34);
env->DeleteLocalRef(v34);
}
v34 = (jobject) v7;
LOGD("850:invoke-interface \x76\x37\x2c\x20\x76\x32\x2c\x20\x76\x36\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x6f\x67\x67\x65\x72\x3b\x2d\x3e\x61\x28\x49\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v26);
jclass &clz = cls8;
jmethodID &mid = mth16;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/event/net/OkInterceptor$Logger", "a", "(ILjava/lang/String;)V");
jvalue args[] = {{.i = v6},{.l = v34}};
env->CallVoidMethodA(v26, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L101:
LOGD("856:if-eqz \x76\x33\x2c\x20\x2b\x32\x61");
if(v8 == NULL){
goto L103;
}
else {
goto L102;
}
L102:
LOGD("85a:iget-object \x76\x36\x2c\x20\x76\x31\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x3b\x2d\x3e\x63\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x6f\x67\x67\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
jclass &clz = cls0;
jfieldID &fld = fld5;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/net/OkInterceptor", "c", "Lio/pro/edge/widget/event/net/OkInterceptor$Logger;");
v7 = (jobject) env->GetObjectField(v2,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v34) {
LOGD("env->DeleteLocalRef(%p):v34", v34);
env->DeleteLocalRef(v34);
}
v34 = (jobject) v7;
LOGD("85e:new-instance \x76\x37\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v26) {
LOGD("env->DeleteLocalRef(%p):v26", v26);
env->DeleteLocalRef(v26);
}
jclass &clz = cls5;
D2C_RESOLVE_CLASS(clz,"java/lang/StringBuilder");
v26 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("862:invoke-direct \x76\x37\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v26);
jclass &clz = cls5;
jmethodID &mid = mth5;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "<init>", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v26, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("868:const-string \x76\x38\x2c\x20\x27\x3c\x2d\x2d\x20\x45\x4e\x44\x20\x48\x54\x54\x50\x20\x28\x27");
if (v13) {
LOGD("env->DeleteLocalRef(%p):v13", v13);
env->DeleteLocalRef(v13);
}
v13 = (jstring) env->NewStringUTF("\x3c\x2d\x2d\x20\x45\x4e\x44\x20\x48\x54\x54\x50\x20\x28");
LOGD("86c:invoke-virtual \x76\x37\x2c\x20\x76\x38\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v26);
jclass &clz = cls5;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v13}};
v7 = (jobject) env->CallObjectMethodA(v26, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("872:invoke-virtual \x76\x35\x2c\x20\x4c\x6f\x6b\x69\x6f\x2f\x42\x75\x66\x66\x65\x72\x3b\x2d\x3e\x73\x69\x7a\x65\x28\x29\x4a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v10);
jclass &clz = cls11;
jmethodID &mid = mth44;
D2C_RESOLVE_METHOD(clz, mid, "okio/Buffer", "size", "()J");
jvalue args[] = {};
v24 = (jlong) env->CallLongMethodA(v10, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("878:move-result-wide \x76\x38");
v35 = (jlong) v24;
LOGD("87a:invoke-virtual \x76\x37\x2c\x20\x76\x38\x2c\x20\x76\x39\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4a\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v26);
jclass &clz = cls5;
jmethodID &mid = mth14;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(J)Ljava/lang/StringBuilder;");
jvalue args[] = {{.j = (jlong) v35}};
v7 = (jobject) env->CallObjectMethodA(v26, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("880:const-string \x76\x35\x2c\x20\x27\x2d\x62\x79\x74\x65\x2c\x20\x27");
if (v10) {
LOGD("env->DeleteLocalRef(%p):v10", v10);
env->DeleteLocalRef(v10);
}
v10 = (jstring) env->NewStringUTF("\x2d\x62\x79\x74\x65\x2c\x20");
LOGD("884:invoke-virtual \x76\x37\x2c\x20\x76\x35\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v26);
jclass &clz = cls5;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v10}};
v7 = (jobject) env->CallObjectMethodA(v26, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("88a:invoke-virtual \x76\x37\x2c\x20\x76\x33\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v26);
jclass &clz = cls5;
jmethodID &mid = mth10;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/Object;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v8}};
v7 = (jobject) env->CallObjectMethodA(v26, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("890:const-string \x76\x33\x2c\x20\x27\x2d\x67\x7a\x69\x70\x70\x65\x64\x2d\x62\x79\x74\x65\x20\x62\x6f\x64\x79\x29\x27");
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jstring) env->NewStringUTF("\x2d\x67\x7a\x69\x70\x70\x65\x64\x2d\x62\x79\x74\x65\x20\x62\x6f\x64\x79\x29");
LOGD("894:invoke-virtual \x76\x37\x2c\x20\x76\x33\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v26);
jclass &clz = cls5;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v8}};
v7 = (jobject) env->CallObjectMethodA(v26, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("89a:invoke-virtual \x76\x37\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x74\x6f\x53\x74\x72\x69\x6e\x67\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v26);
jclass &clz = cls5;
jmethodID &mid = mth12;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "toString", "()Ljava/lang/String;");
jvalue args[] = {};
v7 = (jstring) env->CallObjectMethodA(v26, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("8a0:move-result-object \x76\x33");
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jobject) v7;
LOGD("8a2:invoke-interface \x76\x36\x2c\x20\x76\x32\x2c\x20\x76\x33\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x6f\x67\x67\x65\x72\x3b\x2d\x3e\x61\x28\x49\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v34);
jclass &clz = cls8;
jmethodID &mid = mth16;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/event/net/OkInterceptor$Logger", "a", "(ILjava/lang/String;)V");
jvalue args[] = {{.i = v6},{.l = v8}};
env->CallVoidMethodA(v34, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
goto L106;
L103:
LOGD("8aa:iget-object \x76\x33\x2c\x20\x76\x31\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x3b\x2d\x3e\x63\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x6f\x67\x67\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
jclass &clz = cls0;
jfieldID &fld = fld5;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/net/OkInterceptor", "c", "Lio/pro/edge/widget/event/net/OkInterceptor$Logger;");
v7 = (jobject) env->GetObjectField(v2,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jobject) v7;
LOGD("8ae:new-instance \x76\x36\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v34) {
LOGD("env->DeleteLocalRef(%p):v34", v34);
env->DeleteLocalRef(v34);
}
jclass &clz = cls5;
D2C_RESOLVE_CLASS(clz,"java/lang/StringBuilder");
v34 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("8b2:invoke-direct \x76\x36\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v34);
jclass &clz = cls5;
jmethodID &mid = mth5;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "<init>", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v34, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("8b8:const-string \x76\x37\x2c\x20\x27\x3c\x2d\x2d\x20\x45\x4e\x44\x20\x48\x54\x54\x50\x20\x28\x27");
if (v26) {
LOGD("env->DeleteLocalRef(%p):v26", v26);
env->DeleteLocalRef(v26);
}
v26 = (jstring) env->NewStringUTF("\x3c\x2d\x2d\x20\x45\x4e\x44\x20\x48\x54\x54\x50\x20\x28");
LOGD("8bc:invoke-virtual \x76\x36\x2c\x20\x76\x37\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v34);
jclass &clz = cls5;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v26}};
v7 = (jobject) env->CallObjectMethodA(v34, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("8c2:invoke-virtual \x76\x35\x2c\x20\x4c\x6f\x6b\x69\x6f\x2f\x42\x75\x66\x66\x65\x72\x3b\x2d\x3e\x73\x69\x7a\x65\x28\x29\x4a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v10);
jclass &clz = cls11;
jmethodID &mid = mth44;
D2C_RESOLVE_METHOD(clz, mid, "okio/Buffer", "size", "()J");
jvalue args[] = {};
v24 = (jlong) env->CallLongMethodA(v10, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("8c8:move-result-wide \x76\x37");
v25 = (jlong) v24;
LOGD("8ca:invoke-virtual \x76\x36\x2c\x20\x76\x37\x2c\x20\x76\x38\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4a\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v34);
jclass &clz = cls5;
jmethodID &mid = mth14;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(J)Ljava/lang/StringBuilder;");
jvalue args[] = {{.j = (jlong) v25}};
v7 = (jobject) env->CallObjectMethodA(v34, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
if (v10) {
LOGD("env->DeleteLocalRef(%p):v10", v10);
env->DeleteLocalRef(v10);
}
v10 = (jobject) env->NewLocalRef(v38);
LOGD("8d4:invoke-virtual \x76\x36\x2c\x20\x76\x35\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v34);
jclass &clz = cls5;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v10}};
v7 = (jobject) env->CallObjectMethodA(v34, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("8da:invoke-virtual \x76\x36\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x74\x6f\x53\x74\x72\x69\x6e\x67\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v34);
jclass &clz = cls5;
jmethodID &mid = mth12;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "toString", "()Ljava/lang/String;");
jvalue args[] = {};
v7 = (jstring) env->CallObjectMethodA(v34, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("8e0:move-result-object \x76\x35");
if (v10) {
LOGD("env->DeleteLocalRef(%p):v10", v10);
env->DeleteLocalRef(v10);
}
v10 = (jobject) v7;
LOGD("8e2:invoke-interface \x76\x33\x2c\x20\x76\x32\x2c\x20\x76\x35\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x6f\x67\x67\x65\x72\x3b\x2d\x3e\x61\x28\x49\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v8);
jclass &clz = cls8;
jmethodID &mid = mth16;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/event/net/OkInterceptor$Logger", "a", "(ILjava/lang/String;)V");
jvalue args[] = {{.i = v6},{.l = v10}};
env->CallVoidMethodA(v8, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
goto L106;
L104:
if (v9) {
LOGD("env->DeleteLocalRef(%p):v9", v9);
env->DeleteLocalRef(v9);
}
v9 = (jobject) env->NewLocalRef(v43);
LOGD("8ee:iget-object \x76\x33\x2c\x20\x76\x31\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x3b\x2d\x3e\x63\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x6f\x67\x67\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
jclass &clz = cls0;
jfieldID &fld = fld5;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/net/OkInterceptor", "c", "Lio/pro/edge/widget/event/net/OkInterceptor$Logger;");
v7 = (jobject) env->GetObjectField(v2,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jobject) v7;
LOGD("8f2:const-string \x76\x35\x2c\x20\x27\x3c\x2d\x2d\x20\x45\x4e\x44\x20\x48\x54\x54\x50\x27");
if (v10) {
LOGD("env->DeleteLocalRef(%p):v10", v10);
env->DeleteLocalRef(v10);
}
v10 = (jstring) env->NewStringUTF("\x3c\x2d\x2d\x20\x45\x4e\x44\x20\x48\x54\x54\x50");
LOGD("8f6:invoke-interface \x76\x33\x2c\x20\x76\x32\x2c\x20\x76\x35\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x6f\x67\x67\x65\x72\x3b\x2d\x3e\x61\x28\x49\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v8);
jclass &clz = cls8;
jmethodID &mid = mth16;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/event/net/OkInterceptor$Logger", "a", "(ILjava/lang/String;)V");
jvalue args[] = {{.i = v6},{.l = v10}};
env->CallVoidMethodA(v8, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
goto L106;
L105:
if (v9) {
LOGD("env->DeleteLocalRef(%p):v9", v9);
env->DeleteLocalRef(v9);
}
v9 = (jobject) env->NewLocalRef(v43);
L106:
LOGD("902:iget-object \x76\x32\x2c\x20\x76\x31\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x3b\x2d\x3e\x63\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x6f\x67\x67\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
jclass &clz = cls0;
jfieldID &fld = fld5;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/net/OkInterceptor", "c", "Lio/pro/edge/widget/event/net/OkInterceptor$Logger;");
v7 = (jobject) env->GetObjectField(v2,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
v4 = (jobject) v7;
LOGD("906:invoke-interface \x76\x32\x2c\x20\x76\x34\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x6f\x67\x67\x65\x72\x3b\x2d\x3e\x61\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v4);
jclass &clz = cls8;
jmethodID &mid = mth15;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/event/net/OkInterceptor$Logger", "a", "(Ljava/lang/String;)V");
jvalue args[] = {{.l = v9}};
env->CallVoidMethodA(v4, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("90c:iget-object \x76\x32\x2c\x20\x76\x31\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x3b\x2d\x3e\x63\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x6f\x67\x67\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
jclass &clz = cls0;
jfieldID &fld = fld5;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/net/OkInterceptor", "c", "Lio/pro/edge/widget/event/net/OkInterceptor$Logger;");
v7 = (jobject) env->GetObjectField(v2,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
v4 = (jobject) v7;
LOGD("910:instance-of \x76\x33\x2c\x20\x76\x32\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x45\x61\x73\x79\x4c\x6f\x67\x67\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls21;
D2C_RESOLVE_CLASS(clz,"io/pro/edge/widget/event/net/OkInterceptor$EasyLogger");
v41 = d2c_is_instance_of(env, v4, clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("914:if-eqz \x76\x33\x2c\x20\x2b\x65");
if(v41 == 0){
goto L108;
}
else {
goto L107;
}
L107:
LOGD("918:check-cast \x76\x32\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x45\x61\x73\x79\x4c\x6f\x67\x67\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls21;
D2C_RESOLVE_CLASS(clz,"io/pro/edge/widget/event/net/OkInterceptor$EasyLogger");
D2C_CHECK_CAST(v4, clz, "io/pro/edge/widget/event/net/OkInterceptor$EasyLogger");
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("91c:invoke-static \x76\x32\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x45\x61\x73\x79\x4c\x6f\x67\x67\x65\x72\x3b\x2d\x3e\x61\x28\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x45\x61\x73\x79\x4c\x6f\x67\x67\x65\x72\x3b\x29\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x75\x74\x69\x6c\x73\x2f\x54\x72\x61\x6e\x73\x66\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls21;
jmethodID &mid = mth51;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "io/pro/edge/widget/event/net/OkInterceptor$EasyLogger", "a", "(Lio/pro/edge/widget/event/net/OkInterceptor$EasyLogger;)Lio/pro/edge/widget/event/utils/Transfer;");
jvalue args[] = {{.l = v4}};
v7 = (jobject) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("922:move-result-object \x76\x32");
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
v4 = (jobject) v7;
v41 = 0;
LOGD("926:new-array \x76\x33\x2c\x20\x76\x33\x2c\x20\x5b\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v41 < 0) {
d2c_throw_exception(env, "java/lang/NegativeArraySizeException", "negative array size");
goto EX_HANDLE;
}
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
jclass &clz = cls10;
D2C_RESOLVE_CLASS(clz,"java/lang/String");
v8 = env->NewObjectArray((jint) v41, clz, NULL);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("92a:invoke-virtual \x76\x32\x2c\x20\x76\x33\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x75\x74\x69\x6c\x73\x2f\x54\x72\x61\x6e\x73\x66\x65\x72\x3b\x2d\x3e\x61\x28\x5b\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v4);
jclass &clz = cls22;
jmethodID &mid = mth52;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/event/utils/Transfer", "a", "([Ljava/lang/String;)V");
jvalue args[] = {{.l = v8}};
env->CallVoidMethodA(v4, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L108:
return (jobject) v3;
L109:
LOGD("932:move-exception \x76\x30");
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
v3 = exception;
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jobject) env->NewLocalRef(v3);
LOGD("936:iget-object \x76\x30\x2c\x20\x76\x31\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x3b\x2d\x3e\x63\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x6f\x67\x67\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
jclass &clz = cls0;
jfieldID &fld = fld5;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/net/OkInterceptor", "c", "Lio/pro/edge/widget/event/net/OkInterceptor$Logger;");
v7 = (jobject) env->GetObjectField(v2,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
v3 = (jobject) v7;
LOGD("93a:new-instance \x76\x34\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v9) {
LOGD("env->DeleteLocalRef(%p):v9", v9);
env->DeleteLocalRef(v9);
}
jclass &clz = cls5;
D2C_RESOLVE_CLASS(clz,"java/lang/StringBuilder");
v9 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("93e:invoke-direct \x76\x34\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v9);
jclass &clz = cls5;
jmethodID &mid = mth5;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "<init>", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v9, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("944:const-string \x76\x35\x2c\x20\x27\x3c\x2d\x2d\x20\x48\x54\x54\x50\x20\x46\x41\x49\x4c\x45\x44\x3a\x20\x27");
if (v10) {
LOGD("env->DeleteLocalRef(%p):v10", v10);
env->DeleteLocalRef(v10);
}
v10 = (jstring) env->NewStringUTF("\x3c\x2d\x2d\x20\x48\x54\x54\x50\x20\x46\x41\x49\x4c\x45\x44\x3a\x20");
LOGD("948:invoke-virtual \x76\x34\x2c\x20\x76\x35\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v9);
jclass &clz = cls5;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v10}};
v7 = (jobject) env->CallObjectMethodA(v9, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("94e:invoke-virtual \x76\x34\x2c\x20\x76\x33\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v9);
jclass &clz = cls5;
jmethodID &mid = mth10;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/Object;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v8}};
v7 = (jobject) env->CallObjectMethodA(v9, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("954:invoke-virtual \x76\x34\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x74\x6f\x53\x74\x72\x69\x6e\x67\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v9);
jclass &clz = cls5;
jmethodID &mid = mth12;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "toString", "()Ljava/lang/String;");
jvalue args[] = {};
v7 = (jstring) env->CallObjectMethodA(v9, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("95a:move-result-object \x76\x34");
if (v9) {
LOGD("env->DeleteLocalRef(%p):v9", v9);
env->DeleteLocalRef(v9);
}
v9 = (jobject) v7;
LOGD("95c:invoke-interface \x76\x30\x2c\x20\x76\x32\x2c\x20\x76\x34\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x6f\x67\x67\x65\x72\x3b\x2d\x3e\x61\x28\x49\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls8;
jmethodID &mid = mth16;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/event/net/OkInterceptor$Logger", "a", "(ILjava/lang/String;)V");
jvalue args[] = {{.i = v6},{.l = v9}};
env->CallVoidMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("962:throw \x76\x33");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v8);
env->Throw((jthrowable) v8);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}

EX_LandingPad_48:
D2C_GET_PENDING_EX
if(d2c_is_instance_of(env, exception, "java/lang/Exception")) {
goto L109;
}
D2C_GOTO_UNWINDBLOCK

EX_LandingPad_79:
D2C_GET_PENDING_EX
if(d2c_is_instance_of(env, exception, "java/lang/Throwable")) {
goto L88;
}
D2C_GOTO_UNWINDBLOCK

EX_LandingPad_83:
D2C_GET_PENDING_EX
if(d2c_is_instance_of(env, exception, "java/lang/Throwable")) {
goto L87;
}
D2C_GOTO_UNWINDBLOCK
EX_UnwindBlock: return NULL;
}
