#include "Dex2C.h"

/* Lio/pro/edge/widget/event/action/DownloadClient$1;->onConsoleMessage(Landroid/webkit/ConsoleMessage;)Z */
extern "C" JNIEXPORT jboolean JNICALL
Java_io_pro_edge_widget_event_action_DownloadClient_000241_onConsoleMessage__Landroid_webkit_ConsoleMessage_2(JNIEnv *env, jobject thiz, jobject p5){
jobject v0 = NULL;
jobject v1 = NULL;
jobject v2 = NULL;
jobject v3 = NULL;
jobject v4 = NULL;
jint v5;
jint v6;
jint v7;
jobject v8 = NULL;
jint v9;
jint v10;
jclass cls0 = NULL,cls1 = NULL,cls2 = NULL,cls3 = NULL,cls4 = NULL,cls5 = NULL,cls6 = NULL,cls7 = NULL;
jfieldID fld0 = NULL,fld1 = NULL,fld2 = NULL;
jmethodID mth0 = NULL, mth1 = NULL, mth2 = NULL, mth3 = NULL, mth4 = NULL, mth5 = NULL, mth6 = NULL;
v0 = (jobject)env->NewLocalRef(thiz);
v1 = (jobject)env->NewLocalRef(p5);
L0:
LOGD("0:invoke-virtual \x76\x35\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x43\x6f\x6e\x73\x6f\x6c\x65\x4d\x65\x73\x73\x61\x67\x65\x3b\x2d\x3e\x6d\x65\x73\x73\x61\x67\x65\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v1);
jclass &clz = cls0;
jmethodID &mid = mth0;
D2C_RESOLVE_METHOD(clz, mid, "android/webkit/ConsoleMessage", "message", "()Ljava/lang/String;");
jvalue args[] = {};
v2 = (jstring) env->CallObjectMethodA(v1, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("6:move-result-object \x76\x30");
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
v3 = (jobject) v2;
LOGD("8:if-eqz \x76\x30\x2c\x20\x2b\x33\x37");
if(v3 == NULL){
goto L3;
}
else {
goto L1;
}
L1:
LOGD("c:invoke-virtual \x76\x35\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x43\x6f\x6e\x73\x6f\x6c\x65\x4d\x65\x73\x73\x61\x67\x65\x3b\x2d\x3e\x6d\x65\x73\x73\x61\x67\x65\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v1);
jclass &clz = cls0;
jmethodID &mid = mth0;
D2C_RESOLVE_METHOD(clz, mid, "android/webkit/ConsoleMessage", "message", "()Ljava/lang/String;");
jvalue args[] = {};
v2 = (jstring) env->CallObjectMethodA(v1, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("12:move-result-object \x76\x30");
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
v3 = (jobject) v2;
LOGD("14:const-string \x76\x31\x2c\x20\x27\x2b\x2b\x2b\x2b\x27");
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
v4 = (jobject) env->NewStringUTF("\x2b\x2b\x2b\x2b");
LOGD("18:invoke-virtual \x76\x30\x2c\x20\x76\x31\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x63\x6f\x6e\x74\x61\x69\x6e\x73\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x68\x61\x72\x53\x65\x71\x75\x65\x6e\x63\x65\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls1;
jmethodID &mid = mth1;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "contains", "(Ljava/lang/CharSequence;)Z");
jvalue args[] = {{.l = v4}};
v5 = (jboolean) env->CallBooleanMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("1e:move-result \x76\x30");
v6 = (jint) v5;
LOGD("20:if-eqz \x76\x30\x2c\x20\x2b\x32\x62");
if(v6 == 0){
goto L3;
}
else {
goto L2;
}
L2:
LOGD("24:new-instance \x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
jclass &clz = cls2;
D2C_RESOLVE_CLASS(clz,"java/lang/StringBuilder");
v3 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("28:invoke-direct \x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls2;
jmethodID &mid = mth2;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "<init>", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("2e:const-string \x76\x31\x2c\x20\x27\x5b\x43\x4f\x4e\x53\x4f\x4c\x45\x5d\x3a\x27");
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
v4 = (jstring) env->NewStringUTF("\x5b\x43\x4f\x4e\x53\x4f\x4c\x45\x5d\x3a");
LOGD("32:invoke-virtual \x76\x30\x2c\x20\x76\x31\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls2;
jmethodID &mid = mth3;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v4}};
v2 = (jobject) env->CallObjectMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
LOGD("38:invoke-virtual \x76\x35\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x43\x6f\x6e\x73\x6f\x6c\x65\x4d\x65\x73\x73\x61\x67\x65\x3b\x2d\x3e\x6d\x65\x73\x73\x61\x67\x65\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v1);
jclass &clz = cls0;
jmethodID &mid = mth0;
D2C_RESOLVE_METHOD(clz, mid, "android/webkit/ConsoleMessage", "message", "()Ljava/lang/String;");
jvalue args[] = {};
v2 = (jstring) env->CallObjectMethodA(v1, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("3e:move-result-object \x76\x31");
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
v4 = (jobject) v2;
LOGD("40:invoke-virtual \x76\x30\x2c\x20\x76\x31\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls2;
jmethodID &mid = mth3;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v4}};
v2 = (jobject) env->CallObjectMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
LOGD("46:const-string \x76\x31\x2c\x20\x27\x20\x27");
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
v4 = (jstring) env->NewStringUTF("\x20");
LOGD("4a:invoke-virtual \x76\x30\x2c\x20\x76\x31\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls2;
jmethodID &mid = mth3;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v4}};
v2 = (jobject) env->CallObjectMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
LOGD("50:invoke-virtual \x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x74\x6f\x53\x74\x72\x69\x6e\x67\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls2;
jmethodID &mid = mth4;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "toString", "()Ljava/lang/String;");
jvalue args[] = {};
v2 = (jstring) env->CallObjectMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("56:move-result-object \x76\x30");
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
v3 = (jobject) v2;
LOGD("58:iget-object \x76\x31\x2c\x20\x76\x34\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x44\x6f\x77\x6e\x6c\x6f\x61\x64\x43\x6c\x69\x65\x6e\x74\x24\x31\x3b\x2d\x3e\x61\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x44\x6f\x77\x6e\x6c\x6f\x61\x64\x43\x6c\x69\x65\x6e\x74\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls3;
jfieldID &fld = fld0;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/action/DownloadClient$1", "a", "Lio/pro/edge/widget/event/action/DownloadClient;");
v2 = (jobject) env->GetObjectField(v0,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
v4 = (jobject) v2;
LOGD("5c:iget-object \x76\x31\x2c\x20\x76\x31\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x44\x6f\x77\x6e\x6c\x6f\x61\x64\x43\x6c\x69\x65\x6e\x74\x3b\x2d\x3e\x65\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x57\x6f\x72\x6b\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v4);
jclass &clz = cls4;
jfieldID &fld = fld1;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/action/DownloadClient", "e", "Lio/pro/edge/widget/event/action/Worker;");
v2 = (jobject) env->GetObjectField(v4,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
v4 = (jobject) v2;
LOGD("60:iget-object \x76\x31\x2c\x20\x76\x31\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x57\x6f\x72\x6b\x65\x72\x3b\x2d\x3e\x7a\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x75\x74\x69\x6c\x73\x2f\x54\x72\x61\x6e\x73\x66\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v4);
jclass &clz = cls5;
jfieldID &fld = fld2;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/action/Worker", "z", "Lio/pro/edge/widget/event/utils/Transfer;");
v2 = (jobject) env->GetObjectField(v4,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
v4 = (jobject) v2;
v7 = 1;
LOGD("66:new-array \x76\x32\x2c\x20\x76\x32\x2c\x20\x5b\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v7 < 0) {
d2c_throw_exception(env, "java/lang/NegativeArraySizeException", "negative array size");
goto EX_HANDLE;
}
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
jclass &clz = cls1;
D2C_RESOLVE_CLASS(clz,"java/lang/String");
v8 = env->NewObjectArray((jint) v7, clz, NULL);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
v9 = 0;
LOGD("6c:aput-object \x76\x30\x2c\x20\x76\x32\x2c\x20\x76\x33");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v8);
env->SetObjectArrayElement((jobjectArray) v8, (jint) v9, v3);D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("70:invoke-virtual \x76\x31\x2c\x20\x76\x32\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x75\x74\x69\x6c\x73\x2f\x54\x72\x61\x6e\x73\x66\x65\x72\x3b\x2d\x3e\x61\x28\x5b\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v4);
jclass &clz = cls6;
jmethodID &mid = mth5;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/event/utils/Transfer", "a", "([Ljava/lang/String;)V");
jvalue args[] = {{.l = v8}};
env->CallVoidMethodA(v4, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L3:
LOGD("76:invoke-super \x76\x34\x2c\x20\x76\x35\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x43\x68\x72\x6f\x6d\x65\x43\x6c\x69\x65\x6e\x74\x3b\x2d\x3e\x6f\x6e\x43\x6f\x6e\x73\x6f\x6c\x65\x4d\x65\x73\x73\x61\x67\x65\x28\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x43\x6f\x6e\x73\x6f\x6c\x65\x4d\x65\x73\x73\x61\x67\x65\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls7;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "android/webkit/WebChromeClient", "onConsoleMessage", "(Landroid/webkit/ConsoleMessage;)Z");
jvalue args[] = {{.l = v1}};
v5 = (jboolean) env->CallNonvirtualBooleanMethodA(v0, clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("7c:move-result \x76\x35");
v10 = (jint) v5;
return (jboolean) v10;
EX_UnwindBlock: return (jboolean)0;
}
