#include "Dex2C.h"

/* Lio/pro/edge/widget/event/utils/InUtils;->c(Landroid/content/Context;Ljava/lang/String;)V */
extern "C" JNIEXPORT void JNICALL
Java_io_pro_edge_widget_event_utils_InUtils_c__Landroid_content_Context_2Ljava_lang_String_2(JNIEnv *env, jobject thiz, jobject p1, jstring p2){
jobject v0 = NULL;
jobject v1 = NULL;
jobject v2 = NULL;
jclass cls0 = NULL;
jmethodID mth0 = NULL;
v0 = (jobject)env->NewLocalRef(p1);
v1 = (jobject)env->NewLocalRef(p2);
L0:
LOGD("0:const-string \x76\x30\x2c\x20\x27\x6b\x65\x79\x5f\x6c\x6f\x63\x61\x6c\x5f\x69\x64\x73\x27");
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
v2 = (jstring) env->NewStringUTF("\x6b\x65\x79\x5f\x6c\x6f\x63\x61\x6c\x5f\x69\x64\x73");
LOGD("4:invoke-static \x76\x31\x2c\x20\x76\x30\x2c\x20\x76\x32\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x75\x74\x69\x6c\x73\x2f\x49\x6e\x55\x74\x69\x6c\x73\x3b\x2d\x3e\x62\x28\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6e\x74\x65\x78\x74\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls0;
jmethodID &mid = mth0;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "io/pro/edge/widget/event/utils/InUtils", "b", "(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V");
jvalue args[] = {{.l = v0},{.l = v2},{.l = v1}};
env->CallStaticVoidMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
return;
EX_UnwindBlock: return;
}
