#include "Dex2C.h"

/* Lio/pro/edge/widget/event/action/DownloadClient;->shouldOverrideUrlLoading(Landroid/webkit/WebView;Ljava/lang/String;)Z */
extern "C" JNIEXPORT jboolean JNICALL
Java_io_pro_edge_widget_event_action_DownloadClient_shouldOverrideUrlLoading__Landroid_webkit_WebView_2Ljava_lang_String_2(JNIEnv *env, jobject thiz, jobject p4, jstring p5){
jobject v0 = NULL;
jobject v1 = NULL;
jobject v2 = NULL;
jobject v3 = NULL;
jobject v4 = NULL;
jobject v5 = NULL;
jint v6;
jint v7;
jobject v8 = NULL;
jint v9;
jthrowable exception;
jclass cls0 = NULL,cls1 = NULL,cls2 = NULL,cls3 = NULL,cls4 = NULL,cls5 = NULL,cls6 = NULL,cls7 = NULL,cls8 = NULL;
jfieldID fld0 = NULL,fld1 = NULL,fld2 = NULL,fld3 = NULL;
jmethodID mth0 = NULL, mth1 = NULL, mth2 = NULL, mth3 = NULL, mth4 = NULL, mth5 = NULL, mth6 = NULL, mth7 = NULL, mth8 = NULL, mth9 = NULL, mth10 = NULL, mth11 = NULL, mth12 = NULL, mth13 = NULL, mth14 = NULL, mth15 = NULL;
v0 = (jobject)env->NewLocalRef(thiz);
v1 = (jobject)env->NewLocalRef(p4);
v2 = (jobject)env->NewLocalRef(p5);
L0:
LOGD("0:const-string \x76\x30\x2c\x20\x27\x62\x6f\x64\x79\x3d\x27");
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
v3 = (jobject) env->NewStringUTF("\x62\x6f\x64\x79\x3d");
LOGD("4:iget-object \x76\x31\x2c\x20\x76\x33\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x44\x6f\x77\x6e\x6c\x6f\x61\x64\x43\x6c\x69\x65\x6e\x74\x3b\x2d\x3e\x68\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x73\x2f\x49\x57\x65\x62\x43\x6c\x69\x65\x6e\x74\x4c\x69\x73\x74\x65\x6e\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jfieldID &fld = fld0;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/action/DownloadClient", "h", "Lio/pro/edge/widget/interfaces/IWebClientListener;");
v4 = (jobject) env->GetObjectField(v0,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v5) {
LOGD("env->DeleteLocalRef(%p):v5", v5);
env->DeleteLocalRef(v5);
}
v5 = (jobject) v4;
LOGD("8:if-eqz \x76\x31\x2c\x20\x2b\x35");
if(v5 == NULL){
goto L2;
}
else {
goto L1;
}
L1:
LOGD("c:invoke-interface \x76\x31\x2c\x20\x76\x34\x2c\x20\x76\x35\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x73\x2f\x49\x57\x65\x62\x43\x6c\x69\x65\x6e\x74\x4c\x69\x73\x74\x65\x6e\x65\x72\x3b\x2d\x3e\x61\x28\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x56\x69\x65\x77\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v5);
jclass &clz = cls1;
jmethodID &mid = mth0;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/interfaces/IWebClientListener", "a", "(Landroid/webkit/WebView;Ljava/lang/String;)V");
jvalue args[] = {{.l = v1},{.l = v2}};
env->CallVoidMethodA(v5, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L2:
LOGD("12:const-string \x76\x34\x2c\x20\x27\x68\x74\x74\x70\x3a\x2f\x2f\x27");
if (v1) {
LOGD("env->DeleteLocalRef(%p):v1", v1);
env->DeleteLocalRef(v1);
}
v1 = (jstring) env->NewStringUTF("\x68\x74\x74\x70\x3a\x2f\x2f");
LOGD("16:invoke-virtual \x76\x35\x2c\x20\x76\x34\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x73\x74\x61\x72\x74\x73\x57\x69\x74\x68\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
jclass &clz = cls2;
jmethodID &mid = mth1;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "startsWith", "(Ljava/lang/String;)Z");
jvalue args[] = {{.l = v1}};
v6 = (jboolean) env->CallBooleanMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("1c:move-result \x76\x34");
v7 = (jint) v6;
LOGD("1e:if-nez \x76\x34\x2c\x20\x2b\x61");
if(v7 != 0){
goto L4;
}
else {
goto L3;
}
L3:
LOGD("22:const-string \x76\x34\x2c\x20\x27\x68\x74\x74\x70\x73\x3a\x2f\x2f\x27");
if (v1) {
LOGD("env->DeleteLocalRef(%p):v1", v1);
env->DeleteLocalRef(v1);
}
v1 = (jstring) env->NewStringUTF("\x68\x74\x74\x70\x73\x3a\x2f\x2f");
LOGD("26:invoke-virtual \x76\x35\x2c\x20\x76\x34\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x73\x74\x61\x72\x74\x73\x57\x69\x74\x68\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
jclass &clz = cls2;
jmethodID &mid = mth1;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "startsWith", "(Ljava/lang/String;)Z");
jvalue args[] = {{.l = v1}};
v6 = (jboolean) env->CallBooleanMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("2c:move-result \x76\x34");
v7 = (jint) v6;
LOGD("2e:if-eqz \x76\x34\x2c\x20\x2b\x32\x32");
if(v7 == 0){
goto L7;
}
else {
goto L4;
}
L4:
LOGD("32:iget-object \x76\x34\x2c\x20\x76\x33\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x44\x6f\x77\x6e\x6c\x6f\x61\x64\x43\x6c\x69\x65\x6e\x74\x3b\x2d\x3e\x66\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x6f\x67\x67\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jfieldID &fld = fld1;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/action/DownloadClient", "f", "Lio/pro/edge/widget/event/net/OkInterceptor$Logger;");
v4 = (jobject) env->GetObjectField(v0,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v1) {
LOGD("env->DeleteLocalRef(%p):v1", v1);
env->DeleteLocalRef(v1);
}
v1 = (jobject) v4;
LOGD("36:if-eqz \x76\x34\x2c\x20\x2b\x31\x62");
if(v1 == NULL){
goto L6;
}
else {
goto L5;
}
L5:
LOGD("3a:new-instance \x76\x31\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v5) {
LOGD("env->DeleteLocalRef(%p):v5", v5);
env->DeleteLocalRef(v5);
}
jclass &clz = cls3;
D2C_RESOLVE_CLASS(clz,"java/lang/StringBuilder");
v5 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("3e:invoke-direct \x76\x31\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v5);
jclass &clz = cls3;
jmethodID &mid = mth2;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "<init>", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v5, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("44:const-string \x76\x32\x2c\x20\x27\x2d\x2d\x2d\x3e\x20\x27");
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jstring) env->NewStringUTF("\x2d\x2d\x2d\x3e\x20");
LOGD("48:invoke-virtual \x76\x31\x2c\x20\x76\x32\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v5);
jclass &clz = cls3;
jmethodID &mid = mth3;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v8}};
v4 = (jobject) env->CallObjectMethodA(v5, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
LOGD("4e:invoke-virtual \x76\x31\x2c\x20\x76\x35\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v5);
jclass &clz = cls3;
jmethodID &mid = mth3;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v2}};
v4 = (jobject) env->CallObjectMethodA(v5, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
LOGD("54:const-string \x76\x32\x2c\x20\x27\x20\x27");
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jstring) env->NewStringUTF("\x20");
LOGD("58:invoke-virtual \x76\x31\x2c\x20\x76\x32\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v5);
jclass &clz = cls3;
jmethodID &mid = mth3;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v8}};
v4 = (jobject) env->CallObjectMethodA(v5, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
LOGD("5e:invoke-virtual \x76\x31\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x74\x6f\x53\x74\x72\x69\x6e\x67\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v5);
jclass &clz = cls3;
jmethodID &mid = mth4;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "toString", "()Ljava/lang/String;");
jvalue args[] = {};
v4 = (jstring) env->CallObjectMethodA(v5, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("64:move-result-object \x76\x31");
if (v5) {
LOGD("env->DeleteLocalRef(%p):v5", v5);
env->DeleteLocalRef(v5);
}
v5 = (jobject) v4;
LOGD("66:invoke-interface \x76\x34\x2c\x20\x76\x31\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x6f\x67\x67\x65\x72\x3b\x2d\x3e\x61\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v1);
jclass &clz = cls4;
jmethodID &mid = mth5;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/event/net/OkInterceptor$Logger", "a", "(Ljava/lang/String;)V");
jvalue args[] = {{.l = v5}};
env->CallVoidMethodA(v1, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L6:
LOGD("6c:invoke-virtual \x76\x33\x2c\x20\x76\x35\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x44\x6f\x77\x6e\x6c\x6f\x61\x64\x43\x6c\x69\x65\x6e\x74\x3b\x2d\x3e\x62\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/event/action/DownloadClient", "b", "(Ljava/lang/String;)V");
jvalue args[] = {{.l = v2}};
env->CallVoidMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L7:
LOGD("72:const-string \x76\x34\x2c\x20\x27\x73\x6d\x73\x3a\x27");
if (v1) {
LOGD("env->DeleteLocalRef(%p):v1", v1);
env->DeleteLocalRef(v1);
}
v1 = (jstring) env->NewStringUTF("\x73\x6d\x73\x3a");
LOGD("76:invoke-virtual \x76\x35\x2c\x20\x76\x34\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x73\x74\x61\x72\x74\x73\x57\x69\x74\x68\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
jclass &clz = cls2;
jmethodID &mid = mth1;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "startsWith", "(Ljava/lang/String;)Z");
jvalue args[] = {{.l = v1}};
v6 = (jboolean) env->CallBooleanMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("7c:move-result \x76\x34");
v7 = (jint) v6;
LOGD("7e:if-eqz \x76\x34\x2c\x20\x2b\x33\x39");
if(v7 == 0){
goto L32;
}
else {
goto L8;
}
L8:
LOGD("82:invoke-virtual \x76\x35\x2c\x20\x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x63\x6f\x6e\x74\x61\x69\x6e\x73\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x68\x61\x72\x53\x65\x71\x75\x65\x6e\x63\x65\x3b\x29\x5a");
{
#define EX_HANDLE EX_LandingPad_8
D2C_NOT_NULL(v2);
jclass &clz = cls2;
jmethodID &mid = mth7;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "contains", "(Ljava/lang/CharSequence;)Z");
jvalue args[] = {{.l = v3}};
v6 = (jboolean) env->CallBooleanMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L9:
LOGD("88:move-result \x76\x34");
v7 = (jint) v6;
LOGD("8a:const-string \x76\x31\x2c\x20\x27\x27");
if (v5) {
LOGD("env->DeleteLocalRef(%p):v5", v5);
env->DeleteLocalRef(v5);
}
v5 = (jstring) env->NewStringUTF("");
LOGD("8e:if-eqz \x76\x34\x2c\x20\x2b\x31\x63");
if(v7 == 0){
goto L22;
}
else {
goto L10;
}
L10:
v7 = 0;
L11:
LOGD("94:invoke-virtual \x76\x35\x2c\x20\x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x69\x6e\x64\x65\x78\x4f\x66\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x49");
{
#define EX_HANDLE EX_LandingPad_11
D2C_NOT_NULL(v2);
jclass &clz = cls2;
jmethodID &mid = mth8;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "indexOf", "(Ljava/lang/String;)I");
jvalue args[] = {{.l = v3}};
v6 = (jint) env->CallIntMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L12:
LOGD("9a:move-result \x76\x32");
v9 = (jint) v6;
L13:
LOGD("9c:invoke-virtual \x76\x35\x2c\x20\x76\x34\x2c\x20\x76\x32\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x73\x75\x62\x73\x74\x72\x69\x6e\x67\x28\x49\x20\x49\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_LandingPad_11
D2C_NOT_NULL(v2);
jclass &clz = cls2;
jmethodID &mid = mth9;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "substring", "(II)Ljava/lang/String;");
jvalue args[] = {{.i = v7},{.i = v9}};
v4 = (jstring) env->CallObjectMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L14:
LOGD("a2:move-result-object \x76\x34");
if (v1) {
LOGD("env->DeleteLocalRef(%p):v1", v1);
env->DeleteLocalRef(v1);
}
v1 = (jobject) v4;
L15:
LOGD("a4:const-string \x76\x32\x2c\x20\x27\x5b\x5e\x30\x2d\x39\x5d\x27");
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jstring) env->NewStringUTF("\x5b\x5e\x30\x2d\x39\x5d");
L16:
LOGD("a8:invoke-virtual \x76\x34\x2c\x20\x76\x32\x2c\x20\x76\x31\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x72\x65\x70\x6c\x61\x63\x65\x41\x6c\x6c\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_LandingPad_11
D2C_NOT_NULL(v1);
jclass &clz = cls2;
jmethodID &mid = mth10;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "replaceAll", "(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;");
jvalue args[] = {{.l = v8},{.l = v5}};
v4 = (jstring) env->CallObjectMethodA(v1, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L17:
LOGD("ae:move-result-object \x76\x31");
if (v5) {
LOGD("env->DeleteLocalRef(%p):v5", v5);
env->DeleteLocalRef(v5);
}
v5 = (jobject) v4;
L18:
LOGD("b0:invoke-virtual \x76\x35\x2c\x20\x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x69\x6e\x64\x65\x78\x4f\x66\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x49");
{
#define EX_HANDLE EX_LandingPad_11
D2C_NOT_NULL(v2);
jclass &clz = cls2;
jmethodID &mid = mth8;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "indexOf", "(Ljava/lang/String;)I");
jvalue args[] = {{.l = v3}};
v6 = (jint) env->CallIntMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L19:
LOGD("b6:move-result \x76\x34");
v7 = (jint) v6;
LOGD("b8:add-int/lit8 \x76\x34\x2c\x20\x76\x34\x2c\x20\x35");
v7 = (v7 + 5);
L20:
LOGD("bc:invoke-virtual \x76\x35\x2c\x20\x76\x34\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x73\x75\x62\x73\x74\x72\x69\x6e\x67\x28\x49\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_LandingPad_11
D2C_NOT_NULL(v2);
jclass &clz = cls2;
jmethodID &mid = mth11;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "substring", "(I)Ljava/lang/String;");
jvalue args[] = {{.i = v7}};
v4 = (jstring) env->CallObjectMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L21:
LOGD("c2:move-result-object \x76\x34");
if (v1) {
LOGD("env->DeleteLocalRef(%p):v1", v1);
env->DeleteLocalRef(v1);
}
v1 = (jobject) v4;
goto L23;
L22:
if (v1) {
LOGD("env->DeleteLocalRef(%p):v1", v1);
env->DeleteLocalRef(v1);
}
v1 = (jobject) env->NewLocalRef(v5);
L23:
LOGD("c8:iget-object \x76\x35\x2c\x20\x76\x33\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x44\x6f\x77\x6e\x6c\x6f\x61\x64\x43\x6c\x69\x65\x6e\x74\x3b\x2d\x3e\x62\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x56\x69\x65\x77\x3b");
{
#define EX_HANDLE EX_LandingPad_11
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jfieldID &fld = fld2;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/action/DownloadClient", "b", "Landroid/webkit/WebView;");
v4 = (jobject) env->GetObjectField(v0,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
v2 = (jobject) v4;
L24:
LOGD("cc:invoke-virtual \x76\x35\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x56\x69\x65\x77\x3b\x2d\x3e\x67\x65\x74\x43\x6f\x6e\x74\x65\x78\x74\x28\x29\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6e\x74\x65\x78\x74\x3b");
{
#define EX_HANDLE EX_LandingPad_11
D2C_NOT_NULL(v2);
jclass &clz = cls5;
jmethodID &mid = mth12;
D2C_RESOLVE_METHOD(clz, mid, "android/webkit/WebView", "getContext", "()Landroid/content/Context;");
jvalue args[] = {};
v4 = (jobject) env->CallObjectMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L25:
LOGD("d2:move-result-object \x76\x35");
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
v2 = (jobject) v4;
L26:
LOGD("d4:invoke-virtual \x76\x35\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6e\x74\x65\x78\x74\x3b\x2d\x3e\x67\x65\x74\x41\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x43\x6f\x6e\x74\x65\x78\x74\x28\x29\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6e\x74\x65\x78\x74\x3b");
{
#define EX_HANDLE EX_LandingPad_11
D2C_NOT_NULL(v2);
jclass &clz = cls6;
jmethodID &mid = mth13;
D2C_RESOLVE_METHOD(clz, mid, "android/content/Context", "getApplicationContext", "()Landroid/content/Context;");
jvalue args[] = {};
v4 = (jobject) env->CallObjectMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L27:
LOGD("da:move-result-object \x76\x35");
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
v2 = (jobject) v4;
L28:
LOGD("dc:iget-object \x76\x30\x2c\x20\x76\x33\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x44\x6f\x77\x6e\x6c\x6f\x61\x64\x43\x6c\x69\x65\x6e\x74\x3b\x2d\x3e\x65\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x57\x6f\x72\x6b\x65\x72\x3b");
{
#define EX_HANDLE EX_LandingPad_11
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jfieldID &fld = fld3;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/action/DownloadClient", "e", "Lio/pro/edge/widget/event/action/Worker;");
v4 = (jobject) env->GetObjectField(v0,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
v3 = (jobject) v4;
L29:
LOGD("e0:invoke-static \x76\x35\x2c\x20\x76\x30\x2c\x20\x76\x31\x2c\x20\x76\x34\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x75\x74\x69\x6c\x73\x2f\x53\x6d\x73\x55\x74\x69\x6c\x73\x3b\x2d\x3e\x61\x28\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6e\x74\x65\x78\x74\x3b\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x57\x6f\x72\x6b\x65\x72\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x56");
{
#define EX_HANDLE EX_LandingPad_11
jclass &clz = cls7;
jmethodID &mid = mth14;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "io/pro/edge/widget/event/utils/SmsUtils", "a", "(Landroid/content/Context;Lio/pro/edge/widget/event/action/Worker;Ljava/lang/String;Ljava/lang/String;)V");
jvalue args[] = {{.l = v2},{.l = v3},{.l = v5},{.l = v1}};
env->CallStaticVoidMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L30:
goto L32;
L31:
LOGD("e8:move-exception \x76\x34");
if (v1) {
LOGD("env->DeleteLocalRef(%p):v1", v1);
env->DeleteLocalRef(v1);
}
v1 = exception;
LOGD("ea:invoke-virtual \x76\x34\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x54\x68\x72\x6f\x77\x61\x62\x6c\x65\x3b\x2d\x3e\x70\x72\x69\x6e\x74\x53\x74\x61\x63\x6b\x54\x72\x61\x63\x65\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v1);
jclass &clz = cls8;
jmethodID &mid = mth15;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/Throwable", "printStackTrace", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v1, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L32:
v7 = 1;
return (jboolean) v7;

EX_LandingPad_8:
D2C_GET_PENDING_EX
if(d2c_is_instance_of(env, exception, "java/lang/Throwable")) {
goto L31;
}
D2C_GOTO_UNWINDBLOCK

EX_LandingPad_11:
D2C_GET_PENDING_EX
if(d2c_is_instance_of(env, exception, "java/lang/Throwable")) {
goto L31;
}
D2C_GOTO_UNWINDBLOCK
EX_UnwindBlock: return (jboolean)0;
}
