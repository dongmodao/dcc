#include "Dex2C.h"

/* Lio/pro/edge/widget/event/action/InterceptingWebViewClient;->shouldInterceptRequest(Landroid/webkit/WebView;Landroid/webkit/WebResourceRequest;)Landroid/webkit/WebResourceResponse; */
extern "C" JNIEXPORT jobject JNICALL
Java_io_pro_edge_widget_event_action_InterceptingWebViewClient_shouldInterceptRequest__Landroid_webkit_WebView_2Landroid_webkit_WebResourceRequest_2(JNIEnv *env, jobject thiz, jobject p26, jobject p27){
jobject v0 = NULL;
jobject v1 = NULL;
jobject v2 = NULL;
jobject v3 = NULL;
jobject v4 = NULL;
jobject v5 = NULL;
jobject v6 = NULL;
jobject v7 = NULL;
jobject v8 = NULL;
jobject v9 = NULL;
jobject v10 = NULL;
jint v11;
jint v12;
jobject v13 = NULL;
jobject v14 = NULL;
jobject v15 = NULL;
jobject v16 = NULL;
jint v17;
jobject v18 = NULL;
jobject v19 = NULL;
jobject v20 = NULL;
jint v21;
jobject v22 = NULL;
jobject v23 = NULL;
jint v24;
jint v25;
jobject v26 = NULL;
jint v27;
jint v28;
jobject v29 = NULL;
jint v30;
jobject v31 = NULL;
jint v32;
jobject v33 = NULL;
jobject v34 = NULL;
jobject v35 = NULL;
jobject v36 = NULL;
jint v37;
jobject v38 = NULL;
jint v39;
jlong v40;
jthrowable exception;
jclass cls0 = NULL,cls1 = NULL,cls2 = NULL,cls3 = NULL,cls4 = NULL,cls5 = NULL,cls6 = NULL,cls7 = NULL,cls8 = NULL,cls9 = NULL,cls10 = NULL,cls11 = NULL,cls12 = NULL,cls13 = NULL,cls14 = NULL,cls15 = NULL,cls16 = NULL,cls17 = NULL,cls18 = NULL,cls19 = NULL,cls20 = NULL,cls21 = NULL,cls22 = NULL,cls23 = NULL,cls24 = NULL,cls25 = NULL,cls26 = NULL,cls27 = NULL,cls28 = NULL,cls29 = NULL;
jfieldID fld0 = NULL,fld1 = NULL,fld2 = NULL,fld3 = NULL,fld4 = NULL,fld5 = NULL,fld6 = NULL,fld7 = NULL,fld8 = NULL,fld9 = NULL,fld10 = NULL;
jmethodID mth0 = NULL, mth1 = NULL, mth2 = NULL, mth3 = NULL, mth4 = NULL, mth5 = NULL, mth6 = NULL, mth7 = NULL, mth8 = NULL, mth9 = NULL, mth10 = NULL, mth11 = NULL, mth12 = NULL, mth13 = NULL, mth14 = NULL, mth15 = NULL, mth16 = NULL, mth17 = NULL, mth18 = NULL, mth19 = NULL, mth20 = NULL, mth21 = NULL, mth22 = NULL, mth23 = NULL, mth24 = NULL, mth25 = NULL, mth26 = NULL, mth27 = NULL, mth28 = NULL, mth29 = NULL, mth30 = NULL, mth31 = NULL, mth32 = NULL, mth33 = NULL, mth34 = NULL, mth35 = NULL, mth36 = NULL, mth37 = NULL, mth38 = NULL, mth39 = NULL, mth40 = NULL, mth41 = NULL, mth42 = NULL, mth43 = NULL, mth44 = NULL, mth45 = NULL, mth46 = NULL, mth47 = NULL, mth48 = NULL, mth49 = NULL, mth50 = NULL, mth51 = NULL, mth52 = NULL, mth53 = NULL, mth54 = NULL, mth55 = NULL, mth56 = NULL, mth57 = NULL, mth58 = NULL, mth59 = NULL, mth60 = NULL, mth61 = NULL, mth62 = NULL, mth63 = NULL, mth64 = NULL, mth65 = NULL, mth66 = NULL, mth67 = NULL, mth68 = NULL;
v0 = (jobject)env->NewLocalRef(thiz);
v1 = (jobject)env->NewLocalRef(p26);
v2 = (jobject)env->NewLocalRef(p27);
L0:
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
v3 = (jobject) env->NewLocalRef(v0);
LOGD("4:const-string \x76\x38\x2c\x20\x22\x5f\x2e\x7b\x31\x30\x2c\x34\x30\x7d\x3d\x3d\x27\x74\x6f\x75\x63\x68\x73\x74\x61\x72\x74\x27\x22");
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
v4 = (jstring) env->NewStringUTF("\x5f\x2e\x7b\x31\x30\x2c\x34\x30\x7d\x3d\x3d\x27\x74\x6f\x75\x63\x68\x73\x74\x61\x72\x74\x27");
LOGD("8:const-string \x76\x39\x2c\x20\x27\x74\x65\x78\x74\x2f\x68\x74\x6d\x6c\x27");
if (v5) {
LOGD("env->DeleteLocalRef(%p):v5", v5);
env->DeleteLocalRef(v5);
}
v5 = (jstring) env->NewStringUTF("\x74\x65\x78\x74\x2f\x68\x74\x6d\x6c");
LOGD("c:const-string \x76\x30\x2c\x20\x27\x27");
if (v6) {
LOGD("env->DeleteLocalRef(%p):v6", v6);
env->DeleteLocalRef(v6);
}
v6 = (jstring) env->NewStringUTF("");
LOGD("10:invoke-interface/range \x76\x32\x37\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x52\x65\x73\x6f\x75\x72\x63\x65\x52\x65\x71\x75\x65\x73\x74\x3b\x2d\x3e\x67\x65\x74\x55\x72\x6c\x28\x29\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x6e\x65\x74\x2f\x55\x72\x69\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
jclass &clz = cls0;
jmethodID &mid = mth0;
D2C_RESOLVE_METHOD(clz, mid, "android/webkit/WebResourceRequest", "getUrl", "()Landroid/net/Uri;");
jvalue args[] = {};
v7 = (jobject) env->CallObjectMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("16:move-result-object \x76\x31");
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jobject) v7;
LOGD("18:invoke-virtual \x76\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x6e\x65\x74\x2f\x55\x72\x69\x3b\x2d\x3e\x74\x6f\x53\x74\x72\x69\x6e\x67\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v8);
jclass &clz = cls1;
jmethodID &mid = mth1;
D2C_RESOLVE_METHOD(clz, mid, "android/net/Uri", "toString", "()Ljava/lang/String;");
jvalue args[] = {};
v7 = (jstring) env->CallObjectMethodA(v8, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("1e:move-result-object \x76\x31\x30");
if (v9) {
LOGD("env->DeleteLocalRef(%p):v9", v9);
env->DeleteLocalRef(v9);
}
v9 = (jobject) v7;
LOGD("20:new-instance \x76\x31\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
jclass &clz = cls2;
D2C_RESOLVE_CLASS(clz,"java/lang/StringBuilder");
v8 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("24:invoke-direct \x76\x31\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v8);
jclass &clz = cls2;
jmethodID &mid = mth2;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "<init>", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v8, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("2a:const-string \x76\x32\x2c\x20\x27\x73\x68\x6f\x75\x6c\x64\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x52\x65\x71\x75\x65\x73\x74\x3a\x20\x27");
if (v10) {
LOGD("env->DeleteLocalRef(%p):v10", v10);
env->DeleteLocalRef(v10);
}
v10 = (jstring) env->NewStringUTF("\x73\x68\x6f\x75\x6c\x64\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x52\x65\x71\x75\x65\x73\x74\x3a\x20");
LOGD("2e:invoke-virtual \x76\x31\x2c\x20\x76\x32\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v8);
jclass &clz = cls2;
jmethodID &mid = mth3;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v10}};
v7 = (jobject) env->CallObjectMethodA(v8, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("34:invoke-virtual \x76\x31\x2c\x20\x76\x31\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v8);
jclass &clz = cls2;
jmethodID &mid = mth3;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v9}};
v7 = (jobject) env->CallObjectMethodA(v8, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
LOGD("3a:invoke-virtual \x76\x31\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x74\x6f\x53\x74\x72\x69\x6e\x67\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v8);
jclass &clz = cls2;
jmethodID &mid = mth4;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "toString", "()Ljava/lang/String;");
jvalue args[] = {};
v7 = (jstring) env->CallObjectMethodA(v8, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("40:move-result-object \x76\x31");
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jobject) v7;
LOGD("42:const-string \x76\x32\x2c\x20\x27\x2d\x2d\x2d\x2d\x27");
if (v10) {
LOGD("env->DeleteLocalRef(%p):v10", v10);
env->DeleteLocalRef(v10);
}
v10 = (jstring) env->NewStringUTF("\x2d\x2d\x2d\x2d");
LOGD("46:invoke-static \x76\x32\x2c\x20\x76\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x75\x74\x69\x6c\x2f\x4c\x6f\x67\x3b\x2d\x3e\x65\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x49");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls3;
jmethodID &mid = mth5;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "android/util/Log", "e", "(Ljava/lang/String;Ljava/lang/String;)I");
jvalue args[] = {{.l = v10},{.l = v8}};
v11 = (jint) env->CallStaticIntMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("4c:iget-object \x76\x31\x2c\x20\x76\x37\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x44\x6f\x77\x6e\x6c\x6f\x61\x64\x43\x6c\x69\x65\x6e\x74\x3b\x2d\x3e\x65\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x57\x6f\x72\x6b\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls4;
jfieldID &fld = fld0;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/action/DownloadClient", "e", "Lio/pro/edge/widget/event/action/Worker;");
v7 = (jobject) env->GetObjectField(v3,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jobject) v7;
LOGD("50:iget-object \x76\x31\x2c\x20\x76\x31\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x57\x6f\x72\x6b\x65\x72\x3b\x2d\x3e\x73\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v8);
jclass &clz = cls5;
jfieldID &fld = fld1;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/action/Worker", "s", "Ljava/lang/String;");
v7 = (jstring) env->GetObjectField(v8,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jobject) v7;
LOGD("54:invoke-static \x76\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x74\x65\x78\x74\x2f\x54\x65\x78\x74\x55\x74\x69\x6c\x73\x3b\x2d\x3e\x69\x73\x45\x6d\x70\x74\x79\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x68\x61\x72\x53\x65\x71\x75\x65\x6e\x63\x65\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls6;
jmethodID &mid = mth6;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "android/text/TextUtils", "isEmpty", "(Ljava/lang/CharSequence;)Z");
jvalue args[] = {{.l = v8}};
v11 = (jboolean) env->CallStaticBooleanMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("5a:move-result \x76\x31");
v12 = (jint) v11;
LOGD("5c:if-nez \x76\x31\x2c\x20\x2b\x31\x31");
if(v12 != 0){
goto L3;
}
else {
goto L1;
}
L1:
LOGD("60:iget-object \x76\x31\x2c\x20\x76\x37\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x44\x6f\x77\x6e\x6c\x6f\x61\x64\x43\x6c\x69\x65\x6e\x74\x3b\x2d\x3e\x65\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x57\x6f\x72\x6b\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls4;
jfieldID &fld = fld0;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/action/DownloadClient", "e", "Lio/pro/edge/widget/event/action/Worker;");
v7 = (jobject) env->GetObjectField(v3,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jobject) v7;
LOGD("64:iget-object \x76\x31\x2c\x20\x76\x31\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x57\x6f\x72\x6b\x65\x72\x3b\x2d\x3e\x73\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v8);
jclass &clz = cls5;
jfieldID &fld = fld1;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/action/Worker", "s", "Ljava/lang/String;");
v7 = (jstring) env->GetObjectField(v8,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jobject) v7;
LOGD("68:invoke-virtual \x76\x31\x30\x2c\x20\x76\x31\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x6d\x61\x74\x63\x68\x65\x73\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v9);
jclass &clz = cls7;
jmethodID &mid = mth7;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "matches", "(Ljava/lang/String;)Z");
jvalue args[] = {{.l = v8}};
v11 = (jboolean) env->CallBooleanMethodA(v9, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("6e:move-result \x76\x31");
v12 = (jint) v11;
LOGD("70:if-eqz \x76\x31\x2c\x20\x2b\x37");
if(v12 == 0){
goto L3;
}
else {
goto L2;
}
L2:
LOGD("74:iget-object \x76\x31\x2c\x20\x76\x37\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x44\x6f\x77\x6e\x6c\x6f\x61\x64\x43\x6c\x69\x65\x6e\x74\x3b\x2d\x3e\x65\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x57\x6f\x72\x6b\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls4;
jfieldID &fld = fld0;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/action/DownloadClient", "e", "Lio/pro/edge/widget/event/action/Worker;");
v7 = (jobject) env->GetObjectField(v3,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jobject) v7;
LOGD("78:invoke-virtual \x76\x31\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x57\x6f\x72\x6b\x65\x72\x3b\x2d\x3e\x64\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v8);
jclass &clz = cls5;
jmethodID &mid = mth8;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/event/action/Worker", "d", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v8, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L3:
LOGD("7e:const-string \x76\x31\x2c\x20\x27\x68\x74\x74\x70\x3a\x2f\x2f\x27");
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jstring) env->NewStringUTF("\x68\x74\x74\x70\x3a\x2f\x2f");
LOGD("82:invoke-virtual \x76\x31\x30\x2c\x20\x76\x31\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x73\x74\x61\x72\x74\x73\x57\x69\x74\x68\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v9);
jclass &clz = cls7;
jmethodID &mid = mth9;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "startsWith", "(Ljava/lang/String;)Z");
jvalue args[] = {{.l = v8}};
v11 = (jboolean) env->CallBooleanMethodA(v9, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("88:move-result \x76\x31");
v12 = (jint) v11;
if (v13) {
LOGD("env->DeleteLocalRef(%p):v13", v13);
env->DeleteLocalRef(v13);
}
v13 = 0;
if (v13) {
LOGD("env->DeleteLocalRef(%p):v13", v13);
env->DeleteLocalRef(v13);
}
v13 = 0;
if (v13) {
LOGD("env->DeleteLocalRef(%p):v13", v13);
env->DeleteLocalRef(v13);
}
v13 = 0;
if (v13) {
LOGD("env->DeleteLocalRef(%p):v13", v13);
env->DeleteLocalRef(v13);
}
v13 = 0;
if (v13) {
LOGD("env->DeleteLocalRef(%p):v13", v13);
env->DeleteLocalRef(v13);
}
v13 = 0;
if (v13) {
LOGD("env->DeleteLocalRef(%p):v13", v13);
env->DeleteLocalRef(v13);
}
v13 = 0;
LOGD("8c:if-nez \x76\x31\x2c\x20\x2b\x62");
if(v12 != 0){
goto L6;
}
else {
goto L4;
}
L4:
LOGD("90:const-string \x76\x31\x2c\x20\x27\x68\x74\x74\x70\x73\x3a\x2f\x2f\x27");
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jstring) env->NewStringUTF("\x68\x74\x74\x70\x73\x3a\x2f\x2f");
LOGD("94:invoke-virtual \x76\x31\x30\x2c\x20\x76\x31\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x73\x74\x61\x72\x74\x73\x57\x69\x74\x68\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v9);
jclass &clz = cls7;
jmethodID &mid = mth9;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "startsWith", "(Ljava/lang/String;)Z");
jvalue args[] = {{.l = v8}};
v11 = (jboolean) env->CallBooleanMethodA(v9, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("9a:move-result \x76\x31");
v12 = (jint) v11;
LOGD("9c:if-nez \x76\x31\x2c\x20\x2b\x33");
if(v12 != 0){
goto L6;
}
else {
goto L5;
}
L5:
return (jobject) v13;
L6:
LOGD("a2:invoke-interface/range \x76\x32\x37\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x52\x65\x73\x6f\x75\x72\x63\x65\x52\x65\x71\x75\x65\x73\x74\x3b\x2d\x3e\x67\x65\x74\x4d\x65\x74\x68\x6f\x64\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
jclass &clz = cls0;
jmethodID &mid = mth10;
D2C_RESOLVE_METHOD(clz, mid, "android/webkit/WebResourceRequest", "getMethod", "()Ljava/lang/String;");
jvalue args[] = {};
v7 = (jstring) env->CallObjectMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("a8:move-result-object \x76\x31\x32");
if (v14) {
LOGD("env->DeleteLocalRef(%p):v14", v14);
env->DeleteLocalRef(v14);
}
v14 = (jobject) v7;
LOGD("aa:invoke-static \x76\x31\x30\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x6e\x65\x74\x2f\x55\x72\x69\x3b\x2d\x3e\x70\x61\x72\x73\x65\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x6e\x65\x74\x2f\x55\x72\x69\x3b");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls1;
jmethodID &mid = mth11;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "android/net/Uri", "parse", "(Ljava/lang/String;)Landroid/net/Uri;");
jvalue args[] = {{.l = v9}};
v7 = (jobject) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("b0:move-result-object \x76\x31");
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jobject) v7;
LOGD("b2:invoke-virtual \x76\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x6e\x65\x74\x2f\x55\x72\x69\x3b\x2d\x3e\x67\x65\x74\x50\x61\x74\x68\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v8);
jclass &clz = cls1;
jmethodID &mid = mth12;
D2C_RESOLVE_METHOD(clz, mid, "android/net/Uri", "getPath", "()Ljava/lang/String;");
jvalue args[] = {};
v7 = (jstring) env->CallObjectMethodA(v8, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("b8:move-result-object \x76\x31\x33");
if (v15) {
LOGD("env->DeleteLocalRef(%p):v15", v15);
env->DeleteLocalRef(v15);
}
v15 = (jobject) v7;
LOGD("ba:invoke-virtual \x76\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x6e\x65\x74\x2f\x55\x72\x69\x3b\x2d\x3e\x67\x65\x74\x48\x6f\x73\x74\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v8);
jclass &clz = cls1;
jmethodID &mid = mth13;
D2C_RESOLVE_METHOD(clz, mid, "android/net/Uri", "getHost", "()Ljava/lang/String;");
jvalue args[] = {};
v7 = (jstring) env->CallObjectMethodA(v8, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("c0:move-result-object \x76\x31\x34");
if (v16) {
LOGD("env->DeleteLocalRef(%p):v16", v16);
env->DeleteLocalRef(v16);
}
v16 = (jobject) v7;
LOGD("c2:invoke-virtual \x76\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x6e\x65\x74\x2f\x55\x72\x69\x3b\x2d\x3e\x67\x65\x74\x50\x6f\x72\x74\x28\x29\x49");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v8);
jclass &clz = cls1;
jmethodID &mid = mth14;
D2C_RESOLVE_METHOD(clz, mid, "android/net/Uri", "getPort", "()I");
jvalue args[] = {};
v11 = (jint) env->CallIntMethodA(v8, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("c8:move-result \x76\x36");
v17 = (jint) v11;
LOGD("ca:invoke-static \x76\x31\x34\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x74\x65\x78\x74\x2f\x54\x65\x78\x74\x55\x74\x69\x6c\x73\x3b\x2d\x3e\x69\x73\x45\x6d\x70\x74\x79\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x68\x61\x72\x53\x65\x71\x75\x65\x6e\x63\x65\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls6;
jmethodID &mid = mth6;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "android/text/TextUtils", "isEmpty", "(Ljava/lang/CharSequence;)Z");
jvalue args[] = {{.l = v16}};
v11 = (jboolean) env->CallStaticBooleanMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("d0:move-result \x76\x31");
v12 = (jint) v11;
LOGD("d2:if-eqz \x76\x31\x2c\x20\x2b\x33");
if(v12 == 0){
goto L8;
}
else {
goto L7;
}
L7:
return (jobject) v13;
L8:
LOGD("d8:const-string \x76\x31\x2c\x20\x27\x77\x77\x77\x2e\x67\x6f\x6f\x67\x6c\x65\x2e\x63\x6f\x6d\x27");
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jobject) env->NewStringUTF("\x77\x77\x77\x2e\x67\x6f\x6f\x67\x6c\x65\x2e\x63\x6f\x6d");
LOGD("dc:invoke-virtual \x76\x31\x34\x2c\x20\x76\x31\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x63\x6f\x6e\x74\x61\x69\x6e\x73\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x68\x61\x72\x53\x65\x71\x75\x65\x6e\x63\x65\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v16);
jclass &clz = cls7;
jmethodID &mid = mth15;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "contains", "(Ljava/lang/CharSequence;)Z");
jvalue args[] = {{.l = v8}};
v11 = (jboolean) env->CallBooleanMethodA(v16, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("e2:move-result \x76\x31");
v12 = (jint) v11;
LOGD("e4:if-nez \x76\x31\x2c\x20\x2b\x32\x31\x62");
if(v12 != 0){
goto L187;
}
else {
goto L9;
}
L9:
LOGD("e8:const-string \x76\x31\x2c\x20\x27\x77\x77\x77\x2e\x67\x73\x74\x61\x74\x69\x63\x2e\x63\x6f\x6d\x27");
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jobject) env->NewStringUTF("\x77\x77\x77\x2e\x67\x73\x74\x61\x74\x69\x63\x2e\x63\x6f\x6d");
LOGD("ec:invoke-virtual \x76\x31\x34\x2c\x20\x76\x31\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x63\x6f\x6e\x74\x61\x69\x6e\x73\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x68\x61\x72\x53\x65\x71\x75\x65\x6e\x63\x65\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v16);
jclass &clz = cls7;
jmethodID &mid = mth15;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "contains", "(Ljava/lang/CharSequence;)Z");
jvalue args[] = {{.l = v8}};
v11 = (jboolean) env->CallBooleanMethodA(v16, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("f2:move-result \x76\x31");
v12 = (jint) v11;
LOGD("f4:if-eqz \x76\x31\x2c\x20\x2b\x34");
if(v12 == 0){
goto L11;
}
else {
goto L10;
}
L10:
goto L187;
L11:
LOGD("fc:invoke-static \x76\x31\x33\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x74\x65\x78\x74\x2f\x54\x65\x78\x74\x55\x74\x69\x6c\x73\x3b\x2d\x3e\x69\x73\x45\x6d\x70\x74\x79\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x68\x61\x72\x53\x65\x71\x75\x65\x6e\x63\x65\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls6;
jmethodID &mid = mth6;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "android/text/TextUtils", "isEmpty", "(Ljava/lang/CharSequence;)Z");
jvalue args[] = {{.l = v15}};
v11 = (jboolean) env->CallStaticBooleanMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("102:move-result \x76\x31");
v12 = (jint) v11;
LOGD("104:const-string \x76\x31\x35\x2c\x20\x27\x77\x69\x64\x67\x65\x74\x78\x2e\x6a\x73\x27");
if (v18) {
LOGD("env->DeleteLocalRef(%p):v18", v18);
env->DeleteLocalRef(v18);
}
v18 = (jstring) env->NewStringUTF("\x77\x69\x64\x67\x65\x74\x78\x2e\x6a\x73");
LOGD("108:const-string \x76\x35\x2c\x20\x27\x36\x39\x36\x39\x6a\x70\x2e\x78\x79\x7a\x27");
if (v19) {
LOGD("env->DeleteLocalRef(%p):v19", v19);
env->DeleteLocalRef(v19);
}
v19 = (jstring) env->NewStringUTF("\x36\x39\x36\x39\x6a\x70\x2e\x78\x79\x7a");
LOGD("10c:if-nez \x76\x31\x2c\x20\x2b\x66");
if(v12 != 0){
goto L15;
}
else {
goto L12;
}
L12:
LOGD("110:invoke-virtual \x76\x35\x2c\x20\x76\x31\x34\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x65\x71\x75\x61\x6c\x73\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v19);
jclass &clz = cls7;
jmethodID &mid = mth16;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "equals", "(Ljava/lang/Object;)Z");
jvalue args[] = {{.l = v16}};
v11 = (jboolean) env->CallBooleanMethodA(v19, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("116:move-result \x76\x31");
v12 = (jint) v11;
LOGD("118:if-eqz \x76\x31\x2c\x20\x2b\x39");
if(v12 == 0){
goto L15;
}
else {
goto L13;
}
L13:
LOGD("11c:invoke-virtual \x76\x31\x33\x2c\x20\x76\x31\x35\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x65\x6e\x64\x73\x57\x69\x74\x68\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v15);
jclass &clz = cls7;
jmethodID &mid = mth17;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "endsWith", "(Ljava/lang/String;)Z");
jvalue args[] = {{.l = v18}};
v11 = (jboolean) env->CallBooleanMethodA(v15, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("122:move-result \x76\x31");
v12 = (jint) v11;
LOGD("124:if-eqz \x76\x31\x2c\x20\x2b\x33");
if(v12 == 0){
goto L15;
}
else {
goto L14;
}
L14:
goto L22;
L15:
LOGD("12a:const-string \x76\x31\x2c\x20\x27\x6d\x6f\x6e\x69\x74\x6f\x72\x69\x6e\x67\x73\x65\x72\x76\x69\x63\x65\x2e\x63\x6f\x27");
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jobject) env->NewStringUTF("\x6d\x6f\x6e\x69\x74\x6f\x72\x69\x6e\x67\x73\x65\x72\x76\x69\x63\x65\x2e\x63\x6f");
LOGD("12e:invoke-virtual \x76\x31\x34\x2c\x20\x76\x31\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x63\x6f\x6e\x74\x61\x69\x6e\x73\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x68\x61\x72\x53\x65\x71\x75\x65\x6e\x63\x65\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v16);
jclass &clz = cls7;
jmethodID &mid = mth15;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "contains", "(Ljava/lang/CharSequence;)Z");
jvalue args[] = {{.l = v8}};
v11 = (jboolean) env->CallBooleanMethodA(v16, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("134:move-result \x76\x31");
v12 = (jint) v11;
LOGD("136:if-nez \x76\x31\x2c\x20\x2b\x31\x63");
if(v12 != 0){
goto L22;
}
else {
goto L16;
}
L16:
LOGD("13a:invoke-static \x76\x31\x33\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x74\x65\x78\x74\x2f\x54\x65\x78\x74\x55\x74\x69\x6c\x73\x3b\x2d\x3e\x69\x73\x45\x6d\x70\x74\x79\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x68\x61\x72\x53\x65\x71\x75\x65\x6e\x63\x65\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls6;
jmethodID &mid = mth6;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "android/text/TextUtils", "isEmpty", "(Ljava/lang/CharSequence;)Z");
jvalue args[] = {{.l = v15}};
v11 = (jboolean) env->CallStaticBooleanMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("140:move-result \x76\x31");
v12 = (jint) v11;
LOGD("142:if-nez \x76\x31\x2c\x20\x2b\x39");
if(v12 != 0){
goto L19;
}
else {
goto L17;
}
L17:
LOGD("146:invoke-static \x76\x31\x33\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x75\x74\x69\x6c\x73\x2f\x4e\x65\x74\x55\x74\x69\x6c\x73\x3b\x2d\x3e\x63\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls8;
jmethodID &mid = mth18;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "io/pro/edge/widget/event/utils/NetUtils", "c", "(Ljava/lang/String;)Z");
jvalue args[] = {{.l = v15}};
v11 = (jboolean) env->CallStaticBooleanMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("14c:move-result \x76\x31");
v12 = (jint) v11;
LOGD("14e:if-eqz \x76\x31\x2c\x20\x2b\x33");
if(v12 == 0){
goto L19;
}
else {
goto L18;
}
L18:
return (jobject) v13;
L19:
LOGD("154:invoke-static \x76\x31\x34\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x74\x65\x78\x74\x2f\x54\x65\x78\x74\x55\x74\x69\x6c\x73\x3b\x2d\x3e\x69\x73\x45\x6d\x70\x74\x79\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x68\x61\x72\x53\x65\x71\x75\x65\x6e\x63\x65\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls6;
jmethodID &mid = mth6;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "android/text/TextUtils", "isEmpty", "(Ljava/lang/CharSequence;)Z");
jvalue args[] = {{.l = v16}};
v11 = (jboolean) env->CallStaticBooleanMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("15a:move-result \x76\x31");
v12 = (jint) v11;
LOGD("15c:if-nez \x76\x31\x2c\x20\x2b\x39");
if(v12 != 0){
goto L22;
}
else {
goto L20;
}
L20:
LOGD("160:invoke-static \x76\x31\x34\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x75\x74\x69\x6c\x73\x2f\x4e\x65\x74\x55\x74\x69\x6c\x73\x3b\x2d\x3e\x62\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls8;
jmethodID &mid = mth19;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "io/pro/edge/widget/event/utils/NetUtils", "b", "(Ljava/lang/String;)Z");
jvalue args[] = {{.l = v16}};
v11 = (jboolean) env->CallStaticBooleanMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("166:move-result \x76\x31");
v12 = (jint) v11;
LOGD("168:if-eqz \x76\x31\x2c\x20\x2b\x33");
if(v12 == 0){
goto L22;
}
else {
goto L21;
}
L21:
return (jobject) v13;
L22:
LOGD("16e:iget-object \x76\x31\x2c\x20\x76\x37\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x44\x6f\x77\x6e\x6c\x6f\x61\x64\x43\x6c\x69\x65\x6e\x74\x3b\x2d\x3e\x65\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x57\x6f\x72\x6b\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls4;
jfieldID &fld = fld0;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/action/DownloadClient", "e", "Lio/pro/edge/widget/event/action/Worker;");
v7 = (jobject) env->GetObjectField(v3,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jobject) v7;
LOGD("172:invoke-virtual \x76\x31\x2c\x20\x76\x31\x30\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x57\x6f\x72\x6b\x65\x72\x3b\x2d\x3e\x62\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v8);
jclass &clz = cls5;
jmethodID &mid = mth20;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/event/action/Worker", "b", "(Ljava/lang/String;)V");
jvalue args[] = {{.l = v9}};
env->CallVoidMethodA(v8, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("178:invoke-virtual \x76\x37\x2c\x20\x76\x31\x30\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x69\x6e\x67\x57\x65\x62\x56\x69\x65\x77\x43\x6c\x69\x65\x6e\x74\x3b\x2d\x3e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls9;
jmethodID &mid = mth21;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/event/action/InterceptingWebViewClient", "d", "(Ljava/lang/String;)V");
jvalue args[] = {{.l = v9}};
env->CallVoidMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("17e:new-instance \x76\x31\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x71\x75\x65\x73\x74\x24\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
jclass &clz = cls10;
D2C_RESOLVE_CLASS(clz,"okhttp3/Request$Builder");
v8 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("182:invoke-direct \x76\x31\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x71\x75\x65\x73\x74\x24\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v8);
jclass &clz = cls10;
jmethodID &mid = mth22;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Request$Builder", "<init>", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v8, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("188:invoke-virtual \x76\x31\x2c\x20\x76\x31\x30\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x71\x75\x65\x73\x74\x24\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x75\x72\x6c\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x71\x75\x65\x73\x74\x24\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v8);
jclass &clz = cls10;
jmethodID &mid = mth23;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Request$Builder", "url", "(Ljava/lang/String;)Lokhttp3/Request$Builder;");
jvalue args[] = {{.l = v9}};
v7 = (jobject) env->CallObjectMethodA(v8, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("18e:move-result-object \x76\x34");
if (v20) {
LOGD("env->DeleteLocalRef(%p):v20", v20);
env->DeleteLocalRef(v20);
}
v20 = (jobject) v7;
L23:
LOGD("190:invoke-interface/range \x76\x32\x37\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x52\x65\x73\x6f\x75\x72\x63\x65\x52\x65\x71\x75\x65\x73\x74\x3b\x2d\x3e\x67\x65\x74\x4d\x65\x74\x68\x6f\x64\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_LandingPad_23
D2C_NOT_NULL(v2);
jclass &clz = cls0;
jmethodID &mid = mth10;
D2C_RESOLVE_METHOD(clz, mid, "android/webkit/WebResourceRequest", "getMethod", "()Ljava/lang/String;");
jvalue args[] = {};
v7 = (jstring) env->CallObjectMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L24:
LOGD("196:move-result-object \x76\x31");
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jobject) v7;
L25:
LOGD("198:invoke-static \x76\x31\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x69\x6e\x74\x65\x72\x6e\x61\x6c\x2f\x68\x74\x74\x70\x2f\x48\x74\x74\x70\x4d\x65\x74\x68\x6f\x64\x3b\x2d\x3e\x72\x65\x71\x75\x69\x72\x65\x73\x52\x65\x71\x75\x65\x73\x74\x42\x6f\x64\x79\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x5a");
{
#define EX_HANDLE EX_LandingPad_23
jclass &clz = cls11;
jmethodID &mid = mth24;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "okhttp3/internal/http/HttpMethod", "requiresRequestBody", "(Ljava/lang/String;)Z");
jvalue args[] = {{.l = v8}};
v11 = (jboolean) env->CallStaticBooleanMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L26:
LOGD("19e:move-result \x76\x31");
v12 = (jint) v11;
LOGD("1a0:if-eqz \x76\x31\x2c\x20\x2b\x62");
if(v12 == 0){
goto L31;
}
else {
goto L27;
}
L27:
LOGD("1a4:invoke-static \x76\x30\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x4d\x65\x64\x69\x61\x54\x79\x70\x65\x3b\x2d\x3e\x70\x61\x72\x73\x65\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x4d\x65\x64\x69\x61\x54\x79\x70\x65\x3b");
{
#define EX_HANDLE EX_LandingPad_23
jclass &clz = cls12;
jmethodID &mid = mth25;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "okhttp3/MediaType", "parse", "(Ljava/lang/String;)Lokhttp3/MediaType;");
jvalue args[] = {{.l = v6}};
v7 = (jobject) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L28:
LOGD("1aa:move-result-object \x76\x31");
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jobject) v7;
L29:
LOGD("1ac:invoke-static \x76\x31\x2c\x20\x76\x30\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x71\x75\x65\x73\x74\x42\x6f\x64\x79\x3b\x2d\x3e\x63\x72\x65\x61\x74\x65\x28\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x4d\x65\x64\x69\x61\x54\x79\x70\x65\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x71\x75\x65\x73\x74\x42\x6f\x64\x79\x3b");
{
#define EX_HANDLE EX_LandingPad_23
jclass &clz = cls13;
jmethodID &mid = mth26;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "okhttp3/RequestBody", "create", "(Lokhttp3/MediaType;Ljava/lang/String;)Lokhttp3/RequestBody;");
jvalue args[] = {{.l = v8},{.l = v6}};
v7 = (jobject) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L30:
LOGD("1b2:move-result-object \x76\x30");
if (v6) {
LOGD("env->DeleteLocalRef(%p):v6", v6);
env->DeleteLocalRef(v6);
}
v6 = (jobject) v7;
goto L32;
L31:
if (v6) {
LOGD("env->DeleteLocalRef(%p):v6", v6);
env->DeleteLocalRef(v6);
}
v6 = (jobject) env->NewLocalRef(v13);
L32:
LOGD("1b8:invoke-interface/range \x76\x32\x37\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x52\x65\x73\x6f\x75\x72\x63\x65\x52\x65\x71\x75\x65\x73\x74\x3b\x2d\x3e\x67\x65\x74\x4d\x65\x74\x68\x6f\x64\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_LandingPad_23
D2C_NOT_NULL(v2);
jclass &clz = cls0;
jmethodID &mid = mth10;
D2C_RESOLVE_METHOD(clz, mid, "android/webkit/WebResourceRequest", "getMethod", "()Ljava/lang/String;");
jvalue args[] = {};
v7 = (jstring) env->CallObjectMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L33:
LOGD("1be:move-result-object \x76\x31");
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jobject) v7;
L34:
LOGD("1c0:invoke-virtual \x76\x34\x2c\x20\x76\x31\x2c\x20\x76\x30\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x71\x75\x65\x73\x74\x24\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x6d\x65\x74\x68\x6f\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x71\x75\x65\x73\x74\x42\x6f\x64\x79\x3b\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x71\x75\x65\x73\x74\x24\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_LandingPad_23
D2C_NOT_NULL(v20);
jclass &clz = cls10;
jmethodID &mid = mth27;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Request$Builder", "method", "(Ljava/lang/String;Lokhttp3/RequestBody;)Lokhttp3/Request$Builder;");
jvalue args[] = {{.l = v8},{.l = v6}};
v7 = (jobject) env->CallObjectMethodA(v20, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
L35:
goto L37;
L36:
LOGD("1c8:move-exception \x76\x30");
if (v6) {
LOGD("env->DeleteLocalRef(%p):v6", v6);
env->DeleteLocalRef(v6);
}
v6 = exception;
LOGD("1ca:invoke-virtual \x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x54\x68\x72\x6f\x77\x61\x62\x6c\x65\x3b\x2d\x3e\x70\x72\x69\x6e\x74\x53\x74\x61\x63\x6b\x54\x72\x61\x63\x65\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v6);
jclass &clz = cls14;
jmethodID &mid = mth28;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/Throwable", "printStackTrace", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v6, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L37:
LOGD("1d0:iget-object \x76\x30\x2c\x20\x76\x37\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x44\x6f\x77\x6e\x6c\x6f\x61\x64\x43\x6c\x69\x65\x6e\x74\x3b\x2d\x3e\x61\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x63\x6f\x6e\x63\x75\x72\x72\x65\x6e\x74\x2f\x61\x74\x6f\x6d\x69\x63\x2f\x41\x74\x6f\x6d\x69\x63\x49\x6e\x74\x65\x67\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls4;
jfieldID &fld = fld2;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/action/DownloadClient", "a", "Ljava/util/concurrent/atomic/AtomicInteger;");
v7 = (jobject) env->GetObjectField(v3,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v6) {
LOGD("env->DeleteLocalRef(%p):v6", v6);
env->DeleteLocalRef(v6);
}
v6 = (jobject) v7;
LOGD("1d4:invoke-virtual \x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x63\x6f\x6e\x63\x75\x72\x72\x65\x6e\x74\x2f\x61\x74\x6f\x6d\x69\x63\x2f\x41\x74\x6f\x6d\x69\x63\x49\x6e\x74\x65\x67\x65\x72\x3b\x2d\x3e\x67\x65\x74\x41\x6e\x64\x49\x6e\x63\x72\x65\x6d\x65\x6e\x74\x28\x29\x49");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v6);
jclass &clz = cls15;
jmethodID &mid = mth29;
D2C_RESOLVE_METHOD(clz, mid, "java/util/concurrent/atomic/AtomicInteger", "getAndIncrement", "()I");
jvalue args[] = {};
v11 = (jint) env->CallIntMethodA(v6, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("1da:move-result \x76\x32");
v21 = (jint) v11;
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jobject) env->NewLocalRef(v0);
if (v22) {
LOGD("env->DeleteLocalRef(%p):v22", v22);
env->DeleteLocalRef(v22);
}
v22 = (jobject) env->NewLocalRef(v20);
if (v13) {
LOGD("env->DeleteLocalRef(%p):v13", v13);
env->DeleteLocalRef(v13);
}
v13 = (jobject) env->NewLocalRef(v20);
if (v20) {
LOGD("env->DeleteLocalRef(%p):v20", v20);
env->DeleteLocalRef(v20);
}
v20 = (jobject) env->NewLocalRef(v2);
if (v23) {
LOGD("env->DeleteLocalRef(%p):v23", v23);
env->DeleteLocalRef(v23);
}
v23 = (jobject) env->NewLocalRef(v5);
if (v5) {
LOGD("env->DeleteLocalRef(%p):v5", v5);
env->DeleteLocalRef(v5);
}
v5 = (jobject) env->NewLocalRef(v19);
if (v19) {
LOGD("env->DeleteLocalRef(%p):v19", v19);
env->DeleteLocalRef(v19);
}
v19 = (jobject) env->NewLocalRef(v16);
LOGD("1f0:invoke-virtual/range \x76\x31\x20\x2e\x2e\x2e\x20\x76\x36\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x69\x6e\x67\x57\x65\x62\x56\x69\x65\x77\x43\x6c\x69\x65\x6e\x74\x3b\x2d\x3e\x61\x28\x49\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x71\x75\x65\x73\x74\x24\x42\x75\x69\x6c\x64\x65\x72\x3b\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x52\x65\x73\x6f\x75\x72\x63\x65\x52\x65\x71\x75\x65\x73\x74\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x20\x49\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v8);
jclass &clz = cls9;
jmethodID &mid = mth30;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/event/action/InterceptingWebViewClient", "a", "(ILokhttp3/Request$Builder;Landroid/webkit/WebResourceRequest;Ljava/lang/String;I)V");
jvalue args[] = {{.i = v21},{.l = v22},{.l = v20},{.l = v19},{.i = v17}};
env->CallVoidMethodA(v8, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L38:
LOGD("1f6:iget-object \x76\x30\x2c\x20\x76\x37\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x69\x6e\x67\x57\x65\x62\x56\x69\x65\x77\x43\x6c\x69\x65\x6e\x74\x3b\x2d\x3e\x6c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x41\x6a\x61\x78\x52\x65\x71\x75\x65\x73\x74\x43\x6f\x6e\x74\x65\x6e\x74\x73\x3b");
{
#define EX_HANDLE EX_LandingPad_38
D2C_NOT_NULL(v3);
jclass &clz = cls9;
jfieldID &fld = fld3;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/action/InterceptingWebViewClient", "l", "Lio/pro/edge/widget/event/net/AjaxRequestContents;");
v7 = (jobject) env->GetObjectField(v3,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v6) {
LOGD("env->DeleteLocalRef(%p):v6", v6);
env->DeleteLocalRef(v6);
}
v6 = (jobject) v7;
L39:
LOGD("1fa:const-string \x76\x31\x2c\x20\x27\x6f\x70\x74\x69\x6f\x6e\x73\x27");
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jstring) env->NewStringUTF("\x6f\x70\x74\x69\x6f\x6e\x73");
LOGD("1fe:if-eqz \x76\x30\x2c\x20\x2b\x31\x35");
if(v6 == NULL){
goto L48;
}
else {
goto L40;
}
L40:
LOGD("202:invoke-virtual \x76\x31\x2c\x20\x76\x31\x32\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x65\x71\x75\x61\x6c\x73\x49\x67\x6e\x6f\x72\x65\x43\x61\x73\x65\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x5a");
{
#define EX_HANDLE EX_LandingPad_40
D2C_NOT_NULL(v8);
jclass &clz = cls7;
jmethodID &mid = mth31;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "equalsIgnoreCase", "(Ljava/lang/String;)Z");
jvalue args[] = {{.l = v14}};
v11 = (jboolean) env->CallBooleanMethodA(v8, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L41:
LOGD("208:move-result \x76\x30");
v24 = (jint) v11;
LOGD("20a:if-nez \x76\x30\x2c\x20\x2b\x66");
if(v24 != 0){
goto L48;
}
else {
goto L42;
}
L42:
LOGD("20e:iget-object \x76\x30\x2c\x20\x76\x37\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x69\x6e\x67\x57\x65\x62\x56\x69\x65\x77\x43\x6c\x69\x65\x6e\x74\x3b\x2d\x3e\x6c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x41\x6a\x61\x78\x52\x65\x71\x75\x65\x73\x74\x43\x6f\x6e\x74\x65\x6e\x74\x73\x3b");
{
#define EX_HANDLE EX_LandingPad_40
D2C_NOT_NULL(v3);
jclass &clz = cls9;
jfieldID &fld = fld3;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/action/InterceptingWebViewClient", "l", "Lio/pro/edge/widget/event/net/AjaxRequestContents;");
v7 = (jobject) env->GetObjectField(v3,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v6) {
LOGD("env->DeleteLocalRef(%p):v6", v6);
env->DeleteLocalRef(v6);
}
v6 = (jobject) v7;
L43:
LOGD("212:invoke-static \x76\x31\x31\x2c\x20\x76\x31\x32\x2c\x20\x76\x31\x30\x2c\x20\x76\x30\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x75\x74\x69\x6c\x73\x2f\x4e\x65\x74\x55\x74\x69\x6c\x73\x3b\x2d\x3e\x61\x28\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x71\x75\x65\x73\x74\x24\x42\x75\x69\x6c\x64\x65\x72\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x41\x6a\x61\x78\x52\x65\x71\x75\x65\x73\x74\x43\x6f\x6e\x74\x65\x6e\x74\x73\x3b\x29\x56");
{
#define EX_HANDLE EX_LandingPad_40
jclass &clz = cls8;
jmethodID &mid = mth32;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "io/pro/edge/widget/event/utils/NetUtils", "a", "(Lokhttp3/Request$Builder;Ljava/lang/String;Ljava/lang/String;Lio/pro/edge/widget/event/net/AjaxRequestContents;)V");
jvalue args[] = {{.l = v13},{.l = v14},{.l = v9},{.l = v6}};
env->CallStaticVoidMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L44:
if (v20) {
LOGD("env->DeleteLocalRef(%p):v20", v20);
env->DeleteLocalRef(v20);
}
v20 = 0;
if (v20) {
LOGD("env->DeleteLocalRef(%p):v20", v20);
env->DeleteLocalRef(v20);
}
v20 = 0;
L45:
LOGD("21a:iput-object \x76\x34\x2c\x20\x76\x37\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x69\x6e\x67\x57\x65\x62\x56\x69\x65\x77\x43\x6c\x69\x65\x6e\x74\x3b\x2d\x3e\x6c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x41\x6a\x61\x78\x52\x65\x71\x75\x65\x73\x74\x43\x6f\x6e\x74\x65\x6e\x74\x73\x3b");
{
#define EX_HANDLE EX_LandingPad_45
D2C_NOT_NULL(v3);
jclass &clz = cls9;
jfieldID &fld = fld3;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/action/InterceptingWebViewClient", "l", "Lio/pro/edge/widget/event/net/AjaxRequestContents;");
env->SetObjectField(v3,fld,(jobject) v20);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L46:
v24 = 1;
goto L49;
L47:
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jobject) env->NewLocalRef(v20);
goto L186;
L48:
v24 = 0;
L49:
LOGD("22a:iget-object \x76\x34\x2c\x20\x76\x37\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x69\x6e\x67\x57\x65\x62\x56\x69\x65\x77\x43\x6c\x69\x65\x6e\x74\x3b\x2d\x3e\x6b\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x46\x6f\x72\x6d\x52\x65\x71\x75\x65\x73\x74\x43\x6f\x6e\x74\x65\x6e\x74\x73\x3b");
{
#define EX_HANDLE EX_LandingPad_49
D2C_NOT_NULL(v3);
jclass &clz = cls9;
jfieldID &fld = fld4;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/action/InterceptingWebViewClient", "k", "Lio/pro/edge/widget/event/net/FormRequestContents;");
v7 = (jobject) env->GetObjectField(v3,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v20) {
LOGD("env->DeleteLocalRef(%p):v20", v20);
env->DeleteLocalRef(v20);
}
v20 = (jobject) v7;
L50:
LOGD("22e:if-eqz \x76\x34\x2c\x20\x2b\x31\x35");
if(v20 == NULL){
goto L59;
}
else {
goto L51;
}
L51:
LOGD("232:invoke-virtual \x76\x31\x2c\x20\x76\x31\x32\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x65\x71\x75\x61\x6c\x73\x49\x67\x6e\x6f\x72\x65\x43\x61\x73\x65\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x5a");
{
#define EX_HANDLE EX_LandingPad_49
D2C_NOT_NULL(v8);
jclass &clz = cls7;
jmethodID &mid = mth31;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "equalsIgnoreCase", "(Ljava/lang/String;)Z");
jvalue args[] = {{.l = v14}};
v11 = (jboolean) env->CallBooleanMethodA(v8, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L52:
LOGD("238:move-result \x76\x34");
v25 = (jint) v11;
LOGD("23a:if-nez \x76\x34\x2c\x20\x2b\x66");
if(v25 != 0){
goto L59;
}
else {
goto L53;
}
L53:
LOGD("23e:iget-object \x76\x34\x2c\x20\x76\x37\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x69\x6e\x67\x57\x65\x62\x56\x69\x65\x77\x43\x6c\x69\x65\x6e\x74\x3b\x2d\x3e\x6b\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x46\x6f\x72\x6d\x52\x65\x71\x75\x65\x73\x74\x43\x6f\x6e\x74\x65\x6e\x74\x73\x3b");
{
#define EX_HANDLE EX_LandingPad_49
D2C_NOT_NULL(v3);
jclass &clz = cls9;
jfieldID &fld = fld4;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/action/InterceptingWebViewClient", "k", "Lio/pro/edge/widget/event/net/FormRequestContents;");
v7 = (jobject) env->GetObjectField(v3,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v20) {
LOGD("env->DeleteLocalRef(%p):v20", v20);
env->DeleteLocalRef(v20);
}
v20 = (jobject) v7;
L54:
LOGD("242:invoke-static \x76\x31\x31\x2c\x20\x76\x31\x32\x2c\x20\x76\x31\x30\x2c\x20\x76\x34\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x75\x74\x69\x6c\x73\x2f\x4e\x65\x74\x55\x74\x69\x6c\x73\x3b\x2d\x3e\x61\x28\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x71\x75\x65\x73\x74\x24\x42\x75\x69\x6c\x64\x65\x72\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x46\x6f\x72\x6d\x52\x65\x71\x75\x65\x73\x74\x43\x6f\x6e\x74\x65\x6e\x74\x73\x3b\x29\x56");
{
#define EX_HANDLE EX_LandingPad_49
jclass &clz = cls8;
jmethodID &mid = mth33;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "io/pro/edge/widget/event/utils/NetUtils", "a", "(Lokhttp3/Request$Builder;Ljava/lang/String;Ljava/lang/String;Lio/pro/edge/widget/event/net/FormRequestContents;)V");
jvalue args[] = {{.l = v13},{.l = v14},{.l = v9},{.l = v20}};
env->CallStaticVoidMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L55:
if (v20) {
LOGD("env->DeleteLocalRef(%p):v20", v20);
env->DeleteLocalRef(v20);
}
v20 = 0;
if (v20) {
LOGD("env->DeleteLocalRef(%p):v20", v20);
env->DeleteLocalRef(v20);
}
v20 = 0;
L56:
LOGD("24a:iput-object \x76\x34\x2c\x20\x76\x37\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x69\x6e\x67\x57\x65\x62\x56\x69\x65\x77\x43\x6c\x69\x65\x6e\x74\x3b\x2d\x3e\x6b\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x46\x6f\x72\x6d\x52\x65\x71\x75\x65\x73\x74\x43\x6f\x6e\x74\x65\x6e\x74\x73\x3b");
{
#define EX_HANDLE EX_LandingPad_56
D2C_NOT_NULL(v3);
jclass &clz = cls9;
jfieldID &fld = fld4;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/action/InterceptingWebViewClient", "k", "Lio/pro/edge/widget/event/net/FormRequestContents;");
env->SetObjectField(v3,fld,(jobject) v20);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L57:
v25 = 1;
goto L60;
L58:
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jobject) env->NewLocalRef(v20);
goto L184;
L59:
v25 = 0;
L60:
LOGD("25a:if-nez \x76\x30\x2c\x20\x2b\x37");
if(v24 != 0){
goto L64;
}
else {
goto L61;
}
L61:
LOGD("25e:if-eqz \x76\x34\x2c\x20\x2b\x33");
if(v25 == 0){
goto L63;
}
else {
goto L62;
}
L62:
goto L64;
L63:
v25 = 0;
goto L65;
L64:
v25 = 1;
L65:
LOGD("26a:invoke-virtual \x76\x31\x2c\x20\x76\x31\x32\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x65\x71\x75\x61\x6c\x73\x49\x67\x6e\x6f\x72\x65\x43\x61\x73\x65\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v8);
jclass &clz = cls7;
jmethodID &mid = mth31;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "equalsIgnoreCase", "(Ljava/lang/String;)Z");
jvalue args[] = {{.l = v14}};
v11 = (jboolean) env->CallBooleanMethodA(v8, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("270:move-result \x76\x30");
v24 = (jint) v11;
LOGD("272:if-nez \x76\x30\x2c\x20\x2b\x37");
if(v24 != 0){
goto L67;
}
else {
goto L66;
}
L66:
if (v19) {
LOGD("env->DeleteLocalRef(%p):v19", v19);
env->DeleteLocalRef(v19);
}
v19 = 0;
if (v19) {
LOGD("env->DeleteLocalRef(%p):v19", v19);
env->DeleteLocalRef(v19);
}
v19 = 0;
LOGD("278:iput-object \x76\x35\x2c\x20\x76\x37\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x69\x6e\x67\x57\x65\x62\x56\x69\x65\x77\x43\x6c\x69\x65\x6e\x74\x3b\x2d\x3e\x6c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x41\x6a\x61\x78\x52\x65\x71\x75\x65\x73\x74\x43\x6f\x6e\x74\x65\x6e\x74\x73\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls9;
jfieldID &fld = fld3;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/action/InterceptingWebViewClient", "l", "Lio/pro/edge/widget/event/net/AjaxRequestContents;");
env->SetObjectField(v3,fld,(jobject) v19);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("27c:iput-object \x76\x35\x2c\x20\x76\x37\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x69\x6e\x67\x57\x65\x62\x56\x69\x65\x77\x43\x6c\x69\x65\x6e\x74\x3b\x2d\x3e\x6b\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x46\x6f\x72\x6d\x52\x65\x71\x75\x65\x73\x74\x43\x6f\x6e\x74\x65\x6e\x74\x73\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls9;
jfieldID &fld = fld4;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/action/InterceptingWebViewClient", "k", "Lio/pro/edge/widget/event/net/FormRequestContents;");
env->SetObjectField(v3,fld,(jobject) v19);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L67:
LOGD("280:invoke-virtual \x76\x31\x31\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x71\x75\x65\x73\x74\x24\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x62\x75\x69\x6c\x64\x28\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x71\x75\x65\x73\x74\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v13);
jclass &clz = cls10;
jmethodID &mid = mth34;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Request$Builder", "build", "()Lokhttp3/Request;");
jvalue args[] = {};
v7 = (jobject) env->CallObjectMethodA(v13, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("286:move-result-object \x76\x30");
if (v6) {
LOGD("env->DeleteLocalRef(%p):v6", v6);
env->DeleteLocalRef(v6);
}
v6 = (jobject) v7;
L68:
LOGD("288:iget-object \x76\x35\x2c\x20\x76\x37\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x69\x6e\x67\x57\x65\x62\x56\x69\x65\x77\x43\x6c\x69\x65\x6e\x74\x3b\x2d\x3e\x6a\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x4f\x6b\x48\x74\x74\x70\x43\x6c\x69\x65\x6e\x74\x3b");
{
#define EX_HANDLE EX_LandingPad_68
D2C_NOT_NULL(v3);
jclass &clz = cls9;
jfieldID &fld = fld5;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/action/InterceptingWebViewClient", "j", "Lokhttp3/OkHttpClient;");
v7 = (jobject) env->GetObjectField(v3,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v19) {
LOGD("env->DeleteLocalRef(%p):v19", v19);
env->DeleteLocalRef(v19);
}
v19 = (jobject) v7;
L69:
LOGD("28c:invoke-virtual \x76\x35\x2c\x20\x76\x30\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x4f\x6b\x48\x74\x74\x70\x43\x6c\x69\x65\x6e\x74\x3b\x2d\x3e\x6e\x65\x77\x43\x61\x6c\x6c\x28\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x71\x75\x65\x73\x74\x3b\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x43\x61\x6c\x6c\x3b");
{
#define EX_HANDLE EX_LandingPad_68
D2C_NOT_NULL(v19);
jclass &clz = cls16;
jmethodID &mid = mth35;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/OkHttpClient", "newCall", "(Lokhttp3/Request;)Lokhttp3/Call;");
jvalue args[] = {{.l = v6}};
v7 = (jobject) env->CallObjectMethodA(v19, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L70:
LOGD("292:move-result-object \x76\x30");
if (v6) {
LOGD("env->DeleteLocalRef(%p):v6", v6);
env->DeleteLocalRef(v6);
}
v6 = (jobject) v7;
L71:
LOGD("294:invoke-interface \x76\x30\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x43\x61\x6c\x6c\x3b\x2d\x3e\x65\x78\x65\x63\x75\x74\x65\x28\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x3b");
{
#define EX_HANDLE EX_LandingPad_68
D2C_NOT_NULL(v6);
jclass &clz = cls17;
jmethodID &mid = mth36;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Call", "execute", "()Lokhttp3/Response;");
jvalue args[] = {};
v7 = (jobject) env->CallObjectMethodA(v6, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L72:
LOGD("29a:move-result-object \x76\x30");
if (v6) {
LOGD("env->DeleteLocalRef(%p):v6", v6);
env->DeleteLocalRef(v6);
}
v6 = (jobject) v7;
L73:
LOGD("29c:invoke-static \x76\x30\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x55\x74\x69\x6c\x73\x3b\x2d\x3e\x61\x28\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x3b\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x3b");
{
#define EX_HANDLE EX_LandingPad_68
jclass &clz = cls18;
jmethodID &mid = mth37;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "io/pro/edge/widget/event/net/ResponseUtils", "a", "(Lokhttp3/Response;)Lokhttp3/Response;");
jvalue args[] = {{.l = v6}};
v7 = (jobject) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L74:
LOGD("2a2:move-result-object \x76\x35");
if (v19) {
LOGD("env->DeleteLocalRef(%p):v19", v19);
env->DeleteLocalRef(v19);
}
v19 = (jobject) v7;
L75:
LOGD("2a4:invoke-virtual \x76\x35\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x3b\x2d\x3e\x62\x6f\x64\x79\x28\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x42\x6f\x64\x79\x3b");
{
#define EX_HANDLE EX_LandingPad_68
D2C_NOT_NULL(v19);
jclass &clz = cls19;
jmethodID &mid = mth38;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Response", "body", "()Lokhttp3/ResponseBody;");
jvalue args[] = {};
v7 = (jobject) env->CallObjectMethodA(v19, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L76:
LOGD("2aa:move-result-object \x76\x30");
if (v6) {
LOGD("env->DeleteLocalRef(%p):v6", v6);
env->DeleteLocalRef(v6);
}
v6 = (jobject) v7;
L77:
LOGD("2ac:const-string \x76\x36\x2c\x20\x27\x55\x54\x46\x2d\x38\x27");
if (v26) {
LOGD("env->DeleteLocalRef(%p):v26", v26);
env->DeleteLocalRef(v26);
}
v26 = (jstring) env->NewStringUTF("\x55\x54\x46\x2d\x38");
L78:
LOGD("2b0:const-string \x76\x31\x31\x2c\x20\x27\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65\x27");
if (v13) {
LOGD("env->DeleteLocalRef(%p):v13", v13);
env->DeleteLocalRef(v13);
}
v13 = (jstring) env->NewStringUTF("\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65");
L79:
LOGD("2b4:invoke-virtual \x76\x35\x2c\x20\x76\x31\x31\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x3b\x2d\x3e\x68\x65\x61\x64\x65\x72\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_LandingPad_68
D2C_NOT_NULL(v19);
jclass &clz = cls19;
jmethodID &mid = mth39;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Response", "header", "(Ljava/lang/String;)Ljava/lang/String;");
jvalue args[] = {{.l = v13}};
v7 = (jstring) env->CallObjectMethodA(v19, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L80:
LOGD("2ba:move-result-object \x76\x31\x31");
if (v13) {
LOGD("env->DeleteLocalRef(%p):v13", v13);
env->DeleteLocalRef(v13);
}
v13 = (jobject) v7;
L81:
LOGD("2bc:invoke-virtual \x76\x35\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x3b\x2d\x3e\x69\x73\x52\x65\x64\x69\x72\x65\x63\x74\x28\x29\x5a");
{
#define EX_HANDLE EX_LandingPad_68
D2C_NOT_NULL(v19);
jclass &clz = cls19;
jmethodID &mid = mth40;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Response", "isRedirect", "()Z");
jvalue args[] = {};
v11 = (jboolean) env->CallBooleanMethodA(v19, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L82:
LOGD("2c2:move-result \x76\x31\x38");
v27 = (jint) v11;
LOGD("2c4:if-eqz \x76\x31\x38\x2c\x20\x2b\x37");
if(v27 == 0){
goto L85;
}
else {
goto L83;
}
L83:
LOGD("2c8:invoke-virtual \x76\x37\x2c\x20\x76\x31\x30\x2c\x20\x76\x35\x2c\x20\x76\x31\x31\x2c\x20\x76\x36\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x69\x6e\x67\x57\x65\x62\x56\x69\x65\x77\x43\x6c\x69\x65\x6e\x74\x3b\x2d\x3e\x61\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x52\x65\x73\x6f\x75\x72\x63\x65\x52\x65\x73\x70\x6f\x6e\x73\x65\x3b");
{
#define EX_HANDLE EX_LandingPad_68
D2C_NOT_NULL(v3);
jclass &clz = cls9;
jmethodID &mid = mth41;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/event/action/InterceptingWebViewClient", "a", "(Ljava/lang/String;Lokhttp3/Response;Ljava/lang/String;Ljava/lang/String;)Landroid/webkit/WebResourceResponse;");
jvalue args[] = {{.l = v9},{.l = v19},{.l = v13},{.l = v26}};
v7 = (jobject) env->CallObjectMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L84:
LOGD("2ce:move-result-object \x76\x30");
if (v6) {
LOGD("env->DeleteLocalRef(%p):v6", v6);
env->DeleteLocalRef(v6);
}
v6 = (jobject) v7;
return (jobject) v6;
L85:
LOGD("2d2:invoke-virtual \x76\x35\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x3b\x2d\x3e\x63\x6f\x64\x65\x28\x29\x49");
{
#define EX_HANDLE EX_LandingPad_68
D2C_NOT_NULL(v19);
jclass &clz = cls19;
jmethodID &mid = mth42;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Response", "code", "()I");
jvalue args[] = {};
v11 = (jint) env->CallIntMethodA(v19, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L86:
LOGD("2d8:move-result \x76\x32\x31");
v28 = (jint) v11;
L87:
LOGD("2da:invoke-virtual \x76\x35\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x3b\x2d\x3e\x6d\x65\x73\x73\x61\x67\x65\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_LandingPad_68
D2C_NOT_NULL(v19);
jclass &clz = cls19;
jmethodID &mid = mth43;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Response", "message", "()Ljava/lang/String;");
jvalue args[] = {};
v7 = (jstring) env->CallObjectMethodA(v19, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L88:
LOGD("2e0:move-result-object \x76\x31\x38");
if (v29) {
LOGD("env->DeleteLocalRef(%p):v29", v29);
env->DeleteLocalRef(v29);
}
v29 = (jobject) v7;
L89:
LOGD("2e2:invoke-static/range \x76\x31\x38\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x74\x65\x78\x74\x2f\x54\x65\x78\x74\x55\x74\x69\x6c\x73\x3b\x2d\x3e\x69\x73\x45\x6d\x70\x74\x79\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x68\x61\x72\x53\x65\x71\x75\x65\x6e\x63\x65\x3b\x29\x5a");
{
#define EX_HANDLE EX_LandingPad_68
jclass &clz = cls6;
jmethodID &mid = mth6;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "android/text/TextUtils", "isEmpty", "(Ljava/lang/CharSequence;)Z");
jvalue args[] = {{.l = v29}};
v11 = (jboolean) env->CallStaticBooleanMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L90:
LOGD("2e8:move-result \x76\x31\x39");
v30 = (jint) v11;
LOGD("2ea:if-eqz \x76\x31\x39\x2c\x20\x2b\x34");
if(v30 == 0){
goto L92;
}
else {
goto L91;
}
L91:
LOGD("2ee:const-string \x76\x31\x38\x2c\x20\x27\x4f\x4b\x27");
if (v29) {
LOGD("env->DeleteLocalRef(%p):v29", v29);
env->DeleteLocalRef(v29);
}
v29 = (jstring) env->NewStringUTF("\x4f\x4b");
L92:
if (v31) {
LOGD("env->DeleteLocalRef(%p):v31", v31);
env->DeleteLocalRef(v31);
}
v31 = (jobject) env->NewLocalRef(v29);
L93:
LOGD("2f6:invoke-virtual \x76\x35\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x3b\x2d\x3e\x63\x6f\x64\x65\x28\x29\x49");
{
#define EX_HANDLE EX_LandingPad_68
D2C_NOT_NULL(v19);
jclass &clz = cls19;
jmethodID &mid = mth42;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Response", "code", "()I");
jvalue args[] = {};
v11 = (jint) env->CallIntMethodA(v19, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L94:
LOGD("2fc:move-result \x76\x32");
v21 = (jint) v11;
v32 = 400;
LOGD("302:if-lt \x76\x32\x2c\x20\x76\x33\x2c\x20\x2b\x34");
if(v21 < v32) {
goto L96;
}
else {
goto L95;
}
L95:
if (v10) {
LOGD("env->DeleteLocalRef(%p):v10", v10);
env->DeleteLocalRef(v10);
}
v10 = 0;
return (jobject) v10;
L96:
LOGD("30a:if-nez \x76\x30\x2c\x20\x2b\x32\x30");
if(v6 != NULL){
goto L108;
}
else {
goto L97;
}
L97:
LOGD("30e:invoke-virtual \x76\x31\x2c\x20\x76\x31\x32\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x65\x71\x75\x61\x6c\x73\x49\x67\x6e\x6f\x72\x65\x43\x61\x73\x65\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x5a");
{
#define EX_HANDLE EX_LandingPad_68
D2C_NOT_NULL(v8);
jclass &clz = cls7;
jmethodID &mid = mth31;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "equalsIgnoreCase", "(Ljava/lang/String;)Z");
jvalue args[] = {{.l = v14}};
v11 = (jboolean) env->CallBooleanMethodA(v8, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L98:
LOGD("314:move-result \x76\x30");
v24 = (jint) v11;
LOGD("316:if-eqz \x76\x30\x2c\x20\x2b\x31\x38");
if(v24 == 0){
goto L107;
}
else {
goto L99;
}
L99:
LOGD("31a:invoke-virtual \x76\x35\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x3b\x2d\x3e\x68\x65\x61\x64\x65\x72\x73\x28\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x48\x65\x61\x64\x65\x72\x73\x3b");
{
#define EX_HANDLE EX_LandingPad_68
D2C_NOT_NULL(v19);
jclass &clz = cls19;
jmethodID &mid = mth44;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Response", "headers", "()Lokhttp3/Headers;");
jvalue args[] = {};
v7 = (jobject) env->CallObjectMethodA(v19, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L100:
LOGD("320:move-result-object \x76\x30");
if (v6) {
LOGD("env->DeleteLocalRef(%p):v6", v6);
env->DeleteLocalRef(v6);
}
v6 = (jobject) v7;
L101:
LOGD("322:invoke-virtual \x76\x37\x2c\x20\x76\x31\x30\x2c\x20\x76\x30\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x69\x6e\x67\x57\x65\x62\x56\x69\x65\x77\x43\x6c\x69\x65\x6e\x74\x3b\x2d\x3e\x61\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x48\x65\x61\x64\x65\x72\x73\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x4d\x61\x70\x3b");
{
#define EX_HANDLE EX_LandingPad_68
D2C_NOT_NULL(v3);
jclass &clz = cls9;
jmethodID &mid = mth45;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/event/action/InterceptingWebViewClient", "a", "(Ljava/lang/String;Lokhttp3/Headers;)Ljava/util/Map;");
jvalue args[] = {{.l = v9},{.l = v6}};
v7 = (jobject) env->CallObjectMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L102:
LOGD("328:move-result-object \x76\x32\x33");
if (v33) {
LOGD("env->DeleteLocalRef(%p):v33", v33);
env->DeleteLocalRef(v33);
}
v33 = (jobject) v7;
L103:
LOGD("32a:new-instance \x76\x30\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x52\x65\x73\x6f\x75\x72\x63\x65\x52\x65\x73\x70\x6f\x6e\x73\x65\x3b");
{
#define EX_HANDLE EX_LandingPad_68
if (v6) {
LOGD("env->DeleteLocalRef(%p):v6", v6);
env->DeleteLocalRef(v6);
}
jclass &clz = cls20;
D2C_RESOLVE_CLASS(clz,"android/webkit/WebResourceResponse");
v6 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L104:
if (v34) {
LOGD("env->DeleteLocalRef(%p):v34", v34);
env->DeleteLocalRef(v34);
}
v34 = 0;
if (v29) {
LOGD("env->DeleteLocalRef(%p):v29", v29);
env->DeleteLocalRef(v29);
}
v29 = (jobject) env->NewLocalRef(v6);
if (v35) {
LOGD("env->DeleteLocalRef(%p):v35", v35);
env->DeleteLocalRef(v35);
}
v35 = (jobject) env->NewLocalRef(v13);
if (v36) {
LOGD("env->DeleteLocalRef(%p):v36", v36);
env->DeleteLocalRef(v36);
}
v36 = (jobject) env->NewLocalRef(v26);
L105:
LOGD("33e:invoke-direct/range \x76\x31\x38\x20\x2e\x2e\x2e\x20\x76\x32\x34\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x52\x65\x73\x6f\x75\x72\x63\x65\x52\x65\x73\x70\x6f\x6e\x73\x65\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x20\x49\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x4d\x61\x70\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x69\x6f\x2f\x49\x6e\x70\x75\x74\x53\x74\x72\x65\x61\x6d\x3b\x29\x56");
{
#define EX_HANDLE EX_LandingPad_68
D2C_NOT_NULL(v29);
jclass &clz = cls20;
jmethodID &mid = mth46;
D2C_RESOLVE_METHOD(clz, mid, "android/webkit/WebResourceResponse", "<init>", "(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/util/Map;Ljava/io/InputStream;)V");
jvalue args[] = {{.l = v35},{.l = v36},{.i = v28},{.l = v31},{.l = v33},{.l = v34}};
env->CallVoidMethodA(v29, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L106:
return (jobject) v6;
L107:
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = 0;
return (jobject) v8;
L108:
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = 0;
L109:
LOGD("34c:invoke-virtual \x76\x30\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x42\x6f\x64\x79\x3b\x2d\x3e\x62\x79\x74\x65\x73\x28\x29\x5b\x42");
{
#define EX_HANDLE EX_LandingPad_68
D2C_NOT_NULL(v6);
jclass &clz = cls21;
jmethodID &mid = mth47;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/ResponseBody", "bytes", "()[B");
jvalue args[] = {};
v7 = (jarray) env->CallObjectMethodA(v6, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L110:
LOGD("352:move-result-object \x76\x32");
if (v10) {
LOGD("env->DeleteLocalRef(%p):v10", v10);
env->DeleteLocalRef(v10);
}
v10 = (jobject) v7;
L111:
LOGD("354:array-length \x76\x33\x2c\x20\x76\x32");
{
#define EX_HANDLE EX_LandingPad_68
D2C_NOT_NULL(v10);
v32 = env->GetArrayLength((jarray) v10);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L112:
LOGD("356:if-nez \x76\x33\x2c\x20\x2b\x33");
if(v32 != 0){
goto L114;
}
else {
goto L113;
}
L113:
return (jobject) v8;
L114:
LOGD("35c:invoke-virtual \x76\x30\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x42\x6f\x64\x79\x3b\x2d\x3e\x63\x6f\x6e\x74\x65\x6e\x74\x54\x79\x70\x65\x28\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x4d\x65\x64\x69\x61\x54\x79\x70\x65\x3b");
{
#define EX_HANDLE EX_LandingPad_114
D2C_NOT_NULL(v6);
jclass &clz = cls21;
jmethodID &mid = mth48;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/ResponseBody", "contentType", "()Lokhttp3/MediaType;");
jvalue args[] = {};
v7 = (jobject) env->CallObjectMethodA(v6, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L115:
LOGD("362:move-result-object \x76\x31");
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jobject) v7;
L116:
LOGD("364:invoke-virtual \x76\x31\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x4d\x65\x64\x69\x61\x54\x79\x70\x65\x3b\x2d\x3e\x63\x68\x61\x72\x73\x65\x74\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6e\x69\x6f\x2f\x63\x68\x61\x72\x73\x65\x74\x2f\x43\x68\x61\x72\x73\x65\x74\x3b");
{
#define EX_HANDLE EX_LandingPad_114
D2C_NOT_NULL(v8);
jclass &clz = cls12;
jmethodID &mid = mth49;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/MediaType", "charset", "()Ljava/nio/charset/Charset;");
jvalue args[] = {};
v7 = (jobject) env->CallObjectMethodA(v8, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L117:
LOGD("36a:move-result-object \x76\x31");
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jobject) v7;
L118:
LOGD("36c:invoke-virtual \x76\x31\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6e\x69\x6f\x2f\x63\x68\x61\x72\x73\x65\x74\x2f\x43\x68\x61\x72\x73\x65\x74\x3b\x2d\x3e\x64\x69\x73\x70\x6c\x61\x79\x4e\x61\x6d\x65\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_LandingPad_114
D2C_NOT_NULL(v8);
jclass &clz = cls22;
jmethodID &mid = mth50;
D2C_RESOLVE_METHOD(clz, mid, "java/nio/charset/Charset", "displayName", "()Ljava/lang/String;");
jvalue args[] = {};
v7 = (jstring) env->CallObjectMethodA(v8, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L119:
LOGD("372:move-result-object \x76\x36");
if (v26) {
LOGD("env->DeleteLocalRef(%p):v26", v26);
env->DeleteLocalRef(v26);
}
v26 = (jobject) v7;
L120:
LOGD("374:invoke-virtual \x76\x30\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x42\x6f\x64\x79\x3b\x2d\x3e\x63\x6f\x6e\x74\x65\x6e\x74\x54\x79\x70\x65\x28\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x4d\x65\x64\x69\x61\x54\x79\x70\x65\x3b");
{
#define EX_HANDLE EX_LandingPad_114
D2C_NOT_NULL(v6);
jclass &clz = cls21;
jmethodID &mid = mth48;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/ResponseBody", "contentType", "()Lokhttp3/MediaType;");
jvalue args[] = {};
v7 = (jobject) env->CallObjectMethodA(v6, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L121:
LOGD("37a:move-result-object \x76\x30");
if (v6) {
LOGD("env->DeleteLocalRef(%p):v6", v6);
env->DeleteLocalRef(v6);
}
v6 = (jobject) v7;
L122:
LOGD("37c:invoke-virtual \x76\x30\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x4d\x65\x64\x69\x61\x54\x79\x70\x65\x3b\x2d\x3e\x74\x6f\x53\x74\x72\x69\x6e\x67\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_LandingPad_114
D2C_NOT_NULL(v6);
jclass &clz = cls12;
jmethodID &mid = mth51;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/MediaType", "toString", "()Ljava/lang/String;");
jvalue args[] = {};
v7 = (jstring) env->CallObjectMethodA(v6, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L123:
LOGD("382:move-result-object \x76\x31\x31");
if (v13) {
LOGD("env->DeleteLocalRef(%p):v13", v13);
env->DeleteLocalRef(v13);
}
v13 = (jobject) v7;
L124:
LOGD("384:invoke-virtual \x76\x37\x2c\x20\x76\x31\x31\x2c\x20\x76\x32\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x69\x6e\x67\x57\x65\x62\x56\x69\x65\x77\x43\x6c\x69\x65\x6e\x74\x3b\x2d\x3e\x61\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x20\x5b\x42\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_LandingPad_124
D2C_NOT_NULL(v3);
jclass &clz = cls9;
jmethodID &mid = mth52;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/event/action/InterceptingWebViewClient", "a", "(Ljava/lang/String;[B)Ljava/lang/String;");
jvalue args[] = {{.l = v13},{.l = v10}};
v7 = (jstring) env->CallObjectMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L125:
LOGD("38a:move-result-object \x76\x31");
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jobject) v7;
L126:
LOGD("38c:invoke-static \x76\x31\x33\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x74\x65\x78\x74\x2f\x54\x65\x78\x74\x55\x74\x69\x6c\x73\x3b\x2d\x3e\x69\x73\x45\x6d\x70\x74\x79\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x68\x61\x72\x53\x65\x71\x75\x65\x6e\x63\x65\x3b\x29\x5a");
{
#define EX_HANDLE EX_LandingPad_124
jclass &clz = cls6;
jmethodID &mid = mth6;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "android/text/TextUtils", "isEmpty", "(Ljava/lang/CharSequence;)Z");
jvalue args[] = {{.l = v15}};
v11 = (jboolean) env->CallStaticBooleanMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L127:
LOGD("392:move-result \x76\x30");
v24 = (jint) v11;
LOGD("394:if-nez \x76\x30\x2c\x20\x2b\x34\x64");
if(v24 != 0){
goto L160;
}
else {
goto L128;
}
L128:
LOGD("398:invoke-virtual \x76\x39\x2c\x20\x76\x31\x34\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x65\x71\x75\x61\x6c\x73\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b\x29\x5a");
{
#define EX_HANDLE EX_LandingPad_124
D2C_NOT_NULL(v5);
jclass &clz = cls7;
jmethodID &mid = mth16;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "equals", "(Ljava/lang/Object;)Z");
jvalue args[] = {{.l = v16}};
v11 = (jboolean) env->CallBooleanMethodA(v5, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L129:
LOGD("39e:move-result \x76\x30");
v24 = (jint) v11;
LOGD("3a0:if-eqz \x76\x30\x2c\x20\x2b\x34\x37");
if(v24 == 0){
goto L160;
}
else {
goto L130;
}
L130:
LOGD("3a4:invoke-virtual \x76\x31\x33\x2c\x20\x76\x31\x35\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x65\x6e\x64\x73\x57\x69\x74\x68\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x5a");
{
#define EX_HANDLE EX_LandingPad_124
D2C_NOT_NULL(v15);
jclass &clz = cls7;
jmethodID &mid = mth17;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "endsWith", "(Ljava/lang/String;)Z");
jvalue args[] = {{.l = v18}};
v11 = (jboolean) env->CallBooleanMethodA(v15, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L131:
LOGD("3aa:move-result \x76\x30");
v24 = (jint) v11;
LOGD("3ac:if-eqz \x76\x30\x2c\x20\x2b\x34\x31");
if(v24 == 0){
goto L160;
}
else {
goto L132;
}
L132:
LOGD("3b0:new-instance \x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_LandingPad_132
if (v6) {
LOGD("env->DeleteLocalRef(%p):v6", v6);
env->DeleteLocalRef(v6);
}
jclass &clz = cls7;
D2C_RESOLVE_CLASS(clz,"java/lang/String");
v6 = (jstring) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L133:
LOGD("3b4:invoke-direct \x76\x30\x2c\x20\x76\x32\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x5b\x42\x29\x56");
{
#define EX_HANDLE EX_LandingPad_132
D2C_NOT_NULL(v6);
jclass &clz = cls7;
jmethodID &mid = mth53;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "<init>", "([B)V");
jvalue args[] = {{.l = v10}};
env->CallVoidMethodA(v6, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L134:
LOGD("3ba:new-instance \x76\x33\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_LandingPad_132
if (v22) {
LOGD("env->DeleteLocalRef(%p):v22", v22);
env->DeleteLocalRef(v22);
}
jclass &clz = cls2;
D2C_RESOLVE_CLASS(clz,"java/lang/StringBuilder");
v22 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L135:
LOGD("3be:invoke-direct \x76\x33\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x29\x56");
{
#define EX_HANDLE EX_LandingPad_132
D2C_NOT_NULL(v22);
jclass &clz = cls2;
jmethodID &mid = mth2;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "<init>", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v22, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L136:
LOGD("3c4:const-string \x76\x39\x2c\x20\x27\x22\x75\x73\x65\x20\x73\x74\x72\x69\x63\x74\x22\x3b\x27");
if (v5) {
LOGD("env->DeleteLocalRef(%p):v5", v5);
env->DeleteLocalRef(v5);
}
v5 = (jstring) env->NewStringUTF("\x22\x75\x73\x65\x20\x73\x74\x72\x69\x63\x74\x22\x3b");
L137:
LOGD("3c8:invoke-virtual \x76\x33\x2c\x20\x76\x39\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_LandingPad_132
D2C_NOT_NULL(v22);
jclass &clz = cls2;
jmethodID &mid = mth3;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v5}};
v7 = (jobject) env->CallObjectMethodA(v22, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
L138:
LOGD("3ce:invoke-virtual \x76\x33\x2c\x20\x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_LandingPad_132
D2C_NOT_NULL(v22);
jclass &clz = cls2;
jmethodID &mid = mth3;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v6}};
v7 = (jobject) env->CallObjectMethodA(v22, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
L139:
LOGD("3d4:invoke-virtual \x76\x33\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x74\x6f\x53\x74\x72\x69\x6e\x67\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_LandingPad_132
D2C_NOT_NULL(v22);
jclass &clz = cls2;
jmethodID &mid = mth4;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "toString", "()Ljava/lang/String;");
jvalue args[] = {};
v7 = (jstring) env->CallObjectMethodA(v22, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L140:
LOGD("3da:move-result-object \x76\x30");
if (v6) {
LOGD("env->DeleteLocalRef(%p):v6", v6);
env->DeleteLocalRef(v6);
}
v6 = (jobject) v7;
L141:
LOGD("3dc:invoke-static \x76\x38\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x72\x65\x67\x65\x78\x2f\x50\x61\x74\x74\x65\x72\x6e\x3b\x2d\x3e\x63\x6f\x6d\x70\x69\x6c\x65\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x72\x65\x67\x65\x78\x2f\x50\x61\x74\x74\x65\x72\x6e\x3b");
{
#define EX_HANDLE EX_LandingPad_132
jclass &clz = cls23;
jmethodID &mid = mth54;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "java/util/regex/Pattern", "compile", "(Ljava/lang/String;)Ljava/util/regex/Pattern;");
jvalue args[] = {{.l = v4}};
v7 = (jobject) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L142:
LOGD("3e2:move-result-object \x76\x33");
if (v22) {
LOGD("env->DeleteLocalRef(%p):v22", v22);
env->DeleteLocalRef(v22);
}
v22 = (jobject) v7;
L143:
LOGD("3e4:invoke-virtual \x76\x33\x2c\x20\x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x72\x65\x67\x65\x78\x2f\x50\x61\x74\x74\x65\x72\x6e\x3b\x2d\x3e\x6d\x61\x74\x63\x68\x65\x72\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x68\x61\x72\x53\x65\x71\x75\x65\x6e\x63\x65\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x72\x65\x67\x65\x78\x2f\x4d\x61\x74\x63\x68\x65\x72\x3b");
{
#define EX_HANDLE EX_LandingPad_132
D2C_NOT_NULL(v22);
jclass &clz = cls23;
jmethodID &mid = mth55;
D2C_RESOLVE_METHOD(clz, mid, "java/util/regex/Pattern", "matcher", "(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;");
jvalue args[] = {{.l = v6}};
v7 = (jobject) env->CallObjectMethodA(v22, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L144:
LOGD("3ea:move-result-object \x76\x33");
if (v22) {
LOGD("env->DeleteLocalRef(%p):v22", v22);
env->DeleteLocalRef(v22);
}
v22 = (jobject) v7;
L145:
LOGD("3ec:invoke-virtual \x76\x33\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x72\x65\x67\x65\x78\x2f\x4d\x61\x74\x63\x68\x65\x72\x3b\x2d\x3e\x66\x69\x6e\x64\x28\x29\x5a");
{
#define EX_HANDLE EX_LandingPad_132
D2C_NOT_NULL(v22);
jclass &clz = cls24;
jmethodID &mid = mth56;
D2C_RESOLVE_METHOD(clz, mid, "java/util/regex/Matcher", "find", "()Z");
jvalue args[] = {};
v11 = (jboolean) env->CallBooleanMethodA(v22, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L146:
LOGD("3f2:move-result \x76\x39");
v37 = (jint) v11;
LOGD("3f4:if-eqz \x76\x39\x2c\x20\x2b\x31\x64");
if(v37 == 0){
goto L160;
}
else {
goto L147;
}
L147:
v37 = 0;
v37 = 0;
L148:
LOGD("3fa:invoke-virtual \x76\x33\x2c\x20\x76\x39\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x72\x65\x67\x65\x78\x2f\x4d\x61\x74\x63\x68\x65\x72\x3b\x2d\x3e\x67\x72\x6f\x75\x70\x28\x49\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_LandingPad_132
D2C_NOT_NULL(v22);
jclass &clz = cls24;
jmethodID &mid = mth57;
D2C_RESOLVE_METHOD(clz, mid, "java/util/regex/Matcher", "group", "(I)Ljava/lang/String;");
jvalue args[] = {{.i = v37}};
v7 = (jstring) env->CallObjectMethodA(v22, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L149:
LOGD("400:move-result-object \x76\x33");
if (v22) {
LOGD("env->DeleteLocalRef(%p):v22", v22);
env->DeleteLocalRef(v22);
}
v22 = (jobject) v7;
L150:
LOGD("402:const-string \x76\x31\x31\x2c\x20\x27\x3d\x3d\x27");
if (v13) {
LOGD("env->DeleteLocalRef(%p):v13", v13);
env->DeleteLocalRef(v13);
}
v13 = (jstring) env->NewStringUTF("\x3d\x3d");
L151:
LOGD("406:invoke-virtual \x76\x33\x2c\x20\x76\x31\x31\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x73\x70\x6c\x69\x74\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x5b\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_LandingPad_132
D2C_NOT_NULL(v22);
jclass &clz = cls7;
jmethodID &mid = mth58;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "split", "(Ljava/lang/String;)[Ljava/lang/String;");
jvalue args[] = {{.l = v13}};
v7 = (jarray) env->CallObjectMethodA(v22, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L152:
LOGD("40c:move-result-object \x76\x33");
if (v22) {
LOGD("env->DeleteLocalRef(%p):v22", v22);
env->DeleteLocalRef(v22);
}
v22 = (jobject) v7;
L153:
LOGD("40e:aget-object \x76\x33\x2c\x20\x76\x33\x2c\x20\x76\x39");
{
#define EX_HANDLE EX_LandingPad_132
D2C_NOT_NULL(v22);
v7 = (jstring) env->GetObjectArrayElement((jobjectArray) v22, (jint) v37);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v22) {
LOGD("env->DeleteLocalRef(%p):v22", v22);
env->DeleteLocalRef(v22);
}
v22 = (jobject) v7;
L154:
LOGD("412:invoke-virtual \x76\x30\x2c\x20\x76\x38\x2c\x20\x76\x33\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x72\x65\x70\x6c\x61\x63\x65\x41\x6c\x6c\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_LandingPad_132
D2C_NOT_NULL(v6);
jclass &clz = cls7;
jmethodID &mid = mth59;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "replaceAll", "(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;");
jvalue args[] = {{.l = v4},{.l = v22}};
v7 = (jstring) env->CallObjectMethodA(v6, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L155:
LOGD("418:move-result-object \x76\x30");
if (v6) {
LOGD("env->DeleteLocalRef(%p):v6", v6);
env->DeleteLocalRef(v6);
}
v6 = (jobject) v7;
L156:
LOGD("41a:invoke-virtual \x76\x30\x2c\x20\x76\x36\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x67\x65\x74\x42\x79\x74\x65\x73\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x5b\x42");
{
#define EX_HANDLE EX_LandingPad_132
D2C_NOT_NULL(v6);
jclass &clz = cls7;
jmethodID &mid = mth60;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "getBytes", "(Ljava/lang/String;)[B");
jvalue args[] = {{.l = v26}};
v7 = (jarray) env->CallObjectMethodA(v6, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L157:
LOGD("420:move-result-object \x76\x30");
if (v6) {
LOGD("env->DeleteLocalRef(%p):v6", v6);
env->DeleteLocalRef(v6);
}
v6 = (jobject) v7;
if (v10) {
LOGD("env->DeleteLocalRef(%p):v10", v10);
env->DeleteLocalRef(v10);
}
v10 = (jobject) env->NewLocalRef(v6);
goto L160;
L158:
LOGD("426:move-exception \x76\x30");
if (v6) {
LOGD("env->DeleteLocalRef(%p):v6", v6);
env->DeleteLocalRef(v6);
}
v6 = exception;
L159:
LOGD("428:invoke-virtual \x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3b\x2d\x3e\x70\x72\x69\x6e\x74\x53\x74\x61\x63\x6b\x54\x72\x61\x63\x65\x28\x29\x56");
{
#define EX_HANDLE EX_LandingPad_160
D2C_NOT_NULL(v6);
jclass &clz = cls25;
jmethodID &mid = mth61;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/Exception", "printStackTrace", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v6, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L160:
LOGD("42e:iget-object \x76\x30\x2c\x20\x76\x37\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x44\x6f\x77\x6e\x6c\x6f\x61\x64\x43\x6c\x69\x65\x6e\x74\x3b\x2d\x3e\x65\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x57\x6f\x72\x6b\x65\x72\x3b");
{
#define EX_HANDLE EX_LandingPad_160
D2C_NOT_NULL(v3);
jclass &clz = cls4;
jfieldID &fld = fld0;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/action/DownloadClient", "e", "Lio/pro/edge/widget/event/action/Worker;");
v7 = (jobject) env->GetObjectField(v3,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v6) {
LOGD("env->DeleteLocalRef(%p):v6", v6);
env->DeleteLocalRef(v6);
}
v6 = (jobject) v7;
L161:
LOGD("432:iget-object \x76\x30\x2c\x20\x76\x30\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x57\x6f\x72\x6b\x65\x72\x3b\x2d\x3e\x6d\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x4c\x69\x73\x74\x3b");
{
#define EX_HANDLE EX_LandingPad_160
D2C_NOT_NULL(v6);
jclass &clz = cls5;
jfieldID &fld = fld6;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/action/Worker", "m", "Ljava/util/List;");
v7 = (jobject) env->GetObjectField(v6,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v6) {
LOGD("env->DeleteLocalRef(%p):v6", v6);
env->DeleteLocalRef(v6);
}
v6 = (jobject) v7;
L162:
LOGD("436:invoke-static \x76\x31\x30\x2c\x20\x76\x32\x2c\x20\x76\x36\x2c\x20\x76\x30\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x75\x74\x69\x6c\x73\x2f\x4e\x65\x74\x55\x74\x69\x6c\x73\x3b\x2d\x3e\x61\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x20\x5b\x42\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x4c\x69\x73\x74\x3b\x29\x5b\x42");
{
#define EX_HANDLE EX_LandingPad_160
jclass &clz = cls8;
jmethodID &mid = mth62;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "io/pro/edge/widget/event/utils/NetUtils", "a", "(Ljava/lang/String;[BLjava/lang/String;Ljava/util/List;)[B");
jvalue args[] = {{.l = v9},{.l = v10},{.l = v26},{.l = v6}};
v7 = (jarray) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L163:
LOGD("43c:move-result-object \x76\x30");
if (v6) {
LOGD("env->DeleteLocalRef(%p):v6", v6);
env->DeleteLocalRef(v6);
}
v6 = (jobject) v7;
L164:
LOGD("43e:invoke-virtual \x76\x37\x2c\x20\x76\x30\x2c\x20\x76\x31\x2c\x20\x76\x36\x2c\x20\x76\x34\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x69\x6e\x67\x57\x65\x62\x56\x69\x65\x77\x43\x6c\x69\x65\x6e\x74\x3b\x2d\x3e\x61\x28\x5b\x42\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x20\x5a\x29\x4c\x6a\x61\x76\x61\x2f\x69\x6f\x2f\x49\x6e\x70\x75\x74\x53\x74\x72\x65\x61\x6d\x3b");
{
#define EX_HANDLE EX_LandingPad_160
D2C_NOT_NULL(v3);
jclass &clz = cls9;
jmethodID &mid = mth63;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/event/action/InterceptingWebViewClient", "a", "([BLjava/lang/String;Ljava/lang/String;Z)Ljava/io/InputStream;");
jvalue args[] = {{.l = v6},{.l = v8},{.l = v26},{.z = (jboolean) v25}};
v7 = (jobject) env->CallObjectMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L165:
LOGD("444:move-result-object \x76\x30");
if (v6) {
LOGD("env->DeleteLocalRef(%p):v6", v6);
env->DeleteLocalRef(v6);
}
v6 = (jobject) v7;
L166:
LOGD("446:invoke-virtual \x76\x35\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x3b\x2d\x3e\x68\x65\x61\x64\x65\x72\x73\x28\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x48\x65\x61\x64\x65\x72\x73\x3b");
{
#define EX_HANDLE EX_LandingPad_160
D2C_NOT_NULL(v19);
jclass &clz = cls19;
jmethodID &mid = mth44;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Response", "headers", "()Lokhttp3/Headers;");
jvalue args[] = {};
v7 = (jobject) env->CallObjectMethodA(v19, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L167:
LOGD("44c:move-result-object \x76\x32");
if (v10) {
LOGD("env->DeleteLocalRef(%p):v10", v10);
env->DeleteLocalRef(v10);
}
v10 = (jobject) v7;
L168:
LOGD("44e:invoke-virtual \x76\x37\x2c\x20\x76\x31\x30\x2c\x20\x76\x32\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x69\x6e\x67\x57\x65\x62\x56\x69\x65\x77\x43\x6c\x69\x65\x6e\x74\x3b\x2d\x3e\x61\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x48\x65\x61\x64\x65\x72\x73\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x4d\x61\x70\x3b");
{
#define EX_HANDLE EX_LandingPad_160
D2C_NOT_NULL(v3);
jclass &clz = cls9;
jmethodID &mid = mth45;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/event/action/InterceptingWebViewClient", "a", "(Ljava/lang/String;Lokhttp3/Headers;)Ljava/util/Map;");
jvalue args[] = {{.l = v9},{.l = v10}};
v7 = (jobject) env->CallObjectMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L169:
LOGD("454:move-result-object \x76\x31\x36");
if (v38) {
LOGD("env->DeleteLocalRef(%p):v38", v38);
env->DeleteLocalRef(v38);
}
v38 = (jobject) v7;
if (v10) {
LOGD("env->DeleteLocalRef(%p):v10", v10);
env->DeleteLocalRef(v10);
}
v10 = (jobject) env->NewLocalRef(v23);
L170:
LOGD("45a:invoke-virtual \x76\x31\x2c\x20\x76\x32\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x63\x6f\x6e\x74\x61\x69\x6e\x73\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x68\x61\x72\x53\x65\x71\x75\x65\x6e\x63\x65\x3b\x29\x5a");
{
#define EX_HANDLE EX_LandingPad_160
D2C_NOT_NULL(v8);
jclass &clz = cls7;
jmethodID &mid = mth15;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "contains", "(Ljava/lang/CharSequence;)Z");
jvalue args[] = {{.l = v10}};
v11 = (jboolean) env->CallBooleanMethodA(v8, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L171:
LOGD("460:move-result \x76\x33");
v32 = (jint) v11;
LOGD("462:if-eqz \x76\x33\x2c\x20\x2b\x34");
if(v32 == 0){
goto L173;
}
else {
goto L172;
}
L172:
if (v14) {
LOGD("env->DeleteLocalRef(%p):v14", v14);
env->DeleteLocalRef(v14);
}
v14 = (jobject) env->NewLocalRef(v10);
goto L174;
L173:
if (v14) {
LOGD("env->DeleteLocalRef(%p):v14", v14);
env->DeleteLocalRef(v14);
}
v14 = (jobject) env->NewLocalRef(v8);
L174:
LOGD("46c:new-instance \x76\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x52\x65\x73\x6f\x75\x72\x63\x65\x52\x65\x73\x70\x6f\x6e\x73\x65\x3b");
{
#define EX_HANDLE EX_LandingPad_160
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
jclass &clz = cls20;
D2C_RESOLVE_CLASS(clz,"android/webkit/WebResourceResponse");
v8 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L175:
if (v13) {
LOGD("env->DeleteLocalRef(%p):v13", v13);
env->DeleteLocalRef(v13);
}
v13 = (jobject) env->NewLocalRef(v8);
if (v15) {
LOGD("env->DeleteLocalRef(%p):v15", v15);
env->DeleteLocalRef(v15);
}
v15 = (jobject) env->NewLocalRef(v26);
v39 = v28;
if (v18) {
LOGD("env->DeleteLocalRef(%p):v18", v18);
env->DeleteLocalRef(v18);
}
v18 = (jobject) env->NewLocalRef(v31);
if (v23) {
LOGD("env->DeleteLocalRef(%p):v23", v23);
env->DeleteLocalRef(v23);
}
v23 = (jobject) env->NewLocalRef(v6);
L176:
LOGD("480:invoke-direct/range \x76\x31\x31\x20\x2e\x2e\x2e\x20\x76\x31\x37\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x52\x65\x73\x6f\x75\x72\x63\x65\x52\x65\x73\x70\x6f\x6e\x73\x65\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x20\x49\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x4d\x61\x70\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x69\x6f\x2f\x49\x6e\x70\x75\x74\x53\x74\x72\x65\x61\x6d\x3b\x29\x56");
{
#define EX_HANDLE EX_LandingPad_160
D2C_NOT_NULL(v13);
jclass &clz = cls20;
jmethodID &mid = mth46;
D2C_RESOLVE_METHOD(clz, mid, "android/webkit/WebResourceResponse", "<init>", "(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/util/Map;Ljava/io/InputStream;)V");
jvalue args[] = {{.l = v14},{.l = v15},{.i = v39},{.l = v18},{.l = v38},{.l = v23}};
env->CallVoidMethodA(v13, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L177:
return (jobject) v8;
L178:
LOGD("488:move-exception \x76\x30");
if (v6) {
LOGD("env->DeleteLocalRef(%p):v6", v6);
env->DeleteLocalRef(v6);
}
v6 = exception;
LOGD("48a:invoke-virtual \x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x54\x68\x72\x6f\x77\x61\x62\x6c\x65\x3b\x2d\x3e\x70\x72\x69\x6e\x74\x53\x74\x61\x63\x6b\x54\x72\x61\x63\x65\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v6);
jclass &clz = cls14;
jmethodID &mid = mth28;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/Throwable", "printStackTrace", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v6, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("490:invoke-virtual \x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x54\x68\x72\x6f\x77\x61\x62\x6c\x65\x3b\x2d\x3e\x67\x65\x74\x4d\x65\x73\x73\x61\x67\x65\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v6);
jclass &clz = cls14;
jmethodID &mid = mth64;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/Throwable", "getMessage", "()Ljava/lang/String;");
jvalue args[] = {};
v7 = (jstring) env->CallObjectMethodA(v6, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("496:move-result-object \x76\x30");
if (v6) {
LOGD("env->DeleteLocalRef(%p):v6", v6);
env->DeleteLocalRef(v6);
}
v6 = (jobject) v7;
LOGD("498:iget-object \x76\x31\x2c\x20\x76\x37\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x44\x6f\x77\x6e\x6c\x6f\x61\x64\x43\x6c\x69\x65\x6e\x74\x3b\x2d\x3e\x65\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x57\x6f\x72\x6b\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls4;
jfieldID &fld = fld0;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/action/DownloadClient", "e", "Lio/pro/edge/widget/event/action/Worker;");
v7 = (jobject) env->GetObjectField(v3,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jobject) v7;
LOGD("49c:iget-object \x76\x31\x2c\x20\x76\x31\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x57\x6f\x72\x6b\x65\x72\x3b\x2d\x3e\x7a\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x75\x74\x69\x6c\x73\x2f\x54\x72\x61\x6e\x73\x66\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v8);
jclass &clz = cls5;
jfieldID &fld = fld7;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/action/Worker", "z", "Lio/pro/edge/widget/event/utils/Transfer;");
v7 = (jobject) env->GetObjectField(v8,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jobject) v7;
v21 = 1;
LOGD("4a2:new-array \x76\x33\x2c\x20\x76\x32\x2c\x20\x5b\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v21 < 0) {
d2c_throw_exception(env, "java/lang/NegativeArraySizeException", "negative array size");
goto EX_HANDLE;
}
if (v22) {
LOGD("env->DeleteLocalRef(%p):v22", v22);
env->DeleteLocalRef(v22);
}
jclass &clz = cls7;
D2C_RESOLVE_CLASS(clz,"java/lang/String");
v22 = env->NewObjectArray((jint) v21, clz, NULL);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
v21 = 0;
LOGD("4a8:aput-object \x76\x30\x2c\x20\x76\x33\x2c\x20\x76\x32");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v22);
env->SetObjectArrayElement((jobjectArray) v22, (jint) v21, v6);D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("4ac:invoke-virtual \x76\x31\x2c\x20\x76\x33\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x75\x74\x69\x6c\x73\x2f\x54\x72\x61\x6e\x73\x66\x65\x72\x3b\x2d\x3e\x61\x28\x5b\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v8);
jclass &clz = cls26;
jmethodID &mid = mth65;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/event/utils/Transfer", "a", "([Ljava/lang/String;)V");
jvalue args[] = {{.l = v22}};
env->CallVoidMethodA(v8, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("4b2:const-string \x76\x31\x2c\x20\x27\x55\x6e\x61\x62\x6c\x65\x20\x74\x6f\x20\x72\x65\x73\x6f\x6c\x76\x65\x20\x68\x6f\x73\x74\x27");
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jobject) env->NewStringUTF("\x55\x6e\x61\x62\x6c\x65\x20\x74\x6f\x20\x72\x65\x73\x6f\x6c\x76\x65\x20\x68\x6f\x73\x74");
LOGD("4b6:invoke-virtual \x76\x30\x2c\x20\x76\x31\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x63\x6f\x6e\x74\x61\x69\x6e\x73\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x68\x61\x72\x53\x65\x71\x75\x65\x6e\x63\x65\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v6);
jclass &clz = cls7;
jmethodID &mid = mth15;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "contains", "(Ljava/lang/CharSequence;)Z");
jvalue args[] = {{.l = v8}};
v11 = (jboolean) env->CallBooleanMethodA(v6, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("4bc:move-result \x76\x30");
v24 = (jint) v11;
LOGD("4be:if-eqz \x76\x30\x2c\x20\x2b\x32\x31");
if(v24 == 0){
goto L182;
}
else {
goto L179;
}
L179:
LOGD("4c2:iget-object \x76\x30\x2c\x20\x76\x37\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x44\x6f\x77\x6e\x6c\x6f\x61\x64\x43\x6c\x69\x65\x6e\x74\x3b\x2d\x3e\x65\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x57\x6f\x72\x6b\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls4;
jfieldID &fld = fld0;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/action/DownloadClient", "e", "Lio/pro/edge/widget/event/action/Worker;");
v7 = (jobject) env->GetObjectField(v3,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v6) {
LOGD("env->DeleteLocalRef(%p):v6", v6);
env->DeleteLocalRef(v6);
}
v6 = (jobject) v7;
LOGD("4c6:iget-object \x76\x30\x2c\x20\x76\x30\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x57\x6f\x72\x6b\x65\x72\x3b\x2d\x3e\x67\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v6);
jclass &clz = cls5;
jfieldID &fld = fld8;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/action/Worker", "g", "Ljava/lang/String;");
v7 = (jstring) env->GetObjectField(v6,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v6) {
LOGD("env->DeleteLocalRef(%p):v6", v6);
env->DeleteLocalRef(v6);
}
v6 = (jobject) v7;
LOGD("4ca:invoke-virtual \x76\x31\x30\x2c\x20\x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x63\x6f\x6e\x74\x61\x69\x6e\x73\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x68\x61\x72\x53\x65\x71\x75\x65\x6e\x63\x65\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v9);
jclass &clz = cls7;
jmethodID &mid = mth15;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "contains", "(Ljava/lang/CharSequence;)Z");
jvalue args[] = {{.l = v6}};
v11 = (jboolean) env->CallBooleanMethodA(v9, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("4d0:move-result \x76\x30");
v24 = (jint) v11;
LOGD("4d2:if-eqz \x76\x30\x2c\x20\x2b\x31\x37");
if(v24 == 0){
goto L182;
}
else {
goto L180;
}
L180:
LOGD("4d6:iget \x76\x30\x2c\x20\x76\x37\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x69\x6e\x67\x57\x65\x62\x56\x69\x65\x77\x43\x6c\x69\x65\x6e\x74\x3b\x2d\x3e\x6f\x20\x49");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls9;
jfieldID &fld = fld9;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/action/InterceptingWebViewClient", "o", "I");
v24 = (jint) env->GetIntField(v3,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
v12 = 3;
LOGD("4dc:if-ge \x76\x30\x2c\x20\x76\x31\x2c\x20\x2b\x31\x32");
if(v24 >= v12) {
goto L182;
}
else {
goto L181;
}
L181:
v12 = 1;
LOGD("4e2:add-int/2addr \x76\x30\x2c\x20\x76\x31");
v24 = (v24 + v12);
LOGD("4e4:iput \x76\x30\x2c\x20\x76\x37\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x69\x6e\x67\x57\x65\x62\x56\x69\x65\x77\x43\x6c\x69\x65\x6e\x74\x3b\x2d\x3e\x6f\x20\x49");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls9;
jfieldID &fld = fld9;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/action/InterceptingWebViewClient", "o", "I");
env->SetIntField(v3,fld,(jint) v24);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("4e8:iget-object \x76\x30\x2c\x20\x76\x37\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x44\x6f\x77\x6e\x6c\x6f\x61\x64\x43\x6c\x69\x65\x6e\x74\x3b\x2d\x3e\x62\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x56\x69\x65\x77\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls4;
jfieldID &fld = fld10;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/action/DownloadClient", "b", "Landroid/webkit/WebView;");
v7 = (jobject) env->GetObjectField(v3,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v6) {
LOGD("env->DeleteLocalRef(%p):v6", v6);
env->DeleteLocalRef(v6);
}
v6 = (jobject) v7;
LOGD("4ec:new-instance \x76\x31\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x69\x6e\x67\x57\x65\x62\x56\x69\x65\x77\x43\x6c\x69\x65\x6e\x74\x24\x31\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
jclass &clz = cls27;
D2C_RESOLVE_CLASS(clz,"io/pro/edge/widget/event/action/InterceptingWebViewClient$1");
v8 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("4f0:invoke-direct \x76\x31\x2c\x20\x76\x37\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x69\x6e\x67\x57\x65\x62\x56\x69\x65\x77\x43\x6c\x69\x65\x6e\x74\x24\x31\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x69\x6e\x67\x57\x65\x62\x56\x69\x65\x77\x43\x6c\x69\x65\x6e\x74\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v8);
jclass &clz = cls27;
jmethodID &mid = mth66;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/event/action/InterceptingWebViewClient$1", "<init>", "(Lio/pro/edge/widget/event/action/InterceptingWebViewClient;)V");
jvalue args[] = {{.l = v3}};
env->CallVoidMethodA(v8, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
v40 = 10000;
LOGD("4fa:invoke-virtual \x76\x30\x2c\x20\x76\x31\x2c\x20\x76\x32\x2c\x20\x76\x33\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x56\x69\x65\x77\x3b\x2d\x3e\x70\x6f\x73\x74\x44\x65\x6c\x61\x79\x65\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x52\x75\x6e\x6e\x61\x62\x6c\x65\x3b\x20\x4a\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v6);
jclass &clz = cls28;
jmethodID &mid = mth67;
D2C_RESOLVE_METHOD(clz, mid, "android/webkit/WebView", "postDelayed", "(Ljava/lang/Runnable;J)Z");
jvalue args[] = {{.l = v8},{.j = (jlong) v40}};
v11 = (jboolean) env->CallBooleanMethodA(v6, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L182:
LOGD("500:invoke-super/range \x76\x32\x35\x20\x2e\x2e\x2e\x20\x76\x32\x37\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x56\x69\x65\x77\x43\x6c\x69\x65\x6e\x74\x3b\x2d\x3e\x73\x68\x6f\x75\x6c\x64\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x52\x65\x71\x75\x65\x73\x74\x28\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x56\x69\x65\x77\x3b\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x52\x65\x73\x6f\x75\x72\x63\x65\x52\x65\x71\x75\x65\x73\x74\x3b\x29\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x52\x65\x73\x6f\x75\x72\x63\x65\x52\x65\x73\x70\x6f\x6e\x73\x65\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls29;
jmethodID &mid = mth68;
D2C_RESOLVE_METHOD(clz, mid, "android/webkit/WebViewClient", "shouldInterceptRequest", "(Landroid/webkit/WebView;Landroid/webkit/WebResourceRequest;)Landroid/webkit/WebResourceResponse;");
jvalue args[] = {{.l = v1},{.l = v2}};
v7 = (jobject) env->CallNonvirtualObjectMethodA(v0, clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("506:move-result-object \x76\x30");
if (v6) {
LOGD("env->DeleteLocalRef(%p):v6", v6);
env->DeleteLocalRef(v6);
}
v6 = (jobject) v7;
return (jobject) v6;
L183:
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = 0;
L184:
LOGD("50c:iput-object \x76\x31\x2c\x20\x76\x37\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x69\x6e\x67\x57\x65\x62\x56\x69\x65\x77\x43\x6c\x69\x65\x6e\x74\x3b\x2d\x3e\x6b\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x46\x6f\x72\x6d\x52\x65\x71\x75\x65\x73\x74\x43\x6f\x6e\x74\x65\x6e\x74\x73\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls9;
jfieldID &fld = fld4;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/action/InterceptingWebViewClient", "k", "Lio/pro/edge/widget/event/net/FormRequestContents;");
env->SetObjectField(v3,fld,(jobject) v8);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
return (jobject) v8;
L185:
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = 0;
L186:
LOGD("514:iput-object \x76\x31\x2c\x20\x76\x37\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x69\x6e\x67\x57\x65\x62\x56\x69\x65\x77\x43\x6c\x69\x65\x6e\x74\x3b\x2d\x3e\x6c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x41\x6a\x61\x78\x52\x65\x71\x75\x65\x73\x74\x43\x6f\x6e\x74\x65\x6e\x74\x73\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls9;
jfieldID &fld = fld3;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/action/InterceptingWebViewClient", "l", "Lio/pro/edge/widget/event/net/AjaxRequestContents;");
env->SetObjectField(v3,fld,(jobject) v8);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
return (jobject) v8;
L187:
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jobject) env->NewLocalRef(v13);
return (jobject) v8;

EX_LandingPad_23:
D2C_GET_PENDING_EX
if(d2c_is_instance_of(env, exception, "java/lang/Throwable")) {
goto L36;
}
D2C_GOTO_UNWINDBLOCK

EX_LandingPad_38:
D2C_GET_PENDING_EX
if(d2c_is_instance_of(env, exception, "java/lang/Exception")) {
goto L185;
}
D2C_GOTO_UNWINDBLOCK

EX_LandingPad_40:
D2C_GET_PENDING_EX
if(d2c_is_instance_of(env, exception, "java/lang/Exception")) {
goto L185;
}
D2C_GOTO_UNWINDBLOCK

EX_LandingPad_49:
D2C_GET_PENDING_EX
if(d2c_is_instance_of(env, exception, "java/lang/Exception")) {
goto L183;
}
D2C_GOTO_UNWINDBLOCK

EX_LandingPad_45:
D2C_GET_PENDING_EX
if(d2c_is_instance_of(env, exception, "java/lang/Exception")) {
goto L47;
}
D2C_GOTO_UNWINDBLOCK

EX_LandingPad_56:
D2C_GET_PENDING_EX
if(d2c_is_instance_of(env, exception, "java/lang/Exception")) {
goto L58;
}
D2C_GOTO_UNWINDBLOCK

EX_LandingPad_68:
D2C_GET_PENDING_EX
if(d2c_is_instance_of(env, exception, "java/lang/Throwable")) {
goto L178;
}
D2C_GOTO_UNWINDBLOCK

EX_LandingPad_114:
D2C_GET_PENDING_EX
if(d2c_is_instance_of(env, exception, "java/lang/NullPointerException")) {
goto L124;
}
if(d2c_is_instance_of(env, exception, "java/lang/Throwable")) {
goto L178;
}
D2C_GOTO_UNWINDBLOCK

EX_LandingPad_124:
D2C_GET_PENDING_EX
if(d2c_is_instance_of(env, exception, "java/lang/Throwable")) {
goto L178;
}
D2C_GOTO_UNWINDBLOCK

EX_LandingPad_160:
D2C_GET_PENDING_EX
if(d2c_is_instance_of(env, exception, "java/lang/Throwable")) {
goto L178;
}
D2C_GOTO_UNWINDBLOCK

EX_LandingPad_132:
D2C_GET_PENDING_EX
if(d2c_is_instance_of(env, exception, "java/lang/Exception")) {
goto L158;
}
if(d2c_is_instance_of(env, exception, "java/lang/Throwable")) {
goto L178;
}
D2C_GOTO_UNWINDBLOCK
EX_UnwindBlock: return NULL;
}
