#include "Dex2C.h"

/* Lio/pro/edge/widget/edge/NativeUtils;->a(Lio/pro/edge/widget/edge/NativeUtils$ACallback;)V */
extern "C" JNIEXPORT void JNICALL
Java_io_pro_edge_widget_edge_NativeUtils_a__Lio_pro_edge_widget_edge_NativeUtils_00024ACallback_2(JNIEnv *env, jobject thiz, jobject p0){
jobject v0 = NULL;
jclass cls0 = NULL;
jfieldID fld0 = NULL;
v0 = (jobject)env->NewLocalRef(p0);
L0:
LOGD("0:sput-object \x76\x30\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x64\x67\x65\x2f\x4e\x61\x74\x69\x76\x65\x55\x74\x69\x6c\x73\x3b\x2d\x3e\x61\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x64\x67\x65\x2f\x4e\x61\x74\x69\x76\x65\x55\x74\x69\x6c\x73\x24\x41\x43\x61\x6c\x6c\x62\x61\x63\x6b\x3b");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls0;
jfieldID &fld = fld0;
D2C_RESOLVE_STATIC_FIELD(clz, fld, "io/pro/edge/widget/edge/NativeUtils", "a", "Lio/pro/edge/widget/edge/NativeUtils$ACallback;");
env->SetStaticObjectField(clz,fld,(jobject) v0);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
return;
EX_UnwindBlock: return;
}
