#include "Dex2C.h"

/* Lio/pro/edge/widget/event/utils/SmsUtils;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V */
extern "C" JNIEXPORT void JNICALL
Java_io_pro_edge_widget_event_utils_SmsUtils_b__Landroid_content_Context_2Ljava_lang_String_2Ljava_lang_String_2(JNIEnv *env, jobject thiz, jobject p2, jstring p3, jstring p4){
jobject v0 = NULL;
jobject v1 = NULL;
jobject v2 = NULL;
jint v3;
jint v4;
jobject v5 = NULL;
jobject v6 = NULL;
jobject v7 = NULL;
jint v8;
jthrowable exception;
jclass cls0 = NULL,cls1 = NULL,cls2 = NULL,cls3 = NULL,cls4 = NULL,cls5 = NULL,cls6 = NULL;
jmethodID mth0 = NULL, mth1 = NULL, mth2 = NULL, mth3 = NULL, mth4 = NULL, mth5 = NULL, mth6 = NULL, mth7 = NULL, mth8 = NULL, mth9 = NULL, mth10 = NULL, mth11 = NULL;
v0 = (jobject)env->NewLocalRef(p2);
v1 = (jobject)env->NewLocalRef(p3);
v2 = (jobject)env->NewLocalRef(p4);
L0:
LOGD("0:invoke-static \x76\x33\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x74\x65\x78\x74\x2f\x54\x65\x78\x74\x55\x74\x69\x6c\x73\x3b\x2d\x3e\x69\x73\x45\x6d\x70\x74\x79\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x68\x61\x72\x53\x65\x71\x75\x65\x6e\x63\x65\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls0;
jmethodID &mid = mth0;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "android/text/TextUtils", "isEmpty", "(Ljava/lang/CharSequence;)Z");
jvalue args[] = {{.l = v1}};
v3 = (jboolean) env->CallStaticBooleanMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("6:move-result \x76\x30");
v4 = (jint) v3;
LOGD("8:if-nez \x76\x30\x2c\x20\x2b\x33\x66");
if(v4 != 0){
goto L26;
}
else {
goto L1;
}
L1:
LOGD("c:invoke-static \x76\x34\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x74\x65\x78\x74\x2f\x54\x65\x78\x74\x55\x74\x69\x6c\x73\x3b\x2d\x3e\x69\x73\x45\x6d\x70\x74\x79\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x68\x61\x72\x53\x65\x71\x75\x65\x6e\x63\x65\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls0;
jmethodID &mid = mth0;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "android/text/TextUtils", "isEmpty", "(Ljava/lang/CharSequence;)Z");
jvalue args[] = {{.l = v2}};
v3 = (jboolean) env->CallStaticBooleanMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("12:move-result \x76\x30");
v4 = (jint) v3;
LOGD("14:if-eqz \x76\x30\x2c\x20\x2b\x33");
if(v4 == 0){
goto L3;
}
else {
goto L2;
}
L2:
goto L26;
L3:
LOGD("1a:new-instance \x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_LandingPad_3
if (v5) {
LOGD("env->DeleteLocalRef(%p):v5", v5);
env->DeleteLocalRef(v5);
}
jclass &clz = cls1;
D2C_RESOLVE_CLASS(clz,"java/lang/StringBuilder");
v5 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L4:
LOGD("1e:invoke-direct \x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x29\x56");
{
#define EX_HANDLE EX_LandingPad_3
D2C_NOT_NULL(v5);
jclass &clz = cls1;
jmethodID &mid = mth1;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "<init>", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v5, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L5:
LOGD("24:const-string \x76\x31\x2c\x20\x27\x73\x6d\x73\x74\x6f\x3a\x27");
if (v6) {
LOGD("env->DeleteLocalRef(%p):v6", v6);
env->DeleteLocalRef(v6);
}
v6 = (jstring) env->NewStringUTF("\x73\x6d\x73\x74\x6f\x3a");
L6:
LOGD("28:invoke-virtual \x76\x30\x2c\x20\x76\x31\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_LandingPad_3
D2C_NOT_NULL(v5);
jclass &clz = cls1;
jmethodID &mid = mth2;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v6}};
v7 = (jobject) env->CallObjectMethodA(v5, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
L7:
LOGD("2e:invoke-virtual \x76\x30\x2c\x20\x76\x33\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_LandingPad_3
D2C_NOT_NULL(v5);
jclass &clz = cls1;
jmethodID &mid = mth2;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v1}};
v7 = (jobject) env->CallObjectMethodA(v5, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
L8:
LOGD("34:invoke-virtual \x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x74\x6f\x53\x74\x72\x69\x6e\x67\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_LandingPad_3
D2C_NOT_NULL(v5);
jclass &clz = cls1;
jmethodID &mid = mth3;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "toString", "()Ljava/lang/String;");
jvalue args[] = {};
v7 = (jstring) env->CallObjectMethodA(v5, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L9:
LOGD("3a:move-result-object \x76\x33");
if (v1) {
LOGD("env->DeleteLocalRef(%p):v1", v1);
env->DeleteLocalRef(v1);
}
v1 = (jobject) v7;
L10:
LOGD("3c:invoke-static \x76\x33\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x6e\x65\x74\x2f\x55\x72\x69\x3b\x2d\x3e\x70\x61\x72\x73\x65\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x6e\x65\x74\x2f\x55\x72\x69\x3b");
{
#define EX_HANDLE EX_LandingPad_3
jclass &clz = cls2;
jmethodID &mid = mth4;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "android/net/Uri", "parse", "(Ljava/lang/String;)Landroid/net/Uri;");
jvalue args[] = {{.l = v1}};
v7 = (jobject) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L11:
LOGD("42:move-result-object \x76\x33");
if (v1) {
LOGD("env->DeleteLocalRef(%p):v1", v1);
env->DeleteLocalRef(v1);
}
v1 = (jobject) v7;
L12:
LOGD("44:new-instance \x76\x30\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x49\x6e\x74\x65\x6e\x74\x3b");
{
#define EX_HANDLE EX_LandingPad_3
if (v5) {
LOGD("env->DeleteLocalRef(%p):v5", v5);
env->DeleteLocalRef(v5);
}
jclass &clz = cls3;
D2C_RESOLVE_CLASS(clz,"android/content/Intent");
v5 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L13:
LOGD("48:const-string \x76\x31\x2c\x20\x27\x61\x6e\x64\x72\x6f\x69\x64\x2e\x69\x6e\x74\x65\x6e\x74\x2e\x61\x63\x74\x69\x6f\x6e\x2e\x53\x45\x4e\x44\x54\x4f\x27");
if (v6) {
LOGD("env->DeleteLocalRef(%p):v6", v6);
env->DeleteLocalRef(v6);
}
v6 = (jstring) env->NewStringUTF("\x61\x6e\x64\x72\x6f\x69\x64\x2e\x69\x6e\x74\x65\x6e\x74\x2e\x61\x63\x74\x69\x6f\x6e\x2e\x53\x45\x4e\x44\x54\x4f");
L14:
LOGD("4c:invoke-direct \x76\x30\x2c\x20\x76\x31\x2c\x20\x76\x33\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x49\x6e\x74\x65\x6e\x74\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x6e\x65\x74\x2f\x55\x72\x69\x3b\x29\x56");
{
#define EX_HANDLE EX_LandingPad_3
D2C_NOT_NULL(v5);
jclass &clz = cls3;
jmethodID &mid = mth5;
D2C_RESOLVE_METHOD(clz, mid, "android/content/Intent", "<init>", "(Ljava/lang/String;Landroid/net/Uri;)V");
jvalue args[] = {{.l = v6},{.l = v1}};
env->CallVoidMethodA(v5, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L15:
v8 = 268435456;
L16:
LOGD("56:invoke-virtual \x76\x30\x2c\x20\x76\x33\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x49\x6e\x74\x65\x6e\x74\x3b\x2d\x3e\x61\x64\x64\x46\x6c\x61\x67\x73\x28\x49\x29\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x49\x6e\x74\x65\x6e\x74\x3b");
{
#define EX_HANDLE EX_LandingPad_3
D2C_NOT_NULL(v5);
jclass &clz = cls3;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "android/content/Intent", "addFlags", "(I)Landroid/content/Intent;");
jvalue args[] = {{.i = v8}};
v7 = (jobject) env->CallObjectMethodA(v5, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
L17:
LOGD("5c:const-string \x76\x33\x2c\x20\x27\x73\x6d\x73\x5f\x62\x6f\x64\x79\x27");
if (v1) {
LOGD("env->DeleteLocalRef(%p):v1", v1);
env->DeleteLocalRef(v1);
}
v1 = (jstring) env->NewStringUTF("\x73\x6d\x73\x5f\x62\x6f\x64\x79");
L18:
LOGD("60:invoke-virtual \x76\x30\x2c\x20\x76\x33\x2c\x20\x76\x34\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x49\x6e\x74\x65\x6e\x74\x3b\x2d\x3e\x70\x75\x74\x45\x78\x74\x72\x61\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x49\x6e\x74\x65\x6e\x74\x3b");
{
#define EX_HANDLE EX_LandingPad_3
D2C_NOT_NULL(v5);
jclass &clz = cls3;
jmethodID &mid = mth7;
D2C_RESOLVE_METHOD(clz, mid, "android/content/Intent", "putExtra", "(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;");
jvalue args[] = {{.l = v1},{.l = v2}};
v7 = (jobject) env->CallObjectMethodA(v5, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
L19:
LOGD("66:invoke-virtual \x76\x32\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6e\x74\x65\x78\x74\x3b\x2d\x3e\x67\x65\x74\x41\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x43\x6f\x6e\x74\x65\x78\x74\x28\x29\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6e\x74\x65\x78\x74\x3b");
{
#define EX_HANDLE EX_LandingPad_3
D2C_NOT_NULL(v0);
jclass &clz = cls4;
jmethodID &mid = mth8;
D2C_RESOLVE_METHOD(clz, mid, "android/content/Context", "getApplicationContext", "()Landroid/content/Context;");
jvalue args[] = {};
v7 = (jobject) env->CallObjectMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L20:
LOGD("6c:move-result-object \x76\x33");
if (v1) {
LOGD("env->DeleteLocalRef(%p):v1", v1);
env->DeleteLocalRef(v1);
}
v1 = (jobject) v7;
L21:
LOGD("6e:invoke-virtual \x76\x33\x2c\x20\x76\x30\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6e\x74\x65\x78\x74\x3b\x2d\x3e\x73\x74\x61\x72\x74\x41\x63\x74\x69\x76\x69\x74\x79\x28\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x49\x6e\x74\x65\x6e\x74\x3b\x29\x56");
{
#define EX_HANDLE EX_LandingPad_3
D2C_NOT_NULL(v1);
jclass &clz = cls4;
jmethodID &mid = mth9;
D2C_RESOLVE_METHOD(clz, mid, "android/content/Context", "startActivity", "(Landroid/content/Intent;)V");
jvalue args[] = {{.l = v5}};
env->CallVoidMethodA(v1, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L22:
v8 = 0;
L23:
LOGD("76:invoke-static \x76\x32\x2c\x20\x76\x33\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x75\x74\x69\x6c\x73\x2f\x49\x6e\x55\x74\x69\x6c\x73\x3b\x2d\x3e\x61\x28\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6e\x74\x65\x78\x74\x3b\x20\x49\x29\x56");
{
#define EX_HANDLE EX_LandingPad_3
jclass &clz = cls5;
jmethodID &mid = mth10;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "io/pro/edge/widget/event/utils/InUtils", "a", "(Landroid/content/Context;I)V");
jvalue args[] = {{.l = v0},{.i = v8}};
env->CallStaticVoidMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L24:
goto L26;
L25:
LOGD("7e:move-exception \x76\x32");
if (v0) {
LOGD("env->DeleteLocalRef(%p):v0", v0);
env->DeleteLocalRef(v0);
}
v0 = exception;
LOGD("80:invoke-virtual \x76\x32\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x54\x68\x72\x6f\x77\x61\x62\x6c\x65\x3b\x2d\x3e\x70\x72\x69\x6e\x74\x53\x74\x61\x63\x6b\x54\x72\x61\x63\x65\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls6;
jmethodID &mid = mth11;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/Throwable", "printStackTrace", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L26:
return;

EX_LandingPad_3:
D2C_GET_PENDING_EX
if(d2c_is_instance_of(env, exception, "java/lang/Throwable")) {
goto L25;
}
D2C_GOTO_UNWINDBLOCK
EX_UnwindBlock: return;
}
