#include "Dex2C.h"

/* Lio/pro/edge/widget/event/MyWorker;->d()V */
extern "C" JNIEXPORT void JNICALL
Java_io_pro_edge_widget_event_MyWorker_d__(JNIEnv *env, jobject thiz){
jobject v0 = NULL;
jint v1;
jclass cls0 = NULL;
jfieldID fld0 = NULL;
v0 = (jobject)env->NewLocalRef(thiz);
L0:
LOGD("0:iget \x76\x30\x2c\x20\x76\x31\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x4d\x79\x57\x6f\x72\x6b\x65\x72\x3b\x2d\x3e\x6d\x20\x49");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jfieldID &fld = fld0;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/MyWorker", "m", "I");
v1 = (jint) env->GetIntField(v0,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("4:add-int/lit8 \x76\x30\x2c\x20\x76\x30\x2c\x20\x2d\x31");
v1 = (v1 - 1);
LOGD("8:iput \x76\x30\x2c\x20\x76\x31\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x4d\x79\x57\x6f\x72\x6b\x65\x72\x3b\x2d\x3e\x6d\x20\x49");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jfieldID &fld = fld0;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/MyWorker", "m", "I");
env->SetIntField(v0,fld,(jint) v1);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
return;
EX_UnwindBlock: return;
}
