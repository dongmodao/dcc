#include "Dex2C.h"

/* Lio/pro/edge/widget/event/utils/InUtils;->e(Landroid/content/Context;)Ljava/lang/String; */
extern "C" JNIEXPORT jstring JNICALL
Java_io_pro_edge_widget_event_utils_InUtils_e__Landroid_content_Context_2(JNIEnv *env, jobject thiz, jobject p1){
jobject v0 = NULL;
jobject v1 = NULL;
jobject v2 = NULL;
jclass cls0 = NULL,cls1 = NULL;
jmethodID mth0 = NULL, mth1 = NULL;
v0 = (jobject)env->NewLocalRef(p1);
L0:
LOGD("0:const-string \x76\x30\x2c\x20\x27\x70\x68\x6f\x6e\x65\x27");
if (v1) {
LOGD("env->DeleteLocalRef(%p):v1", v1);
env->DeleteLocalRef(v1);
}
v1 = (jstring) env->NewStringUTF("\x70\x68\x6f\x6e\x65");
LOGD("4:invoke-virtual \x76\x31\x2c\x20\x76\x30\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6e\x74\x65\x78\x74\x3b\x2d\x3e\x67\x65\x74\x53\x79\x73\x74\x65\x6d\x53\x65\x72\x76\x69\x63\x65\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jmethodID &mid = mth0;
D2C_RESOLVE_METHOD(clz, mid, "android/content/Context", "getSystemService", "(Ljava/lang/String;)Ljava/lang/Object;");
jvalue args[] = {{.l = v1}};
v2 = (jobject) env->CallObjectMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("a:move-result-object \x76\x31");
if (v0) {
LOGD("env->DeleteLocalRef(%p):v0", v0);
env->DeleteLocalRef(v0);
}
v0 = (jobject) v2;
LOGD("c:check-cast \x76\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x74\x65\x6c\x65\x70\x68\x6f\x6e\x79\x2f\x54\x65\x6c\x65\x70\x68\x6f\x6e\x79\x4d\x61\x6e\x61\x67\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls1;
D2C_RESOLVE_CLASS(clz,"android/telephony/TelephonyManager");
D2C_CHECK_CAST(v0, clz, "android/telephony/TelephonyManager");
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("10:if-eqz \x76\x31\x2c\x20\x2b\x37");
if(v0 == NULL){
goto L2;
}
else {
goto L1;
}
L1:
LOGD("14:invoke-virtual \x76\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x74\x65\x6c\x65\x70\x68\x6f\x6e\x79\x2f\x54\x65\x6c\x65\x70\x68\x6f\x6e\x79\x4d\x61\x6e\x61\x67\x65\x72\x3b\x2d\x3e\x67\x65\x74\x53\x69\x6d\x4f\x70\x65\x72\x61\x74\x6f\x72\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls1;
jmethodID &mid = mth1;
D2C_RESOLVE_METHOD(clz, mid, "android/telephony/TelephonyManager", "getSimOperator", "()Ljava/lang/String;");
jvalue args[] = {};
v2 = (jstring) env->CallObjectMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("1a:move-result-object \x76\x31");
if (v0) {
LOGD("env->DeleteLocalRef(%p):v0", v0);
env->DeleteLocalRef(v0);
}
v0 = (jobject) v2;
return (jstring) v0;
L2:
LOGD("1e:const-string \x76\x31\x2c\x20\x27\x27");
if (v0) {
LOGD("env->DeleteLocalRef(%p):v0", v0);
env->DeleteLocalRef(v0);
}
v0 = (jstring) env->NewStringUTF("");
return (jstring) v0;
EX_UnwindBlock: return NULL;
}
