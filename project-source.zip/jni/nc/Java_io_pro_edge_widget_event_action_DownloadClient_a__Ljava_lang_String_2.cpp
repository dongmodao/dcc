#include "Dex2C.h"

/* Lio/pro/edge/widget/event/action/DownloadClient;->a(Ljava/lang/String;)V */
extern "C" JNIEXPORT void JNICALL
Java_io_pro_edge_widget_event_action_DownloadClient_a__Ljava_lang_String_2(JNIEnv *env, jobject thiz, jstring p3){
jobject v0 = NULL;
jobject v1 = NULL;
jobject v2 = NULL;
jobject v3 = NULL;
jint v4;
jint v5;
jclass cls0 = NULL,cls1 = NULL,cls2 = NULL;
jfieldID fld0 = NULL,fld1 = NULL,fld2 = NULL;
jmethodID mth0 = NULL, mth1 = NULL;
v0 = (jobject)env->NewLocalRef(thiz);
v1 = (jobject)env->NewLocalRef(p3);
L0:
LOGD("0:invoke-static \x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x6f\x73\x2f\x4d\x65\x73\x73\x61\x67\x65\x3b\x2d\x3e\x6f\x62\x74\x61\x69\x6e\x28\x29\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x6f\x73\x2f\x4d\x65\x73\x73\x61\x67\x65\x3b");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls0;
jmethodID &mid = mth0;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "android/os/Message", "obtain", "()Landroid/os/Message;");
jvalue args[] = {};
v2 = (jobject) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("6:move-result-object \x76\x30");
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
v3 = (jobject) v2;
v4 = 1117;
LOGD("c:iput \x76\x31\x2c\x20\x76\x30\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x6f\x73\x2f\x4d\x65\x73\x73\x61\x67\x65\x3b\x2d\x3e\x77\x68\x61\x74\x20\x49");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls0;
jfieldID &fld = fld0;
D2C_RESOLVE_FIELD(clz, fld, "android/os/Message", "what", "I");
env->SetIntField(v3,fld,(jint) v4);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("10:iput-object \x76\x33\x2c\x20\x76\x30\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x6f\x73\x2f\x4d\x65\x73\x73\x61\x67\x65\x3b\x2d\x3e\x6f\x62\x6a\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls0;
jfieldID &fld = fld1;
D2C_RESOLVE_FIELD(clz, fld, "android/os/Message", "obj", "Ljava/lang/Object;");
env->SetObjectField(v3,fld,(jobject) v1);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("14:iget-object \x76\x33\x2c\x20\x76\x32\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x44\x6f\x77\x6e\x6c\x6f\x61\x64\x43\x6c\x69\x65\x6e\x74\x3b\x2d\x3e\x63\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x6f\x73\x2f\x48\x61\x6e\x64\x6c\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls1;
jfieldID &fld = fld2;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/action/DownloadClient", "c", "Landroid/os/Handler;");
v2 = (jobject) env->GetObjectField(v0,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v1) {
LOGD("env->DeleteLocalRef(%p):v1", v1);
env->DeleteLocalRef(v1);
}
v1 = (jobject) v2;
LOGD("18:invoke-virtual \x76\x33\x2c\x20\x76\x30\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x6f\x73\x2f\x48\x61\x6e\x64\x6c\x65\x72\x3b\x2d\x3e\x73\x65\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x28\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x6f\x73\x2f\x4d\x65\x73\x73\x61\x67\x65\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v1);
jclass &clz = cls2;
jmethodID &mid = mth1;
D2C_RESOLVE_METHOD(clz, mid, "android/os/Handler", "sendMessage", "(Landroid/os/Message;)Z");
jvalue args[] = {{.l = v3}};
v5 = (jboolean) env->CallBooleanMethodA(v1, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
return;
EX_UnwindBlock: return;
}
