#include "Dex2C.h"

/* Lio/pro/edge/widget/event/utils/NetUtils;->a(Ljava/lang/String;[BLjava/lang/String;Ljava/util/List;)[B */
extern "C" JNIEXPORT jarray JNICALL
Java_io_pro_edge_widget_event_utils_NetUtils_a__Ljava_lang_String_2_3BLjava_lang_String_2Ljava_util_List_2(JNIEnv *env, jobject thiz, jstring p10, jarray p11, jstring p12, jobject p13){
jobject v0 = NULL;
jobject v1 = NULL;
jobject v2 = NULL;
jobject v3 = NULL;
jint v4;
jint v5;
jobject v6 = NULL;
jobject v7 = NULL;
jint v8;
jobject v9 = NULL;
jobject v10 = NULL;
jobject v11 = NULL;
jint v12;
jobject v13 = NULL;
jint v14;
jint v15;
jint v16;
jobject v17 = NULL;
jobject v18 = NULL;
jobject v19 = NULL;
jint v20;
jthrowable exception;
jclass cls0 = NULL,cls1 = NULL,cls2 = NULL,cls3 = NULL,cls4 = NULL,cls5 = NULL,cls6 = NULL;
jmethodID mth0 = NULL, mth1 = NULL, mth2 = NULL, mth3 = NULL, mth4 = NULL, mth5 = NULL, mth6 = NULL, mth7 = NULL, mth8 = NULL, mth9 = NULL, mth10 = NULL, mth11 = NULL, mth12 = NULL;
v0 = (jobject)env->NewLocalRef(p10);
v1 = (jobject)env->NewLocalRef(p11);
v2 = (jobject)env->NewLocalRef(p12);
v3 = (jobject)env->NewLocalRef(p13);
L0:
LOGD("0:if-eqz \x76\x31\x33\x2c\x20\x2b\x38\x32");
if(v3 == NULL){
goto L50;
}
else {
goto L1;
}
L1:
LOGD("4:invoke-interface \x76\x31\x33\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x4c\x69\x73\x74\x3b\x2d\x3e\x73\x69\x7a\x65\x28\x29\x49");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls0;
jmethodID &mid = mth0;
D2C_RESOLVE_METHOD(clz, mid, "java/util/List", "size", "()I");
jvalue args[] = {};
v4 = (jint) env->CallIntMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("a:move-result \x76\x30");
v5 = (jint) v4;
LOGD("c:if-lez \x76\x30\x2c\x20\x2b\x37\x63");
if(v5 <= 0){
goto L50;
}
else {
goto L2;
}
L2:
LOGD("10:new-instance \x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v6) {
LOGD("env->DeleteLocalRef(%p):v6", v6);
env->DeleteLocalRef(v6);
}
jclass &clz = cls1;
D2C_RESOLVE_CLASS(clz,"java/lang/String");
v6 = (jstring) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("14:invoke-direct \x76\x30\x2c\x20\x76\x31\x31\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x5b\x42\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v6);
jclass &clz = cls1;
jmethodID &mid = mth1;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "<init>", "([B)V");
jvalue args[] = {{.l = v1}};
env->CallVoidMethodA(v6, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
v7 = (jobject) env->NewLocalRef(v6);
v5 = 0;
L3:
LOGD("20:invoke-interface \x76\x31\x33\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x4c\x69\x73\x74\x3b\x2d\x3e\x73\x69\x7a\x65\x28\x29\x49");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls0;
jmethodID &mid = mth0;
D2C_RESOLVE_METHOD(clz, mid, "java/util/List", "size", "()I");
jvalue args[] = {};
v4 = (jint) env->CallIntMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("26:move-result \x76\x33");
v8 = (jint) v4;
LOGD("28:if-ge \x76\x30\x2c\x20\x76\x33\x2c\x20\x2b\x36\x35");
if(v5 >= v8) {
goto L47;
}
else {
goto L4;
}
L4:
LOGD("2c:invoke-interface \x76\x31\x33\x2c\x20\x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x4c\x69\x73\x74\x3b\x2d\x3e\x67\x65\x74\x28\x49\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b");
{
#define EX_HANDLE EX_LandingPad_4
D2C_NOT_NULL(v3);
jclass &clz = cls0;
jmethodID &mid = mth2;
D2C_RESOLVE_METHOD(clz, mid, "java/util/List", "get", "(I)Ljava/lang/Object;");
jvalue args[] = {{.i = v5}};
v9 = (jobject) env->CallObjectMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L5:
LOGD("32:move-result-object \x76\x33");
if (v10) {
LOGD("env->DeleteLocalRef(%p):v10", v10);
env->DeleteLocalRef(v10);
}
v10 = (jobject) v9;
L6:
LOGD("34:check-cast \x76\x33\x2c\x20\x4c\x6f\x72\x67\x2f\x6a\x73\x6f\x6e\x2f\x4a\x53\x4f\x4e\x4f\x62\x6a\x65\x63\x74\x3b");
{
#define EX_HANDLE EX_LandingPad_4
jclass &clz = cls2;
D2C_RESOLVE_CLASS(clz,"org/json/JSONObject");
D2C_CHECK_CAST(v10, clz, "org/json/JSONObject");
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L7:
LOGD("38:const-string \x76\x34\x2c\x20\x27\x72\x27");
if (v11) {
LOGD("env->DeleteLocalRef(%p):v11", v11);
env->DeleteLocalRef(v11);
}
v11 = (jstring) env->NewStringUTF("\x72");
L8:
LOGD("3c:invoke-virtual \x76\x33\x2c\x20\x76\x34\x2c\x20\x4c\x6f\x72\x67\x2f\x6a\x73\x6f\x6e\x2f\x4a\x53\x4f\x4e\x4f\x62\x6a\x65\x63\x74\x3b\x2d\x3e\x6f\x70\x74\x53\x74\x72\x69\x6e\x67\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_LandingPad_4
D2C_NOT_NULL(v10);
jclass &clz = cls2;
jmethodID &mid = mth3;
D2C_RESOLVE_METHOD(clz, mid, "org/json/JSONObject", "optString", "(Ljava/lang/String;)Ljava/lang/String;");
jvalue args[] = {{.l = v11}};
v9 = (jstring) env->CallObjectMethodA(v10, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L9:
LOGD("42:move-result-object \x76\x34");
if (v11) {
LOGD("env->DeleteLocalRef(%p):v11", v11);
env->DeleteLocalRef(v11);
}
v11 = (jobject) v9;
L10:
LOGD("44:invoke-virtual \x76\x31\x30\x2c\x20\x76\x34\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x6d\x61\x74\x63\x68\x65\x73\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x5a");
{
#define EX_HANDLE EX_LandingPad_4
D2C_NOT_NULL(v0);
jclass &clz = cls1;
jmethodID &mid = mth4;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "matches", "(Ljava/lang/String;)Z");
jvalue args[] = {{.l = v11}};
v4 = (jboolean) env->CallBooleanMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L11:
LOGD("4a:move-result \x76\x34");
v12 = (jint) v4;
LOGD("4c:if-nez \x76\x34\x2c\x20\x2b\x33");
if(v12 != 0){
goto L13;
}
else {
goto L12;
}
L12:
goto L46;
L13:
LOGD("52:const-string \x76\x34\x2c\x20\x27\x6f\x27");
if (v11) {
LOGD("env->DeleteLocalRef(%p):v11", v11);
env->DeleteLocalRef(v11);
}
v11 = (jstring) env->NewStringUTF("\x6f");
L14:
LOGD("56:invoke-virtual \x76\x33\x2c\x20\x76\x34\x2c\x20\x4c\x6f\x72\x67\x2f\x6a\x73\x6f\x6e\x2f\x4a\x53\x4f\x4e\x4f\x62\x6a\x65\x63\x74\x3b\x2d\x3e\x6f\x70\x74\x4a\x53\x4f\x4e\x41\x72\x72\x61\x79\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6f\x72\x67\x2f\x6a\x73\x6f\x6e\x2f\x4a\x53\x4f\x4e\x41\x72\x72\x61\x79\x3b");
{
#define EX_HANDLE EX_LandingPad_4
D2C_NOT_NULL(v10);
jclass &clz = cls2;
jmethodID &mid = mth5;
D2C_RESOLVE_METHOD(clz, mid, "org/json/JSONObject", "optJSONArray", "(Ljava/lang/String;)Lorg/json/JSONArray;");
jvalue args[] = {{.l = v11}};
v9 = (jobject) env->CallObjectMethodA(v10, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L15:
LOGD("5c:move-result-object \x76\x34");
if (v11) {
LOGD("env->DeleteLocalRef(%p):v11", v11);
env->DeleteLocalRef(v11);
}
v11 = (jobject) v9;
L16:
LOGD("5e:const-string \x76\x35\x2c\x20\x27\x6e\x27");
if (v13) {
LOGD("env->DeleteLocalRef(%p):v13", v13);
env->DeleteLocalRef(v13);
}
v13 = (jstring) env->NewStringUTF("\x6e");
L17:
LOGD("62:invoke-virtual \x76\x33\x2c\x20\x76\x35\x2c\x20\x4c\x6f\x72\x67\x2f\x6a\x73\x6f\x6e\x2f\x4a\x53\x4f\x4e\x4f\x62\x6a\x65\x63\x74\x3b\x2d\x3e\x6f\x70\x74\x4a\x53\x4f\x4e\x41\x72\x72\x61\x79\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6f\x72\x67\x2f\x6a\x73\x6f\x6e\x2f\x4a\x53\x4f\x4e\x41\x72\x72\x61\x79\x3b");
{
#define EX_HANDLE EX_LandingPad_4
D2C_NOT_NULL(v10);
jclass &clz = cls2;
jmethodID &mid = mth5;
D2C_RESOLVE_METHOD(clz, mid, "org/json/JSONObject", "optJSONArray", "(Ljava/lang/String;)Lorg/json/JSONArray;");
jvalue args[] = {{.l = v13}};
v9 = (jobject) env->CallObjectMethodA(v10, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L18:
LOGD("68:move-result-object \x76\x33");
if (v10) {
LOGD("env->DeleteLocalRef(%p):v10", v10);
env->DeleteLocalRef(v10);
}
v10 = (jobject) v9;
LOGD("6a:if-eqz \x76\x34\x2c\x20\x2b\x34\x31");
if(v11 == NULL){
goto L46;
}
else {
goto L19;
}
L19:
LOGD("6e:invoke-virtual \x76\x34\x2c\x20\x4c\x6f\x72\x67\x2f\x6a\x73\x6f\x6e\x2f\x4a\x53\x4f\x4e\x41\x72\x72\x61\x79\x3b\x2d\x3e\x6c\x65\x6e\x67\x74\x68\x28\x29\x49");
{
#define EX_HANDLE EX_LandingPad_4
D2C_NOT_NULL(v11);
jclass &clz = cls3;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "org/json/JSONArray", "length", "()I");
jvalue args[] = {};
v4 = (jint) env->CallIntMethodA(v11, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L20:
LOGD("74:move-result \x76\x35");
v14 = (jint) v4;
LOGD("76:if-eqz \x76\x35\x2c\x20\x2b\x33\x62");
if(v14 == 0){
goto L46;
}
else {
goto L21;
}
L21:
LOGD("7a:if-eqz \x76\x33\x2c\x20\x2b\x33\x39");
if(v10 == NULL){
goto L46;
}
else {
goto L22;
}
L22:
LOGD("7e:invoke-virtual \x76\x33\x2c\x20\x4c\x6f\x72\x67\x2f\x6a\x73\x6f\x6e\x2f\x4a\x53\x4f\x4e\x41\x72\x72\x61\x79\x3b\x2d\x3e\x6c\x65\x6e\x67\x74\x68\x28\x29\x49");
{
#define EX_HANDLE EX_LandingPad_4
D2C_NOT_NULL(v10);
jclass &clz = cls3;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "org/json/JSONArray", "length", "()I");
jvalue args[] = {};
v4 = (jint) env->CallIntMethodA(v10, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L23:
LOGD("84:move-result \x76\x35");
v14 = (jint) v4;
LOGD("86:if-nez \x76\x35\x2c\x20\x2b\x33");
if(v14 != 0){
goto L25;
}
else {
goto L24;
}
L24:
goto L46;
L25:
if (v13) {
LOGD("env->DeleteLocalRef(%p):v13", v13);
env->DeleteLocalRef(v13);
}
v13 = (jobject) env->NewLocalRef(v7);
v15 = 0;
L26:
LOGD("90:invoke-virtual \x76\x34\x2c\x20\x4c\x6f\x72\x67\x2f\x6a\x73\x6f\x6e\x2f\x4a\x53\x4f\x4e\x41\x72\x72\x61\x79\x3b\x2d\x3e\x6c\x65\x6e\x67\x74\x68\x28\x29\x49");
{
#define EX_HANDLE EX_LandingPad_26
D2C_NOT_NULL(v11);
jclass &clz = cls3;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "org/json/JSONArray", "length", "()I");
jvalue args[] = {};
v4 = (jint) env->CallIntMethodA(v11, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L27:
LOGD("96:move-result \x76\x36");
v16 = (jint) v4;
LOGD("98:if-ge \x76\x32\x2c\x20\x76\x36\x2c\x20\x2b\x32\x30");
if(v15 >= v16) {
goto L42;
}
else {
goto L28;
}
L28:
LOGD("9c:invoke-virtual \x76\x34\x2c\x20\x76\x32\x2c\x20\x4c\x6f\x72\x67\x2f\x6a\x73\x6f\x6e\x2f\x4a\x53\x4f\x4e\x41\x72\x72\x61\x79\x3b\x2d\x3e\x6f\x70\x74\x53\x74\x72\x69\x6e\x67\x28\x49\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_LandingPad_28
D2C_NOT_NULL(v11);
jclass &clz = cls3;
jmethodID &mid = mth7;
D2C_RESOLVE_METHOD(clz, mid, "org/json/JSONArray", "optString", "(I)Ljava/lang/String;");
jvalue args[] = {{.i = v15}};
v9 = (jstring) env->CallObjectMethodA(v11, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L29:
LOGD("a2:move-result-object \x76\x36");
if (v17) {
LOGD("env->DeleteLocalRef(%p):v17", v17);
env->DeleteLocalRef(v17);
}
v17 = (jobject) v9;
L30:
LOGD("a4:invoke-virtual \x76\x33\x2c\x20\x76\x32\x2c\x20\x4c\x6f\x72\x67\x2f\x6a\x73\x6f\x6e\x2f\x4a\x53\x4f\x4e\x41\x72\x72\x61\x79\x3b\x2d\x3e\x6f\x70\x74\x53\x74\x72\x69\x6e\x67\x28\x49\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_LandingPad_28
D2C_NOT_NULL(v10);
jclass &clz = cls3;
jmethodID &mid = mth7;
D2C_RESOLVE_METHOD(clz, mid, "org/json/JSONArray", "optString", "(I)Ljava/lang/String;");
jvalue args[] = {{.i = v15}};
v9 = (jstring) env->CallObjectMethodA(v10, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L31:
LOGD("aa:move-result-object \x76\x37");
if (v18) {
LOGD("env->DeleteLocalRef(%p):v18", v18);
env->DeleteLocalRef(v18);
}
v18 = (jobject) v9;
L32:
LOGD("ac:new-instance \x76\x38\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_LandingPad_28
if (v19) {
LOGD("env->DeleteLocalRef(%p):v19", v19);
env->DeleteLocalRef(v19);
}
jclass &clz = cls1;
D2C_RESOLVE_CLASS(clz,"java/lang/String");
v19 = (jstring) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L33:
v20 = 1;
L34:
LOGD("b2:invoke-static \x76\x36\x2c\x20\x76\x39\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x75\x74\x69\x6c\x2f\x42\x61\x73\x65\x36\x34\x3b\x2d\x3e\x64\x65\x63\x6f\x64\x65\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x20\x49\x29\x5b\x42");
{
#define EX_HANDLE EX_LandingPad_28
jclass &clz = cls4;
jmethodID &mid = mth8;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "android/util/Base64", "decode", "(Ljava/lang/String;I)[B");
jvalue args[] = {{.l = v17},{.i = v20}};
v9 = (jarray) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L35:
LOGD("b8:move-result-object \x76\x36");
if (v17) {
LOGD("env->DeleteLocalRef(%p):v17", v17);
env->DeleteLocalRef(v17);
}
v17 = (jobject) v9;
L36:
LOGD("ba:invoke-direct \x76\x38\x2c\x20\x76\x36\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x5b\x42\x29\x56");
{
#define EX_HANDLE EX_LandingPad_28
D2C_NOT_NULL(v19);
jclass &clz = cls1;
jmethodID &mid = mth1;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "<init>", "([B)V");
jvalue args[] = {{.l = v17}};
env->CallVoidMethodA(v19, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L37:
LOGD("c0:invoke-virtual \x76\x35\x2c\x20\x76\x38\x2c\x20\x76\x37\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x72\x65\x70\x6c\x61\x63\x65\x41\x6c\x6c\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_LandingPad_28
D2C_NOT_NULL(v13);
jclass &clz = cls1;
jmethodID &mid = mth9;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "replaceAll", "(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;");
jvalue args[] = {{.l = v19},{.l = v18}};
v9 = (jstring) env->CallObjectMethodA(v13, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L38:
LOGD("c6:move-result-object \x76\x35");
if (v13) {
LOGD("env->DeleteLocalRef(%p):v13", v13);
env->DeleteLocalRef(v13);
}
v13 = (jobject) v9;
goto L41;
L39:
LOGD("ca:move-exception \x76\x36");
if (v17) {
LOGD("env->DeleteLocalRef(%p):v17", v17);
env->DeleteLocalRef(v17);
}
v17 = exception;
L40:
LOGD("cc:invoke-virtual \x76\x36\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x54\x68\x72\x6f\x77\x61\x62\x6c\x65\x3b\x2d\x3e\x70\x72\x69\x6e\x74\x53\x74\x61\x63\x6b\x54\x72\x61\x63\x65\x28\x29\x56");
{
#define EX_HANDLE EX_LandingPad_40
D2C_NOT_NULL(v17);
jclass &clz = cls5;
jmethodID &mid = mth10;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/Throwable", "printStackTrace", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v17, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L41:
LOGD("d2:add-int/lit8 \x76\x32\x2c\x20\x76\x32\x2c\x20\x31");
v15 = (v15 + 1);
goto L26;
L42:
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
v7 = (jobject) env->NewLocalRef(v13);
goto L46;
L43:
LOGD("dc:move-exception \x76\x32");
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
v7 = exception;
if (v10) {
LOGD("env->DeleteLocalRef(%p):v10", v10);
env->DeleteLocalRef(v10);
}
v10 = (jobject) env->NewLocalRef(v7);
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
v7 = (jobject) env->NewLocalRef(v13);
goto L45;
L44:
LOGD("e4:move-exception \x76\x33");
if (v10) {
LOGD("env->DeleteLocalRef(%p):v10", v10);
env->DeleteLocalRef(v10);
}
v10 = exception;
L45:
LOGD("e6:invoke-virtual \x76\x33\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x54\x68\x72\x6f\x77\x61\x62\x6c\x65\x3b\x2d\x3e\x70\x72\x69\x6e\x74\x53\x74\x61\x63\x6b\x54\x72\x61\x63\x65\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v10);
jclass &clz = cls5;
jmethodID &mid = mth10;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/Throwable", "printStackTrace", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v10, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L46:
LOGD("ec:add-int/lit8 \x76\x30\x2c\x20\x76\x30\x2c\x20\x31");
v5 = (v5 + 1);
goto L3;
L47:
LOGD("f2:invoke-virtual \x76\x32\x2c\x20\x76\x31\x32\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x67\x65\x74\x42\x79\x74\x65\x73\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x5b\x42");
{
#define EX_HANDLE EX_LandingPad_47
D2C_NOT_NULL(v7);
jclass &clz = cls1;
jmethodID &mid = mth11;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "getBytes", "(Ljava/lang/String;)[B");
jvalue args[] = {{.l = v2}};
v9 = (jarray) env->CallObjectMethodA(v7, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L48:
LOGD("f8:move-result-object \x76\x31\x30");
if (v0) {
LOGD("env->DeleteLocalRef(%p):v0", v0);
env->DeleteLocalRef(v0);
}
v0 = (jobject) v9;
return (jarray) v0;
L49:
LOGD("fc:move-exception \x76\x31\x30");
if (v0) {
LOGD("env->DeleteLocalRef(%p):v0", v0);
env->DeleteLocalRef(v0);
}
v0 = exception;
LOGD("fe:invoke-virtual \x76\x31\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x69\x6f\x2f\x55\x6e\x73\x75\x70\x70\x6f\x72\x74\x65\x64\x45\x6e\x63\x6f\x64\x69\x6e\x67\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3b\x2d\x3e\x70\x72\x69\x6e\x74\x53\x74\x61\x63\x6b\x54\x72\x61\x63\x65\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls6;
jmethodID &mid = mth12;
D2C_RESOLVE_METHOD(clz, mid, "java/io/UnsupportedEncodingException", "printStackTrace", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L50:
return (jarray) v1;

EX_LandingPad_4:
D2C_GET_PENDING_EX
if(d2c_is_instance_of(env, exception, "java/lang/Throwable")) {
goto L44;
}
D2C_GOTO_UNWINDBLOCK

EX_LandingPad_47:
D2C_GET_PENDING_EX
if(d2c_is_instance_of(env, exception, "java/io/UnsupportedEncodingException")) {
goto L49;
}
D2C_GOTO_UNWINDBLOCK

EX_LandingPad_26:
D2C_GET_PENDING_EX
if(d2c_is_instance_of(env, exception, "java/lang/Throwable")) {
goto L43;
}
D2C_GOTO_UNWINDBLOCK

EX_LandingPad_28:
D2C_GET_PENDING_EX
if(d2c_is_instance_of(env, exception, "java/lang/Throwable")) {
goto L39;
}
D2C_GOTO_UNWINDBLOCK

EX_LandingPad_40:
D2C_GET_PENDING_EX
if(d2c_is_instance_of(env, exception, "java/lang/Throwable")) {
goto L43;
}
D2C_GOTO_UNWINDBLOCK
EX_UnwindBlock: return (jarray)0;
}
