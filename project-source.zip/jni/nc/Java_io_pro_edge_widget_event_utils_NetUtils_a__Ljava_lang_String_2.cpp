#include "Dex2C.h"

/* Lio/pro/edge/widget/event/utils/NetUtils;->a(Ljava/lang/String;)Ljava/util/List; */
extern "C" JNIEXPORT jobject JNICALL
Java_io_pro_edge_widget_event_utils_NetUtils_a__Ljava_lang_String_2(JNIEnv *env, jobject thiz, jstring p7){
jobject v0 = NULL;
jobject v1 = NULL;
jobject v2 = NULL;
jint v3;
jint v4;
jint v5;
jobject v6 = NULL;
jobject v7 = NULL;
jobject v8 = NULL;
jobject v9 = NULL;
jobject v10 = NULL;
jint v11;
jobject v12 = NULL;
jthrowable exception;
jclass cls0 = NULL,cls1 = NULL,cls2 = NULL,cls3 = NULL,cls4 = NULL,cls5 = NULL,cls6 = NULL,cls7 = NULL;
jmethodID mth0 = NULL, mth1 = NULL, mth2 = NULL, mth3 = NULL, mth4 = NULL, mth5 = NULL, mth6 = NULL, mth7 = NULL, mth8 = NULL, mth9 = NULL;
v0 = (jobject)env->NewLocalRef(p7);
L0:
LOGD("0:new-instance \x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x41\x72\x72\x61\x79\x4c\x69\x73\x74\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v1) {
LOGD("env->DeleteLocalRef(%p):v1", v1);
env->DeleteLocalRef(v1);
}
jclass &clz = cls0;
D2C_RESOLVE_CLASS(clz,"java/util/ArrayList");
v1 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("4:invoke-direct \x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x41\x72\x72\x61\x79\x4c\x69\x73\x74\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v1);
jclass &clz = cls0;
jmethodID &mid = mth0;
D2C_RESOLVE_METHOD(clz, mid, "java/util/ArrayList", "<init>", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v1, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L1:
LOGD("a:new-instance \x76\x31\x2c\x20\x4c\x6f\x72\x67\x2f\x6a\x73\x6f\x6e\x2f\x4a\x53\x4f\x4e\x41\x72\x72\x61\x79\x3b");
{
#define EX_HANDLE EX_LandingPad_1
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
jclass &clz = cls1;
D2C_RESOLVE_CLASS(clz,"org/json/JSONArray");
v2 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L2:
LOGD("e:invoke-direct \x76\x31\x2c\x20\x76\x37\x2c\x20\x4c\x6f\x72\x67\x2f\x6a\x73\x6f\x6e\x2f\x4a\x53\x4f\x4e\x41\x72\x72\x61\x79\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x56");
{
#define EX_HANDLE EX_LandingPad_1
D2C_NOT_NULL(v2);
jclass &clz = cls1;
jmethodID &mid = mth1;
D2C_RESOLVE_METHOD(clz, mid, "org/json/JSONArray", "<init>", "(Ljava/lang/String;)V");
jvalue args[] = {{.l = v0}};
env->CallVoidMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L3:
v3 = 0;
L4:
LOGD("16:invoke-virtual \x76\x31\x2c\x20\x4c\x6f\x72\x67\x2f\x6a\x73\x6f\x6e\x2f\x4a\x53\x4f\x4e\x41\x72\x72\x61\x79\x3b\x2d\x3e\x6c\x65\x6e\x67\x74\x68\x28\x29\x49");
{
#define EX_HANDLE EX_LandingPad_1
D2C_NOT_NULL(v2);
jclass &clz = cls1;
jmethodID &mid = mth2;
D2C_RESOLVE_METHOD(clz, mid, "org/json/JSONArray", "length", "()I");
jvalue args[] = {};
v4 = (jint) env->CallIntMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L5:
LOGD("1c:move-result \x76\x32");
v5 = (jint) v4;
LOGD("1e:if-ge \x76\x37\x2c\x20\x76\x32\x2c\x20\x2b\x33\x36");
if(v3 >= v5) {
goto L28;
}
else {
goto L6;
}
L6:
LOGD("22:invoke-virtual \x76\x31\x2c\x20\x76\x37\x2c\x20\x4c\x6f\x72\x67\x2f\x6a\x73\x6f\x6e\x2f\x4a\x53\x4f\x4e\x41\x72\x72\x61\x79\x3b\x2d\x3e\x67\x65\x74\x4a\x53\x4f\x4e\x4f\x62\x6a\x65\x63\x74\x28\x49\x29\x4c\x6f\x72\x67\x2f\x6a\x73\x6f\x6e\x2f\x4a\x53\x4f\x4e\x4f\x62\x6a\x65\x63\x74\x3b");
{
#define EX_HANDLE EX_LandingPad_1
D2C_NOT_NULL(v2);
jclass &clz = cls1;
jmethodID &mid = mth3;
D2C_RESOLVE_METHOD(clz, mid, "org/json/JSONArray", "getJSONObject", "(I)Lorg/json/JSONObject;");
jvalue args[] = {{.i = v3}};
v6 = (jobject) env->CallObjectMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L7:
LOGD("28:move-result-object \x76\x32");
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
v7 = (jobject) v6;
L8:
LOGD("2a:const-string \x76\x33\x2c\x20\x27\x6e\x61\x6d\x65\x27");
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jstring) env->NewStringUTF("\x6e\x61\x6d\x65");
L9:
LOGD("2e:const-string \x76\x34\x2c\x20\x27\x76\x61\x6c\x75\x65\x27");
if (v9) {
LOGD("env->DeleteLocalRef(%p):v9", v9);
env->DeleteLocalRef(v9);
}
v9 = (jstring) env->NewStringUTF("\x76\x61\x6c\x75\x65");
L10:
LOGD("32:const-string \x76\x35\x2c\x20\x27\x74\x79\x70\x65\x27");
if (v10) {
LOGD("env->DeleteLocalRef(%p):v10", v10);
env->DeleteLocalRef(v10);
}
v10 = (jstring) env->NewStringUTF("\x74\x79\x70\x65");
L11:
LOGD("36:invoke-virtual \x76\x32\x2c\x20\x76\x35\x2c\x20\x4c\x6f\x72\x67\x2f\x6a\x73\x6f\x6e\x2f\x4a\x53\x4f\x4e\x4f\x62\x6a\x65\x63\x74\x3b\x2d\x3e\x67\x65\x74\x53\x74\x72\x69\x6e\x67\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_LandingPad_1
D2C_NOT_NULL(v7);
jclass &clz = cls2;
jmethodID &mid = mth4;
D2C_RESOLVE_METHOD(clz, mid, "org/json/JSONObject", "getString", "(Ljava/lang/String;)Ljava/lang/String;");
jvalue args[] = {{.l = v10}};
v6 = (jstring) env->CallObjectMethodA(v7, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L12:
LOGD("3c:move-result-object \x76\x35");
if (v10) {
LOGD("env->DeleteLocalRef(%p):v10", v10);
env->DeleteLocalRef(v10);
}
v10 = (jobject) v6;
L13:
LOGD("3e:invoke-static \x76\x35\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x74\x65\x78\x74\x2f\x54\x65\x78\x74\x55\x74\x69\x6c\x73\x3b\x2d\x3e\x69\x73\x45\x6d\x70\x74\x79\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x68\x61\x72\x53\x65\x71\x75\x65\x6e\x63\x65\x3b\x29\x5a");
{
#define EX_HANDLE EX_LandingPad_1
jclass &clz = cls3;
jmethodID &mid = mth5;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "android/text/TextUtils", "isEmpty", "(Ljava/lang/CharSequence;)Z");
jvalue args[] = {{.l = v10}};
v4 = (jboolean) env->CallStaticBooleanMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L14:
LOGD("44:move-result \x76\x36");
v11 = (jint) v4;
LOGD("46:if-nez \x76\x36\x2c\x20\x2b\x62");
if(v11 != 0){
goto L19;
}
else {
goto L15;
}
L15:
LOGD("4a:const-string \x76\x36\x2c\x20\x27\x62\x75\x74\x74\x6f\x6e\x27");
if (v12) {
LOGD("env->DeleteLocalRef(%p):v12", v12);
env->DeleteLocalRef(v12);
}
v12 = (jstring) env->NewStringUTF("\x62\x75\x74\x74\x6f\x6e");
L16:
LOGD("4e:invoke-virtual \x76\x36\x2c\x20\x76\x35\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x65\x71\x75\x61\x6c\x73\x49\x67\x6e\x6f\x72\x65\x43\x61\x73\x65\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x5a");
{
#define EX_HANDLE EX_LandingPad_1
D2C_NOT_NULL(v12);
jclass &clz = cls4;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "equalsIgnoreCase", "(Ljava/lang/String;)Z");
jvalue args[] = {{.l = v10}};
v4 = (jboolean) env->CallBooleanMethodA(v12, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L17:
LOGD("54:move-result \x76\x36");
v11 = (jint) v4;
LOGD("56:if-eqz \x76\x36\x2c\x20\x2b\x33");
if(v11 == 0){
goto L19;
}
else {
goto L18;
}
L18:
goto L26;
L19:
LOGD("5c:new-instance \x76\x36\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x75\x74\x69\x6c\x73\x2f\x4e\x65\x74\x55\x74\x69\x6c\x73\x24\x46\x6f\x72\x6d\x54\x79\x70\x65\x44\x61\x74\x61\x3b");
{
#define EX_HANDLE EX_LandingPad_1
if (v12) {
LOGD("env->DeleteLocalRef(%p):v12", v12);
env->DeleteLocalRef(v12);
}
jclass &clz = cls5;
D2C_RESOLVE_CLASS(clz,"io/pro/edge/widget/event/utils/NetUtils$FormTypeData");
v12 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L20:
LOGD("60:invoke-virtual \x76\x32\x2c\x20\x76\x33\x2c\x20\x4c\x6f\x72\x67\x2f\x6a\x73\x6f\x6e\x2f\x4a\x53\x4f\x4e\x4f\x62\x6a\x65\x63\x74\x3b\x2d\x3e\x67\x65\x74\x53\x74\x72\x69\x6e\x67\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_LandingPad_1
D2C_NOT_NULL(v7);
jclass &clz = cls2;
jmethodID &mid = mth4;
D2C_RESOLVE_METHOD(clz, mid, "org/json/JSONObject", "getString", "(Ljava/lang/String;)Ljava/lang/String;");
jvalue args[] = {{.l = v8}};
v6 = (jstring) env->CallObjectMethodA(v7, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L21:
LOGD("66:move-result-object \x76\x33");
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jobject) v6;
L22:
LOGD("68:invoke-virtual \x76\x32\x2c\x20\x76\x34\x2c\x20\x4c\x6f\x72\x67\x2f\x6a\x73\x6f\x6e\x2f\x4a\x53\x4f\x4e\x4f\x62\x6a\x65\x63\x74\x3b\x2d\x3e\x67\x65\x74\x53\x74\x72\x69\x6e\x67\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_LandingPad_1
D2C_NOT_NULL(v7);
jclass &clz = cls2;
jmethodID &mid = mth4;
D2C_RESOLVE_METHOD(clz, mid, "org/json/JSONObject", "getString", "(Ljava/lang/String;)Ljava/lang/String;");
jvalue args[] = {{.l = v9}};
v6 = (jstring) env->CallObjectMethodA(v7, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L23:
LOGD("6e:move-result-object \x76\x32");
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
v7 = (jobject) v6;
L24:
LOGD("70:invoke-direct \x76\x36\x2c\x20\x76\x33\x2c\x20\x76\x32\x2c\x20\x76\x35\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x75\x74\x69\x6c\x73\x2f\x4e\x65\x74\x55\x74\x69\x6c\x73\x24\x46\x6f\x72\x6d\x54\x79\x70\x65\x44\x61\x74\x61\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x56");
{
#define EX_HANDLE EX_LandingPad_1
D2C_NOT_NULL(v12);
jclass &clz = cls5;
jmethodID &mid = mth7;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/event/utils/NetUtils$FormTypeData", "<init>", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V");
jvalue args[] = {{.l = v8},{.l = v7},{.l = v10}};
env->CallVoidMethodA(v12, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L25:
LOGD("76:invoke-interface \x76\x30\x2c\x20\x76\x36\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x4c\x69\x73\x74\x3b\x2d\x3e\x61\x64\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b\x29\x5a");
{
#define EX_HANDLE EX_LandingPad_1
D2C_NOT_NULL(v1);
jclass &clz = cls6;
jmethodID &mid = mth8;
D2C_RESOLVE_METHOD(clz, mid, "java/util/List", "add", "(Ljava/lang/Object;)Z");
jvalue args[] = {{.l = v12}};
v4 = (jboolean) env->CallBooleanMethodA(v1, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L26:
LOGD("7c:add-int/lit8 \x76\x37\x2c\x20\x76\x37\x2c\x20\x31");
v3 = (v3 + 1);
goto L4;
L27:
LOGD("82:move-exception \x76\x37");
if (v0) {
LOGD("env->DeleteLocalRef(%p):v0", v0);
env->DeleteLocalRef(v0);
}
v0 = exception;
LOGD("84:invoke-virtual \x76\x37\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x54\x68\x72\x6f\x77\x61\x62\x6c\x65\x3b\x2d\x3e\x70\x72\x69\x6e\x74\x53\x74\x61\x63\x6b\x54\x72\x61\x63\x65\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls7;
jmethodID &mid = mth9;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/Throwable", "printStackTrace", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L28:
return (jobject) v1;

EX_LandingPad_1:
D2C_GET_PENDING_EX
if(d2c_is_instance_of(env, exception, "java/lang/Throwable")) {
goto L27;
}
D2C_GOTO_UNWINDBLOCK
EX_UnwindBlock: return NULL;
}
