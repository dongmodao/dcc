#include "Dex2C.h"

/* Lio/pro/edge/widget/event/net/OkHttpProvider$2;->getAcceptedIssuers()[Ljava/security/cert/X509Certificate; */
extern "C" JNIEXPORT jarray JNICALL
Java_io_pro_edge_widget_event_net_OkHttpProvider_000242_getAcceptedIssuers__(JNIEnv *env, jobject thiz){
jobject v0 = NULL;
jint v1;
jobject v2 = NULL;
jclass cls0 = NULL;
v0 = (jobject)env->NewLocalRef(thiz);
L0:
v1 = 0;
LOGD("2:new-array \x76\x30\x2c\x20\x76\x30\x2c\x20\x5b\x4c\x6a\x61\x76\x61\x2f\x73\x65\x63\x75\x72\x69\x74\x79\x2f\x63\x65\x72\x74\x2f\x58\x35\x30\x39\x43\x65\x72\x74\x69\x66\x69\x63\x61\x74\x65\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v1 < 0) {
d2c_throw_exception(env, "java/lang/NegativeArraySizeException", "negative array size");
goto EX_HANDLE;
}
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
jclass &clz = cls0;
D2C_RESOLVE_CLASS(clz,"java/security/cert/X509Certificate");
v2 = env->NewObjectArray((jint) v1, clz, NULL);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
return (jarray) v2;
EX_UnwindBlock: return (jarray)0;
}
