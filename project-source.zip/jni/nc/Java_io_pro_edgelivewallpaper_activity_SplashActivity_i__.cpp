#include "Dex2C.h"

/* Lio/pro/edgelivewallpaper/activity/SplashActivity;->i()I */
extern "C" JNIEXPORT jint JNICALL
Java_io_pro_edgelivewallpaper_activity_SplashActivity_i__(JNIEnv *env, jobject thiz){
jobject v0 = NULL;
jint v1;
v0 = (jobject)env->NewLocalRef(thiz);
L0:
v1 = 2131361824;
return (jint) v1;
EX_UnwindBlock: return (jint)0;
}
