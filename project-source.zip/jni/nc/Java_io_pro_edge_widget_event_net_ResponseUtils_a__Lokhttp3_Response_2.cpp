#include "Dex2C.h"

/* Lio/pro/edge/widget/event/net/ResponseUtils;->a(Lokhttp3/Response;)Lokhttp3/Response; */
extern "C" JNIEXPORT jobject JNICALL
Java_io_pro_edge_widget_event_net_ResponseUtils_a__Lokhttp3_Response_2(JNIEnv *env, jobject thiz, jobject p10){
jobject v0 = NULL;
jobject v1 = NULL;
jobject v2 = NULL;
jobject v3 = NULL;
jobject v4 = NULL;
jobject v5 = NULL;
jint v6;
jint v7;
jlong v8;
jobject v9 = NULL;
jobject v10 = NULL;
jobject v11 = NULL;
jobject v12 = NULL;
jint v13;
jthrowable exception;
jclass cls0 = NULL,cls1 = NULL,cls2 = NULL,cls3 = NULL,cls4 = NULL,cls5 = NULL,cls6 = NULL,cls7 = NULL,cls8 = NULL,cls9 = NULL,cls10 = NULL,cls11 = NULL,cls12 = NULL;
jmethodID mth0 = NULL, mth1 = NULL, mth2 = NULL, mth3 = NULL, mth4 = NULL, mth5 = NULL, mth6 = NULL, mth7 = NULL, mth8 = NULL, mth9 = NULL, mth10 = NULL, mth11 = NULL, mth12 = NULL, mth13 = NULL, mth14 = NULL, mth15 = NULL, mth16 = NULL, mth17 = NULL, mth18 = NULL;
v0 = (jobject)env->NewLocalRef(p10);
L0:
LOGD("0:const-string \x76\x30\x2c\x20\x27\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x45\x6e\x63\x6f\x64\x69\x6e\x67\x27");
if (v1) {
LOGD("env->DeleteLocalRef(%p):v1", v1);
env->DeleteLocalRef(v1);
}
v1 = (jstring) env->NewStringUTF("\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x45\x6e\x63\x6f\x64\x69\x6e\x67");
L1:
LOGD("4:invoke-virtual \x76\x31\x30\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x3b\x2d\x3e\x6e\x65\x77\x42\x75\x69\x6c\x64\x65\x72\x28\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x24\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_LandingPad_1
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jmethodID &mid = mth0;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Response", "newBuilder", "()Lokhttp3/Response$Builder;");
jvalue args[] = {};
v2 = (jobject) env->CallObjectMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L2:
LOGD("a:move-result-object \x76\x31");
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
v3 = (jobject) v2;
L3:
LOGD("c:const-string \x76\x32\x2c\x20\x27\x67\x7a\x69\x70\x27");
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
v4 = (jstring) env->NewStringUTF("\x67\x7a\x69\x70");
L4:
LOGD("10:invoke-virtual \x76\x31\x30\x2c\x20\x76\x30\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x3b\x2d\x3e\x68\x65\x61\x64\x65\x72\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_LandingPad_1
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jmethodID &mid = mth1;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Response", "header", "(Ljava/lang/String;)Ljava/lang/String;");
jvalue args[] = {{.l = v1}};
v2 = (jstring) env->CallObjectMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L5:
LOGD("16:move-result-object \x76\x33");
if (v5) {
LOGD("env->DeleteLocalRef(%p):v5", v5);
env->DeleteLocalRef(v5);
}
v5 = (jobject) v2;
L6:
LOGD("18:invoke-virtual \x76\x32\x2c\x20\x76\x33\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x65\x71\x75\x61\x6c\x73\x49\x67\x6e\x6f\x72\x65\x43\x61\x73\x65\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x5a");
{
#define EX_HANDLE EX_LandingPad_1
D2C_NOT_NULL(v4);
jclass &clz = cls1;
jmethodID &mid = mth2;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "equalsIgnoreCase", "(Ljava/lang/String;)Z");
jvalue args[] = {{.l = v5}};
v6 = (jboolean) env->CallBooleanMethodA(v4, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L7:
LOGD("1e:move-result \x76\x32");
v7 = (jint) v6;
v8 = -1;
v8 = -1;
LOGD("24:const-string \x76\x35\x2c\x20\x27\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65\x27");
if (v9) {
LOGD("env->DeleteLocalRef(%p):v9", v9);
env->DeleteLocalRef(v9);
}
v9 = (jstring) env->NewStringUTF("\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65");
LOGD("28:const-string \x76\x36\x2c\x20\x27\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x4c\x65\x6e\x67\x74\x68\x27");
if (v10) {
LOGD("env->DeleteLocalRef(%p):v10", v10);
env->DeleteLocalRef(v10);
}
v10 = (jstring) env->NewStringUTF("\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x4c\x65\x6e\x67\x74\x68");
LOGD("2c:if-eqz \x76\x32\x2c\x20\x2b\x33\x64");
if(v7 == 0){
goto L35;
}
else {
goto L8;
}
L8:
LOGD("30:invoke-static \x76\x31\x30\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x69\x6e\x74\x65\x72\x6e\x61\x6c\x2f\x68\x74\x74\x70\x2f\x48\x74\x74\x70\x48\x65\x61\x64\x65\x72\x73\x3b\x2d\x3e\x68\x61\x73\x42\x6f\x64\x79\x28\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x3b\x29\x5a");
{
#define EX_HANDLE EX_LandingPad_8
jclass &clz = cls2;
jmethodID &mid = mth3;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "okhttp3/internal/http/HttpHeaders", "hasBody", "(Lokhttp3/Response;)Z");
jvalue args[] = {{.l = v0}};
v6 = (jboolean) env->CallStaticBooleanMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L9:
LOGD("36:move-result \x76\x32");
v7 = (jint) v6;
LOGD("38:if-eqz \x76\x32\x2c\x20\x2b\x33\x37");
if(v7 == 0){
goto L35;
}
else {
goto L10;
}
L10:
LOGD("3c:new-instance \x76\x32\x2c\x20\x4c\x6f\x6b\x69\x6f\x2f\x47\x7a\x69\x70\x53\x6f\x75\x72\x63\x65\x3b");
{
#define EX_HANDLE EX_LandingPad_8
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
jclass &clz = cls3;
D2C_RESOLVE_CLASS(clz,"okio/GzipSource");
v4 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L11:
LOGD("40:invoke-virtual \x76\x31\x30\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x3b\x2d\x3e\x62\x6f\x64\x79\x28\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x42\x6f\x64\x79\x3b");
{
#define EX_HANDLE EX_LandingPad_8
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jmethodID &mid = mth4;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Response", "body", "()Lokhttp3/ResponseBody;");
jvalue args[] = {};
v2 = (jobject) env->CallObjectMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L12:
LOGD("46:move-result-object \x76\x37");
if (v11) {
LOGD("env->DeleteLocalRef(%p):v11", v11);
env->DeleteLocalRef(v11);
}
v11 = (jobject) v2;
L13:
LOGD("48:invoke-virtual \x76\x37\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x42\x6f\x64\x79\x3b\x2d\x3e\x73\x6f\x75\x72\x63\x65\x28\x29\x4c\x6f\x6b\x69\x6f\x2f\x42\x75\x66\x66\x65\x72\x65\x64\x53\x6f\x75\x72\x63\x65\x3b");
{
#define EX_HANDLE EX_LandingPad_8
D2C_NOT_NULL(v11);
jclass &clz = cls4;
jmethodID &mid = mth5;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/ResponseBody", "source", "()Lokio/BufferedSource;");
jvalue args[] = {};
v2 = (jobject) env->CallObjectMethodA(v11, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L14:
LOGD("4e:move-result-object \x76\x37");
if (v11) {
LOGD("env->DeleteLocalRef(%p):v11", v11);
env->DeleteLocalRef(v11);
}
v11 = (jobject) v2;
L15:
LOGD("50:invoke-direct \x76\x32\x2c\x20\x76\x37\x2c\x20\x4c\x6f\x6b\x69\x6f\x2f\x47\x7a\x69\x70\x53\x6f\x75\x72\x63\x65\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x4c\x6f\x6b\x69\x6f\x2f\x53\x6f\x75\x72\x63\x65\x3b\x29\x56");
{
#define EX_HANDLE EX_LandingPad_8
D2C_NOT_NULL(v4);
jclass &clz = cls3;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "okio/GzipSource", "<init>", "(Lokio/Source;)V");
jvalue args[] = {{.l = v11}};
env->CallVoidMethodA(v4, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L16:
LOGD("56:invoke-virtual \x76\x31\x30\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x3b\x2d\x3e\x68\x65\x61\x64\x65\x72\x73\x28\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x48\x65\x61\x64\x65\x72\x73\x3b");
{
#define EX_HANDLE EX_LandingPad_8
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jmethodID &mid = mth7;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Response", "headers", "()Lokhttp3/Headers;");
jvalue args[] = {};
v2 = (jobject) env->CallObjectMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L17:
LOGD("5c:move-result-object \x76\x37");
if (v11) {
LOGD("env->DeleteLocalRef(%p):v11", v11);
env->DeleteLocalRef(v11);
}
v11 = (jobject) v2;
L18:
LOGD("5e:invoke-virtual \x76\x37\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x48\x65\x61\x64\x65\x72\x73\x3b\x2d\x3e\x6e\x65\x77\x42\x75\x69\x6c\x64\x65\x72\x28\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x48\x65\x61\x64\x65\x72\x73\x24\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_LandingPad_8
D2C_NOT_NULL(v11);
jclass &clz = cls5;
jmethodID &mid = mth8;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Headers", "newBuilder", "()Lokhttp3/Headers$Builder;");
jvalue args[] = {};
v2 = (jobject) env->CallObjectMethodA(v11, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L19:
LOGD("64:move-result-object \x76\x37");
if (v11) {
LOGD("env->DeleteLocalRef(%p):v11", v11);
env->DeleteLocalRef(v11);
}
v11 = (jobject) v2;
L20:
LOGD("66:invoke-virtual \x76\x37\x2c\x20\x76\x30\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x48\x65\x61\x64\x65\x72\x73\x24\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x72\x65\x6d\x6f\x76\x65\x41\x6c\x6c\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x48\x65\x61\x64\x65\x72\x73\x24\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_LandingPad_8
D2C_NOT_NULL(v11);
jclass &clz = cls6;
jmethodID &mid = mth9;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Headers$Builder", "removeAll", "(Ljava/lang/String;)Lokhttp3/Headers$Builder;");
jvalue args[] = {{.l = v1}};
v2 = (jobject) env->CallObjectMethodA(v11, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L21:
LOGD("6c:move-result-object \x76\x30");
if (v1) {
LOGD("env->DeleteLocalRef(%p):v1", v1);
env->DeleteLocalRef(v1);
}
v1 = (jobject) v2;
L22:
LOGD("6e:invoke-virtual \x76\x30\x2c\x20\x76\x36\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x48\x65\x61\x64\x65\x72\x73\x24\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x72\x65\x6d\x6f\x76\x65\x41\x6c\x6c\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x48\x65\x61\x64\x65\x72\x73\x24\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_LandingPad_8
D2C_NOT_NULL(v1);
jclass &clz = cls6;
jmethodID &mid = mth9;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Headers$Builder", "removeAll", "(Ljava/lang/String;)Lokhttp3/Headers$Builder;");
jvalue args[] = {{.l = v10}};
v2 = (jobject) env->CallObjectMethodA(v1, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L23:
LOGD("74:move-result-object \x76\x30");
if (v1) {
LOGD("env->DeleteLocalRef(%p):v1", v1);
env->DeleteLocalRef(v1);
}
v1 = (jobject) v2;
L24:
LOGD("76:invoke-virtual \x76\x30\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x48\x65\x61\x64\x65\x72\x73\x24\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x62\x75\x69\x6c\x64\x28\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x48\x65\x61\x64\x65\x72\x73\x3b");
{
#define EX_HANDLE EX_LandingPad_8
D2C_NOT_NULL(v1);
jclass &clz = cls6;
jmethodID &mid = mth10;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Headers$Builder", "build", "()Lokhttp3/Headers;");
jvalue args[] = {};
v2 = (jobject) env->CallObjectMethodA(v1, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L25:
LOGD("7c:move-result-object \x76\x30");
if (v1) {
LOGD("env->DeleteLocalRef(%p):v1", v1);
env->DeleteLocalRef(v1);
}
v1 = (jobject) v2;
L26:
LOGD("7e:invoke-virtual \x76\x31\x2c\x20\x76\x30\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x24\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x68\x65\x61\x64\x65\x72\x73\x28\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x48\x65\x61\x64\x65\x72\x73\x3b\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x24\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_LandingPad_8
D2C_NOT_NULL(v3);
jclass &clz = cls7;
jmethodID &mid = mth11;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Response$Builder", "headers", "(Lokhttp3/Headers;)Lokhttp3/Response$Builder;");
jvalue args[] = {{.l = v1}};
v2 = (jobject) env->CallObjectMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
L27:
LOGD("84:invoke-virtual \x76\x31\x30\x2c\x20\x76\x35\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x3b\x2d\x3e\x68\x65\x61\x64\x65\x72\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_LandingPad_8
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jmethodID &mid = mth1;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Response", "header", "(Ljava/lang/String;)Ljava/lang/String;");
jvalue args[] = {{.l = v9}};
v2 = (jstring) env->CallObjectMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L28:
LOGD("8a:move-result-object \x76\x30");
if (v1) {
LOGD("env->DeleteLocalRef(%p):v1", v1);
env->DeleteLocalRef(v1);
}
v1 = (jobject) v2;
L29:
LOGD("8c:new-instance \x76\x35\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x69\x6e\x74\x65\x72\x6e\x61\x6c\x2f\x68\x74\x74\x70\x2f\x52\x65\x61\x6c\x52\x65\x73\x70\x6f\x6e\x73\x65\x42\x6f\x64\x79\x3b");
{
#define EX_HANDLE EX_LandingPad_8
if (v9) {
LOGD("env->DeleteLocalRef(%p):v9", v9);
env->DeleteLocalRef(v9);
}
jclass &clz = cls8;
D2C_RESOLVE_CLASS(clz,"okhttp3/internal/http/RealResponseBody");
v9 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L30:
LOGD("90:invoke-static \x76\x32\x2c\x20\x4c\x6f\x6b\x69\x6f\x2f\x4f\x6b\x69\x6f\x3b\x2d\x3e\x62\x75\x66\x66\x65\x72\x28\x4c\x6f\x6b\x69\x6f\x2f\x53\x6f\x75\x72\x63\x65\x3b\x29\x4c\x6f\x6b\x69\x6f\x2f\x42\x75\x66\x66\x65\x72\x65\x64\x53\x6f\x75\x72\x63\x65\x3b");
{
#define EX_HANDLE EX_LandingPad_8
jclass &clz = cls9;
jmethodID &mid = mth12;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "okio/Okio", "buffer", "(Lokio/Source;)Lokio/BufferedSource;");
jvalue args[] = {{.l = v4}};
v2 = (jobject) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L31:
LOGD("96:move-result-object \x76\x32");
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
v4 = (jobject) v2;
L32:
LOGD("98:invoke-direct \x76\x35\x2c\x20\x76\x30\x2c\x20\x76\x33\x2c\x20\x76\x34\x2c\x20\x76\x32\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x69\x6e\x74\x65\x72\x6e\x61\x6c\x2f\x68\x74\x74\x70\x2f\x52\x65\x61\x6c\x52\x65\x73\x70\x6f\x6e\x73\x65\x42\x6f\x64\x79\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x20\x4a\x20\x4c\x6f\x6b\x69\x6f\x2f\x42\x75\x66\x66\x65\x72\x65\x64\x53\x6f\x75\x72\x63\x65\x3b\x29\x56");
{
#define EX_HANDLE EX_LandingPad_8
D2C_NOT_NULL(v9);
jclass &clz = cls8;
jmethodID &mid = mth13;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/internal/http/RealResponseBody", "<init>", "(Ljava/lang/String;JLokio/BufferedSource;)V");
jvalue args[] = {{.l = v1},{.j = (jlong) v8},{.l = v4}};
env->CallVoidMethodA(v9, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L33:
LOGD("9e:invoke-virtual \x76\x31\x2c\x20\x76\x35\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x24\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x62\x6f\x64\x79\x28\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x42\x6f\x64\x79\x3b\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x24\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_LandingPad_8
D2C_NOT_NULL(v3);
jclass &clz = cls7;
jmethodID &mid = mth14;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Response$Builder", "body", "(Lokhttp3/ResponseBody;)Lokhttp3/Response$Builder;");
jvalue args[] = {{.l = v9}};
v2 = (jobject) env->CallObjectMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
L34:
goto L69;
L35:
LOGD("a6:const-string \x76\x32\x2c\x20\x27\x64\x65\x66\x6c\x61\x74\x65\x27");
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
v4 = (jstring) env->NewStringUTF("\x64\x65\x66\x6c\x61\x74\x65");
L36:
LOGD("aa:invoke-virtual \x76\x31\x30\x2c\x20\x76\x30\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x3b\x2d\x3e\x68\x65\x61\x64\x65\x72\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_LandingPad_8
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jmethodID &mid = mth1;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Response", "header", "(Ljava/lang/String;)Ljava/lang/String;");
jvalue args[] = {{.l = v1}};
v2 = (jstring) env->CallObjectMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L37:
LOGD("b0:move-result-object \x76\x37");
if (v11) {
LOGD("env->DeleteLocalRef(%p):v11", v11);
env->DeleteLocalRef(v11);
}
v11 = (jobject) v2;
L38:
LOGD("b2:invoke-virtual \x76\x32\x2c\x20\x76\x37\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x65\x71\x75\x61\x6c\x73\x49\x67\x6e\x6f\x72\x65\x43\x61\x73\x65\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x5a");
{
#define EX_HANDLE EX_LandingPad_8
D2C_NOT_NULL(v4);
jclass &clz = cls1;
jmethodID &mid = mth2;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "equalsIgnoreCase", "(Ljava/lang/String;)Z");
jvalue args[] = {{.l = v11}};
v6 = (jboolean) env->CallBooleanMethodA(v4, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L39:
LOGD("b8:move-result \x76\x32");
v7 = (jint) v6;
LOGD("ba:if-eqz \x76\x32\x2c\x20\x2b\x34\x32");
if(v7 == 0){
goto L69;
}
else {
goto L40;
}
L40:
LOGD("be:invoke-static \x76\x31\x30\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x69\x6e\x74\x65\x72\x6e\x61\x6c\x2f\x68\x74\x74\x70\x2f\x48\x74\x74\x70\x48\x65\x61\x64\x65\x72\x73\x3b\x2d\x3e\x68\x61\x73\x42\x6f\x64\x79\x28\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x3b\x29\x5a");
{
#define EX_HANDLE EX_LandingPad_8
jclass &clz = cls2;
jmethodID &mid = mth3;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "okhttp3/internal/http/HttpHeaders", "hasBody", "(Lokhttp3/Response;)Z");
jvalue args[] = {{.l = v0}};
v6 = (jboolean) env->CallStaticBooleanMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L41:
LOGD("c4:move-result \x76\x32");
v7 = (jint) v6;
LOGD("c6:if-eqz \x76\x32\x2c\x20\x2b\x33\x63");
if(v7 == 0){
goto L69;
}
else {
goto L42;
}
L42:
LOGD("ca:new-instance \x76\x32\x2c\x20\x4c\x6f\x6b\x69\x6f\x2f\x49\x6e\x66\x6c\x61\x74\x65\x72\x53\x6f\x75\x72\x63\x65\x3b");
{
#define EX_HANDLE EX_LandingPad_8
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
jclass &clz = cls10;
D2C_RESOLVE_CLASS(clz,"okio/InflaterSource");
v4 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L43:
LOGD("ce:invoke-virtual \x76\x31\x30\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x3b\x2d\x3e\x62\x6f\x64\x79\x28\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x42\x6f\x64\x79\x3b");
{
#define EX_HANDLE EX_LandingPad_8
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jmethodID &mid = mth4;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Response", "body", "()Lokhttp3/ResponseBody;");
jvalue args[] = {};
v2 = (jobject) env->CallObjectMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L44:
LOGD("d4:move-result-object \x76\x37");
if (v11) {
LOGD("env->DeleteLocalRef(%p):v11", v11);
env->DeleteLocalRef(v11);
}
v11 = (jobject) v2;
L45:
LOGD("d6:invoke-virtual \x76\x37\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x42\x6f\x64\x79\x3b\x2d\x3e\x73\x6f\x75\x72\x63\x65\x28\x29\x4c\x6f\x6b\x69\x6f\x2f\x42\x75\x66\x66\x65\x72\x65\x64\x53\x6f\x75\x72\x63\x65\x3b");
{
#define EX_HANDLE EX_LandingPad_8
D2C_NOT_NULL(v11);
jclass &clz = cls4;
jmethodID &mid = mth5;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/ResponseBody", "source", "()Lokio/BufferedSource;");
jvalue args[] = {};
v2 = (jobject) env->CallObjectMethodA(v11, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L46:
LOGD("dc:move-result-object \x76\x37");
if (v11) {
LOGD("env->DeleteLocalRef(%p):v11", v11);
env->DeleteLocalRef(v11);
}
v11 = (jobject) v2;
L47:
LOGD("de:new-instance \x76\x38\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x7a\x69\x70\x2f\x49\x6e\x66\x6c\x61\x74\x65\x72\x3b");
{
#define EX_HANDLE EX_LandingPad_8
if (v12) {
LOGD("env->DeleteLocalRef(%p):v12", v12);
env->DeleteLocalRef(v12);
}
jclass &clz = cls11;
D2C_RESOLVE_CLASS(clz,"java/util/zip/Inflater");
v12 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L48:
v13 = 1;
L49:
LOGD("e4:invoke-direct \x76\x38\x2c\x20\x76\x39\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x7a\x69\x70\x2f\x49\x6e\x66\x6c\x61\x74\x65\x72\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x5a\x29\x56");
{
#define EX_HANDLE EX_LandingPad_8
D2C_NOT_NULL(v12);
jclass &clz = cls11;
jmethodID &mid = mth15;
D2C_RESOLVE_METHOD(clz, mid, "java/util/zip/Inflater", "<init>", "(Z)V");
jvalue args[] = {{.z = (jboolean) v13}};
env->CallVoidMethodA(v12, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L50:
LOGD("ea:invoke-direct \x76\x32\x2c\x20\x76\x37\x2c\x20\x76\x38\x2c\x20\x4c\x6f\x6b\x69\x6f\x2f\x49\x6e\x66\x6c\x61\x74\x65\x72\x53\x6f\x75\x72\x63\x65\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x4c\x6f\x6b\x69\x6f\x2f\x53\x6f\x75\x72\x63\x65\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x7a\x69\x70\x2f\x49\x6e\x66\x6c\x61\x74\x65\x72\x3b\x29\x56");
{
#define EX_HANDLE EX_LandingPad_8
D2C_NOT_NULL(v4);
jclass &clz = cls10;
jmethodID &mid = mth16;
D2C_RESOLVE_METHOD(clz, mid, "okio/InflaterSource", "<init>", "(Lokio/Source;Ljava/util/zip/Inflater;)V");
jvalue args[] = {{.l = v11},{.l = v12}};
env->CallVoidMethodA(v4, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L51:
LOGD("f0:invoke-virtual \x76\x31\x30\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x3b\x2d\x3e\x68\x65\x61\x64\x65\x72\x73\x28\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x48\x65\x61\x64\x65\x72\x73\x3b");
{
#define EX_HANDLE EX_LandingPad_8
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jmethodID &mid = mth7;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Response", "headers", "()Lokhttp3/Headers;");
jvalue args[] = {};
v2 = (jobject) env->CallObjectMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L52:
LOGD("f6:move-result-object \x76\x37");
if (v11) {
LOGD("env->DeleteLocalRef(%p):v11", v11);
env->DeleteLocalRef(v11);
}
v11 = (jobject) v2;
L53:
LOGD("f8:invoke-virtual \x76\x37\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x48\x65\x61\x64\x65\x72\x73\x3b\x2d\x3e\x6e\x65\x77\x42\x75\x69\x6c\x64\x65\x72\x28\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x48\x65\x61\x64\x65\x72\x73\x24\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_LandingPad_8
D2C_NOT_NULL(v11);
jclass &clz = cls5;
jmethodID &mid = mth8;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Headers", "newBuilder", "()Lokhttp3/Headers$Builder;");
jvalue args[] = {};
v2 = (jobject) env->CallObjectMethodA(v11, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L54:
LOGD("fe:move-result-object \x76\x37");
if (v11) {
LOGD("env->DeleteLocalRef(%p):v11", v11);
env->DeleteLocalRef(v11);
}
v11 = (jobject) v2;
L55:
LOGD("100:invoke-virtual \x76\x37\x2c\x20\x76\x30\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x48\x65\x61\x64\x65\x72\x73\x24\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x72\x65\x6d\x6f\x76\x65\x41\x6c\x6c\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x48\x65\x61\x64\x65\x72\x73\x24\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_LandingPad_8
D2C_NOT_NULL(v11);
jclass &clz = cls6;
jmethodID &mid = mth9;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Headers$Builder", "removeAll", "(Ljava/lang/String;)Lokhttp3/Headers$Builder;");
jvalue args[] = {{.l = v1}};
v2 = (jobject) env->CallObjectMethodA(v11, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L56:
LOGD("106:move-result-object \x76\x30");
if (v1) {
LOGD("env->DeleteLocalRef(%p):v1", v1);
env->DeleteLocalRef(v1);
}
v1 = (jobject) v2;
L57:
LOGD("108:invoke-virtual \x76\x30\x2c\x20\x76\x36\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x48\x65\x61\x64\x65\x72\x73\x24\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x72\x65\x6d\x6f\x76\x65\x41\x6c\x6c\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x48\x65\x61\x64\x65\x72\x73\x24\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_LandingPad_8
D2C_NOT_NULL(v1);
jclass &clz = cls6;
jmethodID &mid = mth9;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Headers$Builder", "removeAll", "(Ljava/lang/String;)Lokhttp3/Headers$Builder;");
jvalue args[] = {{.l = v10}};
v2 = (jobject) env->CallObjectMethodA(v1, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L58:
LOGD("10e:move-result-object \x76\x30");
if (v1) {
LOGD("env->DeleteLocalRef(%p):v1", v1);
env->DeleteLocalRef(v1);
}
v1 = (jobject) v2;
L59:
LOGD("110:invoke-virtual \x76\x30\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x48\x65\x61\x64\x65\x72\x73\x24\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x62\x75\x69\x6c\x64\x28\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x48\x65\x61\x64\x65\x72\x73\x3b");
{
#define EX_HANDLE EX_LandingPad_8
D2C_NOT_NULL(v1);
jclass &clz = cls6;
jmethodID &mid = mth10;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Headers$Builder", "build", "()Lokhttp3/Headers;");
jvalue args[] = {};
v2 = (jobject) env->CallObjectMethodA(v1, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L60:
LOGD("116:move-result-object \x76\x30");
if (v1) {
LOGD("env->DeleteLocalRef(%p):v1", v1);
env->DeleteLocalRef(v1);
}
v1 = (jobject) v2;
L61:
LOGD("118:invoke-virtual \x76\x31\x2c\x20\x76\x30\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x24\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x68\x65\x61\x64\x65\x72\x73\x28\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x48\x65\x61\x64\x65\x72\x73\x3b\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x24\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_LandingPad_8
D2C_NOT_NULL(v3);
jclass &clz = cls7;
jmethodID &mid = mth11;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Response$Builder", "headers", "(Lokhttp3/Headers;)Lokhttp3/Response$Builder;");
jvalue args[] = {{.l = v1}};
v2 = (jobject) env->CallObjectMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
L62:
LOGD("11e:invoke-virtual \x76\x31\x30\x2c\x20\x76\x35\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x3b\x2d\x3e\x68\x65\x61\x64\x65\x72\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_LandingPad_8
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jmethodID &mid = mth1;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Response", "header", "(Ljava/lang/String;)Ljava/lang/String;");
jvalue args[] = {{.l = v9}};
v2 = (jstring) env->CallObjectMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L63:
LOGD("124:move-result-object \x76\x30");
if (v1) {
LOGD("env->DeleteLocalRef(%p):v1", v1);
env->DeleteLocalRef(v1);
}
v1 = (jobject) v2;
L64:
LOGD("126:new-instance \x76\x35\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x69\x6e\x74\x65\x72\x6e\x61\x6c\x2f\x68\x74\x74\x70\x2f\x52\x65\x61\x6c\x52\x65\x73\x70\x6f\x6e\x73\x65\x42\x6f\x64\x79\x3b");
{
#define EX_HANDLE EX_LandingPad_8
if (v9) {
LOGD("env->DeleteLocalRef(%p):v9", v9);
env->DeleteLocalRef(v9);
}
jclass &clz = cls8;
D2C_RESOLVE_CLASS(clz,"okhttp3/internal/http/RealResponseBody");
v9 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L65:
LOGD("12a:invoke-static \x76\x32\x2c\x20\x4c\x6f\x6b\x69\x6f\x2f\x4f\x6b\x69\x6f\x3b\x2d\x3e\x62\x75\x66\x66\x65\x72\x28\x4c\x6f\x6b\x69\x6f\x2f\x53\x6f\x75\x72\x63\x65\x3b\x29\x4c\x6f\x6b\x69\x6f\x2f\x42\x75\x66\x66\x65\x72\x65\x64\x53\x6f\x75\x72\x63\x65\x3b");
{
#define EX_HANDLE EX_LandingPad_8
jclass &clz = cls9;
jmethodID &mid = mth12;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "okio/Okio", "buffer", "(Lokio/Source;)Lokio/BufferedSource;");
jvalue args[] = {{.l = v4}};
v2 = (jobject) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L66:
LOGD("130:move-result-object \x76\x32");
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
v4 = (jobject) v2;
L67:
LOGD("132:invoke-direct \x76\x35\x2c\x20\x76\x30\x2c\x20\x76\x33\x2c\x20\x76\x34\x2c\x20\x76\x32\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x69\x6e\x74\x65\x72\x6e\x61\x6c\x2f\x68\x74\x74\x70\x2f\x52\x65\x61\x6c\x52\x65\x73\x70\x6f\x6e\x73\x65\x42\x6f\x64\x79\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x20\x4a\x20\x4c\x6f\x6b\x69\x6f\x2f\x42\x75\x66\x66\x65\x72\x65\x64\x53\x6f\x75\x72\x63\x65\x3b\x29\x56");
{
#define EX_HANDLE EX_LandingPad_8
D2C_NOT_NULL(v9);
jclass &clz = cls8;
jmethodID &mid = mth13;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/internal/http/RealResponseBody", "<init>", "(Ljava/lang/String;JLokio/BufferedSource;)V");
jvalue args[] = {{.l = v1},{.j = (jlong) v8},{.l = v4}};
env->CallVoidMethodA(v9, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L68:
LOGD("138:invoke-virtual \x76\x31\x2c\x20\x76\x35\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x24\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x62\x6f\x64\x79\x28\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x42\x6f\x64\x79\x3b\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x24\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_LandingPad_8
D2C_NOT_NULL(v3);
jclass &clz = cls7;
jmethodID &mid = mth14;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Response$Builder", "body", "(Lokhttp3/ResponseBody;)Lokhttp3/Response$Builder;");
jvalue args[] = {{.l = v9}};
v2 = (jobject) env->CallObjectMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
L69:
LOGD("13e:invoke-virtual \x76\x31\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x24\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x62\x75\x69\x6c\x64\x28\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x3b");
{
#define EX_HANDLE EX_LandingPad_8
D2C_NOT_NULL(v3);
jclass &clz = cls7;
jmethodID &mid = mth17;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Response$Builder", "build", "()Lokhttp3/Response;");
jvalue args[] = {};
v2 = (jobject) env->CallObjectMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L70:
LOGD("144:move-result-object \x76\x31\x30");
if (v0) {
LOGD("env->DeleteLocalRef(%p):v0", v0);
env->DeleteLocalRef(v0);
}
v0 = (jobject) v2;
return (jobject) v0;
L71:
LOGD("148:move-exception \x76\x30");
if (v1) {
LOGD("env->DeleteLocalRef(%p):v1", v1);
env->DeleteLocalRef(v1);
}
v1 = exception;
LOGD("14a:invoke-virtual \x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x54\x68\x72\x6f\x77\x61\x62\x6c\x65\x3b\x2d\x3e\x70\x72\x69\x6e\x74\x53\x74\x61\x63\x6b\x54\x72\x61\x63\x65\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v1);
jclass &clz = cls12;
jmethodID &mid = mth18;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/Throwable", "printStackTrace", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v1, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
return (jobject) v0;

EX_LandingPad_1:
D2C_GET_PENDING_EX
if(d2c_is_instance_of(env, exception, "java/lang/Throwable")) {
goto L71;
}
D2C_GOTO_UNWINDBLOCK

EX_LandingPad_8:
D2C_GET_PENDING_EX
if(d2c_is_instance_of(env, exception, "java/lang/Throwable")) {
goto L71;
}
D2C_GOTO_UNWINDBLOCK
EX_UnwindBlock: return NULL;
}
