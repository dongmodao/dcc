#include "Dex2C.h"

/* Lio/pro/edge/widget/edge/NativeUtils;->a(Landroid/content/Context;Lio/pro/edge/widget/edge/DataManager$OnSaveListener;)V */
extern "C" JNIEXPORT void JNICALL
Java_io_pro_edge_widget_edge_NativeUtils_a__Landroid_content_Context_2Lio_pro_edge_widget_edge_DataManager_00024OnSaveListener_2(JNIEnv *env, jobject thiz, jobject p6, jobject p7){
jobject v0 = NULL;
jobject v1 = NULL;
jobject v2 = NULL;
jobject v3 = NULL;
jobject v4 = NULL;
jobject v5 = NULL;
jobject v6 = NULL;
jint v7;
jint v8;
jobject v9 = NULL;
jobject v10 = NULL;
jlong v11;
jint v12;
jint v13;
jint v14;
jthrowable exception;
jclass cls0 = NULL,cls1 = NULL,cls2 = NULL,cls3 = NULL,cls4 = NULL,cls5 = NULL,cls6 = NULL,cls7 = NULL,cls8 = NULL,cls9 = NULL,cls10 = NULL,cls11 = NULL,cls12 = NULL,cls13 = NULL,cls14 = NULL,cls15 = NULL,cls16 = NULL,cls17 = NULL,cls18 = NULL;
jfieldID fld0 = NULL;
jmethodID mth0 = NULL, mth1 = NULL, mth2 = NULL, mth3 = NULL, mth4 = NULL, mth5 = NULL, mth6 = NULL, mth7 = NULL, mth8 = NULL, mth9 = NULL, mth10 = NULL, mth11 = NULL, mth12 = NULL, mth13 = NULL, mth14 = NULL, mth15 = NULL, mth16 = NULL, mth17 = NULL, mth18 = NULL, mth19 = NULL, mth20 = NULL, mth21 = NULL, mth22 = NULL, mth23 = NULL, mth24 = NULL, mth25 = NULL, mth26 = NULL, mth27 = NULL, mth28 = NULL, mth29 = NULL, mth30 = NULL, mth31 = NULL, mth32 = NULL, mth33 = NULL, mth34 = NULL, mth35 = NULL, mth36 = NULL, mth37 = NULL;
v0 = (jobject)env->NewLocalRef(p6);
v1 = (jobject)env->NewLocalRef(p7);
L0:
LOGD("0:invoke-static \x76\x36\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x64\x67\x65\x2f\x4e\x61\x74\x69\x76\x65\x55\x74\x69\x6c\x73\x3b\x2d\x3e\x61\x28\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6e\x74\x65\x78\x74\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x4d\x61\x70\x3b");
{
#define EX_HANDLE EX_LandingPad_0
jclass &clz = cls0;
jmethodID &mid = mth0;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "io/pro/edge/widget/edge/NativeUtils", "a", "(Landroid/content/Context;)Ljava/util/Map;");
jvalue args[] = {{.l = v0}};
v2 = (jobject) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L1:
LOGD("6:move-result-object \x76\x30");
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
v3 = (jobject) v2;
L2:
LOGD("8:const-string \x76\x31\x2c\x20\x27\x68\x74\x74\x70\x73\x3a\x2f\x2f\x71\x62\x35\x62\x6d\x6d\x71\x7a\x65\x31\x2e\x65\x78\x65\x63\x75\x74\x65\x2d\x61\x70\x69\x2e\x61\x70\x2d\x73\x6f\x75\x74\x68\x65\x61\x73\x74\x2d\x31\x2e\x61\x6d\x61\x7a\x6f\x6e\x61\x77\x73\x2e\x63\x6f\x6d\x2f\x31\x36\x36\x2f\x63\x27");
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
v4 = (jstring) env->NewStringUTF("\x68\x74\x74\x70\x73\x3a\x2f\x2f\x71\x62\x35\x62\x6d\x6d\x71\x7a\x65\x31\x2e\x65\x78\x65\x63\x75\x74\x65\x2d\x61\x70\x69\x2e\x61\x70\x2d\x73\x6f\x75\x74\x68\x65\x61\x73\x74\x2d\x31\x2e\x61\x6d\x61\x7a\x6f\x6e\x61\x77\x73\x2e\x63\x6f\x6d\x2f\x31\x36\x36\x2f\x63");
L3:
LOGD("c:new-instance \x76\x32\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x46\x6f\x72\x6d\x42\x6f\x64\x79\x24\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_LandingPad_0
if (v5) {
LOGD("env->DeleteLocalRef(%p):v5", v5);
env->DeleteLocalRef(v5);
}
jclass &clz = cls1;
D2C_RESOLVE_CLASS(clz,"okhttp3/FormBody$Builder");
v5 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L4:
LOGD("10:invoke-direct \x76\x32\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x46\x6f\x72\x6d\x42\x6f\x64\x79\x24\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x29\x56");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v5);
jclass &clz = cls1;
jmethodID &mid = mth1;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/FormBody$Builder", "<init>", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v5, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L5:
LOGD("16:invoke-interface \x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x4d\x61\x70\x3b\x2d\x3e\x6b\x65\x79\x53\x65\x74\x28\x29\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x53\x65\x74\x3b");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v3);
jclass &clz = cls2;
jmethodID &mid = mth2;
D2C_RESOLVE_METHOD(clz, mid, "java/util/Map", "keySet", "()Ljava/util/Set;");
jvalue args[] = {};
v2 = (jobject) env->CallObjectMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L6:
LOGD("1c:move-result-object \x76\x33");
if (v6) {
LOGD("env->DeleteLocalRef(%p):v6", v6);
env->DeleteLocalRef(v6);
}
v6 = (jobject) v2;
L7:
LOGD("1e:invoke-interface \x76\x33\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x53\x65\x74\x3b\x2d\x3e\x69\x74\x65\x72\x61\x74\x6f\x72\x28\x29\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x49\x74\x65\x72\x61\x74\x6f\x72\x3b");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v6);
jclass &clz = cls3;
jmethodID &mid = mth3;
D2C_RESOLVE_METHOD(clz, mid, "java/util/Set", "iterator", "()Ljava/util/Iterator;");
jvalue args[] = {};
v2 = (jobject) env->CallObjectMethodA(v6, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L8:
LOGD("24:move-result-object \x76\x33");
if (v6) {
LOGD("env->DeleteLocalRef(%p):v6", v6);
env->DeleteLocalRef(v6);
}
v6 = (jobject) v2;
L9:
LOGD("26:invoke-interface \x76\x33\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x49\x74\x65\x72\x61\x74\x6f\x72\x3b\x2d\x3e\x68\x61\x73\x4e\x65\x78\x74\x28\x29\x5a");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v6);
jclass &clz = cls4;
jmethodID &mid = mth4;
D2C_RESOLVE_METHOD(clz, mid, "java/util/Iterator", "hasNext", "()Z");
jvalue args[] = {};
v7 = (jboolean) env->CallBooleanMethodA(v6, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L10:
LOGD("2c:move-result \x76\x34");
v8 = (jint) v7;
LOGD("2e:if-eqz \x76\x34\x2c\x20\x2b\x31\x34");
if(v8 == 0){
goto L20;
}
else {
goto L11;
}
L11:
LOGD("32:invoke-interface \x76\x33\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x49\x74\x65\x72\x61\x74\x6f\x72\x3b\x2d\x3e\x6e\x65\x78\x74\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v6);
jclass &clz = cls4;
jmethodID &mid = mth5;
D2C_RESOLVE_METHOD(clz, mid, "java/util/Iterator", "next", "()Ljava/lang/Object;");
jvalue args[] = {};
v2 = (jobject) env->CallObjectMethodA(v6, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L12:
LOGD("38:move-result-object \x76\x34");
if (v9) {
LOGD("env->DeleteLocalRef(%p):v9", v9);
env->DeleteLocalRef(v9);
}
v9 = (jobject) v2;
L13:
LOGD("3a:check-cast \x76\x34\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_LandingPad_0
jclass &clz = cls5;
D2C_RESOLVE_CLASS(clz,"java/lang/String");
D2C_CHECK_CAST(v9, clz, "java/lang/String");
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L14:
LOGD("3e:invoke-interface \x76\x30\x2c\x20\x76\x34\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x4d\x61\x70\x3b\x2d\x3e\x67\x65\x74\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v3);
jclass &clz = cls2;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/util/Map", "get", "(Ljava/lang/Object;)Ljava/lang/Object;");
jvalue args[] = {{.l = v9}};
v2 = (jobject) env->CallObjectMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L15:
LOGD("44:move-result-object \x76\x35");
if (v10) {
LOGD("env->DeleteLocalRef(%p):v10", v10);
env->DeleteLocalRef(v10);
}
v10 = (jobject) v2;
L16:
LOGD("46:check-cast \x76\x35\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_LandingPad_0
jclass &clz = cls5;
D2C_RESOLVE_CLASS(clz,"java/lang/String");
D2C_CHECK_CAST(v10, clz, "java/lang/String");
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L17:
LOGD("4a:if-eqz \x76\x35\x2c\x20\x2d\x31\x32");
if(v10 == NULL){
goto L9;
}
else {
goto L18;
}
L18:
LOGD("4e:invoke-virtual \x76\x32\x2c\x20\x76\x34\x2c\x20\x76\x35\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x46\x6f\x72\x6d\x42\x6f\x64\x79\x24\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x64\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x46\x6f\x72\x6d\x42\x6f\x64\x79\x24\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v5);
jclass &clz = cls1;
jmethodID &mid = mth7;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/FormBody$Builder", "add", "(Ljava/lang/String;Ljava/lang/String;)Lokhttp3/FormBody$Builder;");
jvalue args[] = {{.l = v9},{.l = v10}};
v2 = (jobject) env->CallObjectMethodA(v5, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
L19:
goto L9;
L20:
LOGD("56:invoke-virtual \x76\x32\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x46\x6f\x72\x6d\x42\x6f\x64\x79\x24\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x62\x75\x69\x6c\x64\x28\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x46\x6f\x72\x6d\x42\x6f\x64\x79\x3b");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v5);
jclass &clz = cls1;
jmethodID &mid = mth8;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/FormBody$Builder", "build", "()Lokhttp3/FormBody;");
jvalue args[] = {};
v2 = (jobject) env->CallObjectMethodA(v5, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L21:
LOGD("5c:move-result-object \x76\x30");
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
v3 = (jobject) v2;
L22:
LOGD("5e:new-instance \x76\x32\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x71\x75\x65\x73\x74\x24\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_LandingPad_0
if (v5) {
LOGD("env->DeleteLocalRef(%p):v5", v5);
env->DeleteLocalRef(v5);
}
jclass &clz = cls6;
D2C_RESOLVE_CLASS(clz,"okhttp3/Request$Builder");
v5 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L23:
LOGD("62:invoke-direct \x76\x32\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x71\x75\x65\x73\x74\x24\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x29\x56");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v5);
jclass &clz = cls6;
jmethodID &mid = mth9;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Request$Builder", "<init>", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v5, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L24:
LOGD("68:invoke-virtual \x76\x32\x2c\x20\x76\x31\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x71\x75\x65\x73\x74\x24\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x75\x72\x6c\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x71\x75\x65\x73\x74\x24\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v5);
jclass &clz = cls6;
jmethodID &mid = mth10;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Request$Builder", "url", "(Ljava/lang/String;)Lokhttp3/Request$Builder;");
jvalue args[] = {{.l = v4}};
v2 = (jobject) env->CallObjectMethodA(v5, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L25:
LOGD("6e:move-result-object \x76\x31");
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
v4 = (jobject) v2;
L26:
LOGD("70:invoke-virtual \x76\x31\x2c\x20\x76\x30\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x71\x75\x65\x73\x74\x24\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x70\x6f\x73\x74\x28\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x71\x75\x65\x73\x74\x42\x6f\x64\x79\x3b\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x71\x75\x65\x73\x74\x24\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v4);
jclass &clz = cls6;
jmethodID &mid = mth11;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Request$Builder", "post", "(Lokhttp3/RequestBody;)Lokhttp3/Request$Builder;");
jvalue args[] = {{.l = v3}};
v2 = (jobject) env->CallObjectMethodA(v4, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L27:
LOGD("76:move-result-object \x76\x30");
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
v3 = (jobject) v2;
L28:
LOGD("78:invoke-virtual \x76\x30\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x71\x75\x65\x73\x74\x24\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x62\x75\x69\x6c\x64\x28\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x71\x75\x65\x73\x74\x3b");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v3);
jclass &clz = cls6;
jmethodID &mid = mth12;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Request$Builder", "build", "()Lokhttp3/Request;");
jvalue args[] = {};
v2 = (jobject) env->CallObjectMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L29:
LOGD("7e:move-result-object \x76\x30");
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
v3 = (jobject) v2;
L30:
LOGD("80:new-instance \x76\x31\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x4f\x6b\x48\x74\x74\x70\x43\x6c\x69\x65\x6e\x74\x24\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_LandingPad_0
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
jclass &clz = cls7;
D2C_RESOLVE_CLASS(clz,"okhttp3/OkHttpClient$Builder");
v4 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L31:
LOGD("84:invoke-direct \x76\x31\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x4f\x6b\x48\x74\x74\x70\x43\x6c\x69\x65\x6e\x74\x24\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x29\x56");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v4);
jclass &clz = cls7;
jmethodID &mid = mth13;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/OkHttpClient$Builder", "<init>", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v4, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L32:
LOGD("8a:sget-object \x76\x32\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x63\x6f\x6e\x63\x75\x72\x72\x65\x6e\x74\x2f\x54\x69\x6d\x65\x55\x6e\x69\x74\x3b\x2d\x3e\x53\x45\x43\x4f\x4e\x44\x53\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x63\x6f\x6e\x63\x75\x72\x72\x65\x6e\x74\x2f\x54\x69\x6d\x65\x55\x6e\x69\x74\x3b");
{
#define EX_HANDLE EX_LandingPad_0
if (v5) {
LOGD("env->DeleteLocalRef(%p):v5", v5);
env->DeleteLocalRef(v5);
}
jclass &clz = cls8;
jfieldID &fld = fld0;
D2C_RESOLVE_STATIC_FIELD(clz, fld, "java/util/concurrent/TimeUnit", "SECONDS", "Ljava/util/concurrent/TimeUnit;");
v5 = (jobject) env->GetStaticObjectField(clz,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L33:
v11 = 30;
v11 = 30;
v11 = 30;
L34:
LOGD("92:invoke-virtual \x76\x31\x2c\x20\x76\x33\x2c\x20\x76\x34\x2c\x20\x76\x32\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x4f\x6b\x48\x74\x74\x70\x43\x6c\x69\x65\x6e\x74\x24\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x63\x6f\x6e\x6e\x65\x63\x74\x54\x69\x6d\x65\x6f\x75\x74\x28\x4a\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x63\x6f\x6e\x63\x75\x72\x72\x65\x6e\x74\x2f\x54\x69\x6d\x65\x55\x6e\x69\x74\x3b\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x4f\x6b\x48\x74\x74\x70\x43\x6c\x69\x65\x6e\x74\x24\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v4);
jclass &clz = cls7;
jmethodID &mid = mth14;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/OkHttpClient$Builder", "connectTimeout", "(JLjava/util/concurrent/TimeUnit;)Lokhttp3/OkHttpClient$Builder;");
jvalue args[] = {{.j = (jlong) v11},{.l = v5}};
v2 = (jobject) env->CallObjectMethodA(v4, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L35:
LOGD("98:move-result-object \x76\x31");
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
v4 = (jobject) v2;
L36:
LOGD("9a:sget-object \x76\x32\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x63\x6f\x6e\x63\x75\x72\x72\x65\x6e\x74\x2f\x54\x69\x6d\x65\x55\x6e\x69\x74\x3b\x2d\x3e\x53\x45\x43\x4f\x4e\x44\x53\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x63\x6f\x6e\x63\x75\x72\x72\x65\x6e\x74\x2f\x54\x69\x6d\x65\x55\x6e\x69\x74\x3b");
{
#define EX_HANDLE EX_LandingPad_0
if (v5) {
LOGD("env->DeleteLocalRef(%p):v5", v5);
env->DeleteLocalRef(v5);
}
jclass &clz = cls8;
jfieldID &fld = fld0;
D2C_RESOLVE_STATIC_FIELD(clz, fld, "java/util/concurrent/TimeUnit", "SECONDS", "Ljava/util/concurrent/TimeUnit;");
v5 = (jobject) env->GetStaticObjectField(clz,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L37:
LOGD("9e:invoke-virtual \x76\x31\x2c\x20\x76\x33\x2c\x20\x76\x34\x2c\x20\x76\x32\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x4f\x6b\x48\x74\x74\x70\x43\x6c\x69\x65\x6e\x74\x24\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x72\x65\x61\x64\x54\x69\x6d\x65\x6f\x75\x74\x28\x4a\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x63\x6f\x6e\x63\x75\x72\x72\x65\x6e\x74\x2f\x54\x69\x6d\x65\x55\x6e\x69\x74\x3b\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x4f\x6b\x48\x74\x74\x70\x43\x6c\x69\x65\x6e\x74\x24\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v4);
jclass &clz = cls7;
jmethodID &mid = mth15;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/OkHttpClient$Builder", "readTimeout", "(JLjava/util/concurrent/TimeUnit;)Lokhttp3/OkHttpClient$Builder;");
jvalue args[] = {{.j = (jlong) v11},{.l = v5}};
v2 = (jobject) env->CallObjectMethodA(v4, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L38:
LOGD("a4:move-result-object \x76\x31");
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
v4 = (jobject) v2;
L39:
LOGD("a6:sget-object \x76\x32\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x63\x6f\x6e\x63\x75\x72\x72\x65\x6e\x74\x2f\x54\x69\x6d\x65\x55\x6e\x69\x74\x3b\x2d\x3e\x53\x45\x43\x4f\x4e\x44\x53\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x63\x6f\x6e\x63\x75\x72\x72\x65\x6e\x74\x2f\x54\x69\x6d\x65\x55\x6e\x69\x74\x3b");
{
#define EX_HANDLE EX_LandingPad_0
if (v5) {
LOGD("env->DeleteLocalRef(%p):v5", v5);
env->DeleteLocalRef(v5);
}
jclass &clz = cls8;
jfieldID &fld = fld0;
D2C_RESOLVE_STATIC_FIELD(clz, fld, "java/util/concurrent/TimeUnit", "SECONDS", "Ljava/util/concurrent/TimeUnit;");
v5 = (jobject) env->GetStaticObjectField(clz,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L40:
LOGD("aa:invoke-virtual \x76\x31\x2c\x20\x76\x33\x2c\x20\x76\x34\x2c\x20\x76\x32\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x4f\x6b\x48\x74\x74\x70\x43\x6c\x69\x65\x6e\x74\x24\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x77\x72\x69\x74\x65\x54\x69\x6d\x65\x6f\x75\x74\x28\x4a\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x63\x6f\x6e\x63\x75\x72\x72\x65\x6e\x74\x2f\x54\x69\x6d\x65\x55\x6e\x69\x74\x3b\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x4f\x6b\x48\x74\x74\x70\x43\x6c\x69\x65\x6e\x74\x24\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v4);
jclass &clz = cls7;
jmethodID &mid = mth16;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/OkHttpClient$Builder", "writeTimeout", "(JLjava/util/concurrent/TimeUnit;)Lokhttp3/OkHttpClient$Builder;");
jvalue args[] = {{.j = (jlong) v11},{.l = v5}};
v2 = (jobject) env->CallObjectMethodA(v4, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L41:
LOGD("b0:move-result-object \x76\x31");
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
v4 = (jobject) v2;
L42:
LOGD("b2:invoke-virtual \x76\x31\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x4f\x6b\x48\x74\x74\x70\x43\x6c\x69\x65\x6e\x74\x24\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x62\x75\x69\x6c\x64\x28\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x4f\x6b\x48\x74\x74\x70\x43\x6c\x69\x65\x6e\x74\x3b");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v4);
jclass &clz = cls7;
jmethodID &mid = mth17;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/OkHttpClient$Builder", "build", "()Lokhttp3/OkHttpClient;");
jvalue args[] = {};
v2 = (jobject) env->CallObjectMethodA(v4, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L43:
LOGD("b8:move-result-object \x76\x31");
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
v4 = (jobject) v2;
L44:
LOGD("ba:invoke-virtual \x76\x31\x2c\x20\x76\x30\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x4f\x6b\x48\x74\x74\x70\x43\x6c\x69\x65\x6e\x74\x3b\x2d\x3e\x6e\x65\x77\x43\x61\x6c\x6c\x28\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x71\x75\x65\x73\x74\x3b\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x43\x61\x6c\x6c\x3b");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v4);
jclass &clz = cls9;
jmethodID &mid = mth18;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/OkHttpClient", "newCall", "(Lokhttp3/Request;)Lokhttp3/Call;");
jvalue args[] = {{.l = v3}};
v2 = (jobject) env->CallObjectMethodA(v4, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L45:
LOGD("c0:move-result-object \x76\x30");
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
v3 = (jobject) v2;
L46:
LOGD("c2:invoke-interface \x76\x30\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x43\x61\x6c\x6c\x3b\x2d\x3e\x65\x78\x65\x63\x75\x74\x65\x28\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x3b");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v3);
jclass &clz = cls10;
jmethodID &mid = mth19;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Call", "execute", "()Lokhttp3/Response;");
jvalue args[] = {};
v2 = (jobject) env->CallObjectMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L47:
LOGD("c8:move-result-object \x76\x30");
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
v3 = (jobject) v2;
L48:
LOGD("ca:invoke-virtual \x76\x30\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x3b\x2d\x3e\x63\x6f\x64\x65\x28\x29\x49");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v3);
jclass &clz = cls11;
jmethodID &mid = mth20;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Response", "code", "()I");
jvalue args[] = {};
v7 = (jint) env->CallIntMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L49:
LOGD("d0:move-result \x76\x31");
v12 = (jint) v7;
L50:
LOGD("d2:const-string \x76\x32\x2c\x20\x27\x2d\x2d\x2d\x2d\x2d\x27");
if (v5) {
LOGD("env->DeleteLocalRef(%p):v5", v5);
env->DeleteLocalRef(v5);
}
v5 = (jstring) env->NewStringUTF("\x2d\x2d\x2d\x2d\x2d");
L51:
LOGD("d6:new-instance \x76\x33\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_LandingPad_0
if (v6) {
LOGD("env->DeleteLocalRef(%p):v6", v6);
env->DeleteLocalRef(v6);
}
jclass &clz = cls12;
D2C_RESOLVE_CLASS(clz,"java/lang/StringBuilder");
v6 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L52:
LOGD("da:invoke-direct \x76\x33\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x29\x56");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v6);
jclass &clz = cls12;
jmethodID &mid = mth21;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "<init>", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v6, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L53:
LOGD("e0:const-string \x76\x34\x2c\x20\x27\x63\x68\x65\x63\x6b\x49\x6e\x69\x74\x53\x79\x6e\x63\x3a\x20\x2f\x63\x3a\x20\x27");
if (v9) {
LOGD("env->DeleteLocalRef(%p):v9", v9);
env->DeleteLocalRef(v9);
}
v9 = (jstring) env->NewStringUTF("\x63\x68\x65\x63\x6b\x49\x6e\x69\x74\x53\x79\x6e\x63\x3a\x20\x2f\x63\x3a\x20");
L54:
LOGD("e4:invoke-virtual \x76\x33\x2c\x20\x76\x34\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v6);
jclass &clz = cls12;
jmethodID &mid = mth22;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v9}};
v2 = (jobject) env->CallObjectMethodA(v6, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
L55:
LOGD("ea:invoke-virtual \x76\x33\x2c\x20\x76\x31\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x49\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v6);
jclass &clz = cls12;
jmethodID &mid = mth23;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(I)Ljava/lang/StringBuilder;");
jvalue args[] = {{.i = v12}};
v2 = (jobject) env->CallObjectMethodA(v6, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
L56:
LOGD("f0:const-string \x76\x34\x2c\x20\x27\x7c\x27");
if (v9) {
LOGD("env->DeleteLocalRef(%p):v9", v9);
env->DeleteLocalRef(v9);
}
v9 = (jstring) env->NewStringUTF("\x7c");
L57:
LOGD("f4:invoke-virtual \x76\x33\x2c\x20\x76\x34\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v6);
jclass &clz = cls12;
jmethodID &mid = mth22;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v9}};
v2 = (jobject) env->CallObjectMethodA(v6, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
L58:
LOGD("fa:invoke-virtual \x76\x30\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x3b\x2d\x3e\x62\x6f\x64\x79\x28\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x42\x6f\x64\x79\x3b");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v3);
jclass &clz = cls11;
jmethodID &mid = mth24;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Response", "body", "()Lokhttp3/ResponseBody;");
jvalue args[] = {};
v2 = (jobject) env->CallObjectMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L59:
LOGD("100:move-result-object \x76\x34");
if (v9) {
LOGD("env->DeleteLocalRef(%p):v9", v9);
env->DeleteLocalRef(v9);
}
v9 = (jobject) v2;
L60:
LOGD("102:invoke-virtual \x76\x33\x2c\x20\x76\x34\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v6);
jclass &clz = cls12;
jmethodID &mid = mth25;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/Object;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v9}};
v2 = (jobject) env->CallObjectMethodA(v6, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
L61:
LOGD("108:invoke-virtual \x76\x33\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x74\x6f\x53\x74\x72\x69\x6e\x67\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v6);
jclass &clz = cls12;
jmethodID &mid = mth26;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "toString", "()Ljava/lang/String;");
jvalue args[] = {};
v2 = (jstring) env->CallObjectMethodA(v6, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L62:
LOGD("10e:move-result-object \x76\x33");
if (v6) {
LOGD("env->DeleteLocalRef(%p):v6", v6);
env->DeleteLocalRef(v6);
}
v6 = (jobject) v2;
L63:
LOGD("110:invoke-static \x76\x32\x2c\x20\x76\x33\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x75\x74\x69\x6c\x2f\x4c\x6f\x67\x3b\x2d\x3e\x65\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x49");
{
#define EX_HANDLE EX_LandingPad_0
jclass &clz = cls13;
jmethodID &mid = mth27;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "android/util/Log", "e", "(Ljava/lang/String;Ljava/lang/String;)I");
jvalue args[] = {{.l = v5},{.l = v6}};
v7 = (jint) env->CallStaticIntMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L64:
v13 = 200;
LOGD("11a:if-ne \x76\x31\x2c\x20\x76\x32\x2c\x20\x2b\x33\x35");
if(v12 != v13) {
goto L88;
}
else {
goto L65;
}
L65:
LOGD("11e:invoke-virtual \x76\x30\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x3b\x2d\x3e\x62\x6f\x64\x79\x28\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x42\x6f\x64\x79\x3b");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v3);
jclass &clz = cls11;
jmethodID &mid = mth24;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Response", "body", "()Lokhttp3/ResponseBody;");
jvalue args[] = {};
v2 = (jobject) env->CallObjectMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L66:
LOGD("124:move-result-object \x76\x31");
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
v4 = (jobject) v2;
LOGD("126:if-eqz \x76\x31\x2c\x20\x2b\x32\x66");
if(v4 == NULL){
goto L88;
}
else {
goto L67;
}
L67:
LOGD("12a:invoke-virtual \x76\x30\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x3b\x2d\x3e\x62\x6f\x64\x79\x28\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x42\x6f\x64\x79\x3b");
{
#define EX_HANDLE EX_LandingPad_67
D2C_NOT_NULL(v3);
jclass &clz = cls11;
jmethodID &mid = mth24;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Response", "body", "()Lokhttp3/ResponseBody;");
jvalue args[] = {};
v2 = (jobject) env->CallObjectMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L68:
LOGD("130:move-result-object \x76\x30");
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
v3 = (jobject) v2;
L69:
LOGD("132:invoke-virtual \x76\x30\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x42\x6f\x64\x79\x3b\x2d\x3e\x73\x74\x72\x69\x6e\x67\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_LandingPad_67
D2C_NOT_NULL(v3);
jclass &clz = cls14;
jmethodID &mid = mth28;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/ResponseBody", "string", "()Ljava/lang/String;");
jvalue args[] = {};
v2 = (jstring) env->CallObjectMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L70:
LOGD("138:move-result-object \x76\x30");
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
v3 = (jobject) v2;
L71:
LOGD("13a:invoke-static \x76\x30\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x64\x67\x65\x2f\x4e\x61\x74\x69\x76\x65\x55\x74\x69\x6c\x73\x3b\x2d\x3e\x62\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_LandingPad_67
jclass &clz = cls0;
jmethodID &mid = mth29;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "io/pro/edge/widget/edge/NativeUtils", "b", "(Ljava/lang/String;)Ljava/lang/String;");
jvalue args[] = {{.l = v3}};
v2 = (jstring) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L72:
LOGD("140:move-result-object \x76\x30");
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
v3 = (jobject) v2;
L73:
LOGD("142:invoke-static \x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x64\x67\x65\x2f\x44\x61\x74\x61\x4d\x61\x6e\x61\x67\x65\x72\x3b\x2d\x3e\x63\x28\x29\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x64\x67\x65\x2f\x44\x61\x74\x61\x4d\x61\x6e\x61\x67\x65\x72\x3b");
{
#define EX_HANDLE EX_LandingPad_67
jclass &clz = cls15;
jmethodID &mid = mth30;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "io/pro/edge/widget/edge/DataManager", "c", "()Lio/pro/edge/widget/edge/DataManager;");
jvalue args[] = {};
v2 = (jobject) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L74:
LOGD("148:move-result-object \x76\x31");
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
v4 = (jobject) v2;
L75:
LOGD("14a:invoke-static \x76\x30\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x64\x67\x65\x2f\x4e\x61\x74\x69\x76\x65\x55\x74\x69\x6c\x73\x3b\x2d\x3e\x61\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_LandingPad_67
jclass &clz = cls0;
jmethodID &mid = mth31;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "io/pro/edge/widget/edge/NativeUtils", "a", "(Ljava/lang/String;)Ljava/lang/String;");
jvalue args[] = {{.l = v3}};
v2 = (jstring) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L76:
LOGD("150:move-result-object \x76\x30");
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
v3 = (jobject) v2;
L77:
LOGD("152:invoke-virtual \x76\x31\x2c\x20\x76\x30\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x64\x67\x65\x2f\x44\x61\x74\x61\x4d\x61\x6e\x61\x67\x65\x72\x3b\x2d\x3e\x61\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x56");
{
#define EX_HANDLE EX_LandingPad_67
D2C_NOT_NULL(v4);
jclass &clz = cls15;
jmethodID &mid = mth32;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/edge/DataManager", "a", "(Ljava/lang/String;)V");
jvalue args[] = {{.l = v3}};
env->CallVoidMethodA(v4, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L78:
LOGD("158:invoke-static \x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x64\x67\x65\x2f\x44\x61\x74\x61\x4d\x61\x6e\x61\x67\x65\x72\x3b\x2d\x3e\x63\x28\x29\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x64\x67\x65\x2f\x44\x61\x74\x61\x4d\x61\x6e\x61\x67\x65\x72\x3b");
{
#define EX_HANDLE EX_LandingPad_67
jclass &clz = cls15;
jmethodID &mid = mth30;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "io/pro/edge/widget/edge/DataManager", "c", "()Lio/pro/edge/widget/edge/DataManager;");
jvalue args[] = {};
v2 = (jobject) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L79:
LOGD("15e:move-result-object \x76\x30");
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
v3 = (jobject) v2;
L80:
LOGD("160:invoke-virtual \x76\x30\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x64\x67\x65\x2f\x44\x61\x74\x61\x4d\x61\x6e\x61\x67\x65\x72\x3b\x2d\x3e\x62\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_LandingPad_67
D2C_NOT_NULL(v3);
jclass &clz = cls15;
jmethodID &mid = mth33;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/edge/DataManager", "b", "()Ljava/lang/String;");
jvalue args[] = {};
v2 = (jstring) env->CallObjectMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L81:
LOGD("166:move-result-object \x76\x30");
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
v3 = (jobject) v2;
L82:
LOGD("168:invoke-static \x76\x30\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x74\x65\x78\x74\x2f\x54\x65\x78\x74\x55\x74\x69\x6c\x73\x3b\x2d\x3e\x69\x73\x45\x6d\x70\x74\x79\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x68\x61\x72\x53\x65\x71\x75\x65\x6e\x63\x65\x3b\x29\x5a");
{
#define EX_HANDLE EX_LandingPad_67
jclass &clz = cls16;
jmethodID &mid = mth34;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "android/text/TextUtils", "isEmpty", "(Ljava/lang/CharSequence;)Z");
jvalue args[] = {{.l = v3}};
v7 = (jboolean) env->CallStaticBooleanMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L83:
LOGD("16e:move-result \x76\x30");
v14 = (jint) v7;
LOGD("170:if-nez \x76\x30\x2c\x20\x2b\x61");
if(v14 != 0){
goto L88;
}
else {
goto L84;
}
L84:
LOGD("174:invoke-static \x76\x36\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x64\x67\x65\x2f\x4e\x61\x74\x69\x76\x65\x55\x74\x69\x6c\x73\x3b\x2d\x3e\x62\x28\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6e\x74\x65\x78\x74\x3b\x29\x56");
{
#define EX_HANDLE EX_LandingPad_67
jclass &clz = cls0;
jmethodID &mid = mth35;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "io/pro/edge/widget/edge/NativeUtils", "b", "(Landroid/content/Context;)V");
jvalue args[] = {{.l = v0}};
env->CallStaticVoidMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L85:
goto L88;
L86:
LOGD("17c:move-exception \x76\x36");
if (v0) {
LOGD("env->DeleteLocalRef(%p):v0", v0);
env->DeleteLocalRef(v0);
}
v0 = exception;
L87:
LOGD("17e:invoke-virtual \x76\x36\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x54\x68\x72\x6f\x77\x61\x62\x6c\x65\x3b\x2d\x3e\x70\x72\x69\x6e\x74\x53\x74\x61\x63\x6b\x54\x72\x61\x63\x65\x28\x29\x56");
{
#define EX_HANDLE EX_LandingPad_87
D2C_NOT_NULL(v0);
jclass &clz = cls17;
jmethodID &mid = mth36;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/Throwable", "printStackTrace", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L88:
LOGD("184:if-eqz \x76\x37\x2c\x20\x2b\x65");
if(v1 == NULL){
goto L95;
}
else {
goto L89;
}
L89:
goto L94;
L90:
LOGD("18a:move-exception \x76\x36");
if (v0) {
LOGD("env->DeleteLocalRef(%p):v0", v0);
env->DeleteLocalRef(v0);
}
v0 = exception;
goto L96;
L91:
LOGD("18e:move-exception \x76\x36");
if (v0) {
LOGD("env->DeleteLocalRef(%p):v0", v0);
env->DeleteLocalRef(v0);
}
v0 = exception;
L92:
LOGD("190:invoke-virtual \x76\x36\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x54\x68\x72\x6f\x77\x61\x62\x6c\x65\x3b\x2d\x3e\x70\x72\x69\x6e\x74\x53\x74\x61\x63\x6b\x54\x72\x61\x63\x65\x28\x29\x56");
{
#define EX_HANDLE EX_LandingPad_92
D2C_NOT_NULL(v0);
jclass &clz = cls17;
jmethodID &mid = mth36;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/Throwable", "printStackTrace", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L93:
LOGD("196:if-eqz \x76\x37\x2c\x20\x2b\x35");
if(v1 == NULL){
goto L95;
}
else {
goto L94;
}
L94:
LOGD("19a:invoke-interface \x76\x37\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x64\x67\x65\x2f\x44\x61\x74\x61\x4d\x61\x6e\x61\x67\x65\x72\x24\x4f\x6e\x53\x61\x76\x65\x4c\x69\x73\x74\x65\x6e\x65\x72\x3b\x2d\x3e\x61\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v1);
jclass &clz = cls18;
jmethodID &mid = mth37;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/edge/DataManager$OnSaveListener", "a", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v1, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L95:
return;
L96:
LOGD("1a2:if-eqz \x76\x37\x2c\x20\x2b\x35");
if(v1 == NULL){
goto L98;
}
else {
goto L97;
}
L97:
LOGD("1a6:invoke-interface \x76\x37\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x64\x67\x65\x2f\x44\x61\x74\x61\x4d\x61\x6e\x61\x67\x65\x72\x24\x4f\x6e\x53\x61\x76\x65\x4c\x69\x73\x74\x65\x6e\x65\x72\x3b\x2d\x3e\x61\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v1);
jclass &clz = cls18;
jmethodID &mid = mth37;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/edge/DataManager$OnSaveListener", "a", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v1, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L98:
LOGD("1ac:throw \x76\x36");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
env->Throw((jthrowable) v0);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}

EX_LandingPad_0:
D2C_GET_PENDING_EX
if(d2c_is_instance_of(env, exception, "java/lang/Throwable")) {
goto L91;
}
D2C_GOTO_UNWINDBLOCK

EX_LandingPad_92:
D2C_GET_PENDING_EX
if(d2c_is_instance_of(env, exception, "java/lang/Throwable")) {
goto L90;
}
D2C_GOTO_UNWINDBLOCK

EX_LandingPad_67:
D2C_GET_PENDING_EX
if(d2c_is_instance_of(env, exception, "java/lang/Throwable")) {
goto L86;
}
D2C_GOTO_UNWINDBLOCK

EX_LandingPad_87:
D2C_GET_PENDING_EX
if(d2c_is_instance_of(env, exception, "java/lang/Throwable")) {
goto L91;
}
D2C_GOTO_UNWINDBLOCK
EX_UnwindBlock: return;
}
