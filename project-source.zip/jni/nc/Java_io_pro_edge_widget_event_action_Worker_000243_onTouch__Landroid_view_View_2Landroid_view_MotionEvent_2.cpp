#include "Dex2C.h"

/* Lio/pro/edge/widget/event/action/Worker$3;->onTouch(Landroid/view/View;Landroid/view/MotionEvent;)Z */
extern "C" JNIEXPORT jboolean JNICALL
Java_io_pro_edge_widget_event_action_Worker_000243_onTouch__Landroid_view_View_2Landroid_view_MotionEvent_2(JNIEnv *env, jobject thiz, jobject p1, jobject p2){
jobject v0 = NULL;
jobject v1 = NULL;
jobject v2 = NULL;
jint v3;
v0 = (jobject)env->NewLocalRef(thiz);
v1 = (jobject)env->NewLocalRef(p1);
v2 = (jobject)env->NewLocalRef(p2);
L0:
v3 = 0;
return (jboolean) v3;
EX_UnwindBlock: return (jboolean)0;
}
