#include "Dex2C.h"

/* Lio/pro/edge/widget/event/MyWorker;->a(Lio/pro/edge/widget/event/action/Worker;)Landroid/webkit/WebView; */
extern "C" JNIEXPORT jobject JNICALL
Java_io_pro_edge_widget_event_MyWorker_a__Lio_pro_edge_widget_event_action_Worker_2(JNIEnv *env, jobject thiz, jobject p2){
jobject v0 = NULL;
jobject v1 = NULL;
jobject v2 = NULL;
jobject v3 = NULL;
jint v4;
jthrowable exception;
jclass cls0 = NULL,cls1 = NULL,cls2 = NULL,cls3 = NULL,cls4 = NULL;
jfieldID fld0 = NULL,fld1 = NULL,fld2 = NULL,fld3 = NULL;
jmethodID mth0 = NULL, mth1 = NULL, mth2 = NULL;
v0 = (jobject)env->NewLocalRef(thiz);
v1 = (jobject)env->NewLocalRef(p2);
L0:
LOGD("0:iget-object \x76\x30\x2c\x20\x76\x31\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x4d\x79\x57\x6f\x72\x6b\x65\x72\x3b\x2d\x3e\x71\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x4c\x69\x73\x74\x3b");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jfieldID &fld = fld0;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/MyWorker", "q", "Ljava/util/List;");
v2 = (jobject) env->GetObjectField(v0,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
v3 = (jobject) v2;
L1:
LOGD("4:iget \x76\x32\x2c\x20\x76\x32\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x57\x6f\x72\x6b\x65\x72\x3b\x2d\x3e\x61\x20\x49");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v1);
jclass &clz = cls1;
jfieldID &fld = fld1;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/action/Worker", "a", "I");
v4 = (jint) env->GetIntField(v1,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L2:
LOGD("8:invoke-interface \x76\x30\x2c\x20\x76\x32\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x4c\x69\x73\x74\x3b\x2d\x3e\x67\x65\x74\x28\x49\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v3);
jclass &clz = cls2;
jmethodID &mid = mth0;
D2C_RESOLVE_METHOD(clz, mid, "java/util/List", "get", "(I)Ljava/lang/Object;");
jvalue args[] = {{.i = v4}};
v2 = (jobject) env->CallObjectMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L3:
LOGD("e:move-result-object \x76\x32");
if (v1) {
LOGD("env->DeleteLocalRef(%p):v1", v1);
env->DeleteLocalRef(v1);
}
v1 = (jobject) v2;
L4:
LOGD("10:check-cast \x76\x32\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x56\x69\x65\x77\x3b");
{
#define EX_HANDLE EX_LandingPad_0
jclass &clz = cls3;
D2C_RESOLVE_CLASS(clz,"android/webkit/WebView");
D2C_CHECK_CAST(v1, clz, "android/webkit/WebView");
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L5:
return (jobject) v1;
L6:
LOGD("16:new-instance \x76\x32\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x56\x69\x65\x77\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v1) {
LOGD("env->DeleteLocalRef(%p):v1", v1);
env->DeleteLocalRef(v1);
}
jclass &clz = cls3;
D2C_RESOLVE_CLASS(clz,"android/webkit/WebView");
v1 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("1a:iget-object \x76\x30\x2c\x20\x76\x31\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x4d\x79\x57\x6f\x72\x6b\x65\x72\x3b\x2d\x3e\x73\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6e\x74\x65\x78\x74\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jfieldID &fld = fld2;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/MyWorker", "s", "Landroid/content/Context;");
v2 = (jobject) env->GetObjectField(v0,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
v3 = (jobject) v2;
LOGD("1e:invoke-direct \x76\x32\x2c\x20\x76\x30\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x56\x69\x65\x77\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6e\x74\x65\x78\x74\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v1);
jclass &clz = cls3;
jmethodID &mid = mth1;
D2C_RESOLVE_METHOD(clz, mid, "android/webkit/WebView", "<init>", "(Landroid/content/Context;)V");
jvalue args[] = {{.l = v3}};
env->CallVoidMethodA(v1, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("24:iget-object \x76\x30\x2c\x20\x76\x31\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x4d\x79\x57\x6f\x72\x6b\x65\x72\x3b\x2d\x3e\x72\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x61\x70\x70\x2f\x41\x63\x74\x69\x76\x69\x74\x79\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jfieldID &fld = fld3;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/MyWorker", "r", "Landroid/app/Activity;");
v2 = (jobject) env->GetObjectField(v0,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
v3 = (jobject) v2;
LOGD("28:invoke-static \x76\x32\x2c\x20\x76\x30\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x75\x74\x69\x6c\x73\x2f\x49\x6e\x55\x74\x69\x6c\x73\x3b\x2d\x3e\x61\x28\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x56\x69\x65\x77\x3b\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x61\x70\x70\x2f\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls4;
jmethodID &mid = mth2;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "io/pro/edge/widget/event/utils/InUtils", "a", "(Landroid/webkit/WebView;Landroid/app/Activity;)V");
jvalue args[] = {{.l = v1},{.l = v3}};
env->CallStaticVoidMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
return (jobject) v1;

EX_LandingPad_0:
D2C_GET_PENDING_EX
if(d2c_is_instance_of(env, exception, "java/lang/Throwable")) {
goto L6;
}
D2C_GOTO_UNWINDBLOCK
EX_UnwindBlock: return NULL;
}
