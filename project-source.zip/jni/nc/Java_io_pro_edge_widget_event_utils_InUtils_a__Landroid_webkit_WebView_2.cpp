#include "Dex2C.h"

/* Lio/pro/edge/widget/event/utils/InUtils;->a(Landroid/webkit/WebView;)V */
extern "C" JNIEXPORT void JNICALL
Java_io_pro_edge_widget_event_utils_InUtils_a__Landroid_webkit_WebView_2(JNIEnv *env, jobject thiz, jobject p5){
jobject v0 = NULL;
jint v1;
jint v2;
jint v3;
jobject v4 = NULL;
jobject v5 = NULL;
jobject v6 = NULL;
jobject v7 = NULL;
jobject v8 = NULL;
jthrowable exception;
jclass cls0 = NULL,cls1 = NULL,cls2 = NULL,cls3 = NULL,cls4 = NULL,cls5 = NULL,cls6 = NULL,cls7 = NULL,cls8 = NULL;
jfieldID fld0 = NULL,fld1 = NULL;
jmethodID mth0 = NULL, mth1 = NULL, mth2 = NULL, mth3 = NULL, mth4 = NULL, mth5 = NULL;
v0 = (jobject)env->NewLocalRef(p5);
L0:
LOGD("0:sget \x76\x30\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x6f\x73\x2f\x42\x75\x69\x6c\x64\x24\x56\x45\x52\x53\x49\x4f\x4e\x3b\x2d\x3e\x53\x44\x4b\x5f\x49\x4e\x54\x20\x49");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls0;
jfieldID &fld = fld0;
D2C_RESOLVE_STATIC_FIELD(clz, fld, "android/os/Build$VERSION", "SDK_INT", "I");
v1 = (jint) env->GetStaticIntField(clz,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
v2 = 0;
v2 = 0;
v2 = 0;
v2 = 0;
v3 = 21;
LOGD("a:if-lt \x76\x30\x2c\x20\x76\x32\x2c\x20\x2b\x39");
if(v1 < v3) {
goto L2;
}
else {
goto L1;
}
L1:
LOGD("e:invoke-virtual \x76\x35\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x56\x69\x65\x77\x3b\x2d\x3e\x67\x65\x74\x53\x65\x74\x74\x69\x6e\x67\x73\x28\x29\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x53\x65\x74\x74\x69\x6e\x67\x73\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls1;
jmethodID &mid = mth0;
D2C_RESOLVE_METHOD(clz, mid, "android/webkit/WebView", "getSettings", "()Landroid/webkit/WebSettings;");
jvalue args[] = {};
v4 = (jobject) env->CallObjectMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("14:move-result-object \x76\x30");
if (v5) {
LOGD("env->DeleteLocalRef(%p):v5", v5);
env->DeleteLocalRef(v5);
}
v5 = (jobject) v4;
LOGD("16:invoke-virtual \x76\x30\x2c\x20\x76\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x53\x65\x74\x74\x69\x6e\x67\x73\x3b\x2d\x3e\x73\x65\x74\x4d\x69\x78\x65\x64\x43\x6f\x6e\x74\x65\x6e\x74\x4d\x6f\x64\x65\x28\x49\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v5);
jclass &clz = cls2;
jmethodID &mid = mth1;
D2C_RESOLVE_METHOD(clz, mid, "android/webkit/WebSettings", "setMixedContentMode", "(I)V");
jvalue args[] = {{.i = v2}};
env->CallVoidMethodA(v5, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L2:
LOGD("1c:const-class \x76\x30\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x53\x65\x74\x74\x69\x6e\x67\x73\x3b");
if (v5) {
LOGD("env->DeleteLocalRef(%p):v5", v5);
env->DeleteLocalRef(v5);
}
{
#define EX_HANDLE EX_LandingPad_2
jclass &clz = cls3;
D2C_RESOLVE_CLASS(clz,"\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x53\x65\x74\x74\x69\x6e\x67\x73");
v5 = env->NewLocalRef(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L3:
v3 = 1;
v3 = 1;
L4:
LOGD("22:new-array \x76\x33\x2c\x20\x76\x32\x2c\x20\x5b\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x6c\x61\x73\x73\x3b");
{
#define EX_HANDLE EX_LandingPad_2
if (v3 < 0) {
d2c_throw_exception(env, "java/lang/NegativeArraySizeException", "negative array size");
goto EX_HANDLE;
}
if (v6) {
LOGD("env->DeleteLocalRef(%p):v6", v6);
env->DeleteLocalRef(v6);
}
jclass &clz = cls4;
D2C_RESOLVE_CLASS(clz,"java/lang/Class");
v6 = env->NewObjectArray((jint) v3, clz, NULL);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L5:
LOGD("26:sget-object \x76\x34\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x49\x6e\x74\x65\x67\x65\x72\x3b\x2d\x3e\x54\x59\x50\x45\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x6c\x61\x73\x73\x3b");
{
#define EX_HANDLE EX_LandingPad_2
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
jclass &clz = cls5;
jfieldID &fld = fld1;
D2C_RESOLVE_STATIC_FIELD(clz, fld, "java/lang/Integer", "TYPE", "Ljava/lang/Class;");
v7 = (jobject) env->GetStaticObjectField(clz,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L6:
LOGD("2a:aput-object \x76\x34\x2c\x20\x76\x33\x2c\x20\x76\x31");
{
#define EX_HANDLE EX_LandingPad_2
D2C_NOT_NULL(v6);
env->SetObjectArrayElement((jobjectArray) v6, (jint) v2, v7);D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L7:
LOGD("2e:const-string \x76\x34\x2c\x20\x27\x73\x65\x74\x4d\x69\x78\x65\x64\x43\x6f\x6e\x74\x65\x6e\x74\x4d\x6f\x64\x65\x27");
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
v7 = (jstring) env->NewStringUTF("\x73\x65\x74\x4d\x69\x78\x65\x64\x43\x6f\x6e\x74\x65\x6e\x74\x4d\x6f\x64\x65");
L8:
LOGD("32:invoke-virtual \x76\x30\x2c\x20\x76\x34\x2c\x20\x76\x33\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x6c\x61\x73\x73\x3b\x2d\x3e\x67\x65\x74\x4d\x65\x74\x68\x6f\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x20\x5b\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x6c\x61\x73\x73\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x72\x65\x66\x6c\x65\x63\x74\x2f\x4d\x65\x74\x68\x6f\x64\x3b");
{
#define EX_HANDLE EX_LandingPad_8
D2C_NOT_NULL(v5);
jclass &clz = cls4;
jmethodID &mid = mth2;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/Class", "getMethod", "(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;");
jvalue args[] = {{.l = v7},{.l = v6}};
v4 = (jobject) env->CallObjectMethodA(v5, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L9:
LOGD("38:move-result-object \x76\x30");
if (v5) {
LOGD("env->DeleteLocalRef(%p):v5", v5);
env->DeleteLocalRef(v5);
}
v5 = (jobject) v4;
L10:
LOGD("3a:invoke-virtual \x76\x35\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x56\x69\x65\x77\x3b\x2d\x3e\x67\x65\x74\x53\x65\x74\x74\x69\x6e\x67\x73\x28\x29\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x53\x65\x74\x74\x69\x6e\x67\x73\x3b");
{
#define EX_HANDLE EX_LandingPad_8
D2C_NOT_NULL(v0);
jclass &clz = cls1;
jmethodID &mid = mth0;
D2C_RESOLVE_METHOD(clz, mid, "android/webkit/WebView", "getSettings", "()Landroid/webkit/WebSettings;");
jvalue args[] = {};
v4 = (jobject) env->CallObjectMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L11:
LOGD("40:move-result-object \x76\x35");
if (v0) {
LOGD("env->DeleteLocalRef(%p):v0", v0);
env->DeleteLocalRef(v0);
}
v0 = (jobject) v4;
L12:
LOGD("42:new-array \x76\x32\x2c\x20\x76\x32\x2c\x20\x5b\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b");
{
#define EX_HANDLE EX_LandingPad_8
if (v3 < 0) {
d2c_throw_exception(env, "java/lang/NegativeArraySizeException", "negative array size");
goto EX_HANDLE;
}
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
jclass &clz = cls6;
D2C_RESOLVE_CLASS(clz,"java/lang/Object");
v8 = env->NewObjectArray((jint) v3, clz, NULL);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L13:
LOGD("46:invoke-static \x76\x31\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x49\x6e\x74\x65\x67\x65\x72\x3b\x2d\x3e\x76\x61\x6c\x75\x65\x4f\x66\x28\x49\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x49\x6e\x74\x65\x67\x65\x72\x3b");
{
#define EX_HANDLE EX_LandingPad_8
jclass &clz = cls5;
jmethodID &mid = mth3;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "java/lang/Integer", "valueOf", "(I)Ljava/lang/Integer;");
jvalue args[] = {{.i = v2}};
v4 = (jobject) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L14:
LOGD("4c:move-result-object \x76\x33");
if (v6) {
LOGD("env->DeleteLocalRef(%p):v6", v6);
env->DeleteLocalRef(v6);
}
v6 = (jobject) v4;
L15:
LOGD("4e:aput-object \x76\x33\x2c\x20\x76\x32\x2c\x20\x76\x31");
{
#define EX_HANDLE EX_LandingPad_8
D2C_NOT_NULL(v8);
env->SetObjectArrayElement((jobjectArray) v8, (jint) v2, v6);D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L16:
LOGD("52:invoke-virtual \x76\x30\x2c\x20\x76\x35\x2c\x20\x76\x32\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x72\x65\x66\x6c\x65\x63\x74\x2f\x4d\x65\x74\x68\x6f\x64\x3b\x2d\x3e\x69\x6e\x76\x6f\x6b\x65\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b\x20\x5b\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b");
{
#define EX_HANDLE EX_LandingPad_8
D2C_NOT_NULL(v5);
jclass &clz = cls7;
jmethodID &mid = mth4;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/reflect/Method", "invoke", "(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;");
jvalue args[] = {{.l = v0},{.l = v8}};
v4 = (jobject) env->CallObjectMethodA(v5, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
L17:
goto L19;
L18:
LOGD("5a:move-exception \x76\x35");
if (v0) {
LOGD("env->DeleteLocalRef(%p):v0", v0);
env->DeleteLocalRef(v0);
}
v0 = exception;
LOGD("5c:invoke-virtual \x76\x35\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x54\x68\x72\x6f\x77\x61\x62\x6c\x65\x3b\x2d\x3e\x70\x72\x69\x6e\x74\x53\x74\x61\x63\x6b\x54\x72\x61\x63\x65\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls8;
jmethodID &mid = mth5;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/Throwable", "printStackTrace", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L19:
return;

EX_LandingPad_2:
D2C_GET_PENDING_EX
if(d2c_is_instance_of(env, exception, "java/lang/Throwable")) {
goto L18;
}
D2C_GOTO_UNWINDBLOCK

EX_LandingPad_8:
D2C_GET_PENDING_EX
if(d2c_is_instance_of(env, exception, "java/lang/Throwable")) {
goto L18;
}
D2C_GOTO_UNWINDBLOCK
EX_UnwindBlock: return;
}
