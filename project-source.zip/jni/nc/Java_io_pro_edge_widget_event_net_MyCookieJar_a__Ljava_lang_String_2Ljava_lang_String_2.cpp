#include "Dex2C.h"

/* Lio/pro/edge/widget/event/net/MyCookieJar;->a(Ljava/lang/String;Ljava/lang/String;)V */
extern "C" JNIEXPORT void JNICALL
Java_io_pro_edge_widget_event_net_MyCookieJar_a__Ljava_lang_String_2Ljava_lang_String_2(JNIEnv *env, jobject thiz, jstring p5, jstring p6){
jobject v0 = NULL;
jobject v1 = NULL;
jobject v2 = NULL;
jint v3;
jint v4;
jobject v5 = NULL;
jobject v6 = NULL;
jint v7;
jint v8;
jobject v9 = NULL;
jclass cls0 = NULL,cls1 = NULL,cls2 = NULL,cls3 = NULL,cls4 = NULL,cls5 = NULL,cls6 = NULL,cls7 = NULL,cls8 = NULL;
jfieldID fld0 = NULL;
jmethodID mth0 = NULL, mth1 = NULL, mth2 = NULL, mth3 = NULL, mth4 = NULL, mth5 = NULL, mth6 = NULL, mth7 = NULL, mth8 = NULL, mth9 = NULL, mth10 = NULL, mth11 = NULL;
v0 = (jobject)env->NewLocalRef(thiz);
v1 = (jobject)env->NewLocalRef(p5);
v2 = (jobject)env->NewLocalRef(p6);
L0:
LOGD("0:invoke-static \x76\x35\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x74\x65\x78\x74\x2f\x54\x65\x78\x74\x55\x74\x69\x6c\x73\x3b\x2d\x3e\x69\x73\x45\x6d\x70\x74\x79\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x68\x61\x72\x53\x65\x71\x75\x65\x6e\x63\x65\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls0;
jmethodID &mid = mth0;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "android/text/TextUtils", "isEmpty", "(Ljava/lang/CharSequence;)Z");
jvalue args[] = {{.l = v1}};
v3 = (jboolean) env->CallStaticBooleanMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("6:move-result \x76\x30");
v4 = (jint) v3;
LOGD("8:if-nez \x76\x30\x2c\x20\x2b\x34\x62");
if(v4 != 0){
goto L15;
}
else {
goto L1;
}
L1:
LOGD("c:invoke-static \x76\x36\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x74\x65\x78\x74\x2f\x54\x65\x78\x74\x55\x74\x69\x6c\x73\x3b\x2d\x3e\x69\x73\x45\x6d\x70\x74\x79\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x68\x61\x72\x53\x65\x71\x75\x65\x6e\x63\x65\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls0;
jmethodID &mid = mth0;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "android/text/TextUtils", "isEmpty", "(Ljava/lang/CharSequence;)Z");
jvalue args[] = {{.l = v2}};
v3 = (jboolean) env->CallStaticBooleanMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("12:move-result \x76\x30");
v4 = (jint) v3;
LOGD("14:if-eqz \x76\x30\x2c\x20\x2b\x33");
if(v4 == 0){
goto L3;
}
else {
goto L2;
}
L2:
goto L15;
L3:
LOGD("1a:invoke-static \x76\x35\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x48\x74\x74\x70\x55\x72\x6c\x3b\x2d\x3e\x70\x61\x72\x73\x65\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x48\x74\x74\x70\x55\x72\x6c\x3b");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls1;
jmethodID &mid = mth1;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "okhttp3/HttpUrl", "parse", "(Ljava/lang/String;)Lokhttp3/HttpUrl;");
jvalue args[] = {{.l = v1}};
v5 = (jobject) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("20:move-result-object \x76\x35");
if (v1) {
LOGD("env->DeleteLocalRef(%p):v1", v1);
env->DeleteLocalRef(v1);
}
v1 = (jobject) v5;
LOGD("22:if-nez \x76\x35\x2c\x20\x2b\x33");
if(v1 != NULL){
goto L5;
}
else {
goto L4;
}
L4:
return;
L5:
LOGD("28:const-string \x76\x30\x2c\x20\x27\x3b\x27");
if (v6) {
LOGD("env->DeleteLocalRef(%p):v6", v6);
env->DeleteLocalRef(v6);
}
v6 = (jstring) env->NewStringUTF("\x3b");
LOGD("2c:invoke-virtual \x76\x36\x2c\x20\x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x73\x70\x6c\x69\x74\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x5b\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
jclass &clz = cls2;
jmethodID &mid = mth2;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "split", "(Ljava/lang/String;)[Ljava/lang/String;");
jvalue args[] = {{.l = v6}};
v5 = (jarray) env->CallObjectMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("32:move-result-object \x76\x36");
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
v2 = (jobject) v5;
LOGD("34:new-instance \x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x41\x72\x72\x61\x79\x4c\x69\x73\x74\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v6) {
LOGD("env->DeleteLocalRef(%p):v6", v6);
env->DeleteLocalRef(v6);
}
jclass &clz = cls3;
D2C_RESOLVE_CLASS(clz,"java/util/ArrayList");
v6 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("38:invoke-direct \x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x41\x72\x72\x61\x79\x4c\x69\x73\x74\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v6);
jclass &clz = cls3;
jmethodID &mid = mth3;
D2C_RESOLVE_METHOD(clz, mid, "java/util/ArrayList", "<init>", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v6, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("3e:array-length \x76\x31\x2c\x20\x76\x36");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
v7 = env->GetArrayLength((jarray) v2);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
v8 = 0;
L6:
LOGD("42:if-ge \x76\x32\x2c\x20\x76\x31\x2c\x20\x2b\x31\x31");
if(v8 >= v7) {
goto L11;
}
else {
goto L7;
}
L7:
LOGD("46:aget-object \x76\x33\x2c\x20\x76\x36\x2c\x20\x76\x32");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
v5 = (jstring) env->GetObjectArrayElement((jobjectArray) v2, (jint) v8);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v9) {
LOGD("env->DeleteLocalRef(%p):v9", v9);
env->DeleteLocalRef(v9);
}
v9 = (jobject) v5;
LOGD("4a:invoke-static \x76\x35\x2c\x20\x76\x33\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x43\x6f\x6f\x6b\x69\x65\x3b\x2d\x3e\x70\x61\x72\x73\x65\x28\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x48\x74\x74\x70\x55\x72\x6c\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x43\x6f\x6f\x6b\x69\x65\x3b");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls4;
jmethodID &mid = mth4;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "okhttp3/Cookie", "parse", "(Lokhttp3/HttpUrl;Ljava/lang/String;)Lokhttp3/Cookie;");
jvalue args[] = {{.l = v1},{.l = v9}};
v5 = (jobject) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("50:move-result-object \x76\x33");
if (v9) {
LOGD("env->DeleteLocalRef(%p):v9", v9);
env->DeleteLocalRef(v9);
}
v9 = (jobject) v5;
LOGD("52:if-nez \x76\x33\x2c\x20\x2b\x33");
if(v9 != NULL){
goto L9;
}
else {
goto L8;
}
L8:
goto L10;
L9:
LOGD("58:invoke-interface \x76\x30\x2c\x20\x76\x33\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x4c\x69\x73\x74\x3b\x2d\x3e\x61\x64\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v6);
jclass &clz = cls5;
jmethodID &mid = mth5;
D2C_RESOLVE_METHOD(clz, mid, "java/util/List", "add", "(Ljava/lang/Object;)Z");
jvalue args[] = {{.l = v9}};
v3 = (jboolean) env->CallBooleanMethodA(v6, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L10:
LOGD("5e:add-int/lit8 \x76\x32\x2c\x20\x76\x32\x2c\x20\x31");
v8 = (v8 + 1);
goto L6;
L11:
LOGD("64:iget-object \x76\x36\x2c\x20\x76\x34\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4d\x79\x43\x6f\x6f\x6b\x69\x65\x4a\x61\x72\x3b\x2d\x3e\x61\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x48\x61\x73\x68\x4d\x61\x70\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls6;
jfieldID &fld = fld0;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/net/MyCookieJar", "a", "Ljava/util/HashMap;");
v5 = (jobject) env->GetObjectField(v0,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
v2 = (jobject) v5;
LOGD("68:invoke-virtual \x76\x36\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x48\x61\x73\x68\x4d\x61\x70\x3b\x2d\x3e\x63\x6c\x65\x61\x72\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
jclass &clz = cls7;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/util/HashMap", "clear", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("6e:iget-object \x76\x36\x2c\x20\x76\x34\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4d\x79\x43\x6f\x6f\x6b\x69\x65\x4a\x61\x72\x3b\x2d\x3e\x61\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x48\x61\x73\x68\x4d\x61\x70\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls6;
jfieldID &fld = fld0;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/net/MyCookieJar", "a", "Ljava/util/HashMap;");
v5 = (jobject) env->GetObjectField(v0,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
v2 = (jobject) v5;
LOGD("72:invoke-virtual \x76\x35\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x48\x74\x74\x70\x55\x72\x6c\x3b\x2d\x3e\x68\x6f\x73\x74\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v1);
jclass &clz = cls1;
jmethodID &mid = mth7;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/HttpUrl", "host", "()Ljava/lang/String;");
jvalue args[] = {};
v5 = (jstring) env->CallObjectMethodA(v1, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("78:move-result-object \x76\x35");
if (v1) {
LOGD("env->DeleteLocalRef(%p):v1", v1);
env->DeleteLocalRef(v1);
}
v1 = (jobject) v5;
LOGD("7a:invoke-interface \x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x4c\x69\x73\x74\x3b\x2d\x3e\x73\x69\x7a\x65\x28\x29\x49");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v6);
jclass &clz = cls5;
jmethodID &mid = mth8;
D2C_RESOLVE_METHOD(clz, mid, "java/util/List", "size", "()I");
jvalue args[] = {};
v3 = (jint) env->CallIntMethodA(v6, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("80:move-result \x76\x31");
v7 = (jint) v3;
LOGD("82:if-eqz \x76\x31\x2c\x20\x2b\x37");
if(v7 == 0){
goto L13;
}
else {
goto L12;
}
L12:
LOGD("86:invoke-static \x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x43\x6f\x6c\x6c\x65\x63\x74\x69\x6f\x6e\x73\x3b\x2d\x3e\x75\x6e\x6d\x6f\x64\x69\x66\x69\x61\x62\x6c\x65\x4c\x69\x73\x74\x28\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x4c\x69\x73\x74\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x4c\x69\x73\x74\x3b");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls8;
jmethodID &mid = mth9;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "java/util/Collections", "unmodifiableList", "(Ljava/util/List;)Ljava/util/List;");
jvalue args[] = {{.l = v6}};
v5 = (jobject) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("8c:move-result-object \x76\x30");
if (v6) {
LOGD("env->DeleteLocalRef(%p):v6", v6);
env->DeleteLocalRef(v6);
}
v6 = (jobject) v5;
goto L14;
L13:
LOGD("90:invoke-static \x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x43\x6f\x6c\x6c\x65\x63\x74\x69\x6f\x6e\x73\x3b\x2d\x3e\x65\x6d\x70\x74\x79\x4c\x69\x73\x74\x28\x29\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x4c\x69\x73\x74\x3b");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls8;
jmethodID &mid = mth10;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "java/util/Collections", "emptyList", "()Ljava/util/List;");
jvalue args[] = {};
v5 = (jobject) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("96:move-result-object \x76\x30");
if (v6) {
LOGD("env->DeleteLocalRef(%p):v6", v6);
env->DeleteLocalRef(v6);
}
v6 = (jobject) v5;
L14:
LOGD("98:invoke-virtual \x76\x36\x2c\x20\x76\x35\x2c\x20\x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x48\x61\x73\x68\x4d\x61\x70\x3b\x2d\x3e\x70\x75\x74\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
jclass &clz = cls7;
jmethodID &mid = mth11;
D2C_RESOLVE_METHOD(clz, mid, "java/util/HashMap", "put", "(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;");
jvalue args[] = {{.l = v1},{.l = v6}};
v5 = (jobject) env->CallObjectMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v5) {
LOGD("env->DeleteLocalRef(%p):v5", v5);
env->DeleteLocalRef(v5);
}
L15:
return;
EX_UnwindBlock: return;
}
