#include "Dex2C.h"

/* Lio/pro/edge/widget/event/utils/Transfer;->e()V */
extern "C" JNIEXPORT void JNICALL
Java_io_pro_edge_widget_event_utils_Transfer_e__(JNIEnv *env, jobject thiz){
jobject v0 = NULL;
jobject v1 = NULL;
jobject v2 = NULL;
jint v3;
jint v4;
jobject v5 = NULL;
jclass cls0 = NULL,cls1 = NULL,cls2 = NULL,cls3 = NULL,cls4 = NULL;
jfieldID fld0 = NULL,fld1 = NULL;
jmethodID mth0 = NULL, mth1 = NULL, mth2 = NULL, mth3 = NULL;
v0 = (jobject)env->NewLocalRef(thiz);
L0:
LOGD("0:iget-object \x76\x30\x2c\x20\x76\x32\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x75\x74\x69\x6c\x73\x2f\x54\x72\x61\x6e\x73\x66\x65\x72\x3b\x2d\x3e\x68\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jfieldID &fld = fld0;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/utils/Transfer", "h", "Ljava/lang/String;");
v1 = (jstring) env->GetObjectField(v0,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
v2 = (jobject) v1;
LOGD("4:invoke-static \x76\x30\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x74\x65\x78\x74\x2f\x54\x65\x78\x74\x55\x74\x69\x6c\x73\x3b\x2d\x3e\x69\x73\x45\x6d\x70\x74\x79\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x68\x61\x72\x53\x65\x71\x75\x65\x6e\x63\x65\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls1;
jmethodID &mid = mth0;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "android/text/TextUtils", "isEmpty", "(Ljava/lang/CharSequence;)Z");
jvalue args[] = {{.l = v2}};
v3 = (jboolean) env->CallStaticBooleanMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("a:move-result \x76\x30");
v4 = (jint) v3;
LOGD("c:if-nez \x76\x30\x2c\x20\x2b\x31\x36");
if(v4 != 0){
goto L3;
}
else {
goto L1;
}
L1:
LOGD("10:iget-object \x76\x30\x2c\x20\x76\x32\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x75\x74\x69\x6c\x73\x2f\x54\x72\x61\x6e\x73\x66\x65\x72\x3b\x2d\x3e\x68\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jfieldID &fld = fld0;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/utils/Transfer", "h", "Ljava/lang/String;");
v1 = (jstring) env->GetObjectField(v0,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
v2 = (jobject) v1;
LOGD("14:const-string \x76\x31\x2c\x20\x27\x7b\x7b\x74\x72\x61\x63\x65\x7d\x7d\x27");
if (v5) {
LOGD("env->DeleteLocalRef(%p):v5", v5);
env->DeleteLocalRef(v5);
}
v5 = (jobject) env->NewStringUTF("\x7b\x7b\x74\x72\x61\x63\x65\x7d\x7d");
LOGD("18:invoke-virtual \x76\x30\x2c\x20\x76\x31\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x63\x6f\x6e\x74\x61\x69\x6e\x73\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x68\x61\x72\x53\x65\x71\x75\x65\x6e\x63\x65\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
jclass &clz = cls2;
jmethodID &mid = mth1;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "contains", "(Ljava/lang/CharSequence;)Z");
jvalue args[] = {{.l = v5}};
v3 = (jboolean) env->CallBooleanMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("1e:move-result \x76\x30");
v4 = (jint) v3;
LOGD("20:if-eqz \x76\x30\x2c\x20\x2b\x63");
if(v4 == 0){
goto L3;
}
else {
goto L2;
}
L2:
LOGD("24:iget-object \x76\x30\x2c\x20\x76\x32\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x75\x74\x69\x6c\x73\x2f\x54\x72\x61\x6e\x73\x66\x65\x72\x3b\x2d\x3e\x63\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x56\x69\x65\x77\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jfieldID &fld = fld1;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/utils/Transfer", "c", "Landroid/webkit/WebView;");
v1 = (jobject) env->GetObjectField(v0,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
v2 = (jobject) v1;
LOGD("28:new-instance \x76\x31\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x75\x74\x69\x6c\x73\x2f\x54\x72\x61\x6e\x73\x66\x65\x72\x24\x32\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v5) {
LOGD("env->DeleteLocalRef(%p):v5", v5);
env->DeleteLocalRef(v5);
}
jclass &clz = cls3;
D2C_RESOLVE_CLASS(clz,"io/pro/edge/widget/event/utils/Transfer$2");
v5 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("2c:invoke-direct \x76\x31\x2c\x20\x76\x32\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x75\x74\x69\x6c\x73\x2f\x54\x72\x61\x6e\x73\x66\x65\x72\x24\x32\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x75\x74\x69\x6c\x73\x2f\x54\x72\x61\x6e\x73\x66\x65\x72\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v5);
jclass &clz = cls3;
jmethodID &mid = mth2;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/event/utils/Transfer$2", "<init>", "(Lio/pro/edge/widget/event/utils/Transfer;)V");
jvalue args[] = {{.l = v0}};
env->CallVoidMethodA(v5, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("32:invoke-virtual \x76\x30\x2c\x20\x76\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x56\x69\x65\x77\x3b\x2d\x3e\x70\x6f\x73\x74\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x52\x75\x6e\x6e\x61\x62\x6c\x65\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
jclass &clz = cls4;
jmethodID &mid = mth3;
D2C_RESOLVE_METHOD(clz, mid, "android/webkit/WebView", "post", "(Ljava/lang/Runnable;)Z");
jvalue args[] = {{.l = v5}};
v3 = (jboolean) env->CallBooleanMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L3:
return;
EX_UnwindBlock: return;
}
