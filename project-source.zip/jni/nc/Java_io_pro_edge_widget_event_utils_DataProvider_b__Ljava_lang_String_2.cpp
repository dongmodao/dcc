#include "Dex2C.h"

/* Lio/pro/edge/widget/event/utils/DataProvider;->b(Ljava/lang/String;)Ljava/util/List; */
extern "C" JNIEXPORT jobject JNICALL
Java_io_pro_edge_widget_event_utils_DataProvider_b__Ljava_lang_String_2(JNIEnv *env, jobject thiz, jstring p3){
jobject v0 = NULL;
jint v1;
jint v2;
jobject v3 = NULL;
jobject v4 = NULL;
jint v5;
jint v6;
jobject v7 = NULL;
jthrowable exception;
jclass cls0 = NULL,cls1 = NULL,cls2 = NULL,cls3 = NULL,cls4 = NULL,cls5 = NULL;
jmethodID mth0 = NULL, mth1 = NULL, mth2 = NULL, mth3 = NULL, mth4 = NULL, mth5 = NULL, mth6 = NULL, mth7 = NULL;
v0 = (jobject)env->NewLocalRef(p3);
L0:
LOGD("0:invoke-static \x76\x33\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x74\x65\x78\x74\x2f\x54\x65\x78\x74\x55\x74\x69\x6c\x73\x3b\x2d\x3e\x69\x73\x45\x6d\x70\x74\x79\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x68\x61\x72\x53\x65\x71\x75\x65\x6e\x63\x65\x3b\x29\x5a");
{
#define EX_HANDLE EX_LandingPad_0
jclass &clz = cls0;
jmethodID &mid = mth0;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "android/text/TextUtils", "isEmpty", "(Ljava/lang/CharSequence;)Z");
jvalue args[] = {{.l = v0}};
v1 = (jboolean) env->CallStaticBooleanMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L1:
LOGD("6:move-result \x76\x30");
v2 = (jint) v1;
LOGD("8:if-nez \x76\x30\x2c\x20\x2b\x32\x38");
if(v2 != 0){
goto L18;
}
else {
goto L2;
}
L2:
LOGD("c:new-instance \x76\x30\x2c\x20\x4c\x6f\x72\x67\x2f\x6a\x73\x6f\x6e\x2f\x4a\x53\x4f\x4e\x4f\x62\x6a\x65\x63\x74\x3b");
{
#define EX_HANDLE EX_LandingPad_0
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
jclass &clz = cls1;
D2C_RESOLVE_CLASS(clz,"org/json/JSONObject");
v3 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L3:
LOGD("10:invoke-direct \x76\x30\x2c\x20\x76\x33\x2c\x20\x4c\x6f\x72\x67\x2f\x6a\x73\x6f\x6e\x2f\x4a\x53\x4f\x4e\x4f\x62\x6a\x65\x63\x74\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x56");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v3);
jclass &clz = cls1;
jmethodID &mid = mth1;
D2C_RESOLVE_METHOD(clz, mid, "org/json/JSONObject", "<init>", "(Ljava/lang/String;)V");
jvalue args[] = {{.l = v0}};
env->CallVoidMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L4:
LOGD("16:const-string \x76\x33\x2c\x20\x27\x73\x70\x27");
if (v0) {
LOGD("env->DeleteLocalRef(%p):v0", v0);
env->DeleteLocalRef(v0);
}
v0 = (jstring) env->NewStringUTF("\x73\x70");
L5:
LOGD("1a:invoke-virtual \x76\x30\x2c\x20\x76\x33\x2c\x20\x4c\x6f\x72\x67\x2f\x6a\x73\x6f\x6e\x2f\x4a\x53\x4f\x4e\x4f\x62\x6a\x65\x63\x74\x3b\x2d\x3e\x6f\x70\x74\x4a\x53\x4f\x4e\x41\x72\x72\x61\x79\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6f\x72\x67\x2f\x6a\x73\x6f\x6e\x2f\x4a\x53\x4f\x4e\x41\x72\x72\x61\x79\x3b");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v3);
jclass &clz = cls1;
jmethodID &mid = mth2;
D2C_RESOLVE_METHOD(clz, mid, "org/json/JSONObject", "optJSONArray", "(Ljava/lang/String;)Lorg/json/JSONArray;");
jvalue args[] = {{.l = v0}};
v4 = (jobject) env->CallObjectMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L6:
LOGD("20:move-result-object \x76\x33");
if (v0) {
LOGD("env->DeleteLocalRef(%p):v0", v0);
env->DeleteLocalRef(v0);
}
v0 = (jobject) v4;
L7:
LOGD("22:new-instance \x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x41\x72\x72\x61\x79\x4c\x69\x73\x74\x3b");
{
#define EX_HANDLE EX_LandingPad_0
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
jclass &clz = cls2;
D2C_RESOLVE_CLASS(clz,"java/util/ArrayList");
v3 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L8:
LOGD("26:invoke-direct \x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x41\x72\x72\x61\x79\x4c\x69\x73\x74\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x29\x56");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v3);
jclass &clz = cls2;
jmethodID &mid = mth3;
D2C_RESOLVE_METHOD(clz, mid, "java/util/ArrayList", "<init>", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L9:
v5 = 0;
L10:
LOGD("2e:invoke-virtual \x76\x33\x2c\x20\x4c\x6f\x72\x67\x2f\x6a\x73\x6f\x6e\x2f\x4a\x53\x4f\x4e\x41\x72\x72\x61\x79\x3b\x2d\x3e\x6c\x65\x6e\x67\x74\x68\x28\x29\x49");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v0);
jclass &clz = cls3;
jmethodID &mid = mth4;
D2C_RESOLVE_METHOD(clz, mid, "org/json/JSONArray", "length", "()I");
jvalue args[] = {};
v1 = (jint) env->CallIntMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L11:
LOGD("34:move-result \x76\x32");
v6 = (jint) v1;
LOGD("36:if-ge \x76\x31\x2c\x20\x76\x32\x2c\x20\x2b\x63");
if(v5 >= v6) {
goto L16;
}
else {
goto L12;
}
L12:
LOGD("3a:invoke-virtual \x76\x33\x2c\x20\x76\x31\x2c\x20\x4c\x6f\x72\x67\x2f\x6a\x73\x6f\x6e\x2f\x4a\x53\x4f\x4e\x41\x72\x72\x61\x79\x3b\x2d\x3e\x67\x65\x74\x4a\x53\x4f\x4e\x4f\x62\x6a\x65\x63\x74\x28\x49\x29\x4c\x6f\x72\x67\x2f\x6a\x73\x6f\x6e\x2f\x4a\x53\x4f\x4e\x4f\x62\x6a\x65\x63\x74\x3b");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v0);
jclass &clz = cls3;
jmethodID &mid = mth5;
D2C_RESOLVE_METHOD(clz, mid, "org/json/JSONArray", "getJSONObject", "(I)Lorg/json/JSONObject;");
jvalue args[] = {{.i = v5}};
v4 = (jobject) env->CallObjectMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L13:
LOGD("40:move-result-object \x76\x32");
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
v7 = (jobject) v4;
L14:
LOGD("42:invoke-interface \x76\x30\x2c\x20\x76\x32\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x4c\x69\x73\x74\x3b\x2d\x3e\x61\x64\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b\x29\x5a");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v3);
jclass &clz = cls4;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/util/List", "add", "(Ljava/lang/Object;)Z");
jvalue args[] = {{.l = v7}};
v1 = (jboolean) env->CallBooleanMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L15:
LOGD("48:add-int/lit8 \x76\x31\x2c\x20\x76\x31\x2c\x20\x31");
v5 = (v5 + 1);
goto L10;
L16:
return (jobject) v3;
L17:
LOGD("50:move-exception \x76\x33");
if (v0) {
LOGD("env->DeleteLocalRef(%p):v0", v0);
env->DeleteLocalRef(v0);
}
v0 = exception;
LOGD("52:invoke-virtual \x76\x33\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3b\x2d\x3e\x70\x72\x69\x6e\x74\x53\x74\x61\x63\x6b\x54\x72\x61\x63\x65\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls5;
jmethodID &mid = mth7;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/Exception", "printStackTrace", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L18:
if (v0) {
LOGD("env->DeleteLocalRef(%p):v0", v0);
env->DeleteLocalRef(v0);
}
v0 = 0;
return (jobject) v0;

EX_LandingPad_0:
D2C_GET_PENDING_EX
if(d2c_is_instance_of(env, exception, "java/lang/Exception")) {
goto L17;
}
D2C_GOTO_UNWINDBLOCK
EX_UnwindBlock: return NULL;
}
