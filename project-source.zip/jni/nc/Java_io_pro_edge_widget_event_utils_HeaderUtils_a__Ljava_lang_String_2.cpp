#include "Dex2C.h"

/* Lio/pro/edge/widget/event/utils/HeaderUtils;->a(Ljava/lang/String;)Ljava/lang/String; */
extern "C" JNIEXPORT jstring JNICALL
Java_io_pro_edge_widget_event_utils_HeaderUtils_a__Ljava_lang_String_2(JNIEnv *env, jobject thiz, jstring p10){
jobject v0 = NULL;
jobject v1 = NULL;
jint v2;
jint v3;
jobject v4 = NULL;
jobject v5 = NULL;
jint v6;
jint v7;
jint v8;
jint v9;
jint v10;
jint v11;
jint v12;
jint v13;
jobject v14 = NULL;
jobject v15 = NULL;
jthrowable exception;
jclass cls0 = NULL,cls1 = NULL,cls2 = NULL,cls3 = NULL;
jmethodID mth0 = NULL, mth1 = NULL, mth2 = NULL, mth3 = NULL, mth4 = NULL, mth5 = NULL, mth6 = NULL, mth7 = NULL, mth8 = NULL, mth9 = NULL, mth10 = NULL;
v0 = (jobject)env->NewLocalRef(p10);
L0:
LOGD("0:const-string \x76\x30\x2c\x20\x27\x2d\x27");
if (v1) {
LOGD("env->DeleteLocalRef(%p):v1", v1);
env->DeleteLocalRef(v1);
}
v1 = (jstring) env->NewStringUTF("\x2d");
LOGD("4:invoke-static \x76\x31\x30\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x74\x65\x78\x74\x2f\x54\x65\x78\x74\x55\x74\x69\x6c\x73\x3b\x2d\x3e\x69\x73\x45\x6d\x70\x74\x79\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x68\x61\x72\x53\x65\x71\x75\x65\x6e\x63\x65\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls0;
jmethodID &mid = mth0;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "android/text/TextUtils", "isEmpty", "(Ljava/lang/CharSequence;)Z");
jvalue args[] = {{.l = v0}};
v2 = (jboolean) env->CallStaticBooleanMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("a:move-result \x76\x31");
v3 = (jint) v2;
LOGD("c:if-eqz \x76\x31\x2c\x20\x2b\x35");
if(v3 == 0){
goto L2;
}
else {
goto L1;
}
L1:
LOGD("10:const-string \x76\x31\x30\x2c\x20\x27\x27");
if (v0) {
LOGD("env->DeleteLocalRef(%p):v0", v0);
env->DeleteLocalRef(v0);
}
v0 = (jstring) env->NewStringUTF("");
return (jstring) v0;
L2:
LOGD("16:invoke-virtual \x76\x31\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x74\x6f\x4c\x6f\x77\x65\x72\x43\x61\x73\x65\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls1;
jmethodID &mid = mth1;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "toLowerCase", "()Ljava/lang/String;");
jvalue args[] = {};
v4 = (jstring) env->CallObjectMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("1c:move-result-object \x76\x31");
if (v5) {
LOGD("env->DeleteLocalRef(%p):v5", v5);
env->DeleteLocalRef(v5);
}
v5 = (jobject) v4;
v6 = -1;
LOGD("20:invoke-virtual \x76\x31\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x68\x61\x73\x68\x43\x6f\x64\x65\x28\x29\x49");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v5);
jclass &clz = cls1;
jmethodID &mid = mth2;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "hashCode", "()I");
jvalue args[] = {};
v2 = (jint) env->CallIntMethodA(v5, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("26:move-result \x76\x33");
v7 = (jint) v2;
v8 = 5;
v9 = 4;
v10 = 3;
v11 = 2;
v12 = 1;
v12 = 1;
v13 = 0;
v13 = 0;
v13 = 0;
v13 = 0;
v13 = 0;
switch (v7) {
case -2117827766: goto L14;
case -390305238: goto L12;
case 3697: goto L10;
case 99626: goto L8;
case 114655: goto L6;
case 1043627653: goto L4;
}
L3:
goto L16;
L4:
LOGD("3c:const-string \x76\x33\x2c\x20\x27\x6c\x61\x73\x74\x2d\x65\x76\x65\x6e\x74\x2d\x69\x64\x27");
if (v14) {
LOGD("env->DeleteLocalRef(%p):v14", v14);
env->DeleteLocalRef(v14);
}
v14 = (jstring) env->NewStringUTF("\x6c\x61\x73\x74\x2d\x65\x76\x65\x6e\x74\x2d\x69\x64");
LOGD("40:invoke-virtual \x76\x31\x2c\x20\x76\x33\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x65\x71\x75\x61\x6c\x73\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v5);
jclass &clz = cls1;
jmethodID &mid = mth3;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "equals", "(Ljava/lang/Object;)Z");
jvalue args[] = {{.l = v14}};
v2 = (jboolean) env->CallBooleanMethodA(v5, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("46:move-result \x76\x31");
v3 = (jint) v2;
LOGD("48:if-eqz \x76\x31\x2c\x20\x2b\x33\x35");
if(v3 == 0){
goto L16;
}
else {
goto L5;
}
L5:
v6 = 2;
goto L16;
L6:
LOGD("50:const-string \x76\x33\x2c\x20\x27\x74\x63\x6e\x27");
if (v14) {
LOGD("env->DeleteLocalRef(%p):v14", v14);
env->DeleteLocalRef(v14);
}
v14 = (jstring) env->NewStringUTF("\x74\x63\x6e");
LOGD("54:invoke-virtual \x76\x31\x2c\x20\x76\x33\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x65\x71\x75\x61\x6c\x73\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v5);
jclass &clz = cls1;
jmethodID &mid = mth3;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "equals", "(Ljava/lang/Object;)Z");
jvalue args[] = {{.l = v14}};
v2 = (jboolean) env->CallBooleanMethodA(v5, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("5a:move-result \x76\x31");
v3 = (jint) v2;
LOGD("5c:if-eqz \x76\x31\x2c\x20\x2b\x32\x62");
if(v3 == 0){
goto L16;
}
else {
goto L7;
}
L7:
v6 = 1;
goto L16;
L8:
LOGD("64:const-string \x76\x33\x2c\x20\x27\x64\x6e\x74\x27");
if (v14) {
LOGD("env->DeleteLocalRef(%p):v14", v14);
env->DeleteLocalRef(v14);
}
v14 = (jstring) env->NewStringUTF("\x64\x6e\x74");
LOGD("68:invoke-virtual \x76\x31\x2c\x20\x76\x33\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x65\x71\x75\x61\x6c\x73\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v5);
jclass &clz = cls1;
jmethodID &mid = mth3;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "equals", "(Ljava/lang/Object;)Z");
jvalue args[] = {{.l = v14}};
v2 = (jboolean) env->CallBooleanMethodA(v5, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("6e:move-result \x76\x31");
v3 = (jint) v2;
LOGD("70:if-eqz \x76\x31\x2c\x20\x2b\x32\x31");
if(v3 == 0){
goto L16;
}
else {
goto L9;
}
L9:
v6 = 3;
goto L16;
L10:
LOGD("78:const-string \x76\x33\x2c\x20\x27\x74\x65\x27");
if (v14) {
LOGD("env->DeleteLocalRef(%p):v14", v14);
env->DeleteLocalRef(v14);
}
v14 = (jstring) env->NewStringUTF("\x74\x65");
LOGD("7c:invoke-virtual \x76\x31\x2c\x20\x76\x33\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x65\x71\x75\x61\x6c\x73\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v5);
jclass &clz = cls1;
jmethodID &mid = mth3;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "equals", "(Ljava/lang/Object;)Z");
jvalue args[] = {{.l = v14}};
v2 = (jboolean) env->CallBooleanMethodA(v5, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("82:move-result \x76\x31");
v3 = (jint) v2;
LOGD("84:if-eqz \x76\x31\x2c\x20\x2b\x31\x37");
if(v3 == 0){
goto L16;
}
else {
goto L11;
}
L11:
v6 = 0;
goto L16;
L12:
LOGD("8c:const-string \x76\x33\x2c\x20\x27\x63\x6f\x6e\x74\x65\x6e\x74\x2d\x6d\x64\x35\x27");
if (v14) {
LOGD("env->DeleteLocalRef(%p):v14", v14);
env->DeleteLocalRef(v14);
}
v14 = (jstring) env->NewStringUTF("\x63\x6f\x6e\x74\x65\x6e\x74\x2d\x6d\x64\x35");
LOGD("90:invoke-virtual \x76\x31\x2c\x20\x76\x33\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x65\x71\x75\x61\x6c\x73\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v5);
jclass &clz = cls1;
jmethodID &mid = mth3;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "equals", "(Ljava/lang/Object;)Z");
jvalue args[] = {{.l = v14}};
v2 = (jboolean) env->CallBooleanMethodA(v5, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("96:move-result \x76\x31");
v3 = (jint) v2;
LOGD("98:if-eqz \x76\x31\x2c\x20\x2b\x64");
if(v3 == 0){
goto L16;
}
else {
goto L13;
}
L13:
v6 = 4;
goto L16;
L14:
LOGD("a0:const-string \x76\x33\x2c\x20\x27\x61\x63\x63\x65\x70\x74\x2d\x63\x68\x27");
if (v14) {
LOGD("env->DeleteLocalRef(%p):v14", v14);
env->DeleteLocalRef(v14);
}
v14 = (jstring) env->NewStringUTF("\x61\x63\x63\x65\x70\x74\x2d\x63\x68");
LOGD("a4:invoke-virtual \x76\x31\x2c\x20\x76\x33\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x65\x71\x75\x61\x6c\x73\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v5);
jclass &clz = cls1;
jmethodID &mid = mth3;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "equals", "(Ljava/lang/Object;)Z");
jvalue args[] = {{.l = v14}};
v2 = (jboolean) env->CallBooleanMethodA(v5, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("aa:move-result \x76\x31");
v3 = (jint) v2;
LOGD("ac:if-eqz \x76\x31\x2c\x20\x2b\x33");
if(v3 == 0){
goto L16;
}
else {
goto L15;
}
L15:
v6 = 5;
L16:
LOGD("b2:if-eqz \x76\x32\x2c\x20\x2b\x36\x34");
if(v6 == 0){
goto L57;
}
else {
goto L17;
}
L17:
LOGD("b6:if-eq \x76\x32\x2c\x20\x76\x38\x2c\x20\x2b\x35\x66");
if(v6 == v12) {
goto L56;
}
else {
goto L18;
}
L18:
LOGD("ba:if-eq \x76\x32\x2c\x20\x76\x37\x2c\x20\x2b\x35\x61");
if(v6 == v11) {
goto L55;
}
else {
goto L19;
}
L19:
LOGD("be:if-eq \x76\x32\x2c\x20\x76\x36\x2c\x20\x2b\x35\x35");
if(v6 == v10) {
goto L54;
}
else {
goto L20;
}
L20:
LOGD("c2:if-eq \x76\x32\x2c\x20\x76\x35\x2c\x20\x2b\x35\x30");
if(v6 == v9) {
goto L53;
}
else {
goto L21;
}
L21:
LOGD("c6:if-eq \x76\x32\x2c\x20\x76\x34\x2c\x20\x2b\x34\x62");
if(v6 == v8) {
goto L52;
}
else {
goto L22;
}
L22:
LOGD("ca:invoke-virtual \x76\x31\x30\x2c\x20\x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x73\x70\x6c\x69\x74\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x5b\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_LandingPad_22
D2C_NOT_NULL(v0);
jclass &clz = cls1;
jmethodID &mid = mth4;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "split", "(Ljava/lang/String;)[Ljava/lang/String;");
jvalue args[] = {{.l = v1}};
v4 = (jarray) env->CallObjectMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L23:
LOGD("d0:move-result-object \x76\x31");
if (v5) {
LOGD("env->DeleteLocalRef(%p):v5", v5);
env->DeleteLocalRef(v5);
}
v5 = (jobject) v4;
v6 = 0;
L24:
LOGD("d4:array-length \x76\x33\x2c\x20\x76\x31");
{
#define EX_HANDLE EX_LandingPad_22
D2C_NOT_NULL(v5);
v7 = env->GetArrayLength((jarray) v5);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L25:
LOGD("d6:if-ge \x76\x32\x2c\x20\x76\x33\x2c\x20\x2b\x32\x34");
if(v6 >= v7) {
goto L40;
}
else {
goto L26;
}
L26:
LOGD("da:aget-object \x76\x33\x2c\x20\x76\x31\x2c\x20\x76\x32");
{
#define EX_HANDLE EX_LandingPad_22
D2C_NOT_NULL(v5);
v4 = (jstring) env->GetObjectArrayElement((jobjectArray) v5, (jint) v6);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v14) {
LOGD("env->DeleteLocalRef(%p):v14", v14);
env->DeleteLocalRef(v14);
}
v14 = (jobject) v4;
L27:
LOGD("de:invoke-virtual \x76\x33\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x74\x6f\x43\x68\x61\x72\x41\x72\x72\x61\x79\x28\x29\x5b\x43");
{
#define EX_HANDLE EX_LandingPad_22
D2C_NOT_NULL(v14);
jclass &clz = cls1;
jmethodID &mid = mth5;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "toCharArray", "()[C");
jvalue args[] = {};
v4 = (jarray) env->CallObjectMethodA(v14, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L28:
LOGD("e4:move-result-object \x76\x33");
if (v14) {
LOGD("env->DeleteLocalRef(%p):v14", v14);
env->DeleteLocalRef(v14);
}
v14 = (jobject) v4;
L29:
LOGD("e6:aget-char \x76\x34\x2c\x20\x76\x33\x2c\x20\x76\x39");
{
#define EX_HANDLE EX_LandingPad_22
D2C_NOT_NULL(v14);
{jchar val;env->GetCharArrayRegion((jcharArray) v14, (jint) v13, 1, &val);v8 = val;}
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L30:
v9 = 97;
LOGD("ee:if-lt \x76\x34\x2c\x20\x76\x35\x2c\x20\x2b\x66");
if(v8 < v9) {
goto L36;
}
else {
goto L31;
}
L31:
LOGD("f2:aget-char \x76\x34\x2c\x20\x76\x33\x2c\x20\x76\x39");
{
#define EX_HANDLE EX_LandingPad_22
D2C_NOT_NULL(v14);
{jchar val;env->GetCharArrayRegion((jcharArray) v14, (jint) v13, 1, &val);v8 = val;}
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L32:
v9 = 122;
LOGD("fa:if-gt \x76\x34\x2c\x20\x76\x35\x2c\x20\x2b\x39");
if(v8 > v9) {
goto L36;
}
else {
goto L33;
}
L33:
LOGD("fe:aget-char \x76\x34\x2c\x20\x76\x33\x2c\x20\x76\x39");
{
#define EX_HANDLE EX_LandingPad_22
D2C_NOT_NULL(v14);
{jchar val;env->GetCharArrayRegion((jcharArray) v14, (jint) v13, 1, &val);v8 = val;}
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L34:
LOGD("102:add-int/lit8 \x76\x34\x2c\x20\x76\x34\x2c\x20\x2d\x33\x32");
v8 = (v8 - 32);
v8 = (jchar)(v8);
L35:
LOGD("108:aput-char \x76\x34\x2c\x20\x76\x33\x2c\x20\x76\x39");
{
#define EX_HANDLE EX_LandingPad_22
D2C_NOT_NULL(v14);
{jchar val = v8;env->SetCharArrayRegion((jcharArray) v14, (jint) v13, 1, &val);}
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L36:
LOGD("10c:invoke-static \x76\x33\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x76\x61\x6c\x75\x65\x4f\x66\x28\x5b\x43\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_LandingPad_22
jclass &clz = cls1;
jmethodID &mid = mth6;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "java/lang/String", "valueOf", "([C)Ljava/lang/String;");
jvalue args[] = {{.l = v14}};
v4 = (jstring) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L37:
LOGD("112:move-result-object \x76\x33");
if (v14) {
LOGD("env->DeleteLocalRef(%p):v14", v14);
env->DeleteLocalRef(v14);
}
v14 = (jobject) v4;
L38:
LOGD("114:aput-object \x76\x33\x2c\x20\x76\x31\x2c\x20\x76\x32");
{
#define EX_HANDLE EX_LandingPad_22
D2C_NOT_NULL(v5);
env->SetObjectArrayElement((jobjectArray) v5, (jint) v6, v14);D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L39:
LOGD("118:add-int/lit8 \x76\x32\x2c\x20\x76\x32\x2c\x20\x31");
v6 = (v6 + 1);
goto L24;
L40:
LOGD("11e:new-instance \x76\x32\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_LandingPad_22
if (v15) {
LOGD("env->DeleteLocalRef(%p):v15", v15);
env->DeleteLocalRef(v15);
}
jclass &clz = cls2;
D2C_RESOLVE_CLASS(clz,"java/lang/StringBuilder");
v15 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L41:
LOGD("122:aget-object \x76\x33\x2c\x20\x76\x31\x2c\x20\x76\x39");
{
#define EX_HANDLE EX_LandingPad_22
D2C_NOT_NULL(v5);
v4 = (jstring) env->GetObjectArrayElement((jobjectArray) v5, (jint) v13);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v14) {
LOGD("env->DeleteLocalRef(%p):v14", v14);
env->DeleteLocalRef(v14);
}
v14 = (jobject) v4;
L42:
LOGD("126:invoke-direct \x76\x32\x2c\x20\x76\x33\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x56");
{
#define EX_HANDLE EX_LandingPad_22
D2C_NOT_NULL(v15);
jclass &clz = cls2;
jmethodID &mid = mth7;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "<init>", "(Ljava/lang/String;)V");
jvalue args[] = {{.l = v14}};
env->CallVoidMethodA(v15, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L43:
LOGD("12c:array-length \x76\x33\x2c\x20\x76\x31");
{
#define EX_HANDLE EX_LandingPad_22
D2C_NOT_NULL(v5);
v7 = env->GetArrayLength((jarray) v5);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L44:
LOGD("12e:if-ge \x76\x38\x2c\x20\x76\x33\x2c\x20\x2b\x64");
if(v12 >= v7) {
goto L49;
}
else {
goto L45;
}
L45:
LOGD("132:invoke-virtual \x76\x32\x2c\x20\x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_LandingPad_22
D2C_NOT_NULL(v15);
jclass &clz = cls2;
jmethodID &mid = mth8;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v1}};
v4 = (jobject) env->CallObjectMethodA(v15, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
L46:
LOGD("138:aget-object \x76\x33\x2c\x20\x76\x31\x2c\x20\x76\x38");
{
#define EX_HANDLE EX_LandingPad_22
D2C_NOT_NULL(v5);
v4 = (jstring) env->GetObjectArrayElement((jobjectArray) v5, (jint) v12);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v14) {
LOGD("env->DeleteLocalRef(%p):v14", v14);
env->DeleteLocalRef(v14);
}
v14 = (jobject) v4;
L47:
LOGD("13c:invoke-virtual \x76\x32\x2c\x20\x76\x33\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x61\x70\x70\x65\x6e\x64\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b");
{
#define EX_HANDLE EX_LandingPad_22
D2C_NOT_NULL(v15);
jclass &clz = cls2;
jmethodID &mid = mth8;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
jvalue args[] = {{.l = v14}};
v4 = (jobject) env->CallObjectMethodA(v15, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
L48:
LOGD("142:add-int/lit8 \x76\x38\x2c\x20\x76\x38\x2c\x20\x31");
v12 = (v12 + 1);
goto L43;
L49:
LOGD("148:invoke-virtual \x76\x32\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x42\x75\x69\x6c\x64\x65\x72\x3b\x2d\x3e\x74\x6f\x53\x74\x72\x69\x6e\x67\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_LandingPad_22
D2C_NOT_NULL(v15);
jclass &clz = cls2;
jmethodID &mid = mth9;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/StringBuilder", "toString", "()Ljava/lang/String;");
jvalue args[] = {};
v4 = (jstring) env->CallObjectMethodA(v15, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L50:
LOGD("14e:move-result-object \x76\x31\x30");
if (v0) {
LOGD("env->DeleteLocalRef(%p):v0", v0);
env->DeleteLocalRef(v0);
}
v0 = (jobject) v4;
return (jstring) v0;
L51:
LOGD("152:move-exception \x76\x30");
if (v1) {
LOGD("env->DeleteLocalRef(%p):v1", v1);
env->DeleteLocalRef(v1);
}
v1 = exception;
LOGD("154:invoke-virtual \x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x54\x68\x72\x6f\x77\x61\x62\x6c\x65\x3b\x2d\x3e\x70\x72\x69\x6e\x74\x53\x74\x61\x63\x6b\x54\x72\x61\x63\x65\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v1);
jclass &clz = cls3;
jmethodID &mid = mth10;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/Throwable", "printStackTrace", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v1, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
return (jstring) v0;
L52:
LOGD("15c:const-string \x76\x31\x30\x2c\x20\x27\x41\x63\x63\x65\x70\x74\x2d\x43\x48\x27");
if (v0) {
LOGD("env->DeleteLocalRef(%p):v0", v0);
env->DeleteLocalRef(v0);
}
v0 = (jstring) env->NewStringUTF("\x41\x63\x63\x65\x70\x74\x2d\x43\x48");
return (jstring) v0;
L53:
LOGD("162:const-string \x76\x31\x30\x2c\x20\x27\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x4d\x44\x35\x27");
if (v0) {
LOGD("env->DeleteLocalRef(%p):v0", v0);
env->DeleteLocalRef(v0);
}
v0 = (jstring) env->NewStringUTF("\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x4d\x44\x35");
return (jstring) v0;
L54:
LOGD("168:const-string \x76\x31\x30\x2c\x20\x27\x44\x4e\x54\x27");
if (v0) {
LOGD("env->DeleteLocalRef(%p):v0", v0);
env->DeleteLocalRef(v0);
}
v0 = (jstring) env->NewStringUTF("\x44\x4e\x54");
return (jstring) v0;
L55:
LOGD("16e:const-string \x76\x31\x30\x2c\x20\x27\x4c\x61\x73\x74\x2d\x45\x76\x65\x6e\x74\x2d\x49\x44\x27");
if (v0) {
LOGD("env->DeleteLocalRef(%p):v0", v0);
env->DeleteLocalRef(v0);
}
v0 = (jstring) env->NewStringUTF("\x4c\x61\x73\x74\x2d\x45\x76\x65\x6e\x74\x2d\x49\x44");
return (jstring) v0;
L56:
LOGD("174:const-string \x76\x31\x30\x2c\x20\x27\x54\x43\x4e\x27");
if (v0) {
LOGD("env->DeleteLocalRef(%p):v0", v0);
env->DeleteLocalRef(v0);
}
v0 = (jstring) env->NewStringUTF("\x54\x43\x4e");
return (jstring) v0;
L57:
LOGD("17a:const-string \x76\x31\x30\x2c\x20\x27\x54\x45\x27");
if (v0) {
LOGD("env->DeleteLocalRef(%p):v0", v0);
env->DeleteLocalRef(v0);
}
v0 = (jstring) env->NewStringUTF("\x54\x45");
return (jstring) v0;

EX_LandingPad_22:
D2C_GET_PENDING_EX
if(d2c_is_instance_of(env, exception, "java/lang/Throwable")) {
goto L51;
}
D2C_GOTO_UNWINDBLOCK
EX_UnwindBlock: return NULL;
}
