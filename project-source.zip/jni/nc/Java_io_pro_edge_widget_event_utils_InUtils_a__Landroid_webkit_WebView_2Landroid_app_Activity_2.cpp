#include "Dex2C.h"

/* Lio/pro/edge/widget/event/utils/InUtils;->a(Landroid/webkit/WebView;Landroid/app/Activity;)V */
extern "C" JNIEXPORT void JNICALL
Java_io_pro_edge_widget_event_utils_InUtils_a__Landroid_webkit_WebView_2Landroid_app_Activity_2(JNIEnv *env, jobject thiz, jobject p2, jobject p3){
jobject v0 = NULL;
jobject v1 = NULL;
jint v2;
jobject v3 = NULL;
jint v4;
jobject v5 = NULL;
jthrowable exception;
jclass cls0 = NULL,cls1 = NULL,cls2 = NULL,cls3 = NULL,cls4 = NULL,cls5 = NULL,cls6 = NULL;
jmethodID mth0 = NULL, mth1 = NULL, mth2 = NULL, mth3 = NULL, mth4 = NULL, mth5 = NULL, mth6 = NULL, mth7 = NULL, mth8 = NULL, mth9 = NULL;
v0 = (jobject)env->NewLocalRef(p2);
v1 = (jobject)env->NewLocalRef(p3);
L0:
v2 = 0;
v2 = 0;
L1:
LOGD("2:invoke-virtual \x76\x32\x2c\x20\x76\x30\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x56\x69\x65\x77\x3b\x2d\x3e\x73\x65\x74\x46\x6f\x63\x75\x73\x61\x62\x6c\x65\x28\x5a\x29\x56");
{
#define EX_HANDLE EX_LandingPad_1
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jmethodID &mid = mth0;
D2C_RESOLVE_METHOD(clz, mid, "android/webkit/WebView", "setFocusable", "(Z)V");
jvalue args[] = {{.z = (jboolean) v2}};
env->CallVoidMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L2:
LOGD("8:invoke-virtual \x76\x32\x2c\x20\x76\x30\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x56\x69\x65\x77\x3b\x2d\x3e\x73\x65\x74\x43\x6c\x69\x63\x6b\x61\x62\x6c\x65\x28\x5a\x29\x56");
{
#define EX_HANDLE EX_LandingPad_1
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jmethodID &mid = mth1;
D2C_RESOLVE_METHOD(clz, mid, "android/webkit/WebView", "setClickable", "(Z)V");
jvalue args[] = {{.z = (jboolean) v2}};
env->CallVoidMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L3:
v2 = 4;
L4:
LOGD("10:invoke-virtual \x76\x32\x2c\x20\x76\x30\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x56\x69\x65\x77\x3b\x2d\x3e\x73\x65\x74\x56\x69\x73\x69\x62\x69\x6c\x69\x74\x79\x28\x49\x29\x56");
{
#define EX_HANDLE EX_LandingPad_1
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jmethodID &mid = mth2;
D2C_RESOLVE_METHOD(clz, mid, "android/webkit/WebView", "setVisibility", "(I)V");
jvalue args[] = {{.i = v2}};
env->CallVoidMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L5:
LOGD("16:new-instance \x76\x30\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x76\x69\x65\x77\x2f\x56\x69\x65\x77\x47\x72\x6f\x75\x70\x24\x4c\x61\x79\x6f\x75\x74\x50\x61\x72\x61\x6d\x73\x3b");
{
#define EX_HANDLE EX_LandingPad_1
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
jclass &clz = cls1;
D2C_RESOLVE_CLASS(clz,"android/view/ViewGroup$LayoutParams");
v3 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L6:
v4 = -1;
L7:
LOGD("1c:invoke-direct \x76\x30\x2c\x20\x76\x31\x2c\x20\x76\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x76\x69\x65\x77\x2f\x56\x69\x65\x77\x47\x72\x6f\x75\x70\x24\x4c\x61\x79\x6f\x75\x74\x50\x61\x72\x61\x6d\x73\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x49\x20\x49\x29\x56");
{
#define EX_HANDLE EX_LandingPad_1
D2C_NOT_NULL(v3);
jclass &clz = cls1;
jmethodID &mid = mth3;
D2C_RESOLVE_METHOD(clz, mid, "android/view/ViewGroup$LayoutParams", "<init>", "(II)V");
jvalue args[] = {{.i = v4},{.i = v4}};
env->CallVoidMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L8:
LOGD("22:invoke-virtual \x76\x32\x2c\x20\x76\x30\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x56\x69\x65\x77\x3b\x2d\x3e\x73\x65\x74\x4c\x61\x79\x6f\x75\x74\x50\x61\x72\x61\x6d\x73\x28\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x76\x69\x65\x77\x2f\x56\x69\x65\x77\x47\x72\x6f\x75\x70\x24\x4c\x61\x79\x6f\x75\x74\x50\x61\x72\x61\x6d\x73\x3b\x29\x56");
{
#define EX_HANDLE EX_LandingPad_1
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jmethodID &mid = mth4;
D2C_RESOLVE_METHOD(clz, mid, "android/webkit/WebView", "setLayoutParams", "(Landroid/view/ViewGroup$LayoutParams;)V");
jvalue args[] = {{.l = v3}};
env->CallVoidMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L9:
LOGD("28:invoke-virtual \x76\x33\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x61\x70\x70\x2f\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x2d\x3e\x67\x65\x74\x57\x69\x6e\x64\x6f\x77\x28\x29\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x76\x69\x65\x77\x2f\x57\x69\x6e\x64\x6f\x77\x3b");
{
#define EX_HANDLE EX_LandingPad_1
D2C_NOT_NULL(v1);
jclass &clz = cls2;
jmethodID &mid = mth5;
D2C_RESOLVE_METHOD(clz, mid, "android/app/Activity", "getWindow", "()Landroid/view/Window;");
jvalue args[] = {};
v5 = (jobject) env->CallObjectMethodA(v1, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L10:
LOGD("2e:move-result-object \x76\x33");
if (v1) {
LOGD("env->DeleteLocalRef(%p):v1", v1);
env->DeleteLocalRef(v1);
}
v1 = (jobject) v5;
L11:
LOGD("30:invoke-virtual \x76\x33\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x76\x69\x65\x77\x2f\x57\x69\x6e\x64\x6f\x77\x3b\x2d\x3e\x67\x65\x74\x44\x65\x63\x6f\x72\x56\x69\x65\x77\x28\x29\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x76\x69\x65\x77\x2f\x56\x69\x65\x77\x3b");
{
#define EX_HANDLE EX_LandingPad_1
D2C_NOT_NULL(v1);
jclass &clz = cls3;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "android/view/Window", "getDecorView", "()Landroid/view/View;");
jvalue args[] = {};
v5 = (jobject) env->CallObjectMethodA(v1, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L12:
LOGD("36:move-result-object \x76\x33");
if (v1) {
LOGD("env->DeleteLocalRef(%p):v1", v1);
env->DeleteLocalRef(v1);
}
v1 = (jobject) v5;
v2 = 16908290;
L13:
LOGD("3e:invoke-virtual \x76\x33\x2c\x20\x76\x30\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x76\x69\x65\x77\x2f\x56\x69\x65\x77\x3b\x2d\x3e\x66\x69\x6e\x64\x56\x69\x65\x77\x42\x79\x49\x64\x28\x49\x29\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x76\x69\x65\x77\x2f\x56\x69\x65\x77\x3b");
{
#define EX_HANDLE EX_LandingPad_1
D2C_NOT_NULL(v1);
jclass &clz = cls4;
jmethodID &mid = mth7;
D2C_RESOLVE_METHOD(clz, mid, "android/view/View", "findViewById", "(I)Landroid/view/View;");
jvalue args[] = {{.i = v2}};
v5 = (jobject) env->CallObjectMethodA(v1, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L14:
LOGD("44:move-result-object \x76\x33");
if (v1) {
LOGD("env->DeleteLocalRef(%p):v1", v1);
env->DeleteLocalRef(v1);
}
v1 = (jobject) v5;
L15:
LOGD("46:check-cast \x76\x33\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x76\x69\x65\x77\x2f\x56\x69\x65\x77\x47\x72\x6f\x75\x70\x3b");
{
#define EX_HANDLE EX_LandingPad_1
jclass &clz = cls5;
D2C_RESOLVE_CLASS(clz,"android/view/ViewGroup");
D2C_CHECK_CAST(v1, clz, "android/view/ViewGroup");
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L16:
LOGD("4a:invoke-virtual \x76\x33\x2c\x20\x76\x32\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x76\x69\x65\x77\x2f\x56\x69\x65\x77\x47\x72\x6f\x75\x70\x3b\x2d\x3e\x61\x64\x64\x56\x69\x65\x77\x28\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x76\x69\x65\x77\x2f\x56\x69\x65\x77\x3b\x29\x56");
{
#define EX_HANDLE EX_LandingPad_1
D2C_NOT_NULL(v1);
jclass &clz = cls5;
jmethodID &mid = mth8;
D2C_RESOLVE_METHOD(clz, mid, "android/view/ViewGroup", "addView", "(Landroid/view/View;)V");
jvalue args[] = {{.l = v0}};
env->CallVoidMethodA(v1, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L17:
goto L19;
L18:
LOGD("52:move-exception \x76\x32");
if (v0) {
LOGD("env->DeleteLocalRef(%p):v0", v0);
env->DeleteLocalRef(v0);
}
v0 = exception;
LOGD("54:invoke-virtual \x76\x32\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3b\x2d\x3e\x70\x72\x69\x6e\x74\x53\x74\x61\x63\x6b\x54\x72\x61\x63\x65\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls6;
jmethodID &mid = mth9;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/Exception", "printStackTrace", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L19:
return;

EX_LandingPad_1:
D2C_GET_PENDING_EX
if(d2c_is_instance_of(env, exception, "java/lang/Exception")) {
goto L18;
}
D2C_GOTO_UNWINDBLOCK
EX_UnwindBlock: return;
}
