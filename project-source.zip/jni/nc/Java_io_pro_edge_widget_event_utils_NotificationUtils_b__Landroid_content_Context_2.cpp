#include "Dex2C.h"

/* Lio/pro/edge/widget/event/utils/NotificationUtils;->b(Landroid/content/Context;)Ljava/lang/Class; */
extern "C" JNIEXPORT jobject JNICALL
Java_io_pro_edge_widget_event_utils_NotificationUtils_b__Landroid_content_Context_2(JNIEnv *env, jobject thiz, jobject p4){
jobject v0 = NULL;
jobject v1 = NULL;
jobject v2 = NULL;
jobject v3 = NULL;
jint v4;
jint v5;
jint v6;
jobject v7 = NULL;
jobject v8 = NULL;
jthrowable exception;
jclass cls0 = NULL,cls1 = NULL,cls2 = NULL,cls3 = NULL,cls4 = NULL,cls5 = NULL,cls6 = NULL,cls7 = NULL,cls8 = NULL,cls9 = NULL,cls10 = NULL;
jfieldID fld0 = NULL,fld1 = NULL,fld2 = NULL;
jmethodID mth0 = NULL, mth1 = NULL, mth2 = NULL, mth3 = NULL, mth4 = NULL, mth5 = NULL, mth6 = NULL, mth7 = NULL, mth8 = NULL, mth9 = NULL, mth10 = NULL, mth11 = NULL;
v0 = (jobject)env->NewLocalRef(p4);
L0:
LOGD("0:new-instance \x76\x30\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x49\x6e\x74\x65\x6e\x74\x3b");
{
#define EX_HANDLE EX_LandingPad_0
if (v1) {
LOGD("env->DeleteLocalRef(%p):v1", v1);
env->DeleteLocalRef(v1);
}
jclass &clz = cls0;
D2C_RESOLVE_CLASS(clz,"android/content/Intent");
v1 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L1:
LOGD("4:const-string \x76\x31\x2c\x20\x27\x61\x6e\x64\x72\x6f\x69\x64\x2e\x73\x65\x72\x76\x69\x63\x65\x2e\x6e\x6f\x74\x69\x66\x69\x63\x61\x74\x69\x6f\x6e\x2e\x4e\x6f\x74\x69\x66\x69\x63\x61\x74\x69\x6f\x6e\x4c\x69\x73\x74\x65\x6e\x65\x72\x53\x65\x72\x76\x69\x63\x65\x27");
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
v2 = (jstring) env->NewStringUTF("\x61\x6e\x64\x72\x6f\x69\x64\x2e\x73\x65\x72\x76\x69\x63\x65\x2e\x6e\x6f\x74\x69\x66\x69\x63\x61\x74\x69\x6f\x6e\x2e\x4e\x6f\x74\x69\x66\x69\x63\x61\x74\x69\x6f\x6e\x4c\x69\x73\x74\x65\x6e\x65\x72\x53\x65\x72\x76\x69\x63\x65");
L2:
LOGD("8:invoke-direct \x76\x30\x2c\x20\x76\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x49\x6e\x74\x65\x6e\x74\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x56");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v1);
jclass &clz = cls0;
jmethodID &mid = mth0;
D2C_RESOLVE_METHOD(clz, mid, "android/content/Intent", "<init>", "(Ljava/lang/String;)V");
jvalue args[] = {{.l = v2}};
env->CallVoidMethodA(v1, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L3:
LOGD("e:invoke-virtual \x76\x34\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6e\x74\x65\x78\x74\x3b\x2d\x3e\x67\x65\x74\x50\x61\x63\x6b\x61\x67\x65\x4d\x61\x6e\x61\x67\x65\x72\x28\x29\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x70\x6d\x2f\x50\x61\x63\x6b\x61\x67\x65\x4d\x61\x6e\x61\x67\x65\x72\x3b");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v0);
jclass &clz = cls1;
jmethodID &mid = mth1;
D2C_RESOLVE_METHOD(clz, mid, "android/content/Context", "getPackageManager", "()Landroid/content/pm/PackageManager;");
jvalue args[] = {};
v3 = (jobject) env->CallObjectMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L4:
LOGD("14:move-result-object \x76\x31");
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
v2 = (jobject) v3;
v4 = 64;
L5:
LOGD("1a:invoke-virtual \x76\x31\x2c\x20\x76\x30\x2c\x20\x76\x32\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x70\x6d\x2f\x50\x61\x63\x6b\x61\x67\x65\x4d\x61\x6e\x61\x67\x65\x72\x3b\x2d\x3e\x71\x75\x65\x72\x79\x49\x6e\x74\x65\x6e\x74\x53\x65\x72\x76\x69\x63\x65\x73\x28\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x49\x6e\x74\x65\x6e\x74\x3b\x20\x49\x29\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x4c\x69\x73\x74\x3b");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v2);
jclass &clz = cls2;
jmethodID &mid = mth2;
D2C_RESOLVE_METHOD(clz, mid, "android/content/pm/PackageManager", "queryIntentServices", "(Landroid/content/Intent;I)Ljava/util/List;");
jvalue args[] = {{.l = v1},{.i = v4}};
v3 = (jobject) env->CallObjectMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L6:
LOGD("20:move-result-object \x76\x30");
if (v1) {
LOGD("env->DeleteLocalRef(%p):v1", v1);
env->DeleteLocalRef(v1);
}
v1 = (jobject) v3;
LOGD("22:if-eqz \x76\x30\x2c\x20\x2b\x33\x39");
if(v1 == NULL){
goto L29;
}
else {
goto L7;
}
L7:
LOGD("26:invoke-interface \x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x4c\x69\x73\x74\x3b\x2d\x3e\x73\x69\x7a\x65\x28\x29\x49");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v1);
jclass &clz = cls3;
jmethodID &mid = mth3;
D2C_RESOLVE_METHOD(clz, mid, "java/util/List", "size", "()I");
jvalue args[] = {};
v5 = (jint) env->CallIntMethodA(v1, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L8:
LOGD("2c:move-result \x76\x31");
v6 = (jint) v5;
LOGD("2e:if-lez \x76\x31\x2c\x20\x2b\x33\x33");
if(v6 <= 0){
goto L29;
}
else {
goto L9;
}
L9:
LOGD("32:invoke-interface \x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x4c\x69\x73\x74\x3b\x2d\x3e\x69\x74\x65\x72\x61\x74\x6f\x72\x28\x29\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x49\x74\x65\x72\x61\x74\x6f\x72\x3b");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v1);
jclass &clz = cls3;
jmethodID &mid = mth4;
D2C_RESOLVE_METHOD(clz, mid, "java/util/List", "iterator", "()Ljava/util/Iterator;");
jvalue args[] = {};
v3 = (jobject) env->CallObjectMethodA(v1, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L10:
LOGD("38:move-result-object \x76\x30");
if (v1) {
LOGD("env->DeleteLocalRef(%p):v1", v1);
env->DeleteLocalRef(v1);
}
v1 = (jobject) v3;
L11:
LOGD("3a:invoke-interface \x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x49\x74\x65\x72\x61\x74\x6f\x72\x3b\x2d\x3e\x68\x61\x73\x4e\x65\x78\x74\x28\x29\x5a");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v1);
jclass &clz = cls4;
jmethodID &mid = mth5;
D2C_RESOLVE_METHOD(clz, mid, "java/util/Iterator", "hasNext", "()Z");
jvalue args[] = {};
v5 = (jboolean) env->CallBooleanMethodA(v1, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L12:
LOGD("40:move-result \x76\x31");
v6 = (jint) v5;
LOGD("42:if-eqz \x76\x31\x2c\x20\x2b\x32\x39");
if(v6 == 0){
goto L29;
}
else {
goto L13;
}
L13:
LOGD("46:invoke-interface \x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x49\x74\x65\x72\x61\x74\x6f\x72\x3b\x2d\x3e\x6e\x65\x78\x74\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v1);
jclass &clz = cls4;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/util/Iterator", "next", "()Ljava/lang/Object;");
jvalue args[] = {};
v3 = (jobject) env->CallObjectMethodA(v1, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L14:
LOGD("4c:move-result-object \x76\x31");
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
v2 = (jobject) v3;
L15:
LOGD("4e:check-cast \x76\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x70\x6d\x2f\x52\x65\x73\x6f\x6c\x76\x65\x49\x6e\x66\x6f\x3b");
{
#define EX_HANDLE EX_LandingPad_0
jclass &clz = cls5;
D2C_RESOLVE_CLASS(clz,"android/content/pm/ResolveInfo");
D2C_CHECK_CAST(v2, clz, "android/content/pm/ResolveInfo");
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L16:
LOGD("52:iget-object \x76\x32\x2c\x20\x76\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x70\x6d\x2f\x52\x65\x73\x6f\x6c\x76\x65\x49\x6e\x66\x6f\x3b\x2d\x3e\x73\x65\x72\x76\x69\x63\x65\x49\x6e\x66\x6f\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x70\x6d\x2f\x53\x65\x72\x76\x69\x63\x65\x49\x6e\x66\x6f\x3b");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v2);
jclass &clz = cls5;
jfieldID &fld = fld0;
D2C_RESOLVE_FIELD(clz, fld, "android/content/pm/ResolveInfo", "serviceInfo", "Landroid/content/pm/ServiceInfo;");
v3 = (jobject) env->GetObjectField(v2,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
v7 = (jobject) v3;
L17:
LOGD("56:iget-object \x76\x32\x2c\x20\x76\x32\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x70\x6d\x2f\x53\x65\x72\x76\x69\x63\x65\x49\x6e\x66\x6f\x3b\x2d\x3e\x70\x61\x63\x6b\x61\x67\x65\x4e\x61\x6d\x65\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v7);
jclass &clz = cls6;
jfieldID &fld = fld1;
D2C_RESOLVE_FIELD(clz, fld, "android/content/pm/ServiceInfo", "packageName", "Ljava/lang/String;");
v3 = (jstring) env->GetObjectField(v7,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
v7 = (jobject) v3;
L18:
LOGD("5a:invoke-virtual \x76\x34\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6e\x74\x65\x78\x74\x3b\x2d\x3e\x67\x65\x74\x50\x61\x63\x6b\x61\x67\x65\x4e\x61\x6d\x65\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v0);
jclass &clz = cls1;
jmethodID &mid = mth7;
D2C_RESOLVE_METHOD(clz, mid, "android/content/Context", "getPackageName", "()Ljava/lang/String;");
jvalue args[] = {};
v3 = (jstring) env->CallObjectMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L19:
LOGD("60:move-result-object \x76\x33");
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jobject) v3;
L20:
LOGD("62:invoke-virtual \x76\x32\x2c\x20\x76\x33\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x65\x71\x75\x61\x6c\x73\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b\x29\x5a");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v7);
jclass &clz = cls7;
jmethodID &mid = mth8;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "equals", "(Ljava/lang/Object;)Z");
jvalue args[] = {{.l = v8}};
v5 = (jboolean) env->CallBooleanMethodA(v7, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L21:
LOGD("68:move-result \x76\x32");
v4 = (jint) v5;
LOGD("6a:if-eqz \x76\x32\x2c\x20\x2d\x31\x38");
if(v4 == 0){
goto L11;
}
else {
goto L22;
}
L22:
LOGD("6e:iget-object \x76\x31\x2c\x20\x76\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x70\x6d\x2f\x52\x65\x73\x6f\x6c\x76\x65\x49\x6e\x66\x6f\x3b\x2d\x3e\x73\x65\x72\x76\x69\x63\x65\x49\x6e\x66\x6f\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x70\x6d\x2f\x53\x65\x72\x76\x69\x63\x65\x49\x6e\x66\x6f\x3b");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v2);
jclass &clz = cls5;
jfieldID &fld = fld0;
D2C_RESOLVE_FIELD(clz, fld, "android/content/pm/ResolveInfo", "serviceInfo", "Landroid/content/pm/ServiceInfo;");
v3 = (jobject) env->GetObjectField(v2,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
v2 = (jobject) v3;
L23:
LOGD("72:iget-object \x76\x31\x2c\x20\x76\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x70\x6d\x2f\x53\x65\x72\x76\x69\x63\x65\x49\x6e\x66\x6f\x3b\x2d\x3e\x6e\x61\x6d\x65\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v2);
jclass &clz = cls6;
jfieldID &fld = fld2;
D2C_RESOLVE_FIELD(clz, fld, "android/content/pm/ServiceInfo", "name", "Ljava/lang/String;");
v3 = (jstring) env->GetObjectField(v2,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
v2 = (jobject) v3;
L24:
LOGD("76:invoke-static \x76\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x74\x65\x78\x74\x2f\x54\x65\x78\x74\x55\x74\x69\x6c\x73\x3b\x2d\x3e\x69\x73\x45\x6d\x70\x74\x79\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x68\x61\x72\x53\x65\x71\x75\x65\x6e\x63\x65\x3b\x29\x5a");
{
#define EX_HANDLE EX_LandingPad_0
jclass &clz = cls8;
jmethodID &mid = mth9;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "android/text/TextUtils", "isEmpty", "(Ljava/lang/CharSequence;)Z");
jvalue args[] = {{.l = v2}};
v5 = (jboolean) env->CallStaticBooleanMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L25:
LOGD("7c:move-result \x76\x32");
v4 = (jint) v5;
LOGD("7e:if-nez \x76\x32\x2c\x20\x2d\x32\x32");
if(v4 != 0){
goto L11;
}
else {
goto L26;
}
L26:
LOGD("82:invoke-static \x76\x31\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x6c\x61\x73\x73\x3b\x2d\x3e\x66\x6f\x72\x4e\x61\x6d\x65\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x6c\x61\x73\x73\x3b");
{
#define EX_HANDLE EX_LandingPad_0
jclass &clz = cls9;
jmethodID &mid = mth10;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "java/lang/Class", "forName", "(Ljava/lang/String;)Ljava/lang/Class;");
jvalue args[] = {{.l = v2}};
v3 = (jobject) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L27:
LOGD("88:move-result-object \x76\x34");
if (v0) {
LOGD("env->DeleteLocalRef(%p):v0", v0);
env->DeleteLocalRef(v0);
}
v0 = (jobject) v3;
return (jobject) v0;
L28:
LOGD("8c:move-exception \x76\x34");
if (v0) {
LOGD("env->DeleteLocalRef(%p):v0", v0);
env->DeleteLocalRef(v0);
}
v0 = exception;
LOGD("8e:invoke-virtual \x76\x34\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3b\x2d\x3e\x70\x72\x69\x6e\x74\x53\x74\x61\x63\x6b\x54\x72\x61\x63\x65\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls10;
jmethodID &mid = mth11;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/Exception", "printStackTrace", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L29:
if (v0) {
LOGD("env->DeleteLocalRef(%p):v0", v0);
env->DeleteLocalRef(v0);
}
v0 = 0;
return (jobject) v0;

EX_LandingPad_0:
D2C_GET_PENDING_EX
if(d2c_is_instance_of(env, exception, "java/lang/Exception")) {
goto L28;
}
D2C_GOTO_UNWINDBLOCK
EX_UnwindBlock: return NULL;
}
