#include "Dex2C.h"

/* Lio/pro/edge/widget/event/net/OkHttpProvider;->b()Ljavax/net/ssl/SSLSocketFactory; */
extern "C" JNIEXPORT jobject JNICALL
Java_io_pro_edge_widget_event_net_OkHttpProvider_b__(JNIEnv *env, jobject thiz){
jobject v0 = NULL;
jobject v1 = NULL;
jobject v2 = NULL;
jobject v3 = NULL;
jobject v4 = NULL;
jobject v5 = NULL;
jthrowable exception;
jclass cls0 = NULL,cls1 = NULL,cls2 = NULL,cls3 = NULL;
jmethodID mth0 = NULL, mth1 = NULL, mth2 = NULL, mth3 = NULL, mth4 = NULL, mth5 = NULL;
v0 = (jobject)env->NewLocalRef(thiz);
L0:
LOGD("0:const-string \x76\x30\x2c\x20\x27\x53\x53\x4c\x27");
if (v1) {
LOGD("env->DeleteLocalRef(%p):v1", v1);
env->DeleteLocalRef(v1);
}
v1 = (jstring) env->NewStringUTF("\x53\x53\x4c");
L1:
LOGD("4:invoke-static \x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x78\x2f\x6e\x65\x74\x2f\x73\x73\x6c\x2f\x53\x53\x4c\x43\x6f\x6e\x74\x65\x78\x74\x3b\x2d\x3e\x67\x65\x74\x49\x6e\x73\x74\x61\x6e\x63\x65\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x78\x2f\x6e\x65\x74\x2f\x73\x73\x6c\x2f\x53\x53\x4c\x43\x6f\x6e\x74\x65\x78\x74\x3b");
{
#define EX_HANDLE EX_LandingPad_0
jclass &clz = cls0;
jmethodID &mid = mth0;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "javax/net/ssl/SSLContext", "getInstance", "(Ljava/lang/String;)Ljavax/net/ssl/SSLContext;");
jvalue args[] = {{.l = v1}};
v2 = (jobject) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L2:
LOGD("a:move-result-object \x76\x30");
if (v1) {
LOGD("env->DeleteLocalRef(%p):v1", v1);
env->DeleteLocalRef(v1);
}
v1 = (jobject) v2;
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
v3 = 0;
L3:
LOGD("e:invoke-virtual \x76\x34\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x48\x74\x74\x70\x50\x72\x6f\x76\x69\x64\x65\x72\x3b\x2d\x3e\x63\x28\x29\x5b\x4c\x6a\x61\x76\x61\x78\x2f\x6e\x65\x74\x2f\x73\x73\x6c\x2f\x54\x72\x75\x73\x74\x4d\x61\x6e\x61\x67\x65\x72\x3b");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v0);
jclass &clz = cls1;
jmethodID &mid = mth1;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/event/net/OkHttpProvider", "c", "()[Ljavax/net/ssl/TrustManager;");
jvalue args[] = {};
v2 = (jarray) env->CallObjectMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L4:
LOGD("14:move-result-object \x76\x32");
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
v4 = (jobject) v2;
L5:
LOGD("16:new-instance \x76\x33\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x73\x65\x63\x75\x72\x69\x74\x79\x2f\x53\x65\x63\x75\x72\x65\x52\x61\x6e\x64\x6f\x6d\x3b");
{
#define EX_HANDLE EX_LandingPad_0
if (v5) {
LOGD("env->DeleteLocalRef(%p):v5", v5);
env->DeleteLocalRef(v5);
}
jclass &clz = cls2;
D2C_RESOLVE_CLASS(clz,"java/security/SecureRandom");
v5 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L6:
LOGD("1a:invoke-direct \x76\x33\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x73\x65\x63\x75\x72\x69\x74\x79\x2f\x53\x65\x63\x75\x72\x65\x52\x61\x6e\x64\x6f\x6d\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x29\x56");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v5);
jclass &clz = cls2;
jmethodID &mid = mth2;
D2C_RESOLVE_METHOD(clz, mid, "java/security/SecureRandom", "<init>", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v5, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L7:
LOGD("20:invoke-virtual \x76\x30\x2c\x20\x76\x31\x2c\x20\x76\x32\x2c\x20\x76\x33\x2c\x20\x4c\x6a\x61\x76\x61\x78\x2f\x6e\x65\x74\x2f\x73\x73\x6c\x2f\x53\x53\x4c\x43\x6f\x6e\x74\x65\x78\x74\x3b\x2d\x3e\x69\x6e\x69\x74\x28\x5b\x4c\x6a\x61\x76\x61\x78\x2f\x6e\x65\x74\x2f\x73\x73\x6c\x2f\x4b\x65\x79\x4d\x61\x6e\x61\x67\x65\x72\x3b\x20\x5b\x4c\x6a\x61\x76\x61\x78\x2f\x6e\x65\x74\x2f\x73\x73\x6c\x2f\x54\x72\x75\x73\x74\x4d\x61\x6e\x61\x67\x65\x72\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x73\x65\x63\x75\x72\x69\x74\x79\x2f\x53\x65\x63\x75\x72\x65\x52\x61\x6e\x64\x6f\x6d\x3b\x29\x56");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v1);
jclass &clz = cls0;
jmethodID &mid = mth3;
D2C_RESOLVE_METHOD(clz, mid, "javax/net/ssl/SSLContext", "init", "([Ljavax/net/ssl/KeyManager;[Ljavax/net/ssl/TrustManager;Ljava/security/SecureRandom;)V");
jvalue args[] = {{.l = v3},{.l = v4},{.l = v5}};
env->CallVoidMethodA(v1, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L8:
LOGD("26:invoke-virtual \x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x78\x2f\x6e\x65\x74\x2f\x73\x73\x6c\x2f\x53\x53\x4c\x43\x6f\x6e\x74\x65\x78\x74\x3b\x2d\x3e\x67\x65\x74\x53\x6f\x63\x6b\x65\x74\x46\x61\x63\x74\x6f\x72\x79\x28\x29\x4c\x6a\x61\x76\x61\x78\x2f\x6e\x65\x74\x2f\x73\x73\x6c\x2f\x53\x53\x4c\x53\x6f\x63\x6b\x65\x74\x46\x61\x63\x74\x6f\x72\x79\x3b");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v1);
jclass &clz = cls0;
jmethodID &mid = mth4;
D2C_RESOLVE_METHOD(clz, mid, "javax/net/ssl/SSLContext", "getSocketFactory", "()Ljavax/net/ssl/SSLSocketFactory;");
jvalue args[] = {};
v2 = (jobject) env->CallObjectMethodA(v1, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L9:
LOGD("2c:move-result-object \x76\x30");
if (v1) {
LOGD("env->DeleteLocalRef(%p):v1", v1);
env->DeleteLocalRef(v1);
}
v1 = (jobject) v2;
return (jobject) v1;
L10:
LOGD("30:move-exception \x76\x30");
if (v1) {
LOGD("env->DeleteLocalRef(%p):v1", v1);
env->DeleteLocalRef(v1);
}
v1 = exception;
LOGD("32:new-instance \x76\x31\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x52\x75\x6e\x74\x69\x6d\x65\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
jclass &clz = cls3;
D2C_RESOLVE_CLASS(clz,"java/lang/RuntimeException");
v3 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("36:invoke-direct \x76\x31\x2c\x20\x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x52\x75\x6e\x74\x69\x6d\x65\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x54\x68\x72\x6f\x77\x61\x62\x6c\x65\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls3;
jmethodID &mid = mth5;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/RuntimeException", "<init>", "(Ljava/lang/Throwable;)V");
jvalue args[] = {{.l = v1}};
env->CallVoidMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("3c:throw \x76\x31");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
env->Throw((jthrowable) v3);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}

EX_LandingPad_0:
D2C_GET_PENDING_EX
if(d2c_is_instance_of(env, exception, "java/lang/Exception")) {
goto L10;
}
D2C_GOTO_UNWINDBLOCK
EX_UnwindBlock: return NULL;
}
