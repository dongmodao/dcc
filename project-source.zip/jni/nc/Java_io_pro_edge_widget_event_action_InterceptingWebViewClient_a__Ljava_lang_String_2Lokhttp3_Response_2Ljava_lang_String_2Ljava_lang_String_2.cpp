#include "Dex2C.h"

/* Lio/pro/edge/widget/event/action/InterceptingWebViewClient;->a(Ljava/lang/String;Lokhttp3/Response;Ljava/lang/String;Ljava/lang/String;)Landroid/webkit/WebResourceResponse; */
extern "C" JNIEXPORT jobject JNICALL
Java_io_pro_edge_widget_event_action_InterceptingWebViewClient_a__Ljava_lang_String_2Lokhttp3_Response_2Ljava_lang_String_2Ljava_lang_String_2(JNIEnv *env, jobject thiz, jstring p9, jobject p10, jstring p11, jstring p12){
jobject v0 = NULL;
jobject v1 = NULL;
jobject v2 = NULL;
jobject v3 = NULL;
jobject v4 = NULL;
jobject v5 = NULL;
jobject v6 = NULL;
jobject v7 = NULL;
jint v8;
jobject v9 = NULL;
jobject v10 = NULL;
jobject v11 = NULL;
jint v12;
jint v13;
jobject v14 = NULL;
jobject v15 = NULL;
jthrowable exception;
jclass cls0 = NULL,cls1 = NULL,cls2 = NULL,cls3 = NULL,cls4 = NULL,cls5 = NULL;
jmethodID mth0 = NULL, mth1 = NULL, mth2 = NULL, mth3 = NULL, mth4 = NULL, mth5 = NULL, mth6 = NULL, mth7 = NULL, mth8 = NULL, mth9 = NULL;
v0 = (jobject)env->NewLocalRef(thiz);
v1 = (jobject)env->NewLocalRef(p9);
v2 = (jobject)env->NewLocalRef(p10);
v3 = (jobject)env->NewLocalRef(p11);
v4 = (jobject)env->NewLocalRef(p12);
L0:
if (v5) {
LOGD("env->DeleteLocalRef(%p):v5", v5);
env->DeleteLocalRef(v5);
}
v5 = 0;
if (v5) {
LOGD("env->DeleteLocalRef(%p):v5", v5);
env->DeleteLocalRef(v5);
}
v5 = 0;
if (v5) {
LOGD("env->DeleteLocalRef(%p):v5", v5);
env->DeleteLocalRef(v5);
}
v5 = 0;
L1:
LOGD("2:invoke-virtual \x76\x31\x30\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x3b\x2d\x3e\x62\x6f\x64\x79\x28\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x42\x6f\x64\x79\x3b");
{
#define EX_HANDLE EX_LandingPad_1
D2C_NOT_NULL(v2);
jclass &clz = cls0;
jmethodID &mid = mth0;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Response", "body", "()Lokhttp3/ResponseBody;");
jvalue args[] = {};
v6 = (jobject) env->CallObjectMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L2:
LOGD("8:move-result-object \x76\x31");
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
v7 = (jobject) v6;
LOGD("a:if-eqz \x76\x31\x2c\x20\x2b\x62");
if(v7 == NULL){
goto L7;
}
else {
goto L3;
}
L3:
LOGD("e:invoke-virtual \x76\x31\x30\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x3b\x2d\x3e\x62\x6f\x64\x79\x28\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x42\x6f\x64\x79\x3b");
{
#define EX_HANDLE EX_LandingPad_1
D2C_NOT_NULL(v2);
jclass &clz = cls0;
jmethodID &mid = mth0;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Response", "body", "()Lokhttp3/ResponseBody;");
jvalue args[] = {};
v6 = (jobject) env->CallObjectMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L4:
LOGD("14:move-result-object \x76\x31");
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
v7 = (jobject) v6;
L5:
LOGD("16:invoke-virtual \x76\x31\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x42\x6f\x64\x79\x3b\x2d\x3e\x62\x79\x74\x65\x73\x28\x29\x5b\x42");
{
#define EX_HANDLE EX_LandingPad_1
D2C_NOT_NULL(v7);
jclass &clz = cls1;
jmethodID &mid = mth1;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/ResponseBody", "bytes", "()[B");
jvalue args[] = {};
v6 = (jarray) env->CallObjectMethodA(v7, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L6:
LOGD("1c:move-result-object \x76\x31");
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
v7 = (jobject) v6;
goto L8;
L7:
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
v7 = (jobject) env->NewLocalRef(v5);
L8:
LOGD("22:if-eqz \x76\x31\x2c\x20\x2b\x63");
if(v7 == NULL){
goto L14;
}
else {
goto L9;
}
L9:
LOGD("26:array-length \x76\x32\x2c\x20\x76\x31");
{
#define EX_HANDLE EX_LandingPad_1
D2C_NOT_NULL(v7);
v8 = env->GetArrayLength((jarray) v7);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L10:
LOGD("28:if-eqz \x76\x32\x2c\x20\x2b\x39");
if(v8 == 0){
goto L14;
}
else {
goto L11;
}
L11:
LOGD("2c:new-instance \x76\x32\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x69\x6f\x2f\x42\x79\x74\x65\x41\x72\x72\x61\x79\x49\x6e\x70\x75\x74\x53\x74\x72\x65\x61\x6d\x3b");
{
#define EX_HANDLE EX_LandingPad_1
if (v9) {
LOGD("env->DeleteLocalRef(%p):v9", v9);
env->DeleteLocalRef(v9);
}
jclass &clz = cls2;
D2C_RESOLVE_CLASS(clz,"java/io/ByteArrayInputStream");
v9 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L12:
LOGD("30:invoke-direct \x76\x32\x2c\x20\x76\x31\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x69\x6f\x2f\x42\x79\x74\x65\x41\x72\x72\x61\x79\x49\x6e\x70\x75\x74\x53\x74\x72\x65\x61\x6d\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x5b\x42\x29\x56");
{
#define EX_HANDLE EX_LandingPad_1
D2C_NOT_NULL(v9);
jclass &clz = cls2;
jmethodID &mid = mth2;
D2C_RESOLVE_METHOD(clz, mid, "java/io/ByteArrayInputStream", "<init>", "([B)V");
jvalue args[] = {{.l = v7}};
env->CallVoidMethodA(v9, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L13:
if (v10) {
LOGD("env->DeleteLocalRef(%p):v10", v10);
env->DeleteLocalRef(v10);
}
v10 = (jobject) env->NewLocalRef(v9);
goto L15;
L14:
if (v10) {
LOGD("env->DeleteLocalRef(%p):v10", v10);
env->DeleteLocalRef(v10);
}
v10 = (jobject) env->NewLocalRef(v5);
L15:
LOGD("3c:invoke-virtual \x76\x31\x30\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x3b\x2d\x3e\x68\x65\x61\x64\x65\x72\x73\x28\x29\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x48\x65\x61\x64\x65\x72\x73\x3b");
{
#define EX_HANDLE EX_LandingPad_1
D2C_NOT_NULL(v2);
jclass &clz = cls0;
jmethodID &mid = mth3;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Response", "headers", "()Lokhttp3/Headers;");
jvalue args[] = {};
v6 = (jobject) env->CallObjectMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L16:
LOGD("42:move-result-object \x76\x31");
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
v7 = (jobject) v6;
L17:
LOGD("44:invoke-virtual \x76\x38\x2c\x20\x76\x39\x2c\x20\x76\x31\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x69\x6e\x67\x57\x65\x62\x56\x69\x65\x77\x43\x6c\x69\x65\x6e\x74\x3b\x2d\x3e\x61\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x48\x65\x61\x64\x65\x72\x73\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x4d\x61\x70\x3b");
{
#define EX_HANDLE EX_LandingPad_1
D2C_NOT_NULL(v0);
jclass &clz = cls3;
jmethodID &mid = mth4;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/event/action/InterceptingWebViewClient", "a", "(Ljava/lang/String;Lokhttp3/Headers;)Ljava/util/Map;");
jvalue args[] = {{.l = v1},{.l = v7}};
v6 = (jobject) env->CallObjectMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L18:
LOGD("4a:move-result-object \x76\x36");
if (v11) {
LOGD("env->DeleteLocalRef(%p):v11", v11);
env->DeleteLocalRef(v11);
}
v11 = (jobject) v6;
L19:
LOGD("4c:new-instance \x76\x39\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x52\x65\x73\x6f\x75\x72\x63\x65\x52\x65\x73\x70\x6f\x6e\x73\x65\x3b");
{
#define EX_HANDLE EX_LandingPad_1
if (v1) {
LOGD("env->DeleteLocalRef(%p):v1", v1);
env->DeleteLocalRef(v1);
}
jclass &clz = cls4;
D2C_RESOLVE_CLASS(clz,"android/webkit/WebResourceResponse");
v1 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L20:
LOGD("50:invoke-virtual \x76\x31\x30\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x3b\x2d\x3e\x63\x6f\x64\x65\x28\x29\x49");
{
#define EX_HANDLE EX_LandingPad_1
D2C_NOT_NULL(v2);
jclass &clz = cls0;
jmethodID &mid = mth5;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Response", "code", "()I");
jvalue args[] = {};
v12 = (jint) env->CallIntMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L21:
LOGD("56:move-result \x76\x34");
v13 = (jint) v12;
L22:
LOGD("58:invoke-virtual \x76\x31\x30\x2c\x20\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x3b\x2d\x3e\x6d\x65\x73\x73\x61\x67\x65\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_LandingPad_1
D2C_NOT_NULL(v2);
jclass &clz = cls0;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "okhttp3/Response", "message", "()Ljava/lang/String;");
jvalue args[] = {};
v6 = (jstring) env->CallObjectMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L23:
LOGD("5e:move-result-object \x76\x35");
if (v14) {
LOGD("env->DeleteLocalRef(%p):v14", v14);
env->DeleteLocalRef(v14);
}
v14 = (jobject) v6;
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
v7 = (jobject) env->NewLocalRef(v1);
if (v9) {
LOGD("env->DeleteLocalRef(%p):v9", v9);
env->DeleteLocalRef(v9);
}
v9 = (jobject) env->NewLocalRef(v3);
if (v15) {
LOGD("env->DeleteLocalRef(%p):v15", v15);
env->DeleteLocalRef(v15);
}
v15 = (jobject) env->NewLocalRef(v4);
L24:
LOGD("66:invoke-direct/range \x76\x31\x20\x2e\x2e\x2e\x20\x76\x37\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x52\x65\x73\x6f\x75\x72\x63\x65\x52\x65\x73\x70\x6f\x6e\x73\x65\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x20\x49\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x4d\x61\x70\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x69\x6f\x2f\x49\x6e\x70\x75\x74\x53\x74\x72\x65\x61\x6d\x3b\x29\x56");
{
#define EX_HANDLE EX_LandingPad_1
D2C_NOT_NULL(v7);
jclass &clz = cls4;
jmethodID &mid = mth7;
D2C_RESOLVE_METHOD(clz, mid, "android/webkit/WebResourceResponse", "<init>", "(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/util/Map;Ljava/io/InputStream;)V");
jvalue args[] = {{.l = v9},{.l = v15},{.i = v13},{.l = v14},{.l = v11},{.l = v10}};
env->CallVoidMethodA(v7, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L25:
return (jobject) v1;
L26:
LOGD("6e:move-exception \x76\x39");
if (v1) {
LOGD("env->DeleteLocalRef(%p):v1", v1);
env->DeleteLocalRef(v1);
}
v1 = exception;
LOGD("70:invoke-virtual \x76\x39\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x54\x68\x72\x6f\x77\x61\x62\x6c\x65\x3b\x2d\x3e\x70\x72\x69\x6e\x74\x53\x74\x61\x63\x6b\x54\x72\x61\x63\x65\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v1);
jclass &clz = cls5;
jmethodID &mid = mth8;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/Throwable", "printStackTrace", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v1, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("76:invoke-virtual \x76\x38\x2c\x20\x76\x31\x30\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x69\x6e\x67\x57\x65\x62\x56\x69\x65\x77\x43\x6c\x69\x65\x6e\x74\x3b\x2d\x3e\x61\x28\x4c\x6f\x6b\x68\x74\x74\x70\x33\x2f\x52\x65\x73\x70\x6f\x6e\x73\x65\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls3;
jmethodID &mid = mth9;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/event/action/InterceptingWebViewClient", "a", "(Lokhttp3/Response;)V");
jvalue args[] = {{.l = v2}};
env->CallVoidMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
return (jobject) v5;

EX_LandingPad_1:
D2C_GET_PENDING_EX
if(d2c_is_instance_of(env, exception, "java/lang/Throwable")) {
goto L26;
}
D2C_GOTO_UNWINDBLOCK
EX_UnwindBlock: return NULL;
}
