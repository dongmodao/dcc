#include "Dex2C.h"

/* Lio/pro/edgelivewallpaper/activity/SplashActivity;->o()La/b/a/k; */
extern "C" JNIEXPORT jobject JNICALL
Java_io_pro_edgelivewallpaper_activity_SplashActivity_o__(JNIEnv *env, jobject thiz){
jobject v0 = NULL;
jobject v1 = NULL;
jobject v2 = NULL;
jclass cls0 = NULL,cls1 = NULL;
jmethodID mth0 = NULL, mth1 = NULL;
v0 = (jobject)env->NewLocalRef(thiz);
L0:
LOGD("0:new-instance \x76\x30\x2c\x20\x4c\x64\x2f\x62\x2f\x62\x2f\x61\x2f\x62\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v1) {
LOGD("env->DeleteLocalRef(%p):v1", v1);
env->DeleteLocalRef(v1);
}
jclass &clz = cls0;
D2C_RESOLVE_CLASS(clz,"d/b/b/a/b");
v1 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("4:invoke-direct \x76\x30\x2c\x20\x76\x31\x2c\x20\x4c\x64\x2f\x62\x2f\x62\x2f\x61\x2f\x62\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x6c\x69\x76\x65\x77\x61\x6c\x6c\x70\x61\x70\x65\x72\x2f\x61\x63\x74\x69\x76\x69\x74\x79\x2f\x53\x70\x6c\x61\x73\x68\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v1);
jclass &clz = cls0;
jmethodID &mid = mth0;
D2C_RESOLVE_METHOD(clz, mid, "d/b/b/a/b", "<init>", "(Lio/pro/edgelivewallpaper/activity/SplashActivity;)V");
jvalue args[] = {{.l = v0}};
env->CallVoidMethodA(v1, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("a:invoke-static \x76\x31\x2c\x20\x76\x30\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x70\x73\x2f\x50\x65\x72\x6d\x69\x73\x73\x69\x6f\x6e\x55\x74\x69\x6c\x73\x3b\x2d\x3e\x61\x28\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x61\x70\x70\x2f\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x44\x69\x61\x6c\x6f\x67\x49\x6e\x74\x65\x72\x66\x61\x63\x65\x24\x4f\x6e\x43\x6c\x69\x63\x6b\x4c\x69\x73\x74\x65\x6e\x65\x72\x3b\x29\x4c\x61\x2f\x62\x2f\x61\x2f\x6b\x3b");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls1;
jmethodID &mid = mth1;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "io/pro/edge/ps/PermissionUtils", "a", "(Landroid/app/Activity;Landroid/content/DialogInterface$OnClickListener;)La/b/a/k;");
jvalue args[] = {{.l = v0},{.l = v1}};
v2 = (jobject) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("10:move-result-object \x76\x30");
if (v1) {
LOGD("env->DeleteLocalRef(%p):v1", v1);
env->DeleteLocalRef(v1);
}
v1 = (jobject) v2;
return (jobject) v1;
EX_UnwindBlock: return NULL;
}
