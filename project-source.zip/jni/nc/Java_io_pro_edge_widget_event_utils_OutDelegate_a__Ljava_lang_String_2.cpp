#include "Dex2C.h"

/* Lio/pro/edge/widget/event/utils/OutDelegate;->a(Ljava/lang/String;)V */
extern "C" JNIEXPORT void JNICALL
Java_io_pro_edge_widget_event_utils_OutDelegate_a__Ljava_lang_String_2(JNIEnv *env, jobject thiz, jstring p1){
jobject v0 = NULL;
jint v1;
jint v2;
jclass cls0 = NULL,cls1 = NULL;
jfieldID fld0 = NULL;
jmethodID mth0 = NULL;
v0 = (jobject)env->NewLocalRef(p1);
L0:
LOGD("0:invoke-static \x76\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x74\x65\x78\x74\x2f\x54\x65\x78\x74\x55\x74\x69\x6c\x73\x3b\x2d\x3e\x69\x73\x45\x6d\x70\x74\x79\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x68\x61\x72\x53\x65\x71\x75\x65\x6e\x63\x65\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls0;
jmethodID &mid = mth0;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "android/text/TextUtils", "isEmpty", "(Ljava/lang/CharSequence;)Z");
jvalue args[] = {{.l = v0}};
v1 = (jboolean) env->CallStaticBooleanMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("6:move-result \x76\x30");
v2 = (jint) v1;
LOGD("8:if-nez \x76\x30\x2c\x20\x2b\x34");
if(v2 != 0){
goto L2;
}
else {
goto L1;
}
L1:
LOGD("c:sput-object \x76\x31\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x75\x74\x69\x6c\x73\x2f\x4f\x75\x74\x44\x65\x6c\x65\x67\x61\x74\x65\x3b\x2d\x3e\x61\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls1;
jfieldID &fld = fld0;
D2C_RESOLVE_STATIC_FIELD(clz, fld, "io/pro/edge/widget/event/utils/OutDelegate", "a", "Ljava/lang/String;");
env->SetStaticObjectField(clz,fld,(jstring) v0);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L2:
return;
EX_UnwindBlock: return;
}
