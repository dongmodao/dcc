#include "Dex2C.h"

/* Lio/pro/edge/widget/edge/NativeUtils;->a()Landroid/app/Activity; */
extern "C" JNIEXPORT jobject JNICALL
Java_io_pro_edge_widget_edge_NativeUtils_a__(JNIEnv *env, jobject thiz){
jobject v0 = NULL;
jobject v1 = NULL;
jclass cls0 = NULL,cls1 = NULL;
jfieldID fld0 = NULL;
jmethodID mth0 = NULL;
L0:
LOGD("0:sget-object \x76\x30\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x64\x67\x65\x2f\x4e\x61\x74\x69\x76\x65\x55\x74\x69\x6c\x73\x3b\x2d\x3e\x61\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x64\x67\x65\x2f\x4e\x61\x74\x69\x76\x65\x55\x74\x69\x6c\x73\x24\x41\x43\x61\x6c\x6c\x62\x61\x63\x6b\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v0) {
LOGD("env->DeleteLocalRef(%p):v0", v0);
env->DeleteLocalRef(v0);
}
jclass &clz = cls0;
jfieldID &fld = fld0;
D2C_RESOLVE_STATIC_FIELD(clz, fld, "io/pro/edge/widget/edge/NativeUtils", "a", "Lio/pro/edge/widget/edge/NativeUtils$ACallback;");
v0 = (jobject) env->GetStaticObjectField(clz,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("4:if-eqz \x76\x30\x2c\x20\x2b\x37");
if(v0 == NULL){
goto L2;
}
else {
goto L1;
}
L1:
LOGD("8:invoke-interface \x76\x30\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x64\x67\x65\x2f\x4e\x61\x74\x69\x76\x65\x55\x74\x69\x6c\x73\x24\x41\x43\x61\x6c\x6c\x62\x61\x63\x6b\x3b\x2d\x3e\x67\x65\x74\x28\x29\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x61\x70\x70\x2f\x41\x63\x74\x69\x76\x69\x74\x79\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls1;
jmethodID &mid = mth0;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/edge/NativeUtils$ACallback", "get", "()Landroid/app/Activity;");
jvalue args[] = {};
v1 = (jobject) env->CallObjectMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("e:move-result-object \x76\x30");
if (v0) {
LOGD("env->DeleteLocalRef(%p):v0", v0);
env->DeleteLocalRef(v0);
}
v0 = (jobject) v1;
return (jobject) v0;
L2:
if (v0) {
LOGD("env->DeleteLocalRef(%p):v0", v0);
env->DeleteLocalRef(v0);
}
v0 = 0;
return (jobject) v0;
EX_UnwindBlock: return NULL;
}
