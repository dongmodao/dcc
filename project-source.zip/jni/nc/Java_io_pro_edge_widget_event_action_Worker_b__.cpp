#include "Dex2C.h"

/* Lio/pro/edge/widget/event/action/Worker;->b()V */
extern "C" JNIEXPORT void JNICALL
Java_io_pro_edge_widget_event_action_Worker_b__(JNIEnv *env, jobject thiz){
jobject v0 = NULL;
jobject v1 = NULL;
jobject v2 = NULL;
jobject v3 = NULL;
jclass cls0 = NULL,cls1 = NULL,cls2 = NULL;
jfieldID fld0 = NULL;
jmethodID mth0 = NULL, mth1 = NULL;
v0 = (jobject)env->NewLocalRef(thiz);
L0:
LOGD("0:iget-object \x76\x30\x2c\x20\x76\x32\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x57\x6f\x72\x6b\x65\x72\x3b\x2d\x3e\x78\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x6f\x73\x2f\x48\x61\x6e\x64\x6c\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jfieldID &fld = fld0;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/action/Worker", "x", "Landroid/os/Handler;");
v1 = (jobject) env->GetObjectField(v0,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
v2 = (jobject) v1;
LOGD("4:if-nez \x76\x30\x2c\x20\x2b\x64");
if(v2 != NULL){
goto L2;
}
else {
goto L1;
}
L1:
LOGD("8:new-instance \x76\x30\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x57\x6f\x72\x6b\x65\x72\x24\x32\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
jclass &clz = cls1;
D2C_RESOLVE_CLASS(clz,"io/pro/edge/widget/event/action/Worker$2");
v2 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("c:invoke-static \x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x6f\x73\x2f\x4c\x6f\x6f\x70\x65\x72\x3b\x2d\x3e\x67\x65\x74\x4d\x61\x69\x6e\x4c\x6f\x6f\x70\x65\x72\x28\x29\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x6f\x73\x2f\x4c\x6f\x6f\x70\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls2;
jmethodID &mid = mth0;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "android/os/Looper", "getMainLooper", "()Landroid/os/Looper;");
jvalue args[] = {};
v1 = (jobject) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("12:move-result-object \x76\x31");
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
v3 = (jobject) v1;
LOGD("14:invoke-direct \x76\x30\x2c\x20\x76\x32\x2c\x20\x76\x31\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x57\x6f\x72\x6b\x65\x72\x24\x32\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x57\x6f\x72\x6b\x65\x72\x3b\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x6f\x73\x2f\x4c\x6f\x6f\x70\x65\x72\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
jclass &clz = cls1;
jmethodID &mid = mth1;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/event/action/Worker$2", "<init>", "(Lio/pro/edge/widget/event/action/Worker;Landroid/os/Looper;)V");
jvalue args[] = {{.l = v0},{.l = v3}};
env->CallVoidMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("1a:iput-object \x76\x30\x2c\x20\x76\x32\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x57\x6f\x72\x6b\x65\x72\x3b\x2d\x3e\x78\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x6f\x73\x2f\x48\x61\x6e\x64\x6c\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jfieldID &fld = fld0;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/action/Worker", "x", "Landroid/os/Handler;");
env->SetObjectField(v0,fld,(jobject) v2);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L2:
return;
EX_UnwindBlock: return;
}
