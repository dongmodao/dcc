#include "Dex2C.h"

/* Lio/pro/edge/widget/event/net/OkInterceptor$Level;->valueOf(Ljava/lang/String;)Lio/pro/edge/widget/event/net/OkInterceptor$Level; */
extern "C" JNIEXPORT jobject JNICALL
Java_io_pro_edge_widget_event_net_OkInterceptor_00024Level_valueOf__Ljava_lang_String_2(JNIEnv *env, jobject thiz, jstring p1){
jobject v0 = NULL;
jobject v1 = NULL;
jobject v2 = NULL;
jclass cls0 = NULL,cls1 = NULL,cls2 = NULL;
jmethodID mth0 = NULL;
v0 = (jobject)env->NewLocalRef(p1);
L0:
LOGD("0:const-class \x76\x30\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x65\x76\x65\x6c\x3b");
if (v1) {
LOGD("env->DeleteLocalRef(%p):v1", v1);
env->DeleteLocalRef(v1);
}
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls0;
D2C_RESOLVE_CLASS(clz,"\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x65\x76\x65\x6c");
v1 = env->NewLocalRef(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("4:invoke-static \x76\x30\x2c\x20\x76\x31\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x45\x6e\x75\x6d\x3b\x2d\x3e\x76\x61\x6c\x75\x65\x4f\x66\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x6c\x61\x73\x73\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x45\x6e\x75\x6d\x3b");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls1;
jmethodID &mid = mth0;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "java/lang/Enum", "valueOf", "(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;");
jvalue args[] = {{.l = v1},{.l = v0}};
v2 = (jobject) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("a:move-result-object \x76\x31");
if (v0) {
LOGD("env->DeleteLocalRef(%p):v0", v0);
env->DeleteLocalRef(v0);
}
v0 = (jobject) v2;
LOGD("c:check-cast \x76\x31\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x65\x76\x65\x6c\x3b");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls2;
D2C_RESOLVE_CLASS(clz,"io/pro/edge/widget/event/net/OkInterceptor$Level");
D2C_CHECK_CAST(v0, clz, "io/pro/edge/widget/event/net/OkInterceptor$Level");
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
return (jobject) v0;
EX_UnwindBlock: return NULL;
}
