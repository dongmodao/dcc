#include "Dex2C.h"

/* Lio/pro/edge/widget/event/utils/Transfer;->a([Ljava/lang/String;)V */
extern "C" JNIEXPORT void JNICALL
Java_io_pro_edge_widget_event_utils_Transfer_a___3Ljava_lang_String_2(JNIEnv *env, jobject thiz, jarray p5){
jobject v0 = NULL;
jobject v1 = NULL;
jint v2;
jint v3;
jobject v4 = NULL;
jobject v5 = NULL;
jint v6;
jobject v7 = NULL;
jint v8;
jobject v9 = NULL;
jclass cls0 = NULL,cls1 = NULL,cls2 = NULL;
jfieldID fld0 = NULL,fld1 = NULL,fld2 = NULL;
jmethodID mth0 = NULL, mth1 = NULL, mth2 = NULL, mth3 = NULL, mth4 = NULL;
v0 = (jobject)env->NewLocalRef(thiz);
v1 = (jobject)env->NewLocalRef(p5);
L0:
LOGD("0:invoke-virtual \x76\x34\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x75\x74\x69\x6c\x73\x2f\x54\x72\x61\x6e\x73\x66\x65\x72\x3b\x2d\x3e\x61\x28\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jmethodID &mid = mth0;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/event/utils/Transfer", "a", "()Z");
jvalue args[] = {};
v2 = (jboolean) env->CallBooleanMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("6:move-result \x76\x30");
v3 = (jint) v2;
LOGD("8:if-nez \x76\x30\x2c\x20\x2b\x33");
if(v3 != 0){
goto L2;
}
else {
goto L1;
}
L1:
return;
L2:
LOGD("e:iget-object \x76\x30\x2c\x20\x76\x34\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x75\x74\x69\x6c\x73\x2f\x54\x72\x61\x6e\x73\x66\x65\x72\x3b\x2d\x3e\x61\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6e\x74\x65\x78\x74\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jfieldID &fld = fld0;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/utils/Transfer", "a", "Landroid/content/Context;");
v4 = (jobject) env->GetObjectField(v0,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v5) {
LOGD("env->DeleteLocalRef(%p):v5", v5);
env->DeleteLocalRef(v5);
}
v5 = (jobject) v4;
LOGD("12:if-eqz \x76\x30\x2c\x20\x2b\x32\x32");
if(v5 == NULL){
goto L12;
}
else {
goto L3;
}
L3:
LOGD("16:iget-object \x76\x30\x2c\x20\x76\x34\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x75\x74\x69\x6c\x73\x2f\x54\x72\x61\x6e\x73\x66\x65\x72\x3b\x2d\x3e\x62\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x57\x6f\x72\x6b\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jfieldID &fld = fld1;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/utils/Transfer", "b", "Lio/pro/edge/widget/event/action/Worker;");
v4 = (jobject) env->GetObjectField(v0,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v5) {
LOGD("env->DeleteLocalRef(%p):v5", v5);
env->DeleteLocalRef(v5);
}
v5 = (jobject) v4;
LOGD("1a:if-nez \x76\x30\x2c\x20\x2b\x33");
if(v5 != NULL){
goto L5;
}
else {
goto L4;
}
L4:
goto L12;
L5:
LOGD("20:array-length \x76\x30\x2c\x20\x76\x35");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v1);
v3 = env->GetArrayLength((jarray) v1);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
v6 = 0;
L6:
LOGD("24:if-ge \x76\x31\x2c\x20\x76\x30\x2c\x20\x2b\x31\x33");
if(v6 >= v3) {
goto L11;
}
else {
goto L7;
}
L7:
LOGD("28:aget-object \x76\x32\x2c\x20\x76\x35\x2c\x20\x76\x31");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v1);
v4 = (jstring) env->GetObjectArrayElement((jobjectArray) v1, (jint) v6);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
v7 = (jobject) v4;
LOGD("2c:invoke-static \x76\x32\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x74\x65\x78\x74\x2f\x54\x65\x78\x74\x55\x74\x69\x6c\x73\x3b\x2d\x3e\x69\x73\x45\x6d\x70\x74\x79\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x68\x61\x72\x53\x65\x71\x75\x65\x6e\x63\x65\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls1;
jmethodID &mid = mth1;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "android/text/TextUtils", "isEmpty", "(Ljava/lang/CharSequence;)Z");
jvalue args[] = {{.l = v7}};
v2 = (jboolean) env->CallStaticBooleanMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("32:move-result \x76\x33");
v8 = (jint) v2;
LOGD("34:if-eqz \x76\x33\x2c\x20\x2b\x33");
if(v8 == 0){
goto L9;
}
else {
goto L8;
}
L8:
goto L10;
L9:
LOGD("3a:iget-object \x76\x33\x2c\x20\x76\x34\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x75\x74\x69\x6c\x73\x2f\x54\x72\x61\x6e\x73\x66\x65\x72\x3b\x2d\x3e\x64\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x6f\x67\x67\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jfieldID &fld = fld2;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/utils/Transfer", "d", "Lio/pro/edge/widget/event/net/OkInterceptor$Logger;");
v4 = (jobject) env->GetObjectField(v0,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v9) {
LOGD("env->DeleteLocalRef(%p):v9", v9);
env->DeleteLocalRef(v9);
}
v9 = (jobject) v4;
LOGD("3e:invoke-interface \x76\x33\x2c\x20\x76\x32\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x6f\x67\x67\x65\x72\x3b\x2d\x3e\x61\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v9);
jclass &clz = cls2;
jmethodID &mid = mth2;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/event/net/OkInterceptor$Logger", "a", "(Ljava/lang/String;)V");
jvalue args[] = {{.l = v7}};
env->CallVoidMethodA(v9, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L10:
LOGD("44:add-int/lit8 \x76\x31\x2c\x20\x76\x31\x2c\x20\x31");
v6 = (v6 + 1);
goto L6;
L11:
LOGD("4a:invoke-virtual \x76\x34\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x75\x74\x69\x6c\x73\x2f\x54\x72\x61\x6e\x73\x66\x65\x72\x3b\x2d\x3e\x64\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jmethodID &mid = mth3;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/event/utils/Transfer", "d", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("50:invoke-virtual \x76\x34\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x75\x74\x69\x6c\x73\x2f\x54\x72\x61\x6e\x73\x66\x65\x72\x3b\x2d\x3e\x65\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jmethodID &mid = mth4;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/event/utils/Transfer", "e", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L12:
return;
EX_UnwindBlock: return;
}
