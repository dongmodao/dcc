#include "Dex2C.h"

/* Lio/pro/edge/widget/event/net/OkHttpProvider$2;->checkClientTrusted([Ljava/security/cert/X509Certificate;Ljava/lang/String;)V */
extern "C" JNIEXPORT void JNICALL
Java_io_pro_edge_widget_event_net_OkHttpProvider_000242_checkClientTrusted___3Ljava_security_cert_X509Certificate_2Ljava_lang_String_2(JNIEnv *env, jobject thiz, jarray p1, jstring p2){
jobject v0 = NULL;
jobject v1 = NULL;
jobject v2 = NULL;
v0 = (jobject)env->NewLocalRef(thiz);
v1 = (jobject)env->NewLocalRef(p1);
v2 = (jobject)env->NewLocalRef(p2);
L0:
return;
EX_UnwindBlock: return;
}
