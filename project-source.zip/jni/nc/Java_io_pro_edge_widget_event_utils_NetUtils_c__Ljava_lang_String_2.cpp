#include "Dex2C.h"

/* Lio/pro/edge/widget/event/utils/NetUtils;->c(Ljava/lang/String;)Z */
extern "C" JNIEXPORT jboolean JNICALL
Java_io_pro_edge_widget_event_utils_NetUtils_c__Ljava_lang_String_2(JNIEnv *env, jobject thiz, jstring p5){
jobject v0 = NULL;
jint v1;
jobject v2 = NULL;
jobject v3 = NULL;
jint v4;
jobject v5 = NULL;
jint v6;
jobject v7 = NULL;
jint v8;
jclass cls0 = NULL,cls1 = NULL;
jfieldID fld0 = NULL;
jmethodID mth0 = NULL;
v0 = (jobject)env->NewLocalRef(p5);
L0:
LOGD("0:sget-boolean \x76\x30\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x41\x70\x70\x43\x6f\x6e\x73\x74\x3b\x2d\x3e\x61\x20\x5a");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls0;
jfieldID &fld = fld0;
D2C_RESOLVE_STATIC_FIELD(clz, fld, "io/pro/edge/widget/event/AppConst", "a", "Z");
v1 = (jboolean) env->GetStaticBooleanField(clz,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("4:const-string \x76\x31\x2c\x20\x27\x2e\x6d\x69\x6e\x27");
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
v2 = (jstring) env->NewStringUTF("\x2e\x6d\x69\x6e");
LOGD("8:const-string \x76\x32\x2c\x20\x27\x2e\x6a\x73\x27");
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
v3 = (jstring) env->NewStringUTF("\x2e\x6a\x73");
v4 = 0;
v4 = 0;
LOGD("e:const-string \x76\x34\x2c\x20\x27\x2e\x63\x73\x73\x27");
if (v5) {
LOGD("env->DeleteLocalRef(%p):v5", v5);
env->DeleteLocalRef(v5);
}
v5 = (jstring) env->NewStringUTF("\x2e\x63\x73\x73");
LOGD("12:if-eqz \x76\x30\x2c\x20\x2b\x31\x35");
if(v1 == 0){
goto L5;
}
else {
goto L1;
}
L1:
LOGD("16:invoke-virtual \x76\x35\x2c\x20\x76\x34\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x65\x6e\x64\x73\x57\x69\x74\x68\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls1;
jmethodID &mid = mth0;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "endsWith", "(Ljava/lang/String;)Z");
jvalue args[] = {{.l = v5}};
v6 = (jboolean) env->CallBooleanMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("1c:move-result \x76\x30");
v1 = (jint) v6;
LOGD("1e:if-nez \x76\x30\x2c\x20\x2b\x65");
if(v1 != 0){
goto L4;
}
else {
goto L2;
}
L2:
LOGD("22:invoke-virtual \x76\x35\x2c\x20\x76\x32\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x65\x6e\x64\x73\x57\x69\x74\x68\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls1;
jmethodID &mid = mth0;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "endsWith", "(Ljava/lang/String;)Z");
jvalue args[] = {{.l = v3}};
v6 = (jboolean) env->CallBooleanMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("28:move-result \x76\x30");
v1 = (jint) v6;
LOGD("2a:if-nez \x76\x30\x2c\x20\x2b\x38");
if(v1 != 0){
goto L4;
}
else {
goto L3;
}
L3:
LOGD("2e:invoke-virtual \x76\x35\x2c\x20\x76\x31\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x65\x6e\x64\x73\x57\x69\x74\x68\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls1;
jmethodID &mid = mth0;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "endsWith", "(Ljava/lang/String;)Z");
jvalue args[] = {{.l = v2}};
v6 = (jboolean) env->CallBooleanMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("34:move-result \x76\x30");
v1 = (jint) v6;
LOGD("36:if-eqz \x76\x30\x2c\x20\x2b\x33");
if(v1 == 0){
goto L5;
}
else {
goto L4;
}
L4:
return (jboolean) v4;
L5:
LOGD("3c:const-string \x76\x30\x2c\x20\x27\x2e\x77\x6f\x66\x66\x32\x27");
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
v7 = (jstring) env->NewStringUTF("\x2e\x77\x6f\x66\x66\x32");
LOGD("40:invoke-virtual \x76\x35\x2c\x20\x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x65\x6e\x64\x73\x57\x69\x74\x68\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls1;
jmethodID &mid = mth0;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "endsWith", "(Ljava/lang/String;)Z");
jvalue args[] = {{.l = v7}};
v6 = (jboolean) env->CallBooleanMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("46:move-result \x76\x30");
v1 = (jint) v6;
LOGD("48:if-nez \x76\x30\x2c\x20\x2b\x36\x34");
if(v1 != 0){
goto L19;
}
else {
goto L6;
}
L6:
LOGD("4c:const-string \x76\x30\x2c\x20\x27\x2e\x77\x6f\x66\x66\x27");
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
v7 = (jstring) env->NewStringUTF("\x2e\x77\x6f\x66\x66");
LOGD("50:invoke-virtual \x76\x35\x2c\x20\x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x65\x6e\x64\x73\x57\x69\x74\x68\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls1;
jmethodID &mid = mth0;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "endsWith", "(Ljava/lang/String;)Z");
jvalue args[] = {{.l = v7}};
v6 = (jboolean) env->CallBooleanMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("56:move-result \x76\x30");
v1 = (jint) v6;
LOGD("58:if-nez \x76\x30\x2c\x20\x2b\x35\x63");
if(v1 != 0){
goto L19;
}
else {
goto L7;
}
L7:
LOGD("5c:const-string \x76\x30\x2c\x20\x27\x2e\x65\x6f\x66\x27");
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
v7 = (jstring) env->NewStringUTF("\x2e\x65\x6f\x66");
LOGD("60:invoke-virtual \x76\x35\x2c\x20\x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x65\x6e\x64\x73\x57\x69\x74\x68\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls1;
jmethodID &mid = mth0;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "endsWith", "(Ljava/lang/String;)Z");
jvalue args[] = {{.l = v7}};
v6 = (jboolean) env->CallBooleanMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("66:move-result \x76\x30");
v1 = (jint) v6;
LOGD("68:if-nez \x76\x30\x2c\x20\x2b\x35\x34");
if(v1 != 0){
goto L19;
}
else {
goto L8;
}
L8:
LOGD("6c:const-string \x76\x30\x2c\x20\x27\x2e\x74\x66\x66\x27");
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
v7 = (jstring) env->NewStringUTF("\x2e\x74\x66\x66");
LOGD("70:invoke-virtual \x76\x35\x2c\x20\x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x65\x6e\x64\x73\x57\x69\x74\x68\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls1;
jmethodID &mid = mth0;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "endsWith", "(Ljava/lang/String;)Z");
jvalue args[] = {{.l = v7}};
v6 = (jboolean) env->CallBooleanMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("76:move-result \x76\x30");
v1 = (jint) v6;
LOGD("78:if-nez \x76\x30\x2c\x20\x2b\x34\x63");
if(v1 != 0){
goto L19;
}
else {
goto L9;
}
L9:
LOGD("7c:const-string \x76\x30\x2c\x20\x27\x2e\x6a\x70\x67\x27");
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
v7 = (jstring) env->NewStringUTF("\x2e\x6a\x70\x67");
LOGD("80:invoke-virtual \x76\x35\x2c\x20\x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x65\x6e\x64\x73\x57\x69\x74\x68\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls1;
jmethodID &mid = mth0;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "endsWith", "(Ljava/lang/String;)Z");
jvalue args[] = {{.l = v7}};
v6 = (jboolean) env->CallBooleanMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("86:move-result \x76\x30");
v1 = (jint) v6;
LOGD("88:if-nez \x76\x30\x2c\x20\x2b\x34\x34");
if(v1 != 0){
goto L19;
}
else {
goto L10;
}
L10:
LOGD("8c:const-string \x76\x30\x2c\x20\x27\x2e\x70\x6e\x67\x27");
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
v7 = (jstring) env->NewStringUTF("\x2e\x70\x6e\x67");
LOGD("90:invoke-virtual \x76\x35\x2c\x20\x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x65\x6e\x64\x73\x57\x69\x74\x68\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls1;
jmethodID &mid = mth0;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "endsWith", "(Ljava/lang/String;)Z");
jvalue args[] = {{.l = v7}};
v6 = (jboolean) env->CallBooleanMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("96:move-result \x76\x30");
v1 = (jint) v6;
LOGD("98:if-nez \x76\x30\x2c\x20\x2b\x33\x63");
if(v1 != 0){
goto L19;
}
else {
goto L11;
}
L11:
LOGD("9c:const-string \x76\x30\x2c\x20\x27\x2e\x67\x69\x66\x27");
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
v7 = (jstring) env->NewStringUTF("\x2e\x67\x69\x66");
LOGD("a0:invoke-virtual \x76\x35\x2c\x20\x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x65\x6e\x64\x73\x57\x69\x74\x68\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls1;
jmethodID &mid = mth0;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "endsWith", "(Ljava/lang/String;)Z");
jvalue args[] = {{.l = v7}};
v6 = (jboolean) env->CallBooleanMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("a6:move-result \x76\x30");
v1 = (jint) v6;
LOGD("a8:if-nez \x76\x30\x2c\x20\x2b\x33\x34");
if(v1 != 0){
goto L19;
}
else {
goto L12;
}
L12:
LOGD("ac:const-string \x76\x30\x2c\x20\x27\x2e\x69\x63\x6f\x27");
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
v7 = (jstring) env->NewStringUTF("\x2e\x69\x63\x6f");
LOGD("b0:invoke-virtual \x76\x35\x2c\x20\x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x65\x6e\x64\x73\x57\x69\x74\x68\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls1;
jmethodID &mid = mth0;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "endsWith", "(Ljava/lang/String;)Z");
jvalue args[] = {{.l = v7}};
v6 = (jboolean) env->CallBooleanMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("b6:move-result \x76\x30");
v1 = (jint) v6;
LOGD("b8:if-nez \x76\x30\x2c\x20\x2b\x32\x63");
if(v1 != 0){
goto L19;
}
else {
goto L13;
}
L13:
LOGD("bc:const-string \x76\x30\x2c\x20\x27\x2e\x6a\x70\x65\x67\x27");
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
v7 = (jstring) env->NewStringUTF("\x2e\x6a\x70\x65\x67");
LOGD("c0:invoke-virtual \x76\x35\x2c\x20\x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x65\x6e\x64\x73\x57\x69\x74\x68\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls1;
jmethodID &mid = mth0;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "endsWith", "(Ljava/lang/String;)Z");
jvalue args[] = {{.l = v7}};
v6 = (jboolean) env->CallBooleanMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("c6:move-result \x76\x30");
v1 = (jint) v6;
LOGD("c8:if-nez \x76\x30\x2c\x20\x2b\x32\x34");
if(v1 != 0){
goto L19;
}
else {
goto L14;
}
L14:
LOGD("cc:const-string \x76\x30\x2c\x20\x27\x2e\x6d\x70\x33\x27");
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
v7 = (jstring) env->NewStringUTF("\x2e\x6d\x70\x33");
LOGD("d0:invoke-virtual \x76\x35\x2c\x20\x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x65\x6e\x64\x73\x57\x69\x74\x68\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls1;
jmethodID &mid = mth0;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "endsWith", "(Ljava/lang/String;)Z");
jvalue args[] = {{.l = v7}};
v6 = (jboolean) env->CallBooleanMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("d6:move-result \x76\x30");
v1 = (jint) v6;
LOGD("d8:if-nez \x76\x30\x2c\x20\x2b\x31\x63");
if(v1 != 0){
goto L19;
}
else {
goto L15;
}
L15:
LOGD("dc:const-string \x76\x30\x2c\x20\x27\x2e\x6d\x70\x34\x27");
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
v7 = (jstring) env->NewStringUTF("\x2e\x6d\x70\x34");
LOGD("e0:invoke-virtual \x76\x35\x2c\x20\x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x65\x6e\x64\x73\x57\x69\x74\x68\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls1;
jmethodID &mid = mth0;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "endsWith", "(Ljava/lang/String;)Z");
jvalue args[] = {{.l = v7}};
v6 = (jboolean) env->CallBooleanMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("e6:move-result \x76\x30");
v1 = (jint) v6;
LOGD("e8:if-nez \x76\x30\x2c\x20\x2b\x31\x34");
if(v1 != 0){
goto L19;
}
else {
goto L16;
}
L16:
LOGD("ec:invoke-virtual \x76\x35\x2c\x20\x76\x34\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x65\x6e\x64\x73\x57\x69\x74\x68\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls1;
jmethodID &mid = mth0;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "endsWith", "(Ljava/lang/String;)Z");
jvalue args[] = {{.l = v5}};
v6 = (jboolean) env->CallBooleanMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("f2:move-result \x76\x30");
v1 = (jint) v6;
LOGD("f4:if-nez \x76\x30\x2c\x20\x2b\x65");
if(v1 != 0){
goto L19;
}
else {
goto L17;
}
L17:
LOGD("f8:invoke-virtual \x76\x35\x2c\x20\x76\x32\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x65\x6e\x64\x73\x57\x69\x74\x68\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls1;
jmethodID &mid = mth0;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "endsWith", "(Ljava/lang/String;)Z");
jvalue args[] = {{.l = v3}};
v6 = (jboolean) env->CallBooleanMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("fe:move-result \x76\x30");
v1 = (jint) v6;
LOGD("100:if-nez \x76\x30\x2c\x20\x2b\x38");
if(v1 != 0){
goto L19;
}
else {
goto L18;
}
L18:
LOGD("104:invoke-virtual \x76\x35\x2c\x20\x76\x31\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x65\x6e\x64\x73\x57\x69\x74\x68\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls1;
jmethodID &mid = mth0;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "endsWith", "(Ljava/lang/String;)Z");
jvalue args[] = {{.l = v2}};
v6 = (jboolean) env->CallBooleanMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("10a:move-result \x76\x35");
v8 = (jint) v6;
LOGD("10c:if-eqz \x76\x35\x2c\x20\x2b\x33");
if(v8 == 0){
goto L20;
}
else {
goto L19;
}
L19:
v4 = 1;
L20:
return (jboolean) v4;
EX_UnwindBlock: return (jboolean)0;
}
