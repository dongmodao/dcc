#include "Dex2C.h"

/* Lio/pro/edgelivewallpaper/activity/SplashActivity;->l()Z */
extern "C" JNIEXPORT jboolean JNICALL
Java_io_pro_edgelivewallpaper_activity_SplashActivity_l__(JNIEnv *env, jobject thiz){
jobject v0 = NULL;
jint v1;
v0 = (jobject)env->NewLocalRef(thiz);
L0:
v1 = 1;
return (jboolean) v1;
EX_UnwindBlock: return (jboolean)0;
}
