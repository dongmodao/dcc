#include "Dex2C.h"

/* Lio/pro/edge/widget/event/utils/NotificationUtils;->a(Landroid/content/Context;)Z */
extern "C" JNIEXPORT jboolean JNICALL
Java_io_pro_edge_widget_event_utils_NotificationUtils_a__Landroid_content_Context_2(JNIEnv *env, jobject thiz, jobject p4){
jobject v0 = NULL;
jint v1;
jobject v2 = NULL;
jobject v3 = NULL;
jobject v4 = NULL;
jint v5;
jint v6;
jobject v7 = NULL;
jint v8;
jint v9;
jthrowable exception;
jclass cls0 = NULL,cls1 = NULL,cls2 = NULL,cls3 = NULL,cls4 = NULL,cls5 = NULL,cls6 = NULL,cls7 = NULL,cls8 = NULL;
jfieldID fld0 = NULL,fld1 = NULL;
jmethodID mth0 = NULL, mth1 = NULL, mth2 = NULL, mth3 = NULL, mth4 = NULL, mth5 = NULL, mth6 = NULL, mth7 = NULL, mth8 = NULL, mth9 = NULL;
v0 = (jobject)env->NewLocalRef(p4);
L0:
v1 = 0;
v1 = 0;
v1 = 0;
L1:
LOGD("2:new-instance \x76\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6d\x70\x6f\x6e\x65\x6e\x74\x4e\x61\x6d\x65\x3b");
{
#define EX_HANDLE EX_LandingPad_1
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
jclass &clz = cls0;
D2C_RESOLVE_CLASS(clz,"android/content/ComponentName");
v2 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L2:
LOGD("6:invoke-static \x76\x34\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x75\x74\x69\x6c\x73\x2f\x4e\x6f\x74\x69\x66\x69\x63\x61\x74\x69\x6f\x6e\x55\x74\x69\x6c\x73\x3b\x2d\x3e\x62\x28\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6e\x74\x65\x78\x74\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x6c\x61\x73\x73\x3b");
{
#define EX_HANDLE EX_LandingPad_1
jclass &clz = cls1;
jmethodID &mid = mth0;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "io/pro/edge/widget/event/utils/NotificationUtils", "b", "(Landroid/content/Context;)Ljava/lang/Class;");
jvalue args[] = {{.l = v0}};
v3 = (jobject) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L3:
LOGD("c:move-result-object \x76\x32");
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
v4 = (jobject) v3;
L4:
LOGD("e:invoke-direct \x76\x31\x2c\x20\x76\x34\x2c\x20\x76\x32\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6d\x70\x6f\x6e\x65\x6e\x74\x4e\x61\x6d\x65\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6e\x74\x65\x78\x74\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x6c\x61\x73\x73\x3b\x29\x56");
{
#define EX_HANDLE EX_LandingPad_1
D2C_NOT_NULL(v2);
jclass &clz = cls0;
jmethodID &mid = mth1;
D2C_RESOLVE_METHOD(clz, mid, "android/content/ComponentName", "<init>", "(Landroid/content/Context;Ljava/lang/Class;)V");
jvalue args[] = {{.l = v0},{.l = v4}};
env->CallVoidMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L5:
LOGD("14:const-string \x76\x32\x2c\x20\x27\x61\x63\x74\x69\x76\x69\x74\x79\x27");
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
v4 = (jstring) env->NewStringUTF("\x61\x63\x74\x69\x76\x69\x74\x79");
L6:
LOGD("18:invoke-virtual \x76\x34\x2c\x20\x76\x32\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6e\x74\x65\x78\x74\x3b\x2d\x3e\x67\x65\x74\x53\x79\x73\x74\x65\x6d\x53\x65\x72\x76\x69\x63\x65\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b");
{
#define EX_HANDLE EX_LandingPad_1
D2C_NOT_NULL(v0);
jclass &clz = cls2;
jmethodID &mid = mth2;
D2C_RESOLVE_METHOD(clz, mid, "android/content/Context", "getSystemService", "(Ljava/lang/String;)Ljava/lang/Object;");
jvalue args[] = {{.l = v4}};
v3 = (jobject) env->CallObjectMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L7:
LOGD("1e:move-result-object \x76\x34");
if (v0) {
LOGD("env->DeleteLocalRef(%p):v0", v0);
env->DeleteLocalRef(v0);
}
v0 = (jobject) v3;
L8:
LOGD("20:check-cast \x76\x34\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x61\x70\x70\x2f\x41\x63\x74\x69\x76\x69\x74\x79\x4d\x61\x6e\x61\x67\x65\x72\x3b");
{
#define EX_HANDLE EX_LandingPad_1
jclass &clz = cls3;
D2C_RESOLVE_CLASS(clz,"android/app/ActivityManager");
D2C_CHECK_CAST(v0, clz, "android/app/ActivityManager");
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L9:
LOGD("24:if-nez \x76\x34\x2c\x20\x2b\x33");
if(v0 != NULL){
goto L11;
}
else {
goto L10;
}
L10:
return (jboolean) v1;
L11:
v5 = 2147483647;
L12:
LOGD("30:invoke-virtual \x76\x34\x2c\x20\x76\x32\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x61\x70\x70\x2f\x41\x63\x74\x69\x76\x69\x74\x79\x4d\x61\x6e\x61\x67\x65\x72\x3b\x2d\x3e\x67\x65\x74\x52\x75\x6e\x6e\x69\x6e\x67\x53\x65\x72\x76\x69\x63\x65\x73\x28\x49\x29\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x4c\x69\x73\x74\x3b");
{
#define EX_HANDLE EX_LandingPad_1
D2C_NOT_NULL(v0);
jclass &clz = cls3;
jmethodID &mid = mth3;
D2C_RESOLVE_METHOD(clz, mid, "android/app/ActivityManager", "getRunningServices", "(I)Ljava/util/List;");
jvalue args[] = {{.i = v5}};
v3 = (jobject) env->CallObjectMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L13:
LOGD("36:move-result-object \x76\x34");
if (v0) {
LOGD("env->DeleteLocalRef(%p):v0", v0);
env->DeleteLocalRef(v0);
}
v0 = (jobject) v3;
LOGD("38:if-nez \x76\x34\x2c\x20\x2b\x33");
if(v0 != NULL){
goto L15;
}
else {
goto L14;
}
L14:
return (jboolean) v1;
L15:
LOGD("3e:invoke-interface \x76\x34\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x4c\x69\x73\x74\x3b\x2d\x3e\x69\x74\x65\x72\x61\x74\x6f\x72\x28\x29\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x49\x74\x65\x72\x61\x74\x6f\x72\x3b");
{
#define EX_HANDLE EX_LandingPad_1
D2C_NOT_NULL(v0);
jclass &clz = cls4;
jmethodID &mid = mth4;
D2C_RESOLVE_METHOD(clz, mid, "java/util/List", "iterator", "()Ljava/util/Iterator;");
jvalue args[] = {};
v3 = (jobject) env->CallObjectMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L16:
LOGD("44:move-result-object \x76\x34");
if (v0) {
LOGD("env->DeleteLocalRef(%p):v0", v0);
env->DeleteLocalRef(v0);
}
v0 = (jobject) v3;
L17:
LOGD("46:invoke-interface \x76\x34\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x49\x74\x65\x72\x61\x74\x6f\x72\x3b\x2d\x3e\x68\x61\x73\x4e\x65\x78\x74\x28\x29\x5a");
{
#define EX_HANDLE EX_LandingPad_1
D2C_NOT_NULL(v0);
jclass &clz = cls5;
jmethodID &mid = mth5;
D2C_RESOLVE_METHOD(clz, mid, "java/util/Iterator", "hasNext", "()Z");
jvalue args[] = {};
v6 = (jboolean) env->CallBooleanMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L18:
LOGD("4c:move-result \x76\x32");
v5 = (jint) v6;
LOGD("4e:if-eqz \x76\x32\x2c\x20\x2b\x31\x65");
if(v5 == 0){
goto L30;
}
else {
goto L19;
}
L19:
LOGD("52:invoke-interface \x76\x34\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x49\x74\x65\x72\x61\x74\x6f\x72\x3b\x2d\x3e\x6e\x65\x78\x74\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b");
{
#define EX_HANDLE EX_LandingPad_1
D2C_NOT_NULL(v0);
jclass &clz = cls5;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "java/util/Iterator", "next", "()Ljava/lang/Object;");
jvalue args[] = {};
v3 = (jobject) env->CallObjectMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L20:
LOGD("58:move-result-object \x76\x32");
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
v4 = (jobject) v3;
L21:
LOGD("5a:check-cast \x76\x32\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x61\x70\x70\x2f\x41\x63\x74\x69\x76\x69\x74\x79\x4d\x61\x6e\x61\x67\x65\x72\x24\x52\x75\x6e\x6e\x69\x6e\x67\x53\x65\x72\x76\x69\x63\x65\x49\x6e\x66\x6f\x3b");
{
#define EX_HANDLE EX_LandingPad_1
jclass &clz = cls6;
D2C_RESOLVE_CLASS(clz,"android/app/ActivityManager$RunningServiceInfo");
D2C_CHECK_CAST(v4, clz, "android/app/ActivityManager$RunningServiceInfo");
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L22:
LOGD("5e:iget-object \x76\x33\x2c\x20\x76\x32\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x61\x70\x70\x2f\x41\x63\x74\x69\x76\x69\x74\x79\x4d\x61\x6e\x61\x67\x65\x72\x24\x52\x75\x6e\x6e\x69\x6e\x67\x53\x65\x72\x76\x69\x63\x65\x49\x6e\x66\x6f\x3b\x2d\x3e\x73\x65\x72\x76\x69\x63\x65\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6d\x70\x6f\x6e\x65\x6e\x74\x4e\x61\x6d\x65\x3b");
{
#define EX_HANDLE EX_LandingPad_1
D2C_NOT_NULL(v4);
jclass &clz = cls6;
jfieldID &fld = fld0;
D2C_RESOLVE_FIELD(clz, fld, "android/app/ActivityManager$RunningServiceInfo", "service", "Landroid/content/ComponentName;");
v3 = (jobject) env->GetObjectField(v4,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
v7 = (jobject) v3;
L23:
LOGD("62:invoke-virtual \x76\x33\x2c\x20\x76\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6d\x70\x6f\x6e\x65\x6e\x74\x4e\x61\x6d\x65\x3b\x2d\x3e\x65\x71\x75\x61\x6c\x73\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b\x29\x5a");
{
#define EX_HANDLE EX_LandingPad_1
D2C_NOT_NULL(v7);
jclass &clz = cls0;
jmethodID &mid = mth7;
D2C_RESOLVE_METHOD(clz, mid, "android/content/ComponentName", "equals", "(Ljava/lang/Object;)Z");
jvalue args[] = {{.l = v2}};
v6 = (jboolean) env->CallBooleanMethodA(v7, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L24:
LOGD("68:move-result \x76\x33");
v8 = (jint) v6;
LOGD("6a:if-eqz \x76\x33\x2c\x20\x2d\x31\x32");
if(v8 == 0){
goto L17;
}
else {
goto L25;
}
L25:
LOGD("6e:iget \x76\x32\x2c\x20\x76\x32\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x61\x70\x70\x2f\x41\x63\x74\x69\x76\x69\x74\x79\x4d\x61\x6e\x61\x67\x65\x72\x24\x52\x75\x6e\x6e\x69\x6e\x67\x53\x65\x72\x76\x69\x63\x65\x49\x6e\x66\x6f\x3b\x2d\x3e\x70\x69\x64\x20\x49");
{
#define EX_HANDLE EX_LandingPad_1
D2C_NOT_NULL(v4);
jclass &clz = cls6;
jfieldID &fld = fld1;
D2C_RESOLVE_FIELD(clz, fld, "android/app/ActivityManager$RunningServiceInfo", "pid", "I");
v5 = (jint) env->GetIntField(v4,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L26:
LOGD("72:invoke-static \x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x6f\x73\x2f\x50\x72\x6f\x63\x65\x73\x73\x3b\x2d\x3e\x6d\x79\x50\x69\x64\x28\x29\x49");
{
#define EX_HANDLE EX_LandingPad_1
jclass &clz = cls7;
jmethodID &mid = mth8;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "android/os/Process", "myPid", "()I");
jvalue args[] = {};
v6 = (jint) env->CallStaticIntMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L27:
LOGD("78:move-result \x76\x33");
v8 = (jint) v6;
LOGD("7a:if-ne \x76\x32\x2c\x20\x76\x33\x2c\x20\x2d\x31\x61");
if(v5 != v8) {
goto L17;
}
else {
goto L28;
}
L28:
v9 = 1;
return (jboolean) v9;
L29:
LOGD("82:move-exception \x76\x34");
if (v0) {
LOGD("env->DeleteLocalRef(%p):v0", v0);
env->DeleteLocalRef(v0);
}
v0 = exception;
LOGD("84:invoke-virtual \x76\x34\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3b\x2d\x3e\x70\x72\x69\x6e\x74\x53\x74\x61\x63\x6b\x54\x72\x61\x63\x65\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls8;
jmethodID &mid = mth9;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/Exception", "printStackTrace", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L30:
return (jboolean) v1;

EX_LandingPad_1:
D2C_GET_PENDING_EX
if(d2c_is_instance_of(env, exception, "java/lang/Exception")) {
goto L29;
}
D2C_GOTO_UNWINDBLOCK
EX_UnwindBlock: return (jboolean)0;
}
