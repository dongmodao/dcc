#include "Dex2C.h"

/* Lio/pro/edge/widget/event/net/OkHttpProvider$1;->verify(Ljava/lang/String;Ljavax/net/ssl/SSLSession;)Z */
extern "C" JNIEXPORT jboolean JNICALL
Java_io_pro_edge_widget_event_net_OkHttpProvider_000241_verify__Ljava_lang_String_2Ljavax_net_ssl_SSLSession_2(JNIEnv *env, jobject thiz, jstring p1, jobject p2){
jobject v0 = NULL;
jobject v1 = NULL;
jobject v2 = NULL;
jint v3;
v0 = (jobject)env->NewLocalRef(thiz);
v1 = (jobject)env->NewLocalRef(p1);
v2 = (jobject)env->NewLocalRef(p2);
L0:
v3 = 1;
return (jboolean) v3;
EX_UnwindBlock: return (jboolean)0;
}
