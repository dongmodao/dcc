#include "Dex2C.h"

/* Lio/pro/edgelivewallpaper/activity/SplashActivity;->k()V */
extern "C" JNIEXPORT void JNICALL
Java_io_pro_edgelivewallpaper_activity_SplashActivity_k__(JNIEnv *env, jobject thiz){
jobject v0 = NULL;
jint v1;
jobject v2 = NULL;
jobject v3 = NULL;
jclass cls0 = NULL,cls1 = NULL,cls2 = NULL;
jfieldID fld0 = NULL,fld1 = NULL;
jmethodID mth0 = NULL, mth1 = NULL, mth2 = NULL;
v0 = (jobject)env->NewLocalRef(thiz);
L0:
v1 = 2131165371;
LOGD("6:invoke-virtual \x76\x31\x2c\x20\x76\x30\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x78\x2f\x61\x70\x70\x63\x6f\x6d\x70\x61\x74\x2f\x61\x70\x70\x2f\x41\x70\x70\x43\x6f\x6d\x70\x61\x74\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x2d\x3e\x66\x69\x6e\x64\x56\x69\x65\x77\x42\x79\x49\x64\x28\x49\x29\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x76\x69\x65\x77\x2f\x56\x69\x65\x77\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jmethodID &mid = mth0;
D2C_RESOLVE_METHOD(clz, mid, "androidx/appcompat/app/AppCompatActivity", "findViewById", "(I)Landroid/view/View;");
jvalue args[] = {{.i = v1}};
v2 = (jobject) env->CallObjectMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("c:move-result-object \x76\x30");
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
v3 = (jobject) v2;
LOGD("e:check-cast \x76\x30\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x49\x6d\x61\x67\x65\x56\x69\x65\x77\x3b");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls1;
D2C_RESOLVE_CLASS(clz,"android/widget/ImageView");
D2C_CHECK_CAST(v3, clz, "android/widget/ImageView");
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("12:iput-object \x76\x30\x2c\x20\x76\x31\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x6c\x69\x76\x65\x77\x61\x6c\x6c\x70\x61\x70\x65\x72\x2f\x61\x63\x74\x69\x76\x69\x74\x79\x2f\x53\x70\x6c\x61\x73\x68\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x2d\x3e\x64\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x49\x6d\x61\x67\x65\x56\x69\x65\x77\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls2;
jfieldID &fld = fld0;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edgelivewallpaper/activity/SplashActivity", "d", "Landroid/widget/ImageView;");
env->SetObjectField(v0,fld,(jobject) v3);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("16:invoke-virtual \x76\x31\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x6c\x69\x76\x65\x77\x61\x6c\x6c\x70\x61\x70\x65\x72\x2f\x61\x63\x74\x69\x76\x69\x74\x79\x2f\x53\x70\x6c\x61\x73\x68\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x2d\x3e\x6f\x28\x29\x4c\x61\x2f\x62\x2f\x61\x2f\x6b\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls2;
jmethodID &mid = mth1;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edgelivewallpaper/activity/SplashActivity", "o", "()La/b/a/k;");
jvalue args[] = {};
v2 = (jobject) env->CallObjectMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("1c:move-result-object \x76\x30");
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
v3 = (jobject) v2;
LOGD("1e:iput-object \x76\x30\x2c\x20\x76\x31\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x6c\x69\x76\x65\x77\x61\x6c\x6c\x70\x61\x70\x65\x72\x2f\x61\x63\x74\x69\x76\x69\x74\x79\x2f\x53\x70\x6c\x61\x73\x68\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x2d\x3e\x65\x20\x4c\x61\x2f\x62\x2f\x61\x2f\x6b\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls2;
jfieldID &fld = fld1;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edgelivewallpaper/activity/SplashActivity", "e", "La/b/a/k;");
env->SetObjectField(v0,fld,(jobject) v3);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("22:invoke-virtual \x76\x31\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x6c\x69\x76\x65\x77\x61\x6c\x6c\x70\x61\x70\x65\x72\x2f\x61\x63\x74\x69\x76\x69\x74\x79\x2f\x53\x70\x6c\x61\x73\x68\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x2d\x3e\x75\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls2;
jmethodID &mid = mth2;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edgelivewallpaper/activity/SplashActivity", "u", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
return;
EX_UnwindBlock: return;
}
