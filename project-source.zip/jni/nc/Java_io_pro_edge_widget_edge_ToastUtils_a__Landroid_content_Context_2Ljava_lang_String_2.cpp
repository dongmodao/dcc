#include "Dex2C.h"

/* Lio/pro/edge/widget/edge/ToastUtils;->a(Landroid/content/Context;Ljava/lang/String;)V */
extern "C" JNIEXPORT void JNICALL
Java_io_pro_edge_widget_edge_ToastUtils_a__Landroid_content_Context_2Ljava_lang_String_2(JNIEnv *env, jobject thiz, jobject p3, jstring p4){
jobject v0 = NULL;
jobject v1 = NULL;
jobject v2 = NULL;
jobject v3 = NULL;
jobject v4 = NULL;
jint v5;
jobject v6 = NULL;
jint v7;
jint v8;
jthrowable exception;
jclass cls0 = NULL,cls1 = NULL,cls2 = NULL,cls3 = NULL,cls4 = NULL,cls5 = NULL,cls6 = NULL,cls7 = NULL;
jfieldID fld0 = NULL,fld1 = NULL;
jmethodID mth0 = NULL, mth1 = NULL, mth2 = NULL, mth3 = NULL, mth4 = NULL, mth5 = NULL, mth6 = NULL, mth7 = NULL, mth8 = NULL, mth9 = NULL, mth10 = NULL;
v0 = (jobject)env->NewLocalRef(p3);
v1 = (jobject)env->NewLocalRef(p4);
L0:
LOGD("0:new-instance \x76\x30\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x54\x6f\x61\x73\x74\x3b");
{
#define EX_HANDLE EX_LandingPad_0
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
jclass &clz = cls0;
D2C_RESOLVE_CLASS(clz,"android/widget/Toast");
v2 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L1:
LOGD("4:invoke-virtual \x76\x33\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6e\x74\x65\x78\x74\x3b\x2d\x3e\x67\x65\x74\x41\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x43\x6f\x6e\x74\x65\x78\x74\x28\x29\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6e\x74\x65\x78\x74\x3b");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v0);
jclass &clz = cls1;
jmethodID &mid = mth0;
D2C_RESOLVE_METHOD(clz, mid, "android/content/Context", "getApplicationContext", "()Landroid/content/Context;");
jvalue args[] = {};
v3 = (jobject) env->CallObjectMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L2:
LOGD("a:move-result-object \x76\x31");
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
v4 = (jobject) v3;
L3:
LOGD("c:invoke-direct \x76\x30\x2c\x20\x76\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x54\x6f\x61\x73\x74\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6e\x74\x65\x78\x74\x3b\x29\x56");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v2);
jclass &clz = cls0;
jmethodID &mid = mth1;
D2C_RESOLVE_METHOD(clz, mid, "android/widget/Toast", "<init>", "(Landroid/content/Context;)V");
jvalue args[] = {{.l = v4}};
env->CallVoidMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L4:
LOGD("12:invoke-virtual \x76\x33\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6e\x74\x65\x78\x74\x3b\x2d\x3e\x67\x65\x74\x41\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x43\x6f\x6e\x74\x65\x78\x74\x28\x29\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6e\x74\x65\x78\x74\x3b");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v0);
jclass &clz = cls1;
jmethodID &mid = mth0;
D2C_RESOLVE_METHOD(clz, mid, "android/content/Context", "getApplicationContext", "()Landroid/content/Context;");
jvalue args[] = {};
v3 = (jobject) env->CallObjectMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L5:
LOGD("18:move-result-object \x76\x33");
if (v0) {
LOGD("env->DeleteLocalRef(%p):v0", v0);
env->DeleteLocalRef(v0);
}
v0 = (jobject) v3;
L6:
LOGD("1a:invoke-static \x76\x33\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x76\x69\x65\x77\x2f\x4c\x61\x79\x6f\x75\x74\x49\x6e\x66\x6c\x61\x74\x65\x72\x3b\x2d\x3e\x66\x72\x6f\x6d\x28\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6e\x74\x65\x78\x74\x3b\x29\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x76\x69\x65\x77\x2f\x4c\x61\x79\x6f\x75\x74\x49\x6e\x66\x6c\x61\x74\x65\x72\x3b");
{
#define EX_HANDLE EX_LandingPad_0
jclass &clz = cls2;
jmethodID &mid = mth2;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "android/view/LayoutInflater", "from", "(Landroid/content/Context;)Landroid/view/LayoutInflater;");
jvalue args[] = {{.l = v0}};
v3 = (jobject) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L7:
LOGD("20:move-result-object \x76\x33");
if (v0) {
LOGD("env->DeleteLocalRef(%p):v0", v0);
env->DeleteLocalRef(v0);
}
v0 = (jobject) v3;
L8:
LOGD("22:sget \x76\x31\x2c\x20\x4c\x63\x2f\x62\x2f\x61\x2f\x62\x3b\x2d\x3e\x6c\x61\x79\x6f\x75\x74\x5f\x74\x6f\x61\x73\x74\x20\x49");
{
#define EX_HANDLE EX_LandingPad_0
jclass &clz = cls3;
jfieldID &fld = fld0;
D2C_RESOLVE_STATIC_FIELD(clz, fld, "c/b/a/b", "layout_toast", "I");
v5 = (jint) env->GetStaticIntField(clz,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L9:
if (v6) {
LOGD("env->DeleteLocalRef(%p):v6", v6);
env->DeleteLocalRef(v6);
}
v6 = 0;
L10:
LOGD("28:invoke-virtual \x76\x33\x2c\x20\x76\x31\x2c\x20\x76\x32\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x76\x69\x65\x77\x2f\x4c\x61\x79\x6f\x75\x74\x49\x6e\x66\x6c\x61\x74\x65\x72\x3b\x2d\x3e\x69\x6e\x66\x6c\x61\x74\x65\x28\x49\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x76\x69\x65\x77\x2f\x56\x69\x65\x77\x47\x72\x6f\x75\x70\x3b\x29\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x76\x69\x65\x77\x2f\x56\x69\x65\x77\x3b");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v0);
jclass &clz = cls2;
jmethodID &mid = mth3;
D2C_RESOLVE_METHOD(clz, mid, "android/view/LayoutInflater", "inflate", "(ILandroid/view/ViewGroup;)Landroid/view/View;");
jvalue args[] = {{.i = v5},{.l = v6}};
v3 = (jobject) env->CallObjectMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L11:
LOGD("2e:move-result-object \x76\x33");
if (v0) {
LOGD("env->DeleteLocalRef(%p):v0", v0);
env->DeleteLocalRef(v0);
}
v0 = (jobject) v3;
L12:
LOGD("30:sget \x76\x31\x2c\x20\x4c\x63\x2f\x62\x2f\x61\x2f\x61\x3b\x2d\x3e\x74\x76\x5f\x6d\x65\x73\x73\x61\x67\x65\x20\x49");
{
#define EX_HANDLE EX_LandingPad_0
jclass &clz = cls4;
jfieldID &fld = fld1;
D2C_RESOLVE_STATIC_FIELD(clz, fld, "c/b/a/a", "tv_message", "I");
v5 = (jint) env->GetStaticIntField(clz,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L13:
LOGD("34:invoke-virtual \x76\x33\x2c\x20\x76\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x76\x69\x65\x77\x2f\x56\x69\x65\x77\x3b\x2d\x3e\x66\x69\x6e\x64\x56\x69\x65\x77\x42\x79\x49\x64\x28\x49\x29\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x76\x69\x65\x77\x2f\x56\x69\x65\x77\x3b");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v0);
jclass &clz = cls5;
jmethodID &mid = mth4;
D2C_RESOLVE_METHOD(clz, mid, "android/view/View", "findViewById", "(I)Landroid/view/View;");
jvalue args[] = {{.i = v5}};
v3 = (jobject) env->CallObjectMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L14:
LOGD("3a:move-result-object \x76\x31");
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
v4 = (jobject) v3;
L15:
LOGD("3c:check-cast \x76\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x54\x65\x78\x74\x56\x69\x65\x77\x3b");
{
#define EX_HANDLE EX_LandingPad_0
jclass &clz = cls6;
D2C_RESOLVE_CLASS(clz,"android/widget/TextView");
D2C_CHECK_CAST(v4, clz, "android/widget/TextView");
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L16:
LOGD("40:invoke-virtual \x76\x31\x2c\x20\x76\x34\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x54\x65\x78\x74\x56\x69\x65\x77\x3b\x2d\x3e\x73\x65\x74\x54\x65\x78\x74\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x68\x61\x72\x53\x65\x71\x75\x65\x6e\x63\x65\x3b\x29\x56");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v4);
jclass &clz = cls6;
jmethodID &mid = mth5;
D2C_RESOLVE_METHOD(clz, mid, "android/widget/TextView", "setText", "(Ljava/lang/CharSequence;)V");
jvalue args[] = {{.l = v1}};
env->CallVoidMethodA(v4, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L17:
LOGD("46:invoke-virtual \x76\x30\x2c\x20\x76\x33\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x54\x6f\x61\x73\x74\x3b\x2d\x3e\x73\x65\x74\x56\x69\x65\x77\x28\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x76\x69\x65\x77\x2f\x56\x69\x65\x77\x3b\x29\x56");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v2);
jclass &clz = cls0;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "android/widget/Toast", "setView", "(Landroid/view/View;)V");
jvalue args[] = {{.l = v0}};
env->CallVoidMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L18:
v7 = 17;
v8 = 0;
L19:
LOGD("52:invoke-virtual \x76\x30\x2c\x20\x76\x33\x2c\x20\x76\x34\x2c\x20\x76\x34\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x54\x6f\x61\x73\x74\x3b\x2d\x3e\x73\x65\x74\x47\x72\x61\x76\x69\x74\x79\x28\x49\x20\x49\x20\x49\x29\x56");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v2);
jclass &clz = cls0;
jmethodID &mid = mth7;
D2C_RESOLVE_METHOD(clz, mid, "android/widget/Toast", "setGravity", "(III)V");
jvalue args[] = {{.i = v7},{.i = v8},{.i = v8}};
env->CallVoidMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L20:
v7 = 1;
L21:
LOGD("5a:invoke-virtual \x76\x30\x2c\x20\x76\x33\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x54\x6f\x61\x73\x74\x3b\x2d\x3e\x73\x65\x74\x44\x75\x72\x61\x74\x69\x6f\x6e\x28\x49\x29\x56");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v2);
jclass &clz = cls0;
jmethodID &mid = mth8;
D2C_RESOLVE_METHOD(clz, mid, "android/widget/Toast", "setDuration", "(I)V");
jvalue args[] = {{.i = v7}};
env->CallVoidMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L22:
LOGD("60:invoke-virtual \x76\x30\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x54\x6f\x61\x73\x74\x3b\x2d\x3e\x73\x68\x6f\x77\x28\x29\x56");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v2);
jclass &clz = cls0;
jmethodID &mid = mth9;
D2C_RESOLVE_METHOD(clz, mid, "android/widget/Toast", "show", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L23:
goto L25;
L24:
LOGD("68:move-exception \x76\x33");
if (v0) {
LOGD("env->DeleteLocalRef(%p):v0", v0);
env->DeleteLocalRef(v0);
}
v0 = exception;
LOGD("6a:invoke-virtual \x76\x33\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x54\x68\x72\x6f\x77\x61\x62\x6c\x65\x3b\x2d\x3e\x70\x72\x69\x6e\x74\x53\x74\x61\x63\x6b\x54\x72\x61\x63\x65\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls7;
jmethodID &mid = mth10;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/Throwable", "printStackTrace", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L25:
return;

EX_LandingPad_0:
D2C_GET_PENDING_EX
if(d2c_is_instance_of(env, exception, "java/lang/Throwable")) {
goto L24;
}
D2C_GOTO_UNWINDBLOCK
EX_UnwindBlock: return;
}
