#include "Dex2C.h"

/* Lio/pro/edge/widget/event/utils/InUtils;->h(Landroid/content/Context;)V */
extern "C" JNIEXPORT void JNICALL
Java_io_pro_edge_widget_event_utils_InUtils_h__Landroid_content_Context_2(JNIEnv *env, jobject thiz, jobject p4){
jobject v0 = NULL;
jobject v1 = NULL;
jobject v2 = NULL;
jobject v3 = NULL;
jobject v4 = NULL;
jint v5;
jthrowable exception;
jclass cls0 = NULL,cls1 = NULL,cls2 = NULL,cls3 = NULL;
jmethodID mth0 = NULL, mth1 = NULL, mth2 = NULL, mth3 = NULL, mth4 = NULL, mth5 = NULL, mth6 = NULL, mth7 = NULL;
v0 = (jobject)env->NewLocalRef(p4);
L0:
LOGD("0:invoke-static \x76\x34\x2c\x20\x4c\x63\x6f\x6d\x2f\x66\x61\x63\x65\x62\x6f\x6f\x6b\x2f\x61\x70\x70\x65\x76\x65\x6e\x74\x73\x2f\x41\x70\x70\x45\x76\x65\x6e\x74\x73\x4c\x6f\x67\x67\x65\x72\x3b\x2d\x3e\x6e\x65\x77\x4c\x6f\x67\x67\x65\x72\x28\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6e\x74\x65\x78\x74\x3b\x29\x4c\x63\x6f\x6d\x2f\x66\x61\x63\x65\x62\x6f\x6f\x6b\x2f\x61\x70\x70\x65\x76\x65\x6e\x74\x73\x2f\x41\x70\x70\x45\x76\x65\x6e\x74\x73\x4c\x6f\x67\x67\x65\x72\x3b");
{
#define EX_HANDLE EX_LandingPad_0
jclass &clz = cls0;
jmethodID &mid = mth0;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "com/facebook/appevents/AppEventsLogger", "newLogger", "(Landroid/content/Context;)Lcom/facebook/appevents/AppEventsLogger;");
jvalue args[] = {{.l = v0}};
v1 = (jobject) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L1:
LOGD("6:move-result-object \x76\x30");
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
v2 = (jobject) v1;
L2:
LOGD("8:new-instance \x76\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x6f\x73\x2f\x42\x75\x6e\x64\x6c\x65\x3b");
{
#define EX_HANDLE EX_LandingPad_0
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
jclass &clz = cls1;
D2C_RESOLVE_CLASS(clz,"android/os/Bundle");
v3 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L3:
LOGD("c:invoke-direct \x76\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x6f\x73\x2f\x42\x75\x6e\x64\x6c\x65\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x29\x56");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v3);
jclass &clz = cls1;
jmethodID &mid = mth1;
D2C_RESOLVE_METHOD(clz, mid, "android/os/Bundle", "<init>", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L4:
LOGD("12:const-string \x76\x32\x2c\x20\x27\x66\x62\x5f\x73\x75\x63\x63\x65\x73\x73\x27");
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
v4 = (jstring) env->NewStringUTF("\x66\x62\x5f\x73\x75\x63\x63\x65\x73\x73");
L5:
v5 = 1;
L6:
LOGD("18:invoke-virtual \x76\x31\x2c\x20\x76\x32\x2c\x20\x76\x33\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x6f\x73\x2f\x42\x75\x6e\x64\x6c\x65\x3b\x2d\x3e\x70\x75\x74\x49\x6e\x74\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x20\x49\x29\x56");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v3);
jclass &clz = cls1;
jmethodID &mid = mth2;
D2C_RESOLVE_METHOD(clz, mid, "android/os/Bundle", "putInt", "(Ljava/lang/String;I)V");
jvalue args[] = {{.l = v4},{.i = v5}};
env->CallVoidMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L7:
LOGD("1e:const-string \x76\x32\x2c\x20\x27\x66\x62\x5f\x6d\x6f\x62\x69\x6c\x65\x5f\x61\x64\x64\x5f\x70\x61\x79\x6d\x65\x6e\x74\x5f\x69\x6e\x66\x6f\x27");
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
v4 = (jstring) env->NewStringUTF("\x66\x62\x5f\x6d\x6f\x62\x69\x6c\x65\x5f\x61\x64\x64\x5f\x70\x61\x79\x6d\x65\x6e\x74\x5f\x69\x6e\x66\x6f");
L8:
LOGD("22:invoke-virtual \x76\x30\x2c\x20\x76\x32\x2c\x20\x76\x31\x2c\x20\x4c\x63\x6f\x6d\x2f\x66\x61\x63\x65\x62\x6f\x6f\x6b\x2f\x61\x70\x70\x65\x76\x65\x6e\x74\x73\x2f\x41\x70\x70\x45\x76\x65\x6e\x74\x73\x4c\x6f\x67\x67\x65\x72\x3b\x2d\x3e\x6c\x6f\x67\x45\x76\x65\x6e\x74\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x6f\x73\x2f\x42\x75\x6e\x64\x6c\x65\x3b\x29\x56");
{
#define EX_HANDLE EX_LandingPad_0
D2C_NOT_NULL(v2);
jclass &clz = cls0;
jmethodID &mid = mth3;
D2C_RESOLVE_METHOD(clz, mid, "com/facebook/appevents/AppEventsLogger", "logEvent", "(Ljava/lang/String;Landroid/os/Bundle;)V");
jvalue args[] = {{.l = v4},{.l = v3}};
env->CallVoidMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L9:
goto L11;
L10:
LOGD("2a:move-exception \x76\x30");
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
v2 = exception;
LOGD("2c:invoke-virtual \x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x54\x68\x72\x6f\x77\x61\x62\x6c\x65\x3b\x2d\x3e\x70\x72\x69\x6e\x74\x53\x74\x61\x63\x6b\x54\x72\x61\x63\x65\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
jclass &clz = cls2;
jmethodID &mid = mth4;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/Throwable", "printStackTrace", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L11:
LOGD("32:new-instance \x76\x30\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x6f\x73\x2f\x42\x75\x6e\x64\x6c\x65\x3b");
{
#define EX_HANDLE EX_LandingPad_11
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
jclass &clz = cls1;
D2C_RESOLVE_CLASS(clz,"android/os/Bundle");
v2 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L12:
LOGD("36:invoke-direct \x76\x30\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x6f\x73\x2f\x42\x75\x6e\x64\x6c\x65\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x29\x56");
{
#define EX_HANDLE EX_LandingPad_11
D2C_NOT_NULL(v2);
jclass &clz = cls1;
jmethodID &mid = mth1;
D2C_RESOLVE_METHOD(clz, mid, "android/os/Bundle", "<init>", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L13:
LOGD("3c:const-string \x76\x31\x2c\x20\x27\x73\x75\x63\x63\x65\x73\x73\x27");
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
v3 = (jstring) env->NewStringUTF("\x73\x75\x63\x63\x65\x73\x73");
L14:
LOGD("40:const-string \x76\x32\x2c\x20\x27\x31\x27");
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
v4 = (jstring) env->NewStringUTF("\x31");
L15:
LOGD("44:invoke-virtual \x76\x30\x2c\x20\x76\x31\x2c\x20\x76\x32\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x6f\x73\x2f\x42\x75\x6e\x64\x6c\x65\x3b\x2d\x3e\x70\x75\x74\x53\x74\x72\x69\x6e\x67\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x56");
{
#define EX_HANDLE EX_LandingPad_11
D2C_NOT_NULL(v2);
jclass &clz = cls1;
jmethodID &mid = mth5;
D2C_RESOLVE_METHOD(clz, mid, "android/os/Bundle", "putString", "(Ljava/lang/String;Ljava/lang/String;)V");
jvalue args[] = {{.l = v3},{.l = v4}};
env->CallVoidMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L16:
LOGD("4a:invoke-static \x76\x34\x2c\x20\x4c\x63\x6f\x6d\x2f\x67\x6f\x6f\x67\x6c\x65\x2f\x66\x69\x72\x65\x62\x61\x73\x65\x2f\x61\x6e\x61\x6c\x79\x74\x69\x63\x73\x2f\x46\x69\x72\x65\x62\x61\x73\x65\x41\x6e\x61\x6c\x79\x74\x69\x63\x73\x3b\x2d\x3e\x67\x65\x74\x49\x6e\x73\x74\x61\x6e\x63\x65\x28\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6e\x74\x65\x78\x74\x3b\x29\x4c\x63\x6f\x6d\x2f\x67\x6f\x6f\x67\x6c\x65\x2f\x66\x69\x72\x65\x62\x61\x73\x65\x2f\x61\x6e\x61\x6c\x79\x74\x69\x63\x73\x2f\x46\x69\x72\x65\x62\x61\x73\x65\x41\x6e\x61\x6c\x79\x74\x69\x63\x73\x3b");
{
#define EX_HANDLE EX_LandingPad_11
jclass &clz = cls3;
jmethodID &mid = mth6;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "com/google/firebase/analytics/FirebaseAnalytics", "getInstance", "(Landroid/content/Context;)Lcom/google/firebase/analytics/FirebaseAnalytics;");
jvalue args[] = {{.l = v0}};
v1 = (jobject) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L17:
LOGD("50:move-result-object \x76\x34");
if (v0) {
LOGD("env->DeleteLocalRef(%p):v0", v0);
env->DeleteLocalRef(v0);
}
v0 = (jobject) v1;
L18:
LOGD("52:const-string \x76\x31\x2c\x20\x27\x61\x64\x64\x5f\x70\x61\x79\x6d\x65\x6e\x74\x5f\x69\x6e\x66\x6f\x27");
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
v3 = (jstring) env->NewStringUTF("\x61\x64\x64\x5f\x70\x61\x79\x6d\x65\x6e\x74\x5f\x69\x6e\x66\x6f");
L19:
LOGD("56:invoke-virtual \x76\x34\x2c\x20\x76\x31\x2c\x20\x76\x30\x2c\x20\x4c\x63\x6f\x6d\x2f\x67\x6f\x6f\x67\x6c\x65\x2f\x66\x69\x72\x65\x62\x61\x73\x65\x2f\x61\x6e\x61\x6c\x79\x74\x69\x63\x73\x2f\x46\x69\x72\x65\x62\x61\x73\x65\x41\x6e\x61\x6c\x79\x74\x69\x63\x73\x3b\x2d\x3e\x6c\x6f\x67\x45\x76\x65\x6e\x74\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x6f\x73\x2f\x42\x75\x6e\x64\x6c\x65\x3b\x29\x56");
{
#define EX_HANDLE EX_LandingPad_11
D2C_NOT_NULL(v0);
jclass &clz = cls3;
jmethodID &mid = mth7;
D2C_RESOLVE_METHOD(clz, mid, "com/google/firebase/analytics/FirebaseAnalytics", "logEvent", "(Ljava/lang/String;Landroid/os/Bundle;)V");
jvalue args[] = {{.l = v3},{.l = v2}};
env->CallVoidMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L20:
goto L22;
L21:
LOGD("5e:move-exception \x76\x34");
if (v0) {
LOGD("env->DeleteLocalRef(%p):v0", v0);
env->DeleteLocalRef(v0);
}
v0 = exception;
LOGD("60:invoke-virtual \x76\x34\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x54\x68\x72\x6f\x77\x61\x62\x6c\x65\x3b\x2d\x3e\x70\x72\x69\x6e\x74\x53\x74\x61\x63\x6b\x54\x72\x61\x63\x65\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls2;
jmethodID &mid = mth4;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/Throwable", "printStackTrace", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L22:
return;

EX_LandingPad_0:
D2C_GET_PENDING_EX
if(d2c_is_instance_of(env, exception, "java/lang/Throwable")) {
goto L10;
}
D2C_GOTO_UNWINDBLOCK

EX_LandingPad_11:
D2C_GET_PENDING_EX
if(d2c_is_instance_of(env, exception, "java/lang/Throwable")) {
goto L21;
}
D2C_GOTO_UNWINDBLOCK
EX_UnwindBlock: return;
}
