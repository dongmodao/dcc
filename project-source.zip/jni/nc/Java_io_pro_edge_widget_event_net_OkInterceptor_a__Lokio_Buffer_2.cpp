#include "Dex2C.h"

/* Lio/pro/edge/widget/event/net/OkInterceptor;->a(Lokio/Buffer;)Z */
extern "C" JNIEXPORT jboolean JNICALL
Java_io_pro_edge_widget_event_net_OkInterceptor_a__Lokio_Buffer_2(JNIEnv *env, jobject thiz, jobject p8){
jobject v0 = NULL;
jint v1;
jobject v2 = NULL;
jlong v3;
jlong v4;
jlong v5;
jint v6;
jlong v7;
jobject v8 = NULL;
jobject v9 = NULL;
jobject v10 = NULL;
jint v11;
jint v12;
jint v13;
jint v14;
jthrowable exception;
jclass cls0 = NULL,cls1 = NULL;
jmethodID mth0 = NULL, mth1 = NULL, mth2 = NULL, mth3 = NULL, mth4 = NULL, mth5 = NULL, mth6 = NULL;
v0 = (jobject)env->NewLocalRef(p8);
L0:
v1 = 0;
v1 = 0;
L1:
LOGD("2:new-instance \x76\x37\x2c\x20\x4c\x6f\x6b\x69\x6f\x2f\x42\x75\x66\x66\x65\x72\x3b");
{
#define EX_HANDLE EX_LandingPad_1
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
jclass &clz = cls0;
D2C_RESOLVE_CLASS(clz,"okio/Buffer");
v2 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L2:
LOGD("6:invoke-direct \x76\x37\x2c\x20\x4c\x6f\x6b\x69\x6f\x2f\x42\x75\x66\x66\x65\x72\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x29\x56");
{
#define EX_HANDLE EX_LandingPad_1
D2C_NOT_NULL(v2);
jclass &clz = cls0;
jmethodID &mid = mth0;
D2C_RESOLVE_METHOD(clz, mid, "okio/Buffer", "<init>", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L3:
LOGD("c:invoke-virtual \x76\x38\x2c\x20\x4c\x6f\x6b\x69\x6f\x2f\x42\x75\x66\x66\x65\x72\x3b\x2d\x3e\x73\x69\x7a\x65\x28\x29\x4a");
{
#define EX_HANDLE EX_LandingPad_1
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jmethodID &mid = mth1;
D2C_RESOLVE_METHOD(clz, mid, "okio/Buffer", "size", "()J");
jvalue args[] = {};
v3 = (jlong) env->CallLongMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L4:
LOGD("12:move-result-wide \x76\x31");
v4 = (jlong) v3;
v5 = 64;
v5 = 64;
LOGD("18:cmp-long \x76\x35\x2c\x20\x76\x31\x2c\x20\x76\x33");
v6 = (v4 == v5) ? 0 : (v4 > v5) ? 1 : -1;
LOGD("1c:if-gez \x76\x35\x2c\x20\x2b\x38");
if(v6 >= 0){
goto L7;
}
else {
goto L5;
}
L5:
LOGD("20:invoke-virtual \x76\x38\x2c\x20\x4c\x6f\x6b\x69\x6f\x2f\x42\x75\x66\x66\x65\x72\x3b\x2d\x3e\x73\x69\x7a\x65\x28\x29\x4a");
{
#define EX_HANDLE EX_LandingPad_1
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jmethodID &mid = mth1;
D2C_RESOLVE_METHOD(clz, mid, "okio/Buffer", "size", "()J");
jvalue args[] = {};
v3 = (jlong) env->CallLongMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L6:
LOGD("26:move-result-wide \x76\x31");
v4 = (jlong) v3;
v7 = v4;
goto L8;
L7:
v7 = v5;
L8:
v5 = 0;
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jobject) env->NewLocalRef(v0);
if (v9) {
LOGD("env->DeleteLocalRef(%p):v9", v9);
env->DeleteLocalRef(v9);
}
v9 = (jobject) env->NewLocalRef(v2);
L9:
LOGD("36:invoke-virtual/range \x76\x31\x20\x2e\x2e\x2e\x20\x76\x36\x2c\x20\x4c\x6f\x6b\x69\x6f\x2f\x42\x75\x66\x66\x65\x72\x3b\x2d\x3e\x63\x6f\x70\x79\x54\x6f\x28\x4c\x6f\x6b\x69\x6f\x2f\x42\x75\x66\x66\x65\x72\x3b\x20\x4a\x20\x4a\x29\x4c\x6f\x6b\x69\x6f\x2f\x42\x75\x66\x66\x65\x72\x3b");
{
#define EX_HANDLE EX_LandingPad_1
D2C_NOT_NULL(v8);
jclass &clz = cls0;
jmethodID &mid = mth2;
D2C_RESOLVE_METHOD(clz, mid, "okio/Buffer", "copyTo", "(Lokio/Buffer;JJ)Lokio/Buffer;");
jvalue args[] = {{.l = v9},{.j = (jlong) v5},{.j = (jlong) v7}};
v10 = (jobject) env->CallObjectMethodA(v8, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v10) {
LOGD("env->DeleteLocalRef(%p):v10", v10);
env->DeleteLocalRef(v10);
}
L10:
v11 = 0;
L11:
v12 = 16;
LOGD("42:if-ge \x76\x38\x2c\x20\x76\x31\x2c\x20\x2b\x31\x64");
if(v11 >= v12) {
goto L23;
}
else {
goto L12;
}
L12:
LOGD("46:invoke-virtual \x76\x37\x2c\x20\x4c\x6f\x6b\x69\x6f\x2f\x42\x75\x66\x66\x65\x72\x3b\x2d\x3e\x65\x78\x68\x61\x75\x73\x74\x65\x64\x28\x29\x5a");
{
#define EX_HANDLE EX_LandingPad_1
D2C_NOT_NULL(v2);
jclass &clz = cls0;
jmethodID &mid = mth3;
D2C_RESOLVE_METHOD(clz, mid, "okio/Buffer", "exhausted", "()Z");
jvalue args[] = {};
v13 = (jboolean) env->CallBooleanMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L13:
LOGD("4c:move-result \x76\x31");
v12 = (jint) v13;
LOGD("4e:if-eqz \x76\x31\x2c\x20\x2b\x33");
if(v12 == 0){
goto L15;
}
else {
goto L14;
}
L14:
goto L23;
L15:
LOGD("54:invoke-virtual \x76\x37\x2c\x20\x4c\x6f\x6b\x69\x6f\x2f\x42\x75\x66\x66\x65\x72\x3b\x2d\x3e\x72\x65\x61\x64\x55\x74\x66\x38\x43\x6f\x64\x65\x50\x6f\x69\x6e\x74\x28\x29\x49");
{
#define EX_HANDLE EX_LandingPad_1
D2C_NOT_NULL(v2);
jclass &clz = cls0;
jmethodID &mid = mth4;
D2C_RESOLVE_METHOD(clz, mid, "okio/Buffer", "readUtf8CodePoint", "()I");
jvalue args[] = {};
v13 = (jint) env->CallIntMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L16:
LOGD("5a:move-result \x76\x31");
v12 = (jint) v13;
L17:
LOGD("5c:invoke-static \x76\x31\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x68\x61\x72\x61\x63\x74\x65\x72\x3b\x2d\x3e\x69\x73\x49\x53\x4f\x43\x6f\x6e\x74\x72\x6f\x6c\x28\x49\x29\x5a");
{
#define EX_HANDLE EX_LandingPad_1
jclass &clz = cls1;
jmethodID &mid = mth5;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "java/lang/Character", "isISOControl", "(I)Z");
jvalue args[] = {{.i = v12}};
v13 = (jboolean) env->CallStaticBooleanMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L18:
LOGD("62:move-result \x76\x32");
v14 = (jint) v13;
LOGD("64:if-eqz \x76\x32\x2c\x20\x2b\x39");
if(v14 == 0){
goto L22;
}
else {
goto L19;
}
L19:
LOGD("68:invoke-static \x76\x31\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x68\x61\x72\x61\x63\x74\x65\x72\x3b\x2d\x3e\x69\x73\x57\x68\x69\x74\x65\x73\x70\x61\x63\x65\x28\x49\x29\x5a");
{
#define EX_HANDLE EX_LandingPad_1
jclass &clz = cls1;
jmethodID &mid = mth6;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "java/lang/Character", "isWhitespace", "(I)Z");
jvalue args[] = {{.i = v12}};
v13 = (jboolean) env->CallStaticBooleanMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L20:
LOGD("6e:move-result \x76\x31");
v12 = (jint) v13;
LOGD("70:if-nez \x76\x31\x2c\x20\x2b\x33");
if(v12 != 0){
goto L22;
}
else {
goto L21;
}
L21:
return (jboolean) v1;
L22:
LOGD("76:add-int/lit8 \x76\x38\x2c\x20\x76\x38\x2c\x20\x31");
v11 = (v11 + 1);
goto L11;
L23:
v11 = 1;
return (jboolean) v11;
L24:
return (jboolean) v1;

EX_LandingPad_1:
D2C_GET_PENDING_EX
if(d2c_is_instance_of(env, exception, "java/io/EOFException")) {
goto L24;
}
D2C_GOTO_UNWINDBLOCK
EX_UnwindBlock: return (jboolean)0;
}
