#include "Dex2C.h"

/* Lio/pro/edgelivewallpaper/activity/SplashActivity;->onResume()V */
extern "C" JNIEXPORT void JNICALL
Java_io_pro_edgelivewallpaper_activity_SplashActivity_onResume__(JNIEnv *env, jobject thiz){
jobject v0 = NULL;
jint v1;
jint v2;
jobject v3 = NULL;
jint v4;
jobject v5 = NULL;
jclass cls0 = NULL,cls1 = NULL,cls2 = NULL,cls3 = NULL,cls4 = NULL,cls5 = NULL;
jfieldID fld0 = NULL,fld1 = NULL;
jmethodID mth0 = NULL, mth1 = NULL, mth2 = NULL, mth3 = NULL, mth4 = NULL, mth5 = NULL, mth6 = NULL;
v0 = (jobject)env->NewLocalRef(thiz);
L0:
LOGD("0:invoke-super \x76\x32\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x62\x61\x73\x65\x66\x72\x61\x6d\x65\x6d\x6f\x64\x75\x6c\x65\x2f\x61\x63\x74\x69\x76\x69\x74\x79\x2f\x42\x61\x73\x65\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x2d\x3e\x6f\x6e\x52\x65\x73\x75\x6d\x65\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jmethodID &mid = mth0;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/baseframemodule/activity/BaseActivity", "onResume", "()V");
jvalue args[] = {};
env->CallNonvirtualVoidMethodA(v0, clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("6:iget-boolean \x76\x30\x2c\x20\x76\x32\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x6c\x69\x76\x65\x77\x61\x6c\x6c\x70\x61\x70\x65\x72\x2f\x61\x63\x74\x69\x76\x69\x74\x79\x2f\x53\x70\x6c\x61\x73\x68\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x2d\x3e\x66\x20\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls1;
jfieldID &fld = fld0;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edgelivewallpaper/activity/SplashActivity", "f", "Z");
v1 = (jboolean) env->GetBooleanField(v0,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("a:if-eqz \x76\x30\x2c\x20\x2b\x32\x32");
if(v1 == 0){
goto L5;
}
else {
goto L1;
}
L1:
LOGD("e:invoke-static \x76\x32\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x64\x67\x65\x2f\x55\x74\x69\x6c\x73\x3b\x2d\x3e\x66\x28\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6e\x74\x65\x78\x74\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls2;
jmethodID &mid = mth1;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "io/pro/edge/widget/edge/Utils", "f", "(Landroid/content/Context;)Z");
jvalue args[] = {{.l = v0}};
v2 = (jboolean) env->CallStaticBooleanMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("14:move-result \x76\x30");
v1 = (jint) v2;
LOGD("16:if-eqz \x76\x30\x2c\x20\x2b\x63");
if(v1 == 0){
goto L3;
}
else {
goto L2;
}
L2:
LOGD("1a:invoke-static \x76\x32\x2c\x20\x4c\x64\x2f\x62\x2f\x62\x2f\x67\x2f\x68\x3b\x2d\x3e\x63\x28\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6e\x74\x65\x78\x74\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls3;
jmethodID &mid = mth2;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "d/b/b/g/h", "c", "(Landroid/content/Context;)V");
jvalue args[] = {{.l = v0}};
env->CallStaticVoidMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("20:const-class \x76\x30\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x6c\x69\x76\x65\x77\x61\x6c\x6c\x70\x61\x70\x65\x72\x2f\x61\x63\x74\x69\x76\x69\x74\x79\x2f\x4d\x61\x69\x6e\x41\x63\x74\x69\x76\x69\x74\x79\x3b");
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls4;
D2C_RESOLVE_CLASS(clz,"\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x6c\x69\x76\x65\x77\x61\x6c\x6c\x70\x61\x70\x65\x72\x2f\x61\x63\x74\x69\x76\x69\x74\x79\x2f\x4d\x61\x69\x6e\x41\x63\x74\x69\x76\x69\x74\x79");
v3 = env->NewLocalRef(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
v4 = 1;
LOGD("26:invoke-virtual \x76\x32\x2c\x20\x76\x30\x2c\x20\x76\x31\x2c\x20\x76\x31\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x62\x61\x73\x65\x66\x72\x61\x6d\x65\x6d\x6f\x64\x75\x6c\x65\x2f\x61\x63\x74\x69\x76\x69\x74\x79\x2f\x42\x61\x73\x65\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x2d\x3e\x61\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x6c\x61\x73\x73\x3b\x20\x5a\x20\x5a\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jmethodID &mid = mth3;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/baseframemodule/activity/BaseActivity", "a", "(Ljava/lang/Class;ZZ)V");
jvalue args[] = {{.l = v3},{.z = (jboolean) v4},{.z = (jboolean) v4}};
env->CallVoidMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
goto L5;
L3:
LOGD("2e:iget-object \x76\x30\x2c\x20\x76\x32\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x6c\x69\x76\x65\x77\x61\x6c\x6c\x70\x61\x70\x65\x72\x2f\x61\x63\x74\x69\x76\x69\x74\x79\x2f\x53\x70\x6c\x61\x73\x68\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x2d\x3e\x65\x20\x4c\x61\x2f\x62\x2f\x61\x2f\x6b\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls1;
jfieldID &fld = fld1;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edgelivewallpaper/activity/SplashActivity", "e", "La/b/a/k;");
v5 = (jobject) env->GetObjectField(v0,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
v3 = (jobject) v5;
LOGD("32:invoke-virtual \x76\x30\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x61\x70\x70\x2f\x44\x69\x61\x6c\x6f\x67\x3b\x2d\x3e\x69\x73\x53\x68\x6f\x77\x69\x6e\x67\x28\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls5;
jmethodID &mid = mth4;
D2C_RESOLVE_METHOD(clz, mid, "android/app/Dialog", "isShowing", "()Z");
jvalue args[] = {};
v2 = (jboolean) env->CallBooleanMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("38:move-result \x76\x30");
v1 = (jint) v2;
LOGD("3a:if-nez \x76\x30\x2c\x20\x2b\x61");
if(v1 != 0){
goto L5;
}
else {
goto L4;
}
L4:
LOGD("3e:invoke-virtual \x76\x32\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x6c\x69\x76\x65\x77\x61\x6c\x6c\x70\x61\x70\x65\x72\x2f\x61\x63\x74\x69\x76\x69\x74\x79\x2f\x53\x70\x6c\x61\x73\x68\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x2d\x3e\x73\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls1;
jmethodID &mid = mth5;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edgelivewallpaper/activity/SplashActivity", "s", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("44:iget-object \x76\x30\x2c\x20\x76\x32\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x6c\x69\x76\x65\x77\x61\x6c\x6c\x70\x61\x70\x65\x72\x2f\x61\x63\x74\x69\x76\x69\x74\x79\x2f\x53\x70\x6c\x61\x73\x68\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x2d\x3e\x65\x20\x4c\x61\x2f\x62\x2f\x61\x2f\x6b\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls1;
jfieldID &fld = fld1;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edgelivewallpaper/activity/SplashActivity", "e", "La/b/a/k;");
v5 = (jobject) env->GetObjectField(v0,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
v3 = (jobject) v5;
LOGD("48:invoke-virtual \x76\x30\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x61\x70\x70\x2f\x44\x69\x61\x6c\x6f\x67\x3b\x2d\x3e\x73\x68\x6f\x77\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls5;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "android/app/Dialog", "show", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L5:
return;
EX_UnwindBlock: return;
}
