#include "Dex2C.h"

/* Lio/pro/edge/widget/event/action/Worker;->a(IJ)V */
extern "C" JNIEXPORT void JNICALL
Java_io_pro_edge_widget_event_action_Worker_a__IJ(JNIEnv *env, jobject thiz, jint p2, jlong p3){
jobject v0 = NULL;
jint v1;
jlong v2;
jobject v3 = NULL;
jobject v4 = NULL;
jint v5;
jclass cls0 = NULL,cls1 = NULL;
jfieldID fld0 = NULL;
jmethodID mth0 = NULL;
v0 = (jobject)env->NewLocalRef(thiz);
v1 = (jint)p2;
v2 = (jlong)p3;
L0:
LOGD("0:iget-object \x76\x30\x2c\x20\x76\x31\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x61\x63\x74\x69\x6f\x6e\x2f\x57\x6f\x72\x6b\x65\x72\x3b\x2d\x3e\x78\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x6f\x73\x2f\x48\x61\x6e\x64\x6c\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jfieldID &fld = fld0;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/action/Worker", "x", "Landroid/os/Handler;");
v3 = (jobject) env->GetObjectField(v0,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
v4 = (jobject) v3;
LOGD("4:if-nez \x76\x30\x2c\x20\x2b\x33");
if(v4 != NULL){
goto L2;
}
else {
goto L1;
}
L1:
return;
L2:
LOGD("a:invoke-virtual \x76\x30\x2c\x20\x76\x32\x2c\x20\x76\x33\x2c\x20\x76\x34\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x6f\x73\x2f\x48\x61\x6e\x64\x6c\x65\x72\x3b\x2d\x3e\x73\x65\x6e\x64\x45\x6d\x70\x74\x79\x4d\x65\x73\x73\x61\x67\x65\x44\x65\x6c\x61\x79\x65\x64\x28\x49\x20\x4a\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v4);
jclass &clz = cls1;
jmethodID &mid = mth0;
D2C_RESOLVE_METHOD(clz, mid, "android/os/Handler", "sendEmptyMessageDelayed", "(IJ)Z");
jvalue args[] = {{.i = v1},{.j = (jlong) v2}};
v5 = (jboolean) env->CallBooleanMethodA(v4, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
return;
EX_UnwindBlock: return;
}
