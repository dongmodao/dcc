#include "Dex2C.h"

/* Lio/pro/edgelivewallpaper/activity/SplashActivity;->s()V */
extern "C" JNIEXPORT void JNICALL
Java_io_pro_edgelivewallpaper_activity_SplashActivity_s__(JNIEnv *env, jobject thiz){
jobject v0 = NULL;
jint v1;
jobject v2 = NULL;
jobject v3 = NULL;
jobject v4 = NULL;
jint v5;
jint v6;
jlong v7;
jobject v8 = NULL;
jobject v9 = NULL;
jobject v10 = NULL;
jclass cls0 = NULL,cls1 = NULL,cls2 = NULL,cls3 = NULL,cls4 = NULL,cls5 = NULL;
jfieldID fld0 = NULL,fld1 = NULL;
jmethodID mth0 = NULL, mth1 = NULL, mth2 = NULL, mth3 = NULL, mth4 = NULL, mth5 = NULL;
v0 = (jobject)env->NewLocalRef(thiz);
L0:
LOGD("0:iget-boolean \x76\x30\x2c\x20\x76\x39\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x6c\x69\x76\x65\x77\x61\x6c\x6c\x70\x61\x70\x65\x72\x2f\x61\x63\x74\x69\x76\x69\x74\x79\x2f\x53\x70\x6c\x61\x73\x68\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x2d\x3e\x67\x20\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jfieldID &fld = fld0;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edgelivewallpaper/activity/SplashActivity", "g", "Z");
v1 = (jboolean) env->GetBooleanField(v0,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("4:if-eqz \x76\x30\x2c\x20\x2b\x33");
if(v1 == 0){
goto L2;
}
else {
goto L1;
}
L1:
return;
L2:
v1 = 1;
LOGD("c:iput-boolean \x76\x30\x2c\x20\x76\x39\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x6c\x69\x76\x65\x77\x61\x6c\x6c\x70\x61\x70\x65\x72\x2f\x61\x63\x74\x69\x76\x69\x74\x79\x2f\x53\x70\x6c\x61\x73\x68\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x2d\x3e\x67\x20\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jfieldID &fld = fld0;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edgelivewallpaper/activity/SplashActivity", "g", "Z");
env->SetBooleanField(v0,fld,(jboolean) v1);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("10:invoke-static \x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x63\x6f\x6e\x63\x75\x72\x72\x65\x6e\x74\x2f\x45\x78\x65\x63\x75\x74\x6f\x72\x73\x3b\x2d\x3e\x64\x65\x66\x61\x75\x6c\x74\x54\x68\x72\x65\x61\x64\x46\x61\x63\x74\x6f\x72\x79\x28\x29\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x63\x6f\x6e\x63\x75\x72\x72\x65\x6e\x74\x2f\x54\x68\x72\x65\x61\x64\x46\x61\x63\x74\x6f\x72\x79\x3b");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls1;
jmethodID &mid = mth0;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "java/util/concurrent/Executors", "defaultThreadFactory", "()Ljava/util/concurrent/ThreadFactory;");
jvalue args[] = {};
v2 = (jobject) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("16:move-result-object \x76\x38");
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
v3 = (jobject) v2;
LOGD("18:new-instance \x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x63\x6f\x6e\x63\x75\x72\x72\x65\x6e\x74\x2f\x54\x68\x72\x65\x61\x64\x50\x6f\x6f\x6c\x45\x78\x65\x63\x75\x74\x6f\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
jclass &clz = cls2;
D2C_RESOLVE_CLASS(clz,"java/util/concurrent/ThreadPoolExecutor");
v4 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
v5 = 1;
v6 = 1;
v7 = 0;
LOGD("24:sget-object \x76\x36\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x63\x6f\x6e\x63\x75\x72\x72\x65\x6e\x74\x2f\x54\x69\x6d\x65\x55\x6e\x69\x74\x3b\x2d\x3e\x4d\x49\x4c\x4c\x49\x53\x45\x43\x4f\x4e\x44\x53\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x63\x6f\x6e\x63\x75\x72\x72\x65\x6e\x74\x2f\x54\x69\x6d\x65\x55\x6e\x69\x74\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
jclass &clz = cls3;
jfieldID &fld = fld1;
D2C_RESOLVE_STATIC_FIELD(clz, fld, "java/util/concurrent/TimeUnit", "MILLISECONDS", "Ljava/util/concurrent/TimeUnit;");
v8 = (jobject) env->GetStaticObjectField(clz,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("28:new-instance \x76\x37\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x63\x6f\x6e\x63\x75\x72\x72\x65\x6e\x74\x2f\x4c\x69\x6e\x6b\x65\x64\x42\x6c\x6f\x63\x6b\x69\x6e\x67\x51\x75\x65\x75\x65\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v9) {
LOGD("env->DeleteLocalRef(%p):v9", v9);
env->DeleteLocalRef(v9);
}
jclass &clz = cls4;
D2C_RESOLVE_CLASS(clz,"java/util/concurrent/LinkedBlockingQueue");
v9 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("2c:invoke-direct \x76\x37\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x63\x6f\x6e\x63\x75\x72\x72\x65\x6e\x74\x2f\x4c\x69\x6e\x6b\x65\x64\x42\x6c\x6f\x63\x6b\x69\x6e\x67\x51\x75\x65\x75\x65\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v9);
jclass &clz = cls4;
jmethodID &mid = mth1;
D2C_RESOLVE_METHOD(clz, mid, "java/util/concurrent/LinkedBlockingQueue", "<init>", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v9, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v10) {
LOGD("env->DeleteLocalRef(%p):v10", v10);
env->DeleteLocalRef(v10);
}
v10 = (jobject) env->NewLocalRef(v4);
LOGD("34:invoke-direct/range \x76\x31\x20\x2e\x2e\x2e\x20\x76\x38\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x63\x6f\x6e\x63\x75\x72\x72\x65\x6e\x74\x2f\x54\x68\x72\x65\x61\x64\x50\x6f\x6f\x6c\x45\x78\x65\x63\x75\x74\x6f\x72\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x49\x20\x49\x20\x4a\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x63\x6f\x6e\x63\x75\x72\x72\x65\x6e\x74\x2f\x54\x69\x6d\x65\x55\x6e\x69\x74\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x63\x6f\x6e\x63\x75\x72\x72\x65\x6e\x74\x2f\x42\x6c\x6f\x63\x6b\x69\x6e\x67\x51\x75\x65\x75\x65\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x63\x6f\x6e\x63\x75\x72\x72\x65\x6e\x74\x2f\x54\x68\x72\x65\x61\x64\x46\x61\x63\x74\x6f\x72\x79\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v10);
jclass &clz = cls2;
jmethodID &mid = mth2;
D2C_RESOLVE_METHOD(clz, mid, "java/util/concurrent/ThreadPoolExecutor", "<init>", "(IIJLjava/util/concurrent/TimeUnit;Ljava/util/concurrent/BlockingQueue;Ljava/util/concurrent/ThreadFactory;)V");
jvalue args[] = {{.i = v5},{.i = v6},{.j = (jlong) v7},{.l = v8},{.l = v9},{.l = v3}};
env->CallVoidMethodA(v10, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("3a:new-instance \x76\x31\x2c\x20\x4c\x64\x2f\x62\x2f\x62\x2f\x61\x2f\x63\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v10) {
LOGD("env->DeleteLocalRef(%p):v10", v10);
env->DeleteLocalRef(v10);
}
jclass &clz = cls5;
D2C_RESOLVE_CLASS(clz,"d/b/b/a/c");
v10 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("3e:invoke-direct \x76\x31\x2c\x20\x76\x39\x2c\x20\x4c\x64\x2f\x62\x2f\x62\x2f\x61\x2f\x63\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x6c\x69\x76\x65\x77\x61\x6c\x6c\x70\x61\x70\x65\x72\x2f\x61\x63\x74\x69\x76\x69\x74\x79\x2f\x53\x70\x6c\x61\x73\x68\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v10);
jclass &clz = cls5;
jmethodID &mid = mth3;
D2C_RESOLVE_METHOD(clz, mid, "d/b/b/a/c", "<init>", "(Lio/pro/edgelivewallpaper/activity/SplashActivity;)V");
jvalue args[] = {{.l = v0}};
env->CallVoidMethodA(v10, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("44:invoke-virtual \x76\x30\x2c\x20\x76\x31\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x63\x6f\x6e\x63\x75\x72\x72\x65\x6e\x74\x2f\x54\x68\x72\x65\x61\x64\x50\x6f\x6f\x6c\x45\x78\x65\x63\x75\x74\x6f\x72\x3b\x2d\x3e\x65\x78\x65\x63\x75\x74\x65\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x52\x75\x6e\x6e\x61\x62\x6c\x65\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v4);
jclass &clz = cls2;
jmethodID &mid = mth4;
D2C_RESOLVE_METHOD(clz, mid, "java/util/concurrent/ThreadPoolExecutor", "execute", "(Ljava/lang/Runnable;)V");
jvalue args[] = {{.l = v10}};
env->CallVoidMethodA(v4, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("4a:invoke-virtual \x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x75\x74\x69\x6c\x2f\x63\x6f\x6e\x63\x75\x72\x72\x65\x6e\x74\x2f\x54\x68\x72\x65\x61\x64\x50\x6f\x6f\x6c\x45\x78\x65\x63\x75\x74\x6f\x72\x3b\x2d\x3e\x73\x68\x75\x74\x64\x6f\x77\x6e\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v4);
jclass &clz = cls2;
jmethodID &mid = mth5;
D2C_RESOLVE_METHOD(clz, mid, "java/util/concurrent/ThreadPoolExecutor", "shutdown", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v4, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
return;
EX_UnwindBlock: return;
}
