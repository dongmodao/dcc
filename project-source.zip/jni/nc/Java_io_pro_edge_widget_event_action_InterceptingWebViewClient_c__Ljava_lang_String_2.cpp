#include "Dex2C.h"

/* Lio/pro/edge/widget/event/action/InterceptingWebViewClient;->c(Ljava/lang/String;)Z */
extern "C" JNIEXPORT jboolean JNICALL
Java_io_pro_edge_widget_event_action_InterceptingWebViewClient_c__Ljava_lang_String_2(JNIEnv *env, jobject thiz, jstring p6){
jobject v0 = NULL;
jobject v1 = NULL;
jobject v2 = NULL;
jobject v3 = NULL;
jobject v4 = NULL;
jobject v5 = NULL;
jobject v6 = NULL;
jint v7;
jint v8;
jint v9;
jobject v10 = NULL;
jint v11;
jint v12;
jint v13;
jclass cls0 = NULL;
jmethodID mth0 = NULL;
v0 = (jobject)env->NewLocalRef(thiz);
v1 = (jobject)env->NewLocalRef(p6);
L0:
LOGD("0:const-string \x76\x30\x2c\x20\x27\x78\x2d\x61\x6d\x7a\x2d\x61\x70\x69\x67\x77\x2d\x69\x64\x27");
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
v2 = (jstring) env->NewStringUTF("\x78\x2d\x61\x6d\x7a\x2d\x61\x70\x69\x67\x77\x2d\x69\x64");
LOGD("4:const-string \x76\x31\x2c\x20\x27\x78\x2d\x61\x6d\x7a\x6e\x2d\x72\x65\x6d\x61\x70\x70\x65\x64\x2d\x63\x6f\x6e\x74\x65\x6e\x74\x2d\x6c\x65\x6e\x67\x74\x68\x27");
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
v3 = (jstring) env->NewStringUTF("\x78\x2d\x61\x6d\x7a\x6e\x2d\x72\x65\x6d\x61\x70\x70\x65\x64\x2d\x63\x6f\x6e\x74\x65\x6e\x74\x2d\x6c\x65\x6e\x67\x74\x68");
LOGD("8:const-string \x76\x32\x2c\x20\x27\x78\x2d\x61\x6d\x7a\x6e\x2d\x72\x65\x6d\x61\x70\x70\x65\x64\x2d\x64\x61\x74\x65\x27");
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
v4 = (jstring) env->NewStringUTF("\x78\x2d\x61\x6d\x7a\x6e\x2d\x72\x65\x6d\x61\x70\x70\x65\x64\x2d\x64\x61\x74\x65");
LOGD("c:const-string \x76\x33\x2c\x20\x27\x78\x2d\x61\x6d\x7a\x6e\x2d\x72\x65\x71\x75\x65\x73\x74\x69\x64\x27");
if (v5) {
LOGD("env->DeleteLocalRef(%p):v5", v5);
env->DeleteLocalRef(v5);
}
v5 = (jstring) env->NewStringUTF("\x78\x2d\x61\x6d\x7a\x6e\x2d\x72\x65\x71\x75\x65\x73\x74\x69\x64");
LOGD("10:filled-new-array \x76\x30\x2c\x20\x76\x31\x2c\x20\x76\x32\x2c\x20\x76\x33\x2c\x20\x5b\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls0;
D2C_RESOLVE_CLASS(clz,"java/lang/String");
v6 = env->NewObjectArray((jint) 4, clz, NULL);
d2c_filled_new_array(env, (jarray) v6, "Ljava/lang/String;", 4, v2, v3, v4, v5);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("16:move-result-object \x76\x30");
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
v2 = (jobject) v6;
LOGD("18:array-length \x76\x31\x2c\x20\x76\x30");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
v7 = env->GetArrayLength((jarray) v2);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
v8 = 0;
v9 = 0;
L1:
LOGD("1e:if-ge \x76\x33\x2c\x20\x76\x31\x2c\x20\x2b\x66");
if(v9 >= v7) {
goto L5;
}
else {
goto L2;
}
L2:
LOGD("22:aget-object \x76\x34\x2c\x20\x76\x30\x2c\x20\x76\x33");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
v6 = (jstring) env->GetObjectArrayElement((jobjectArray) v2, (jint) v9);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v10) {
LOGD("env->DeleteLocalRef(%p):v10", v10);
env->DeleteLocalRef(v10);
}
v10 = (jobject) v6;
LOGD("26:invoke-virtual \x76\x34\x2c\x20\x76\x36\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x65\x71\x75\x61\x6c\x73\x49\x67\x6e\x6f\x72\x65\x43\x61\x73\x65\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v10);
jclass &clz = cls0;
jmethodID &mid = mth0;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "equalsIgnoreCase", "(Ljava/lang/String;)Z");
jvalue args[] = {{.l = v1}};
v11 = (jboolean) env->CallBooleanMethodA(v10, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("2c:move-result \x76\x34");
v12 = (jint) v11;
LOGD("2e:if-eqz \x76\x34\x2c\x20\x2b\x34");
if(v12 == 0){
goto L4;
}
else {
goto L3;
}
L3:
v13 = 1;
return (jboolean) v13;
L4:
LOGD("36:add-int/lit8 \x76\x33\x2c\x20\x76\x33\x2c\x20\x31");
v9 = (v9 + 1);
goto L1;
L5:
return (jboolean) v8;
EX_UnwindBlock: return (jboolean)0;
}
