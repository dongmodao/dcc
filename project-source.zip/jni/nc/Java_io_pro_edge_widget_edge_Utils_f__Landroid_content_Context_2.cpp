#include "Dex2C.h"

/* Lio/pro/edge/widget/edge/Utils;->f(Landroid/content/Context;)Z */
extern "C" JNIEXPORT jboolean JNICALL
Java_io_pro_edge_widget_edge_Utils_f__Landroid_content_Context_2(JNIEnv *env, jobject thiz, jobject p5){
jobject v0 = NULL;
jobject v1 = NULL;
jobject v2 = NULL;
jobject v3 = NULL;
jint v4;
jint v5;
jint v6;
jint v7;
jobject v8 = NULL;
jobject v9 = NULL;
jint v10;
jclass cls0 = NULL,cls1 = NULL,cls2 = NULL,cls3 = NULL,cls4 = NULL;
jmethodID mth0 = NULL, mth1 = NULL, mth2 = NULL, mth3 = NULL, mth4 = NULL, mth5 = NULL, mth6 = NULL, mth7 = NULL;
v0 = (jobject)env->NewLocalRef(p5);
L0:
LOGD("0:invoke-virtual \x76\x35\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6e\x74\x65\x78\x74\x3b\x2d\x3e\x67\x65\x74\x43\x6f\x6e\x74\x65\x6e\x74\x52\x65\x73\x6f\x6c\x76\x65\x72\x28\x29\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6e\x74\x65\x6e\x74\x52\x65\x73\x6f\x6c\x76\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jmethodID &mid = mth0;
D2C_RESOLVE_METHOD(clz, mid, "android/content/Context", "getContentResolver", "()Landroid/content/ContentResolver;");
jvalue args[] = {};
v1 = (jobject) env->CallObjectMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("6:move-result-object \x76\x30");
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
v2 = (jobject) v1;
LOGD("8:const-string \x76\x31\x2c\x20\x27\x65\x6e\x61\x62\x6c\x65\x64\x5f\x6e\x6f\x74\x69\x66\x69\x63\x61\x74\x69\x6f\x6e\x5f\x6c\x69\x73\x74\x65\x6e\x65\x72\x73\x27");
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
v3 = (jstring) env->NewStringUTF("\x65\x6e\x61\x62\x6c\x65\x64\x5f\x6e\x6f\x74\x69\x66\x69\x63\x61\x74\x69\x6f\x6e\x5f\x6c\x69\x73\x74\x65\x6e\x65\x72\x73");
LOGD("c:invoke-static \x76\x30\x2c\x20\x76\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x70\x72\x6f\x76\x69\x64\x65\x72\x2f\x53\x65\x74\x74\x69\x6e\x67\x73\x24\x53\x65\x63\x75\x72\x65\x3b\x2d\x3e\x67\x65\x74\x53\x74\x72\x69\x6e\x67\x28\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6e\x74\x65\x6e\x74\x52\x65\x73\x6f\x6c\x76\x65\x72\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls1;
jmethodID &mid = mth1;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "android/provider/Settings$Secure", "getString", "(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;");
jvalue args[] = {{.l = v2},{.l = v3}};
v1 = (jstring) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("12:move-result-object \x76\x30");
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
v2 = (jobject) v1;
LOGD("14:invoke-static \x76\x30\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x74\x65\x78\x74\x2f\x54\x65\x78\x74\x55\x74\x69\x6c\x73\x3b\x2d\x3e\x69\x73\x45\x6d\x70\x74\x79\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x68\x61\x72\x53\x65\x71\x75\x65\x6e\x63\x65\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls2;
jmethodID &mid = mth2;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "android/text/TextUtils", "isEmpty", "(Ljava/lang/CharSequence;)Z");
jvalue args[] = {{.l = v2}};
v4 = (jboolean) env->CallStaticBooleanMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("1a:move-result \x76\x31");
v5 = (jint) v4;
v6 = 0;
LOGD("1e:if-nez \x76\x31\x2c\x20\x2b\x32\x37");
if(v5 != 0){
goto L7;
}
else {
goto L1;
}
L1:
LOGD("22:const-string \x76\x31\x2c\x20\x27\x3a\x27");
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
v3 = (jstring) env->NewStringUTF("\x3a");
LOGD("26:invoke-virtual \x76\x30\x2c\x20\x76\x31\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x73\x70\x6c\x69\x74\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x5b\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
jclass &clz = cls3;
jmethodID &mid = mth3;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "split", "(Ljava/lang/String;)[Ljava/lang/String;");
jvalue args[] = {{.l = v3}};
v1 = (jarray) env->CallObjectMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("2c:move-result-object \x76\x30");
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
v2 = (jobject) v1;
v5 = 0;
L2:
LOGD("30:array-length \x76\x33\x2c\x20\x76\x30");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
v7 = env->GetArrayLength((jarray) v2);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("32:if-ge \x76\x31\x2c\x20\x76\x33\x2c\x20\x2b\x31\x64");
if(v5 >= v7) {
goto L7;
}
else {
goto L3;
}
L3:
LOGD("36:aget-object \x76\x33\x2c\x20\x76\x30\x2c\x20\x76\x31");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
v1 = (jstring) env->GetObjectArrayElement((jobjectArray) v2, (jint) v5);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jobject) v1;
LOGD("3a:invoke-static \x76\x33\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6d\x70\x6f\x6e\x65\x6e\x74\x4e\x61\x6d\x65\x3b\x2d\x3e\x75\x6e\x66\x6c\x61\x74\x74\x65\x6e\x46\x72\x6f\x6d\x53\x74\x72\x69\x6e\x67\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6d\x70\x6f\x6e\x65\x6e\x74\x4e\x61\x6d\x65\x3b");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls4;
jmethodID &mid = mth4;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "android/content/ComponentName", "unflattenFromString", "(Ljava/lang/String;)Landroid/content/ComponentName;");
jvalue args[] = {{.l = v8}};
v1 = (jobject) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("40:move-result-object \x76\x33");
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jobject) v1;
LOGD("42:if-eqz \x76\x33\x2c\x20\x2b\x31\x32");
if(v8 == NULL){
goto L6;
}
else {
goto L4;
}
L4:
LOGD("46:invoke-virtual \x76\x35\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6e\x74\x65\x78\x74\x3b\x2d\x3e\x67\x65\x74\x50\x61\x63\x6b\x61\x67\x65\x4e\x61\x6d\x65\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jmethodID &mid = mth5;
D2C_RESOLVE_METHOD(clz, mid, "android/content/Context", "getPackageName", "()Ljava/lang/String;");
jvalue args[] = {};
v1 = (jstring) env->CallObjectMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("4c:move-result-object \x76\x34");
if (v9) {
LOGD("env->DeleteLocalRef(%p):v9", v9);
env->DeleteLocalRef(v9);
}
v9 = (jobject) v1;
LOGD("4e:invoke-virtual \x76\x33\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6d\x70\x6f\x6e\x65\x6e\x74\x4e\x61\x6d\x65\x3b\x2d\x3e\x67\x65\x74\x50\x61\x63\x6b\x61\x67\x65\x4e\x61\x6d\x65\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v8);
jclass &clz = cls4;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "android/content/ComponentName", "getPackageName", "()Ljava/lang/String;");
jvalue args[] = {};
v1 = (jstring) env->CallObjectMethodA(v8, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("54:move-result-object \x76\x33");
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jobject) v1;
LOGD("56:invoke-static \x76\x34\x2c\x20\x76\x33\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x74\x65\x78\x74\x2f\x54\x65\x78\x74\x55\x74\x69\x6c\x73\x3b\x2d\x3e\x65\x71\x75\x61\x6c\x73\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x68\x61\x72\x53\x65\x71\x75\x65\x6e\x63\x65\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x68\x61\x72\x53\x65\x71\x75\x65\x6e\x63\x65\x3b\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls2;
jmethodID &mid = mth7;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "android/text/TextUtils", "equals", "(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z");
jvalue args[] = {{.l = v9},{.l = v8}};
v4 = (jboolean) env->CallStaticBooleanMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("5c:move-result \x76\x33");
v7 = (jint) v4;
LOGD("5e:if-eqz \x76\x33\x2c\x20\x2b\x34");
if(v7 == 0){
goto L6;
}
else {
goto L5;
}
L5:
v10 = 1;
return (jboolean) v10;
L6:
LOGD("66:add-int/lit8 \x76\x31\x2c\x20\x76\x31\x2c\x20\x31");
v5 = (v5 + 1);
goto L2;
L7:
return (jboolean) v6;
EX_UnwindBlock: return (jboolean)0;
}
