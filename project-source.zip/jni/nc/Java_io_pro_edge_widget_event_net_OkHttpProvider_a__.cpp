#include "Dex2C.h"

/* Lio/pro/edge/widget/event/net/OkHttpProvider;->a()Ljavax/net/ssl/HostnameVerifier; */
extern "C" JNIEXPORT jobject JNICALL
Java_io_pro_edge_widget_event_net_OkHttpProvider_a__(JNIEnv *env, jobject thiz){
jobject v0 = NULL;
jobject v1 = NULL;
jclass cls0 = NULL;
jmethodID mth0 = NULL;
v0 = (jobject)env->NewLocalRef(thiz);
L0:
LOGD("0:new-instance \x76\x30\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x48\x74\x74\x70\x50\x72\x6f\x76\x69\x64\x65\x72\x24\x31\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v1) {
LOGD("env->DeleteLocalRef(%p):v1", v1);
env->DeleteLocalRef(v1);
}
jclass &clz = cls0;
D2C_RESOLVE_CLASS(clz,"io/pro/edge/widget/event/net/OkHttpProvider$1");
v1 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("4:invoke-direct \x76\x30\x2c\x20\x76\x31\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x48\x74\x74\x70\x50\x72\x6f\x76\x69\x64\x65\x72\x24\x31\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x48\x74\x74\x70\x50\x72\x6f\x76\x69\x64\x65\x72\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v1);
jclass &clz = cls0;
jmethodID &mid = mth0;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edge/widget/event/net/OkHttpProvider$1", "<init>", "(Lio/pro/edge/widget/event/net/OkHttpProvider;)V");
jvalue args[] = {{.l = v0}};
env->CallVoidMethodA(v1, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
return (jobject) v1;
EX_UnwindBlock: return NULL;
}
