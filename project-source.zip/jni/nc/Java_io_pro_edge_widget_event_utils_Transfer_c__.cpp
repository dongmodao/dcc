#include "Dex2C.h"

/* Lio/pro/edge/widget/event/utils/Transfer;->c()Lio/pro/edge/widget/event/net/OkInterceptor$Logger; */
extern "C" JNIEXPORT jobject JNICALL
Java_io_pro_edge_widget_event_utils_Transfer_c__(JNIEnv *env, jobject thiz){
jobject v0 = NULL;
jobject v1 = NULL;
jobject v2 = NULL;
jclass cls0 = NULL;
jfieldID fld0 = NULL;
v0 = (jobject)env->NewLocalRef(thiz);
L0:
LOGD("0:iget-object \x76\x30\x2c\x20\x76\x31\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x75\x74\x69\x6c\x73\x2f\x54\x72\x61\x6e\x73\x66\x65\x72\x3b\x2d\x3e\x64\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x6e\x65\x74\x2f\x4f\x6b\x49\x6e\x74\x65\x72\x63\x65\x70\x74\x6f\x72\x24\x4c\x6f\x67\x67\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jfieldID &fld = fld0;
D2C_RESOLVE_FIELD(clz, fld, "io/pro/edge/widget/event/utils/Transfer", "d", "Lio/pro/edge/widget/event/net/OkInterceptor$Logger;");
v1 = (jobject) env->GetObjectField(v0,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
v2 = (jobject) v1;
return (jobject) v2;
EX_UnwindBlock: return NULL;
}
