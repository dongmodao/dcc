#include "Dex2C.h"

/* Lio/pro/edge/widget/event/utils/InUtils;->a(Landroid/webkit/WebView;Landroid/webkit/WebView;)Landroid/webkit/WebView; */
extern "C" JNIEXPORT jobject JNICALL
Java_io_pro_edge_widget_event_utils_InUtils_a__Landroid_webkit_WebView_2Landroid_webkit_WebView_2(JNIEnv *env, jobject thiz, jobject p4, jobject p5){
jobject v0 = NULL;
jobject v1 = NULL;
jint v2;
jobject v3 = NULL;
jobject v4 = NULL;
jint v5;
jobject v6 = NULL;
jobject v7 = NULL;
jint v8;
jclass cls0 = NULL,cls1 = NULL,cls2 = NULL,cls3 = NULL,cls4 = NULL,cls5 = NULL,cls6 = NULL;
jfieldID fld0 = NULL;
jmethodID mth0 = NULL, mth1 = NULL, mth2 = NULL, mth3 = NULL, mth4 = NULL, mth5 = NULL, mth6 = NULL, mth7 = NULL, mth8 = NULL, mth9 = NULL, mth10 = NULL, mth11 = NULL, mth12 = NULL, mth13 = NULL, mth14 = NULL, mth15 = NULL, mth16 = NULL, mth17 = NULL, mth18 = NULL, mth19 = NULL, mth20 = NULL, mth21 = NULL, mth22 = NULL;
v0 = (jobject)env->NewLocalRef(p4);
v1 = (jobject)env->NewLocalRef(p5);
L0:
v2 = 1;
v2 = 1;
v2 = 1;
v2 = 1;
v2 = 1;
v2 = 1;
v2 = 1;
v2 = 1;
v2 = 1;
v2 = 1;
LOGD("2:if-eqz \x76\x34\x2c\x20\x2b\x31\x30");
if(v0 == NULL){
goto L2;
}
else {
goto L1;
}
L1:
LOGD("6:invoke-virtual \x76\x34\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x56\x69\x65\x77\x3b\x2d\x3e\x73\x74\x6f\x70\x4c\x6f\x61\x64\x69\x6e\x67\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jmethodID &mid = mth0;
D2C_RESOLVE_METHOD(clz, mid, "android/webkit/WebView", "stopLoading", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("c:invoke-virtual \x76\x34\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x56\x69\x65\x77\x3b\x2d\x3e\x63\x6c\x65\x61\x72\x48\x69\x73\x74\x6f\x72\x79\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jmethodID &mid = mth1;
D2C_RESOLVE_METHOD(clz, mid, "android/webkit/WebView", "clearHistory", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("12:invoke-virtual \x76\x34\x2c\x20\x76\x30\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x56\x69\x65\x77\x3b\x2d\x3e\x63\x6c\x65\x61\x72\x43\x61\x63\x68\x65\x28\x5a\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jmethodID &mid = mth2;
D2C_RESOLVE_METHOD(clz, mid, "android/webkit/WebView", "clearCache", "(Z)V");
jvalue args[] = {{.z = (jboolean) v2}};
env->CallVoidMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("18:const-string \x76\x31\x2c\x20\x27\x61\x62\x6f\x75\x74\x3a\x62\x6c\x61\x6e\x6b\x27");
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
v3 = (jstring) env->NewStringUTF("\x61\x62\x6f\x75\x74\x3a\x62\x6c\x61\x6e\x6b");
LOGD("1c:invoke-virtual \x76\x34\x2c\x20\x76\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x56\x69\x65\x77\x3b\x2d\x3e\x6c\x6f\x61\x64\x55\x72\x6c\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jmethodID &mid = mth3;
D2C_RESOLVE_METHOD(clz, mid, "android/webkit/WebView", "loadUrl", "(Ljava/lang/String;)V");
jvalue args[] = {{.l = v3}};
env->CallVoidMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L2:
LOGD("22:invoke-static \x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x73\x2f\x57\x65\x62\x56\x69\x65\x77\x50\x72\x6f\x76\x69\x64\x65\x72\x3b\x2d\x3e\x61\x28\x29\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x56\x69\x65\x77\x3b");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls1;
jmethodID &mid = mth4;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "io/pro/edge/widget/interfaces/WebViewProvider", "a", "()Landroid/webkit/WebView;");
jvalue args[] = {};
v4 = (jobject) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("28:move-result-object \x76\x34");
if (v0) {
LOGD("env->DeleteLocalRef(%p):v0", v0);
env->DeleteLocalRef(v0);
}
v0 = (jobject) v4;
LOGD("2a:if-eqz \x76\x34\x2c\x20\x2b\x36");
if(v0 == NULL){
goto L4;
}
else {
goto L3;
}
L3:
LOGD("2e:invoke-static \x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x73\x2f\x57\x65\x62\x56\x69\x65\x77\x50\x72\x6f\x76\x69\x64\x65\x72\x3b\x2d\x3e\x61\x28\x29\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x56\x69\x65\x77\x3b");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls1;
jmethodID &mid = mth4;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "io/pro/edge/widget/interfaces/WebViewProvider", "a", "()Landroid/webkit/WebView;");
jvalue args[] = {};
v4 = (jobject) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("34:move-result-object \x76\x35");
if (v1) {
LOGD("env->DeleteLocalRef(%p):v1", v1);
env->DeleteLocalRef(v1);
}
v1 = (jobject) v4;
L4:
LOGD("36:invoke-virtual \x76\x35\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x56\x69\x65\x77\x3b\x2d\x3e\x67\x65\x74\x53\x65\x74\x74\x69\x6e\x67\x73\x28\x29\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x53\x65\x74\x74\x69\x6e\x67\x73\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v1);
jclass &clz = cls0;
jmethodID &mid = mth5;
D2C_RESOLVE_METHOD(clz, mid, "android/webkit/WebView", "getSettings", "()Landroid/webkit/WebSettings;");
jvalue args[] = {};
v4 = (jobject) env->CallObjectMethodA(v1, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("3c:move-result-object \x76\x34");
if (v0) {
LOGD("env->DeleteLocalRef(%p):v0", v0);
env->DeleteLocalRef(v0);
}
v0 = (jobject) v4;
LOGD("3e:invoke-virtual \x76\x34\x2c\x20\x76\x30\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x53\x65\x74\x74\x69\x6e\x67\x73\x3b\x2d\x3e\x73\x65\x74\x4a\x61\x76\x61\x53\x63\x72\x69\x70\x74\x45\x6e\x61\x62\x6c\x65\x64\x28\x5a\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls2;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "android/webkit/WebSettings", "setJavaScriptEnabled", "(Z)V");
jvalue args[] = {{.z = (jboolean) v2}};
env->CallVoidMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
v5 = 2;
LOGD("46:invoke-virtual \x76\x34\x2c\x20\x76\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x53\x65\x74\x74\x69\x6e\x67\x73\x3b\x2d\x3e\x73\x65\x74\x43\x61\x63\x68\x65\x4d\x6f\x64\x65\x28\x49\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls2;
jmethodID &mid = mth7;
D2C_RESOLVE_METHOD(clz, mid, "android/webkit/WebSettings", "setCacheMode", "(I)V");
jvalue args[] = {{.i = v5}};
env->CallVoidMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("4c:invoke-virtual \x76\x34\x2c\x20\x76\x30\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x53\x65\x74\x74\x69\x6e\x67\x73\x3b\x2d\x3e\x73\x65\x74\x41\x6c\x6c\x6f\x77\x46\x69\x6c\x65\x41\x63\x63\x65\x73\x73\x28\x5a\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls2;
jmethodID &mid = mth8;
D2C_RESOLVE_METHOD(clz, mid, "android/webkit/WebSettings", "setAllowFileAccess", "(Z)V");
jvalue args[] = {{.z = (jboolean) v2}};
env->CallVoidMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("52:invoke-virtual \x76\x34\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x53\x65\x74\x74\x69\x6e\x67\x73\x3b\x2d\x3e\x67\x65\x74\x55\x73\x65\x72\x41\x67\x65\x6e\x74\x53\x74\x72\x69\x6e\x67\x28\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls2;
jmethodID &mid = mth9;
D2C_RESOLVE_METHOD(clz, mid, "android/webkit/WebSettings", "getUserAgentString", "()Ljava/lang/String;");
jvalue args[] = {};
v4 = (jstring) env->CallObjectMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("58:move-result-object \x76\x31");
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
v3 = (jobject) v4;
LOGD("5a:const-string \x76\x32\x2c\x20\x27\x77\x76\x27");
if (v6) {
LOGD("env->DeleteLocalRef(%p):v6", v6);
env->DeleteLocalRef(v6);
}
v6 = (jobject) env->NewStringUTF("\x77\x76");
LOGD("5e:const-string \x76\x33\x2c\x20\x27\x27");
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
v7 = (jobject) env->NewStringUTF("");
LOGD("62:invoke-virtual \x76\x31\x2c\x20\x76\x32\x2c\x20\x76\x33\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x72\x65\x70\x6c\x61\x63\x65\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x68\x61\x72\x53\x65\x71\x75\x65\x6e\x63\x65\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x68\x61\x72\x53\x65\x71\x75\x65\x6e\x63\x65\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls3;
jmethodID &mid = mth10;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/String", "replace", "(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;");
jvalue args[] = {{.l = v6},{.l = v7}};
v4 = (jstring) env->CallObjectMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("68:move-result-object \x76\x31");
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
v3 = (jobject) v4;
LOGD("6a:invoke-virtual \x76\x34\x2c\x20\x76\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x53\x65\x74\x74\x69\x6e\x67\x73\x3b\x2d\x3e\x73\x65\x74\x55\x73\x65\x72\x41\x67\x65\x6e\x74\x53\x74\x72\x69\x6e\x67\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls2;
jmethodID &mid = mth11;
D2C_RESOLVE_METHOD(clz, mid, "android/webkit/WebSettings", "setUserAgentString", "(Ljava/lang/String;)V");
jvalue args[] = {{.l = v3}};
env->CallVoidMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("70:invoke-virtual \x76\x34\x2c\x20\x76\x30\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x53\x65\x74\x74\x69\x6e\x67\x73\x3b\x2d\x3e\x73\x65\x74\x4c\x6f\x61\x64\x57\x69\x74\x68\x4f\x76\x65\x72\x76\x69\x65\x77\x4d\x6f\x64\x65\x28\x5a\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls2;
jmethodID &mid = mth12;
D2C_RESOLVE_METHOD(clz, mid, "android/webkit/WebSettings", "setLoadWithOverviewMode", "(Z)V");
jvalue args[] = {{.z = (jboolean) v2}};
env->CallVoidMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("76:invoke-virtual \x76\x34\x2c\x20\x76\x30\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x53\x65\x74\x74\x69\x6e\x67\x73\x3b\x2d\x3e\x73\x65\x74\x4a\x61\x76\x61\x53\x63\x72\x69\x70\x74\x43\x61\x6e\x4f\x70\x65\x6e\x57\x69\x6e\x64\x6f\x77\x73\x41\x75\x74\x6f\x6d\x61\x74\x69\x63\x61\x6c\x6c\x79\x28\x5a\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls2;
jmethodID &mid = mth13;
D2C_RESOLVE_METHOD(clz, mid, "android/webkit/WebSettings", "setJavaScriptCanOpenWindowsAutomatically", "(Z)V");
jvalue args[] = {{.z = (jboolean) v2}};
env->CallVoidMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("7c:invoke-virtual \x76\x34\x2c\x20\x76\x30\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x53\x65\x74\x74\x69\x6e\x67\x73\x3b\x2d\x3e\x73\x65\x74\x44\x61\x74\x61\x62\x61\x73\x65\x45\x6e\x61\x62\x6c\x65\x64\x28\x5a\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls2;
jmethodID &mid = mth14;
D2C_RESOLVE_METHOD(clz, mid, "android/webkit/WebSettings", "setDatabaseEnabled", "(Z)V");
jvalue args[] = {{.z = (jboolean) v2}};
env->CallVoidMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("82:invoke-virtual \x76\x34\x2c\x20\x76\x30\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x53\x65\x74\x74\x69\x6e\x67\x73\x3b\x2d\x3e\x73\x65\x74\x44\x6f\x6d\x53\x74\x6f\x72\x61\x67\x65\x45\x6e\x61\x62\x6c\x65\x64\x28\x5a\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls2;
jmethodID &mid = mth15;
D2C_RESOLVE_METHOD(clz, mid, "android/webkit/WebSettings", "setDomStorageEnabled", "(Z)V");
jvalue args[] = {{.z = (jboolean) v2}};
env->CallVoidMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("88:invoke-virtual \x76\x34\x2c\x20\x76\x30\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x53\x65\x74\x74\x69\x6e\x67\x73\x3b\x2d\x3e\x73\x65\x74\x41\x6c\x6c\x6f\x77\x43\x6f\x6e\x74\x65\x6e\x74\x41\x63\x63\x65\x73\x73\x28\x5a\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls2;
jmethodID &mid = mth16;
D2C_RESOLVE_METHOD(clz, mid, "android/webkit/WebSettings", "setAllowContentAccess", "(Z)V");
jvalue args[] = {{.z = (jboolean) v2}};
env->CallVoidMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
v5 = 0;
v5 = 0;
LOGD("90:invoke-virtual \x76\x34\x2c\x20\x76\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x53\x65\x74\x74\x69\x6e\x67\x73\x3b\x2d\x3e\x73\x65\x74\x41\x6c\x6c\x6f\x77\x46\x69\x6c\x65\x41\x63\x63\x65\x73\x73\x46\x72\x6f\x6d\x46\x69\x6c\x65\x55\x52\x4c\x73\x28\x5a\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls2;
jmethodID &mid = mth17;
D2C_RESOLVE_METHOD(clz, mid, "android/webkit/WebSettings", "setAllowFileAccessFromFileURLs", "(Z)V");
jvalue args[] = {{.z = (jboolean) v5}};
env->CallVoidMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("96:invoke-virtual \x76\x34\x2c\x20\x76\x30\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x53\x65\x74\x74\x69\x6e\x67\x73\x3b\x2d\x3e\x73\x65\x74\x41\x6c\x6c\x6f\x77\x55\x6e\x69\x76\x65\x72\x73\x61\x6c\x41\x63\x63\x65\x73\x73\x46\x72\x6f\x6d\x46\x69\x6c\x65\x55\x52\x4c\x73\x28\x5a\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls2;
jmethodID &mid = mth18;
D2C_RESOLVE_METHOD(clz, mid, "android/webkit/WebSettings", "setAllowUniversalAccessFromFileURLs", "(Z)V");
jvalue args[] = {{.z = (jboolean) v2}};
env->CallVoidMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("9c:invoke-virtual \x76\x34\x2c\x20\x76\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x53\x65\x74\x74\x69\x6e\x67\x73\x3b\x2d\x3e\x73\x65\x74\x42\x6c\x6f\x63\x6b\x4e\x65\x74\x77\x6f\x72\x6b\x49\x6d\x61\x67\x65\x28\x5a\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls2;
jmethodID &mid = mth19;
D2C_RESOLVE_METHOD(clz, mid, "android/webkit/WebSettings", "setBlockNetworkImage", "(Z)V");
jvalue args[] = {{.z = (jboolean) v5}};
env->CallVoidMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("a2:sget \x76\x34\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x6f\x73\x2f\x42\x75\x69\x6c\x64\x24\x56\x45\x52\x53\x49\x4f\x4e\x3b\x2d\x3e\x53\x44\x4b\x5f\x49\x4e\x54\x20\x49");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls4;
jfieldID &fld = fld0;
D2C_RESOLVE_STATIC_FIELD(clz, fld, "android/os/Build$VERSION", "SDK_INT", "I");
v8 = (jint) env->GetStaticIntField(clz,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
v5 = 21;
LOGD("aa:if-lt \x76\x34\x2c\x20\x76\x31\x2c\x20\x2b\x39");
if(v8 < v5) {
goto L6;
}
else {
goto L5;
}
L5:
LOGD("ae:invoke-static \x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x43\x6f\x6f\x6b\x69\x65\x4d\x61\x6e\x61\x67\x65\x72\x3b\x2d\x3e\x67\x65\x74\x49\x6e\x73\x74\x61\x6e\x63\x65\x28\x29\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x43\x6f\x6f\x6b\x69\x65\x4d\x61\x6e\x61\x67\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls5;
jmethodID &mid = mth20;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "android/webkit/CookieManager", "getInstance", "()Landroid/webkit/CookieManager;");
jvalue args[] = {};
v4 = (jobject) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("b4:move-result-object \x76\x34");
if (v0) {
LOGD("env->DeleteLocalRef(%p):v0", v0);
env->DeleteLocalRef(v0);
}
v0 = (jobject) v4;
LOGD("b6:invoke-virtual \x76\x34\x2c\x20\x76\x35\x2c\x20\x76\x30\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x43\x6f\x6f\x6b\x69\x65\x4d\x61\x6e\x61\x67\x65\x72\x3b\x2d\x3e\x73\x65\x74\x41\x63\x63\x65\x70\x74\x54\x68\x69\x72\x64\x50\x61\x72\x74\x79\x43\x6f\x6f\x6b\x69\x65\x73\x28\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x56\x69\x65\x77\x3b\x20\x5a\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls5;
jmethodID &mid = mth21;
D2C_RESOLVE_METHOD(clz, mid, "android/webkit/CookieManager", "setAcceptThirdPartyCookies", "(Landroid/webkit/WebView;Z)V");
jvalue args[] = {{.l = v1},{.z = (jboolean) v2}};
env->CallVoidMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L6:
LOGD("bc:invoke-static \x76\x35\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x2f\x77\x69\x64\x67\x65\x74\x2f\x65\x76\x65\x6e\x74\x2f\x75\x74\x69\x6c\x73\x2f\x49\x6e\x55\x74\x69\x6c\x73\x3b\x2d\x3e\x61\x28\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x65\x62\x6b\x69\x74\x2f\x57\x65\x62\x56\x69\x65\x77\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls6;
jmethodID &mid = mth22;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "io/pro/edge/widget/event/utils/InUtils", "a", "(Landroid/webkit/WebView;)V");
jvalue args[] = {{.l = v1}};
env->CallStaticVoidMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
return (jobject) v1;
EX_UnwindBlock: return NULL;
}
