#include "Dex2C.h"

/* Lio/pro/edgelivewallpaper/activity/SplashActivity;->onRequestPermissionsResult(I[Ljava/lang/String;[I)V */
extern "C" JNIEXPORT void JNICALL
Java_io_pro_edgelivewallpaper_activity_SplashActivity_onRequestPermissionsResult__I_3Ljava_lang_String_2_3I(JNIEnv *env, jobject thiz, jint p1, jarray p2, jarray p3){
jobject v0 = NULL;
jint v1;
jobject v2 = NULL;
jobject v3 = NULL;
jclass cls0 = NULL,cls1 = NULL;
jmethodID mth0 = NULL, mth1 = NULL;
v0 = (jobject)env->NewLocalRef(thiz);
v1 = (jint)p1;
v2 = (jobject)env->NewLocalRef(p2);
v3 = (jobject)env->NewLocalRef(p3);
L0:
LOGD("0:invoke-virtual \x76\x30\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x6c\x69\x76\x65\x77\x61\x6c\x6c\x70\x61\x70\x65\x72\x2f\x61\x63\x74\x69\x76\x69\x74\x79\x2f\x53\x70\x6c\x61\x73\x68\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x2d\x3e\x74\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jmethodID &mid = mth0;
D2C_RESOLVE_METHOD(clz, mid, "io/pro/edgelivewallpaper/activity/SplashActivity", "t", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("6:invoke-super \x76\x30\x2c\x20\x76\x31\x2c\x20\x76\x32\x2c\x20\x76\x33\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x78\x2f\x66\x72\x61\x67\x6d\x65\x6e\x74\x2f\x61\x70\x70\x2f\x46\x72\x61\x67\x6d\x65\x6e\x74\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x2d\x3e\x6f\x6e\x52\x65\x71\x75\x65\x73\x74\x50\x65\x72\x6d\x69\x73\x73\x69\x6f\x6e\x73\x52\x65\x73\x75\x6c\x74\x28\x49\x20\x5b\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x20\x5b\x49\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls1;
jmethodID &mid = mth1;
D2C_RESOLVE_METHOD(clz, mid, "androidx/fragment/app/FragmentActivity", "onRequestPermissionsResult", "(I[Ljava/lang/String;[I)V");
jvalue args[] = {{.i = v1},{.l = v2},{.l = v3}};
env->CallNonvirtualVoidMethodA(v0, clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
return;
EX_UnwindBlock: return;
}
