#include "Dex2C.h"

/* Lio/pro/edgelivewallpaper/application/MyApplication;->f()Lio/pro/edgelivewallpaper/application/MyApplication; */
extern "C" JNIEXPORT jobject JNICALL
Java_io_pro_edgelivewallpaper_application_MyApplication_f__(JNIEnv *env, jobject thiz){
jobject v0 = NULL;
jclass cls0 = NULL;
jfieldID fld0 = NULL;
L0:
LOGD("0:sget-object \x76\x30\x2c\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x6c\x69\x76\x65\x77\x61\x6c\x6c\x70\x61\x70\x65\x72\x2f\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x4d\x79\x41\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x3b\x2d\x3e\x64\x20\x4c\x69\x6f\x2f\x70\x72\x6f\x2f\x65\x64\x67\x65\x6c\x69\x76\x65\x77\x61\x6c\x6c\x70\x61\x70\x65\x72\x2f\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x4d\x79\x41\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v0) {
LOGD("env->DeleteLocalRef(%p):v0", v0);
env->DeleteLocalRef(v0);
}
jclass &clz = cls0;
jfieldID &fld = fld0;
D2C_RESOLVE_STATIC_FIELD(clz, fld, "io/pro/edgelivewallpaper/application/MyApplication", "d", "Lio/pro/edgelivewallpaper/application/MyApplication;");
v0 = (jobject) env->GetStaticObjectField(clz,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
return (jobject) v0;
EX_UnwindBlock: return NULL;
}
